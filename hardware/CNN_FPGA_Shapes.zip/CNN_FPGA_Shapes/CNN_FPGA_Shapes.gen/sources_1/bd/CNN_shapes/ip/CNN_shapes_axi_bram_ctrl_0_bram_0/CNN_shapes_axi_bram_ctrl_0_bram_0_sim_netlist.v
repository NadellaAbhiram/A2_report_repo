// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Tue Nov 17 14:24:08 2026
// Host        : Nadella running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/EmbeddedSystems_E26/Assignment2/CNN_FPGA_Shapes/CNN_FPGA_Shapes.gen/sources_1/bd/CNN_shapes/ip/CNN_shapes_axi_bram_ctrl_0_bram_0/CNN_shapes_axi_bram_ctrl_0_bram_0_sim_netlist.v
// Design      : CNN_shapes_axi_bram_ctrl_0_bram_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CNN_shapes_axi_bram_ctrl_0_bram_0,blk_mem_gen_v8_4_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_13,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module CNN_shapes_axi_bram_ctrl_0_bram_0
   (clka,
    rsta,
    ena,
    wea,
    addra,
    dina,
    douta,
    rsta_busy);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE BRAM_CTRL, READ_WRITE_MODE READ_WRITE, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA RST" *) input rsta;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [3:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [31:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [31:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;
  output rsta_busy;

  wire [31:0]addra;
  wire clka;
  wire [31:0]dina;
  wire [31:0]douta;
  wire ena;
  wire rsta;
  wire rsta_busy;
  wire [3:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [31:0]NLW_U0_doutb_UNCONNECTED;
  wire [31:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "32" *) 
  (* C_ADDRB_WIDTH = "32" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "8" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "0" *) 
  (* C_COUNT_36K_BRAM = "2" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "1" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "1" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     5.3746 mW" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "1" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "NONE" *) 
  (* C_INIT_FILE_NAME = "no_coe_file_loaded" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "0" *) 
  (* C_MEMORY_OPTIMIZATION = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "2048" *) 
  (* C_READ_DEPTH_B = "2048" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "32" *) 
  (* C_READ_WIDTH_B = "32" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "1" *) 
  (* C_USE_BYTE_WEA = "1" *) 
  (* C_USE_BYTE_WEB = "1" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "4" *) 
  (* C_WEB_WIDTH = "4" *) 
  (* C_WRITE_DEPTH_A = "2048" *) 
  (* C_WRITE_DEPTH_B = "2048" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "32" *) 
  (* C_WRITE_WIDTH_B = "32" *) 
  (* C_XDEVICEFAMILY = "zynq" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  CNN_shapes_axi_bram_ctrl_0_bram_0_blk_mem_gen_v8_4_13 U0
       (.addra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addra[12:2],1'b0,1'b0}),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[31:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[31:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(rsta),
        .rsta_busy(rsta_busy),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[31:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[31:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web({1'b0,1'b0,1'b0,1'b0}));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2026.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
kZgFhM2d/jlaPzxpf6XHBAvY3udA2n90sVrL5ios3dCU6DHMG01BptGv7AEkMGv1nBWc9wOv8Ao5
MO+RYUWfJloAgvE9oz3EJHrmhQHk1oDdQ/EpnejIRbEZCjmfHUEI21gyKS6oLdkyx2gHs3HX+wks
75MnE8jDP5XEe0wRk70=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CotVlRfEkpF8whBUKgocdcjhKyrcMEGPZvHkGVHISj+GCXwa3Gdeme07eFJpz/ZotBRm0H+nvk9U
c+cu76zAYcGZA4BB8k5S5CN9te+cdcMud4cLzxM3NWHdGuMLRnzIf+YH7ADhhyN/3GRT3GlBC9un
8gg46/rnawNHyJnmhY8sUwhYJFSC6Zp+YpCreJEMMsSSR0D4CM0VZx3eT8IWhFsOz6ekLOhifcRk
JdWdOdywGnTqpOq97/LmRPbfEGBiYB5YDEex+rP8S+WkdfZSRXRcMfIMDifCL2F9vyvALaXXU/HK
kczWE+R+OoMRMGX7ipHLpx7Q08Lk2uu9pJiE9Q==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
tZnJNN2Qmv8npxJcsUh1oNo5AcwWv4Go3b6+WqtB8cYERd3tAiuYpzM9E8x0/NSOgU2lO+XGGWqL
PXOFRGE6+vT9Uw+MMZ7IhiFhNUxakIUv/kmA/Kpo9+5Y8aWN581krtWN9KT8/ccdMg7//qZ5aT8D
c323EB+407vCn2c62Ug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
KKZGVVr56cxydgpa10+BIppw9vsPylE78OMiTW7WTk1ML6QnGGk6Ufm83Q5BYCGjf79wKt+EDVr2
Faz5O4p7NqDjYc+6UH+r3tYhzg8ax3QQ/lL0h4ROXjjznYZN4GT3jpmEVd5M9uz0VZRUklNggvzs
aHgFve9gt7F5cG1cwxr+CFWUfKcsH6XCTrNM3UP1/Ye33LxT6qzhZVuCb4w1zybXO9K1HZRARNeE
XmaMeB1MHLiswqCVSWCi3ahqMoTIL8Nkwb7LISvYxN88qxMca/sR/Y59W48DrGDRBBzZ48hIpVXK
9wpPb6wF5zA03FsVqRSc5JxQzfKhTSxAnXSVMA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ywVnQUL8hRlFZUGP9Kpsx7UfX2m6K2oMp1dIrzsl1e7ahG0jDMr0uZjciYiQvVpl++f7jBR3qTGo
/E63+MEs3aH3oSmrd0H/Etz+j2FU3ASZNwvS98uACXUBPzAeEwFUuJ9/8jqLJsiNybXigf8spDDy
xB/JnUfJl4/mmyClxySXyscK3aOnErzAZ9B9i8PeHPttmRn6onzR+wukt29Z0ETtVcyKKb9JQeO5
4ipDn79/o1IPYLzFyyiP5/oKUP/4zmX/6pbiO6bdzi2kdrhBtRE6ztlUGTI0WBHPOO+nZcIlF5S4
jckQo17l4fcqBJC8p6S7fb4eyfp+IU8PFj6wDQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GUQu/hEzrCx6whrKX9cnRKGYwu/EkGwKC+5ZIAahvY/upngQfvNVWyz4hLS5Q+jQdoupTTPWruY8
5QnccTfRLO/UNkPmbg8atB4asCjrKgLIhzPG1pqhoH9BtKKby74jLu4vyRH0Hk9XOXkAXLos7eBX
Nudw/vzxy74RzWXjstE5NRhMqfXi+jrP7VLV+NT9AN7PZQ8SsVifNwD2P2HwGzqQT/beYW8LvNbr
bRbtDAwcCcJomfkUvNb4pYE7MuJK22aox2ar8nUAviLnxnmy/ASVSGou0mCxgkZKW88UP70HDIhl
aueFj0IyK2H6IPJM9GCgGAwEeA0w0rzI7faPlg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YHSFaIRKyhIVU+ZO/EyZESP/nTM928AcWJGbKx6Nxkm8PEl7yBr3z8S8G0MbToKUpAO14Ei843y2
QSES26grec+g5bQHTjG1w5mR0gi3IRbGAT8ctIbI6qe8HxLmMViuDiYNb2JRHPBhpGjx1o9s0K53
1FVtSLcIMPdvZ6vGzYYlswxXiOA7D0qdnIFeJXb/6BzeYM/ZSO3kXFNYZVuhaNU0AcFxQzxAe/sK
lx5QdNGpyfexd+UnTCdHIul+eFr91+gTUaOVHDR7qvAiX+c3k+nbn4d1gBOExbPG5xXxO9QzpWZH
pkGcv5/2mmPVGGa6bx1rd+/wxxqJYs2r4GBQhQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
SuOFRD2tIt83R5vOz6fwY9Uj1WJom9jlw00FrgpAa9zzHh8NDaN1pvHliEpw0RI/EXGai+RqFTtv
ODI2Qchq2R+Ohalo8v9B//WzHrQEoZOqY8ExEpKNbhp2IJiwsZKz4enjUze+QgFiZFFBQSuEtvRx
6PvI0tTjXp4d4nJZP6HbKHFzj2SEggoTEvkYm2QqrEIRu3HQ9cXOaM9B77eWbQvHHj8yGYRw4A5u
Grwq5j0VzH8/eaysSLlB32jy65hpz1XiigFMnu01jNTA/Fh2qkMYpJeiiityiftiHDGBeEi78AUU
DCNlSbHo0NgXbyxwgV82OqxM0bTJUXK6Gh6/8xgla6TEAub1vTzQH5Uche+S6QnV24o6ll5HwYyV
RoBr27Aj0mceN3MNqSTnsoEMthFh1MLmp0imxgG/6NjNFKABJTDuaGPLE9XjU59knvKP1VKk9Fp5
rI7Y3IvGFhu0bHKEhV60LLTosXWr9gzS3uKCMCb0T38cAx5GX6FcChb0

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
WC3gV9hDsJlJGDWXD9/OXXBzEn6vsr7+oOdKz7gm4Rk/FFR50y93jhYmcWd1K2InGg42AOhIHo2Z
TvhSjky9Smc6kaftDv0qbAD/y3awUgVWMhvanfJnlEuAZfoFEJGwGr9jYg55AvfvuX1rQTtKoUFi
ACZ7pJVaLnkCKFVPNuhRAQxCs7KLW7cG1ALcdtOdnRrcG3bh4dHzct2JzL2/VK03C8gPKr3uM6DE
9O0lltoTf/AzP3jfV2LZekZChJx+UY4WWMhnVCiQKoa9voReSAKbrxHl/hqJvWQiYa6CFpABdUpX
fjEHVkVIdpnVpslTz0sOxXMvpxX7F8T6O5KvOA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Iqc6J3NDm5J0Ukvjev1H/S4Q4RmJahnBq0A8nClyXeu33t4xanh+aGq3+WcR0KQRtSZvQDrbXWvy
VpRaHzQu/lgwraB5780gv5qhqt1D3uYyerl5fx6fl2ozWlr8yZKs/qaDlktEWGF0MPUsJuYE6ZcM
72yOpO5/ynMUgwJs9FVcK5pRasgkXgOUeN1tA6mmLAiYCor4CtxoB2CGVa0z1Xsrai6cNrXCDd8I
D1f10kYi4ICIsU7uhC3hLMQ66OSpgzGDdHUq52hVB7ESc7B/fk4nrcm0mSK0cPc0un7O8vvvykdb
kA7qDovHJqWd0VWle0m3J0DvA2pKJUU4AmG51A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Y+N5GKAwdOuN9nS/lU52Y4ZNhFpP5Eg6jiLvP1rQk7jt7v332HLd3dDgIcKOvTZ+cT2qc/fEH3km
qRW6R6MDwiTEv5NDgR96180FbWhHKmyQ/AZmvgAhcSnKARj27eDEkTFcUfN+RgRNycooCPjQ2LvE
RAHSYS+ob7G8GxymUfgoG2pJ1BZF8n98Yv+Aj+fx3pPWyFx63XYQu0VIla5KV1WkhDxakW9v4pJh
kWzHMGwdhrs9q2KAQjFgZaDXVv5oFd/wcJWXkvkbsRdm3Ok9s3OwuaW9LsKnBGReVg6ii5BR+7Za
9w0kFZHcWjmf5ns8L/rFEzHcIGqE15ZlLKYekg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 53008)
`pragma protect data_block
q2BvYyDvtb6vn/tXUb+jiUYqIQFv0ZqkynONNScg6srQs2vkHnQWtfHCO9FUZVy1GC3OJ5jtCy7r
impkY/sgECM6j8DvVxeqX2dDZEq4J/DR5DZ9rF3fsMAXQtOyJLaG2xxuD95t/6j7y736n9AgAGgB
dGZvU5u125QsPOEa3l5XtEcFjVH8mD0E8JOOn5bLTqSPQLmX5+Qctu/0nB1tqTC122yM2Biq6s6e
ax5prnvgzxXEi0yqZuo1tJZxkC2DpLWQuCZ3Kaq3ENoi0LKj9eJMYs745klCQBo+GtDuZyoCyvVQ
dOz3IZdMKr68vLziH51N8q1nJKE4ehor23BiIC/pWKbn2pnjJde6GDCnp9Ee2TrJ6EOg+cV867k+
BcAiJlChmXVt/M0jsHjOM5pUjPDLZ/OORsxaRQ+DkU2fqkbv762FkyQiQfcnAxK+1TYgSnLZSGKN
UStM30/lqEmztRV6AnlL+Ra7Wa48hDV3GOzESWT/Mu3km2y91KymKdrTTcz5PUh6SQnbcKeMXvzd
qtTPJBqFsqxOIGPkGggZmjTzblcR7UOh29kK0p0DejXKX07UOEBYYZFbRK0cuTbLtG6gBLiobvdO
8kEfOJzsBInsAbLtQTFQfpI8M7yGlX7v/1/U7ADJr3uq3z47jDt34TXrgjBZTLWUUFDc99gkVuuH
bawe3OBN6x02U9Kw1L0R+07LAnTqvfDozog4FKnuh7ZjyFZ7KuEHSceaxhsX9shnKCiz3hRQXeKG
kVo0zrktvmmNOZMTPYWPikXCVAiM3G6BK1DLTla0FlHsGUUiPuPu6+WvzjdXVAh7HVrYnIY8+QLd
1EOLrbFyqce/3+K6f3kDjorcusU2sJMw8z6L/tmvLo3KfVdyCytbH7plL+PslkhmyToOKVRO3u55
aH+FRqjjbPsmb+uv7rOh9L8Gk8a04d79fWwPbGQ9nX4mSrHdVq+MhOFkhwO4iP2IW023sF9kFCU3
8sR3CG2oZfskIg23DkiTtXCB3gPqY0QPF6qVdRlVvLiY3qNbFqcXahtTkJgf+OBIjkn6SIeNEU58
liUc+VKSL3EmE8JfpKF/1dOpU2l6b98BAxmIFBblz+RCSRu+VLuFn27vf7/B3rCxabf5aFHUl56Y
4dk4dNKZzupxwt4UMWCcvSa+GgxSjvN7YFsQdP1B/+M5EBCr92cGL/zSTGB0FtQfs/Y1mH6FUo3k
CQTXaDU6zUlSypYy747jiYRt3sYU0MF+DFKqxG08eKxOp6Li+RAErs4v4Ow/RYbjKHShzlxKTdNv
SWvIr6FUtk6fjEejqGPCt38qBZYNL0iB0vCygljTvz0mPjdNDx1objgvPegpb1baAUG1m1IjKg2s
tWeTQ4NFEKpaEsvgj0FPzfVzjqQcJtZd9YVI76WSX5bn+P6h9ahf1xqMMWkEC9VLGq/qOexIkwNy
7vzv23vr+dDHE0TwQiRIYH60CD9pLfGHdMD6jYHd4+CHizUBqGGvayc8sA8hPFzgkbJMglcRiYzz
0026mSQoHuHkzelO9PFOFZmWYALeBtXJhbno4i1ntSk1qPnS6rdVIpIIVFMUtVlIekptIzOKlCfu
dqX2IkQY6kNWR+ORXwi1Kxtuc3XI1CHhYQK6jhXSV7BZE4tGz+qX+yBkusehePeXTmzzotuaCFze
HtyIQoY9HG8WIeJrgnulIU/8zMkc3CUb4Gcq1TZVW+r5crlWftwIPnhv5ktM/Jg1bN7wPowGct5z
Cx/jdbJ9J2Uoj/F2FSfcl+ITT2eOXI5qEAEgMt666lR2yPYCEi19h/ik3MpTYRC7SdDs2Zbq8SeJ
/MOUp3bF985mHMCXoBLRa8sTr9hIEOfp0tPGQrIsYuGsqeBS6fmX7MtZKCdnB8vYwfXRIwtqbtJo
uMXc3bEWTXCuUQptOSBnG8CUcv/HmogTs0msSTTZeiIJno0NtPYjlB+Y8kso7wMsMftf+TWXlYxd
yVkYLph1IVEm6urjRWfJkoDN26QBKft2mdIB2WhIUlJEmRZ7K5Xuop91LFhL0u5oALqSJPXP8OPo
rFKfI+g+QXTgpGzf6d7grRgoPduLR0OdXZgfizvCHx6/sXX1XVf3SamCA3R8kt0R/Ml9Pe1zFvoT
4BVRvSLP0aOOtX0WxtGIG1f6MahCKXbsG0QVKyMDdtT8BTUmd6hoskuVqhitdBf88iWwzbISzGyA
PDP5EpHavUDrPQyEJ8G/k8WD4lhqRwtDr5zfFirnZXpEfwlo/qnjjS+I6otg0HeA8TGxdAn+0RVA
fwpqYMqtXf9GTjDWkm2WKNipDhM5NhWhB2rdsHbnxr5zn/d86MaCJQeJJ5A+UhdO4JD0WPHMAzx8
1vGtf9JwcQ8uMUZrddk49WxEa4RW6ycYE/Lyq9a7GseKbLgD7AdAZN3x/AvKU8Y+zKHksi/R36HL
07d2U/6nv13N8doy6OVHYriCXjZ/37azZ9WHukuQ3VE/Iw9pTDJOXsadigz3K+2/LNtMeR7NwMHO
0WzNKDcCxWQxRsPNJGKzwmwlPcQNgIeAQTMBq6RmppvfMRjY+e/+IdTKJoucpUXLRhCv7ClSgFQs
AabP3JHNr7YKrsniK5zGqLoPkpwTlgnS6YiL8YlF9fj1mslLw8bkolb9ea9EVLQoxcH3ONLJ6SnH
crZTffmdv7xdzTD8K614v8qjxUCQUVCVCuag5xR3olNl1hf2DsGhEA1XUN8czD45W1C5TqszfS+s
45uuiVqHSTenywmKNG7JwGqGnwl/Vi4gdiuFoiRKgxGavkLvaDGeyfi9bLlD4aFELWkXEmL+PktA
lZbbzcjHorCmJZLFWBg0XvNc8Z7fE538KbJEb5BDDbx2ASJJZzfiA+IOHaefLTKGJBl54G9oYiEx
0f06FoFK28dbg/MLWbGrXA6JL5eK8l2stVWYiTW6JNVkJXn+626Fdv1j0s8M4QTt8MwyR7mpw7Jl
/7QJXAlmy7dsS2K+J6v61Xq3qI96HJariwV5UdVJ/+f6z8DLM/gGIOQQXvD47Z0KugRnulmGKuf6
JhkYwruYcqT5XIl1L3S5R8bJk4LqEgIemJO3PQV8no8LFUWn6Z/wcNlPQn4/9DVyDblWrxFfTfK7
Jkxtp5MLi10J0OcMyLSOFM2iqbX3OFhBd3emfJOOND7yN0rsRpZffxPXwoXCLhMf0pexwhY+cOfl
P7kMudiRA5dcPHmWtWJmXRAZP0jw4rHSGYwRiVeso7Ta/6TJjPRnui9Oj/hzR5aSEz1WQavo8jKs
uVITo5t5dmqYgiy8n0c01x1vF/+pEBr84/5umPyN6UK86ANj5p2YRcxWzvfEgsdyh3hZvS5kwzTE
degBwYTMyLEkH/yyH2dayX70lNrm3WnJhfzYjNkrac4F6GdOcoZLis9ZqTVF3scz3FKSSkubnZ+z
8MyTsQnIhPpSnTPJj0fkv3ofA3ylwYLp2arfFU4SZ1dg+gRza3xSrk+/iyFnUllxVTK+CtnVUIPn
JqeKq8ReY6AhhpXu/4lZeOQ5sURZh079jMQJoOzeeucz0iPbIN3nOqGPSh6cbQ90qFgZlh+m8T+H
sGRJ1uuzi3viby0GPoxGGH7B356t0UWC5vogeqVClk4lzP5F9T4lZ1/Cf03YkTl4L0dDmGz7z/ZG
Nwf7N79blFTwEEXd1srkxlESJzGQ1DN94OpWwxQrEz3k3vXz6sFrB4WxFCiAVALt6JeclhL8eCLO
EgijX1uxtAmhP7GfWZYKJ2vJ6zrpPBFCl9Kmbv21TxxyKnhh2afKIwYaB9rspPFvHhBd/JATPHUR
BvAsV16hBShZO4QDnkHdR0pz8IM6Hsx3Yx1GkgQ9uql0Y9NGgeX65LZXg8+v8vuW/1MMNf3naGDy
LsncQxOt8x1oZQTpoLeh9OQWU3+UeZ5xvKyN4psnkeRUAyC6tUjATrB3shf8Wr2yTNetYhkSt9l/
J0OwJbk+bJCU9NM+bfVjRQU+JzaRmzfmJoqzb7SE69/DS1O5G7swL0GgD24y2WuXI4OGh0+DE8v2
dgoS8B/fpL4oC6WIehq/4U2hQQQSz0DQAQliH4Eh5jDOgswFQ0n08kfPGyd8aq8sqIt50TAui9PH
LH2OMGdop0ftzVo+pKoAusQtJHy4mnoD4nKajytBYtH7GAoVh6Bl6YyJ+UUc+ZVtR2ajkTryzjtS
vWj6qFZymReA8ct9Ce3L2Lxydn+M90H0V8M3Iq5HthgOgJXs0fIJwAPMK6qlSbGaRdXggWct3aP9
cNMqez08RHdUGBI58XwMsTE9ioz8DNL/FlWCOfbw3vhO30VOy/p2k+p66QExN3k+MaNYyWsfDWZm
UvLf+qUvkmwWo4c85l4jUShXwRtg0KUNSL7k0iPjwqVB2uoBEX6lwQO2x9xRCvc4ZhGmpMae+ANP
z/2dBEBpnHyKSNMOK210RS6bvWmOFvwgUlKlAXlCMMGHTuC9o1s63iT4nYg1ybx3AOYMXHMIEksg
ucrrAutHlOMdwrflIrF5gPN/8itD5oW/j3n43DRtAI/xSXuhZMWZlXF/CUet9RwQMZKRW7yqjdXD
cZwDjpqk975wYY30EWBOnWJ0vgSndjKJPf/uv3xsVflW+JPaJNrKkanNCfODCu5vlvs3uVzfz6PV
uGGraXbOkwANsKhfeDmBGzZXEU0lVQkCZRIP2XatkqatL71F7wt09bk3KjyipKSs25smIRa9gMbs
5J1WVm5GGax8Xbh8ZWgPzupiN1sXSq3eUttf5oaZU7QlRJyjrh2U7HaFKVeK6Ul3WFZXtczfWqZt
uk4/BUh/D7aAxBa3VcuJelN65Qyc287Fn6Is/ShvjQ0Ay8Zmqzd4MYu73zm6HLUKq8EAgkn0WHHk
oEa3WXAxhLti/o55790XeAxxRotlspAdZhy2vS7ok3W7cQ8S+LW2eCskG5WCyxDlfbv7sfrzE7LT
/CbwFTcwn74B8yigIKfU7qwx0IToDWTIlg0h1zR150v6Y13vGlLhhzyzQnst7hP9njrXCSJ0k4MG
BhKGFSAqEl+EP6UBsN/K/4lEzqYmlvJcUlWBLFQieVR1djt+ez8pL6cZW/2LGbCutU5HmTBFAPJU
ZgK2DcK+eWoshkDadcInV0dXVO7QPYQlsYtf7C2x5JvXTja2fHVaki+tDXY+3FztcKpbpOm4e89U
Pi3Guj0T1HOKiVR8YfO4KtwJv65a+N2EmiEk0rVBQS98jXYkFXjxw/kFtBLwtqMnV16zM+COERZA
EHteiLTzHtl8JVW/Zr9Es8yp5rAaqbr6s1wmkbUVQBe1NANlfblX+pWM9vx2IQHv1SUK6+Gclyo/
9YzKTQZnWMsVpjlm4c8U0GUlVhjTfZ2NQT+NZp8R+zvRGKKx/hIq2eqAfPmR925gkjs5qRHqi+of
hyfZ1FfRSOQze4QpuGvhtiUowJ0LccrMb1Gu3PlrNbf8ngJCD797ozRPLJJ0HMW0NVyxzVaCj8rC
bNkkX0F9PdbP+iLDgu0nnJ3G2ls4PWJU56xMXKTfkZ7bZ39zhHonliPWzp1YPoKPOMFXCUH21Cvq
hKOIwYVIBUamK8k2pHjFttXhoCmMFYHfinHBOQya7XH3e9DO+NsinUQL0ECBsk1i91oQnxob1KcR
gG39OtEbUyA31HBqknwpJ7gzJ2ECHtWEN1xVeeYD4ZBwITvAfcvdwWCRolCEROEcJbp3MDjka/i5
tG0sJByU+6Efh80cNW+qMIAPo3UzUJ+WBve9lMtgIux/iscsC5xvV9mlrPDQq44199loca4YB6Ey
ziuuZBBILn+Rk9BHlvfaRyhjriihaVJ5x28E3nX4+yPGsOTo9Ivml0mzwk0hK4lV2OkHm2rsiD8o
sEZPLbPsC/vAnHtCCNRhVgx3seOqAjOpYa0/ppO3j2WU1KmLaPgj6nVxbrnDXZFeogJn7pg1/xFS
TEMPcGs7fGKxVEhzuJHF1QeTGIzrafwv6xFmcBSYxq+S7DFjmkCffbnvBY+DU6ggLd+4MoMml2jV
T2Mv7VJFrSJun9kVtxPdAIWn2yDD8dit+YRcX1Iy58a1qNY7bPKUDclfWF3hALarDEqdx/9v82HE
Zs1XQv+sQQ+/n/Jc36TeN2EBgAINH06KsQbp4qRm0gV5g5tP4OaJSLWC8CVjvlBEvrms1ufAA0g8
8xZL5JFSC3zv47RS3iFGqvlNO29tLCncHYjQhfM6zFAhv/AG/mUtCMSdfyjd4iP2n9LEfMy3wNPd
C9YmQucTitYgOHX7YVmfFAFBhCbrOuD27NH+WwYl1QQm+O5ocBVpQeh2p1i+4qW+sXTEAaj1Ul7J
4zOC5DaawXmvXViSHeAeGW8ODNG1obMspkm0QY2D2J/HESER0VF8WMHqidKj4+VxE78R/5c1KOrq
a/CEflDa6gcoYXPJzJCRR+3vcG7HVPUPkQI43HcCYE4S+lG1GxG6a4YgKOR3I3nEAURlOg6C1KC1
thsR4c2nG15UyvSdDrVz1eN8WwwmaObbM2bR85G2T40uYpLZgNC+6Hx3C71kUlFyBqczh55EJtT7
3UglZ+pKCc7LnG5FFn/9Q9mTip/PQ8ZsJ4ERKGHl3HY8y43Q2MlNvQ5z4B+kthRAyARfgehB7gP2
HPvocZuWJsnqz3cmPqxvTjTsiQ5wfYcrPuel7FR/3AByOSNRG7WIWG3Q1X9G0mvV16f2rqkZV3Xu
TRwmaNbUZ9MyPvPWnbU112pZcCEx7xjSuksmN/hmtaqrb2/yBA97KoqP1Zb4ltuDa+0ijOuvc2FN
uSBQscclizQ5otF9eRM0P/JS/BFdvuf/s7vZw0HoOkg1LTaNUCiSugPexgLGB43n9t9gMKNpmFGh
vPyFDEO7KZMTrU6fap+cT2einhIOlgJW4J06d3n9E/HxQvsWaM3xwuNQ46EFERJX/wvmICfy0MLQ
dCmDaaLY/XD8aYq4XlmMtQR+x3JlUDYTw0p+YdjgCXAL1CtL8yY8P20DZflOPB3CMAUaqHQcfrKb
6EstclWMvvrnuRXXvEJOYNBM61qPkOYXyhXqCBhxSFvHmNmLb8Ln+S5arXMNhjkpZwqNGbbEJkr5
65ngvoUMKUcUB9kowUxL/WLuskcp7Q3mRMvGqU07ykbBvkSOolrBDDyvWRI/8dQFsVFnn/3kG8JX
386kIkggsjUwLuyaM3fOPPVPh3vp9zEzgopd4NGO141QZWbxr8wpNVktgXz1tXG3ZkpY3tJ+ujl/
DiQj/mkBfQNBimVLP4mPd4CbJUvIL0uYALTvVlK0bfvJdADckc+4PghjKkz+7dnlJCZU+z/CZN4e
LKJOFjyz58oPClOpzUpX81B2erJhJWHa2OcgmeuTitF0r1Qsrr8a1QSvefLeq0/qWIVqOTwrICLp
XM3GYeGUCA+OwXdRSRaMqrBJoBfRQtvQpRa7779+eG0jIG4rclcPVk3OAxfWX4x1cOgH9CEsD++G
JU/ReA/Nt0xi9BEpPyCdNUGew4pLSDByqO+J+UOv6/Eqg425ji3NBeAIBGG8ODAAf8Z86hWru1X8
dE4IJXf9235i8tg7v/Tq2aERV4KYCrBLNkA3qN2Y1X0qN74xN1yh52IT0LUb6ed4okh1l/btbPfj
J8nx2nkBmMe+aki0Cr67VNEQLn/oJeDrNBpgbpE4QH9r1DVOLb8Vn6OVcvvOd5CLZEKwmRGjathI
OwQCSBpYlRq4uJnHU/slcVCz6c3GGb3Vl1W0mjzuYvCJ+DNQyTFhqUM/4+HytBcBmqH0uUTdaTkY
WBv/7qofKe/Xr+bhj3nDUym5I2FE7tZ7+4WwcD64tQGYlLEjk69OjSlGZtqOCyhVzL22aIgYEb0z
r3906a+2nJk8O7MUmCsSby2zFRb3BE9CxKMuCm2BY8UjIR5Nqlmbb/ojATZ1r7cE+5GcTpjXUq1J
x4fbWMJNg/ToHxJJ+vg95CvyAiXFiL2NHAtW3Se1iUTjZ3w/OvRV8ouowidEVZQPju9Nnkqon1Wd
JGOYuCDoLnfJGc4bAtD1I5Q/TpbX5Wyn1iDUATbQIttNasmskPsJ703g9aDTIaV0awA7lueljX7J
VJubVP9sHlBxJMSpYNRjMEtwAsHeVcZnxgW2kv/8bMUoxRlIwnGOrezaOY7YGeNVni+DeQ0z1s3w
BSz3KZqVG8B9QFfsVz0hcaCCWugR1Pu+QeZTp/2lld87SUZhbxo12smlT95f5nUKhho0B6RL+jTN
qysF/qXJBUljtww50OJusZ7NxSgyCfdvGKPDdrsPx1CZW8I09k7Vi76cgAHeeqhvN1LJ6B4LW/An
kDFFKzMIdQcAgrd0626Xl+CJjTQjxatYFkxilMbLawc78qhiwo9/6026j3QEktEv2oSbRGdaE5xI
G9wfddl5O+gAuoGAtiQlLb4UYfAMf7Vhts7LKk8Y8WXGLv4oVUw+GDlWgdW82eaFwLbhH/5tWdzg
HShGUZyc2CPwMriBSyxz0/UoMS0S9dLhPSVYbIU/iW0F0LnRchDGksLQdFLaPhoCq3mByVeDqL5L
D5QLEugALSW2UAr6w20JTaAJ5whst5QWATWheKway7qF0KLXpSgY9GCB3mDdjZNXCMYE2DCVACAc
SMiF4Igk16ESsS9//muNxC+n99ZbxsFLv+nIYXt5W5nDSgRfxSJMljfGZizTMXFrCgSxZCkjERSF
BVuLyIcgcBtBsX+qUfRjSpnkO4QkFZwGaK/kqpXeNCtXfmSRteryhF4Ibbsh76Jr8+9zJmPsUILA
x2efVaHFr2ocywrWISuLS5sVMLT89nHolypkX48S2Pey0r8+UFg/oHjciWYW+jRS/M+DgEwLz2vB
ali49UAwZj68sbN4k1dpu4e4AhklCBglWD+5urpIy6L4eY09uF4yjiPVuUa2+bewnP7jD79jP1F8
H/0FXd4IlO+gjGhxBnGE96z31+N3nyS+HM7P++QAHPs+Cjg+uDFDf5OpqxHENHXjpU+Qv4EokoJC
XdWe5UBTS/lYeJuxGrSpe9CSFBAZMXTxYBsxtBtya/m7j+eFyktp9v8lU2Dg/ThkV79aQgbYQLFv
zPS6KC+9nBPV1/4U/1ZH3pU0cznMxTrkNHFw2eyrfQoUmd3xY5MwYU5wSXMXdan0vNUOZJmirBCk
yDSSDw5fLg9M7KW3A9UBr7yuJSjfFRQ2KTzKoDtyKBY7Nnl4Vhe+FHthmuudnAiXofoVVXh9bYXH
fqMIIbpEIcr3Z0hC0zlg9OVbYfhCtOV3SiUfyxuf79N+l1OVZJ/BSKBWiKYxz4839dsHQt7LYjXG
qmw9AVp2owAIP++iD11sINuF+zfnPbXUSVI0XHUu3ljpBSYhX7A1vnqjqwlWrELnHot7bVKjIGfC
W5L0I8uTtWnqnA8vXpmooGCYDGsws4miNSYdM4S5xGljvnEGrJ57gyW3oUQN5nLl/F5lAH5NZovQ
BtBwZcyTJdjzHu5vObwW47zhzUow+pWkliNlT0OcBKPmdM1uylqKxldCNnKyYWyAubHAej80gF+X
2igS05/uJ+kZyxXIKWeNLr71DrOY+DzKZ6qelQp485rF4yDrbjx2IDGkt8gliHkz0CxnE/+OSR7+
L7QCv5RPi2UHdD0VfJ6hfZci9Gcj1tHoGvvx9NllT/3mLZPVwLThzNSy+lYz9ev2l+A6DHh4LsES
dUs5mCOdZAKdd2p4hpHznqBPI6onaoxV8MSi5Isv2FfcPat0jMC0piRurdnWhqxh5It5dm+uRYAf
OFWdXB/2dRb7CCk7J70wPKEQCdl3K+Izu3yk5Wk9xBVdFJmOMeXq1DTK3ZlVvGECbNGBpv262/mc
1TaSdU9mMJ4zHvezNNCM64Pu7OKH32RUfZ9EN0Ex4sAYlu8L2CDrP5CL+9Ufr5SX75kgIE9llGK7
Ousocx6XSnRGDDyxKSKX5fMXWzfzCr5H/j0quSyU6b8A8lfZfzxwYMyWcy3RbN+M8J8YJpK0k6ny
VECHfoJVKR/M8Lab0gsLawKiR4YbwZDIIkqGGowGTmeZuwL8ScZlpceQBHDEFVC56CAqmGBQuy/h
7WMNYNPDZEHVl4/o0uPTNyqFWWJAz1ym4b5/LNG+zJG34jGrne8QwmqXUkUP7+hxz25LQKHz8KEs
Dh6lOvxULmJUv1tO11lCXK4Q/MdVec8vaHp/nNU88jU4kgvSZkWlB9jP1OmbbY44mdxe4iawPbcB
iwRtlYb1jaeKev3IegPjMqNWvgVWYTesGT04tjvMc3807IrdQinHpnfp4edq/h4C2KII5Wqo+4OH
7f4moB7sabmzweEOeUy+aTtd8y9NlMDhaFirqaJnFErFfoRACEx5v2DjVvBO5cYiGRmR/8pTLVgc
1HGY/e0McfhhaOeMDDlMIb4QqqX2Y7Nwo58xVtDgrDOu1GsdiFpX+WXr/0TdixqbQYhXvWS5FU8M
QzBKHmqq3A7RuiZFrMhBxwrUxnEZtYAcIjlegh0zas7ruroztaJEC4DiyJRku1y3ehdyEs6YQSb4
zUuNEXrGVRyMS66Z7NOZuK4cVNgcI84erJHlXaOPhrDlq17FklJn5kEACqZsVFtS5zGIZjbBKXuv
97qKGo6OCGf1ztihlfj1DXWkP174hIkD22Gy0oD2F2K66uQO0q84wamYNU3p4ga41CjeRJP35ROA
ISX5fhd6PLKPlp7agrIayq0Dy0GMwPteCVFo037V4wgbraBS5Ax5Xm5csrE9eKXK41jhvucyKSCq
Wd46U7E5OBV1KwbQLdT3+Kc7xSjXiwl/n95HapHmRiiowlByCtFStin4xjGoECGOcB8lNa3POlOL
k1o+/WKak2bajHRAohRX47qyXibEKYMpzH+RWPAKBeF1mOgRQvfa9RDNEYrW4kKW24Cn+fwawvyB
gqWNMTGsJpFctGBF5zRPQohPisRTBRSpMrMgINGASgwfZ5OtIr4Jq5LKej9a7KkmsaD1g3nQ8jZs
3s59H4TLzQR8t5GJvqcD39bHb14O0JEqnORSO2QAxF2cmkGUQTuwdseq4cuJsIZshOCR/bfv43Oz
hAvJMxS0FDimCWcrQYrpQuw1Z5KG0B5ptIHplCtasZhCv1XCeqd4xmGQ9auqiHA8tvD9wy0/pDVQ
2Q20j0v+wISHooRuoGsa0EYAy+kqAGGId4pQ5sNGVh16ljR1gJ0MZvJw3R5Yhl45S8/TUOUXtBbh
4urXvij1cEKQUBaEPDiky+lNUWz38dJfgtwbvtO4VS/XVqSkBusLUzni50p/3Dbrjx0wywWA2Q0R
37PTDg+cIqm4U7ZGW6FBnuEN7CO3kLYCcPHSNYxC/GRegEzkdSYsU5eQPN6cCShV2mQ/6t0P/of1
CXVBECFN7LtlMrgh+ThfWtuie7CMlKlez0jKvH1+DnnowGl+eFCb8CZCXvory8JxwY2zZDUMfEkI
JeF/L+DNVnV6eF0bPtMWWjTNvPsAopyTujUtPLdkRgGsK/rL89jFd9JthHQS2YC5uZvOvFK52wOz
9dUbULEObKoYsetaLEXZvQKKbyJZwkuxSA+bWMsbWljPLvRRb87a6I9IDovCBpKM9met0NS0PNuf
WdpHSwqlzm37TgpxJdvRnB2AKRXLQx1V/M18Rst4sZvDoZevkH8vD4mc+9sbUb9AHAI+5vyybRpy
uFfbU3T2kl/ub+GyI5in99OOq5OgnS9GTosDggU10bDBvVoI1yDeMuurNdpAIG8eOfwHaJ8Kl/uO
ts/e96hrEK/7UI2ox47Kru+9wdQjiyQb/co8RfFWHwOe+jP2r1kyIc9uUWXkaEm7mtfhobhYxTeL
yxhHBJiMLZW/tv9ygiXpIgALU8s+eppsjwdlP1iUaGYHYo7AWlvS1hV+9AirGf1+dEyql6+DZOSM
DNJfqtTd1+FfB1OI+w6+3t4vlmk+AhLtA4jjkuYYg1JI/jiuVsEsiHhu7Oq9gm1xk05X4W6Xm0TU
ZucrlYocQypn9RCa0NLL41/RkQtdTbnPHHp+gnFpVRkWbO2AQl+/clmo1gjL8YIA0f+WinPsq2NI
2PfZQnXd3rSNmaKwllIPWIS5/Qane2qD9uix2i70W5Xj7nuJSihdaQC8UJ2gM20pCTEfKpSsevcS
zzwYe6Zocs4TN6Qsq57wuHjTYa1kYeSm4Ae1QXL5Zyw37wHFPQlQZkS6V8vyDvHYA1Lv2g1Bt8lX
Za50h0xd35E87SwM30Gr1XGXEEsNUYvj8rqTlcCOUXVH/1LLGllB0l27K33eLKix3xgljwITiOxn
EktmNMRCYaZruKCvGhbCTSUh2H5FjQEsaYWR8BrRsu6ganIaPtiBuHWHbG1BeztVGv+SqKokGjMK
sC5W2KEljiZcPe645uxt3k+hns6qKX1+CcXQbS65li676KdYROrK3pniikxJjvZr+vusmDpHFABm
zeOdVlWBxsc6QUCN/IHilUleubMgLHxJ3PLScCJuYSVmJnFnGEmzUs7iaf19isWJA8aymlZUD5Dk
2gbuxfsxr+9kRd1htMNyJ6aWq1UWHQd2fIJe26tgGDEghKmY65DCz+cpDwWwgspFk1I96ihHuoPO
GUjbjb2ih3Z0gpREfjhUGXBXQ4eB7ADgH5WgX34pMCWAPUnwhC2g7arqEJaQi2SNGOdbEgHrp0tE
76zd5is+kR4TIJaxvdePyXZgo6VJxgnWEVpsPclFQ+mx5mNHKYfOj5zXjNwR+3WqEVpHot6miz9R
HTZ+01SnYb29FJAWU/T/wCoNrKfmgVXRjM9h0NF1e0leyeiP1WhiBvxg8ULnLOECayqjjTB3lDeG
IL0DWtRN0+AI8+VXgNaHBvhRmgQ9rVCAkjPxE2ZlTTjY1l39QRS5SMqmnWPqRm5awvhXlcjBDcUy
VUgf4nGY7bJeglPcPV020sQwfXLpzd8XFP4kK4TUkMmDVgNeEqJ95sDVfhKYU/pr1i+dt6XFkArT
6WXDa42swHJHyznjXX3HPnp7CvNNMue18p7olzoE4qlN2MgYFTOfeh9KXa3DfpUD4UNo1pYXRpu1
Nv6yTqEQGpXTDM/RkLb+4b0kwS2lPeng0U0QK8irhF71fPha8sALqaN/XnkB/IiPXGTZqDi3ioW9
tVQL6GASoT6drMlbZcF+vR6bBTVuLLa2w1xVPtqrE3YvrUlBfOx1RDkVpmsyHIOMqjyJnrunkenY
esJG1bo6RglmckXpDKO+Kmg2aCQsn4/tOUDjF4ZupuKicMIYAqTHrLFpjrD0CiJotGzuUwHodi4N
i75KXVfGNB0rslvv4sXJ9qRHPB2tIPDkk+fvXi8T2MON3Mi7zJNKZPdai5CtiOF5zXHIWzWOfKpD
7V+Gt1VJPoRYyX4rOsJE997Y8qfhqtQpUrBoIZN912zsFJU8+hN+mGjNEp5tRSZ05Hei8rwC3CUH
fM1rJEwSy3ZbNXA5ICu2lXHEQmXnuB9owOP0RDER8oX9Q7fZncjbZNcardh20Mb2lQ3XjlLJKSG/
mZDveng0U5UjdBJTNt9Urq62hW9Y5eFWwXWP0Olb9jIqT0AL/q31IaLTLawUrX7qNPZwqGKCJivg
bw2Ef+hkD0+JmD0sb2JxjmUKYOoPp+GNXFfjRZG4q09sJzlkrWL3lx6xXjRODbHotVaLGLkdMuy/
ay5ABjYhkriwAHspMA5jqPUue//eQy635/R+vJORmjUya+yvE3f14wvmFCEk+8u87bggQgL/yW9H
PKkCO0hHZET+XzbNbkRXyIwbJ3jhBguT1NaH1EJOvr/HR9BhODz9zPVDXVh6Hqq1+JUG7WdUxJCj
GUA0ucVdvl2uWpul7VBUkQxhCmp/U2mHWXZRgkUtebCn9m2syFywXViho3crNQxTjpBIjAdeV0X3
At0F8X7owl7P4/WQkT4iNYz93NhyCHEaJyBofGrontLPo1Oz+p/g8HM+TxQC4biiZpstOW50rPI2
mlN5XBYNorxxNy92dalwzk1c9ztRQnuCpnfIPe38fmgraA7y/APt7eAP5EqZhiMncD8Wac0ZWYnQ
d6w4NpCsGTxRlrubdGj6D/TAyJoRhdLLmq83K3W0ZTfz8WEdtL/vydMlOFgKTe7YxwJ8mBKt/XQs
JaktDto6MQTEg8nHmi2jD0Od2j1v0kvbOMVwEUHdkjXoRCPEjLCGoxNnSCBVKagsMKv+3p3SCRVk
nTXLYrB7jFjlnyQBizIt+xv2BvZrzd+gofjoEP4Zw+cgSN0BcL8QigduofUC4U5OJZKf2mTRozQD
16m2GWjAxpGsIB5TqtLqvDC1GiL7sHXc6L6ZQxNbVl4fVnEqqSR7ArQQmSwEDAplBjXcjjdiIXR5
4gvaVy2VIqSxvAnXfsUuaHPuISIvtowGz5ndCbz/8eOzWTPbXmFpZMojMQHq9tob8UpMK7hhhl3z
FgABOkvjMAmy4njwB8Q7OrhrCawAaZXF0aVtLagV/kROTAm3grP2NBXy95z4PTry7LqCsvkgIPa/
SFm4dphNdNuy3bxXqJxirdMU7aE0P4ew3Y9qBnmU473EjVj5nwtH5IfRPyVrU6RB0GviBIPNv2NM
DgZai9540pTe5uZSeqUWukFNDaTJ7p7rCQKXVgXYBMXp4V8uZL7bL13YY2ROtpafgh82+8Q6hZu9
hFazeOQ4rIRmaoGnzfbDZnwoAxSIp0zvguRV8lOrisJOQ2d0xA6Zwk29hmCt8L+ZdqALf5pKjF9P
sdjhJpdpLPqNSTpzK1ZsnIStOxUlLcuGpTFMxzjFyHJjgYtQIMUrHqq7htx+b9JvYQgQNvT0+HuD
Qi21L22kJB4L5TTCPVeCoJozaQ/NxJxVTazEXmZFLozFzLD1qMY/t3nqQvt6a2CuK8rjE/8ZuAZW
j0QdJoMiazrmWmbV/fHhrs8W4pNWapR9E6FAWG9b4iR7YtV9s33iuDGE2moJAXEw9DrLB/SVN0iw
MNTVmb67xWeiXQy2JwCFprAPTy42kVvXNsGtLIre9Wh2PN1hHAfms/0xrRipudUOTXGPZ16bkREH
R0/Vv7HfLu83fXBdfVEtzQmfL4AGS1Mlf/qVeDrGF9AaqMz5kJlRKr+GgyO6B+MaVHbymPX47hWS
w7PnzKQqXNy7/rUOaseoInYAmbbd1smecCsUklv9WW1gOjoZvtRxzUMuxvJEVRiuJTFSl4wrPEYl
tfeP8z/gmXXt6ZdiV4B4ILa5sJQAPhUcR4bIxKZI7tjbRxJEzCaD3IvPa5dW+P4x90HlGXGwIxnL
OGSYu7BTuv1pExzopCQ8kgY8CMqysqpmCrO34FCPO6BBXHrFR3eUL2VD9zdEQN36g7A5WVcDgU9a
GE/dXd0Vcnit45ub4Dq/P5IKIE15vNGddgXLohfMgKlJYfQIebLGM6JH8HVM//pGqRm8i2HHCb+E
JDC7+6ZphiklZFJ8DJ6LUC2lHfTU0xyM+/ljeukWZ7G/xociq88Jt2HYhHDiO9Uqc/B1Pvccdn5n
vOitnm7H1R0iG9mW0JpAmfpr8Navg0RU0cerIwStOz+KE2BH5G8zxwCwLjqydf3xeNMLaOwDIY/M
DI3klm6v0mrDwxwKTuvLitC2ipQCg/Gzu6doSfoXAIc4TwdK2ZFLKEZzQPrZPcG1LysGm5u4ST+3
DLJW24mBamBnvcb74XQO9g1PYuZNSCPXMIcPVQcf0TJaXi7Bz3mFwvgyLWMfFZQvYq0SUH1rRbUK
/BQ4Y3qQ6kipdqb8gcMn5N8qbwU/7oDKJOSzQ9J/JcU89enEJXqBWj3PSN4Om+uO6+vvZWjuDEx1
FdhG2YtXoySxPtNkaG9maHbB2IBIlDbQ9BZqMEAaw5Co8xoKLp6UqTB4BJhYpfRpppXkKsMtsMeK
EFZaNv5Rh2Tnsaqfb/CrcIp+b/dproKMDJtU1DRieGOrnmrLlBKng74HQpMGu6Cw9f9dWbCtJD76
AREANKaLj//BW2cfMeV33jM7n/OUMlmTNS1y6gP2ycK7lDLyabQEFhApCmpR7Zm+OCuK5SNYy5Ta
YQUGGUSfFmBEHSWSdto8ypjQ8NpXTGCkoQy/uzwx5m6ohtFosIELYjl8AHAG03PmQ+1lmaWuQ8zw
isI9j0CPEIGB1lIVJ8cg6kcbWYU02Y0gUNHCG4XYB4ZNsclwDdl4whoFZ56/ly5NW+AT5Vyp9Mws
1uDQ82+mN08Zh1cDO7mRWUqWJyv5N6dmAozum/1U9mgfH220Jn8f27FNMlIREVIIPwMYJPUKp7Qm
emjBlsvgw4PV3g47rhWkK7whimxQp/pcgoAxzunPlDU7nTkVFTgT6r9/PBjcJC6DhUKgqOXxiUBR
Ei7ehCAVGAANwAaWH+IaM08vmBiy4YE8nxaqIRUSIh7NtPmokxdKwf2oxjI/2fYC6zr/ipounN5D
hDkynExq7vxwbNPonZFn9adl3Q1YK5XMla8ZMCpd316OhKCF5dF0s2zw/09Kl9v92TXnJ2hrBfmy
fWS1gmMRLq7uaey8/zjTgYMS+IbLrQpCTe9gepatgmjQfB6bfZsSfAKnI5I+w/lrlVGOYvHeRHvr
SO1kXv3bOzr2rh8DmVcZIMkLSNtiKV31LRvoVyrWUFKtxHg6s80FYObmwu6v27vdIa53AfmczG5s
0gn+QeCY/pG+KvEQHbt9N6HSyS0WN2ljst2rYDMIxNQscEErgB7GKfVHoskA2r09Hj/m5OLSoQIS
KNUQh30seLAIzVyr8HsBzWdjZvhi07Q/vBjGtu6sYA5+ynC30y4l4gyo1Z6suztbw3P9CzsEI/id
3YXd3LavgYv5sUrAzGW+PgkGo6SjLwRIK3ZVRgKWh9ya56p9/H/zLY9RsD9UToZG9nQ1ur4tY3dq
RO+PNm6e7JJdXVNn802eb0isSft3skZlXKZd2AFGBTM7w1UKop4UU7nV3uOrnWrok5546dOZb8oB
HxFtwI7oiQUR/Nl99bB42gxFfdAVraV3RpYhy0wf4KtSlvCN5xc5Pa2K/O1eYM9eF4pJ+qC1EfcC
tUGmxgGOYtaA/1VEcguwSU6aQub1bm8CBqbVVUUCfTWbIKg/yxpHnwdm333RcXycEuc9PjfddhpM
KeH4wIFWqHmWGl7RWQyrPssUOAOm9fdoaVppU+NJxK0I/FukAoL5bxim/F9JeElSRPie2OYoAPc6
8Haw5wKSSDz0OrV0aPkrxrF0+OmW6JJLYsCEPstF4QVq8mTbBSM4zV/BLi6Ut2z+pRpEQgREVcWY
rCSocFNZuNDVfhNAQinR18uANeDBknwJKccbtEeDKlMCMPn1z/S/gRrgUIPk/dCVYyMfglUbqh1P
q4cRSo6mrN5Up9jl/AR2y6rGMF0Ue0AZFRm6PnYUTXeb3owrIHhswS7jtdTZTEqw4eaWzYL2EKa4
xvamOwY9aKwl/vizepj2WAd/pKVGhtI9tKyJuGKztYsm1tXqwKDKPdsvvi2Gx38GiKdoCpUXdneI
xYkQc7ybeoKdSJOQyMFXzMgG35Rnc/tHRyVwWSmDAtTUT646Cls3CzQLLJmCak7kYITRc+pAgwba
U6wyZJGmxkDjcsjnhWTTc1TRqQv3Oos5JF2IB1WnrWh88t4yEQSTnSz8wC2Lg0r71BYn6rzmIjI6
zJs6VINJT9pBuqVtBoHaECkWCowFdwD+Y+ETEuXs/c+6naykWLUc5eOwME8EozczWDTz0PJ0d2jL
EkjHgXMRczdVq4X1BxKqp58+XdLP6w7cBL4ocDU4wnIrRSrb+VkkLuFQfo9ytC+4s5xAhOFIWNwJ
PZ/l4Oza5BFa+W7j38PS97o9jmVx3gz0OubILEmJ+HpPiWUgPcVHr4Jej6QWtdu2s9ltqYyfOigU
7GUnbgf1JEzsCdIzl/lOYNEc1QCIDhk3sib2Fw2U3gH6C0xqnNNhH0885fOhm1CPZie7/4EQkoE5
ken1t9Cd+H6YipOcK0K6z9mW65rdxdnYdzJrYbKY1BI7lPk6IMHuXMrpONlH/vnAxwgZmRjsCJ1B
rpo/Hm6FT9AAK4+A+6EIsS4CktYNXLn9xbAWabu7Nfn50R58OZkfYoVWosPXoeBizZjUgWhdrfl+
EqyKlrvI/YZYo6yjBPuoYapH5RLsv8U1cOnNzqDz3CvWq+1HnBWpq+ChiyrZoar43PgqC26708vW
51x+NGS+x7aGiBlaiMwhikAo25WrULG4FPPP2Smxrsk9EuGuq7WHwjw+1Jp+xQ60qdXaWELO7B6E
rk5p5/nsirJVQdOOyw6YYtOiLtnFSWBD8ZN6I4IVOxnR06+BTuGu/ARnmDOO1FolmUPXTu0aKvd1
QBxx1F6ca0wtE0xxJ8NptMdW0pZTAK1xYeU040xdR2tn/PKoAT2yd5x8tXggJh70JR3jW8QqDxL8
CRGVI6lAOk3k5t0POr6w1VacO6HkSuK8X5kPSw5XG+XY5a7rR1kmErp2UpGlweE4JS7uKI+9UVV6
KTH4v2qFytwsW5vLO3A812h1qDldS0FLgbwaD1shEmTa9Egv+MGmOIzNLgILs6DajJrop7LZWeHY
hhG8ZvC3C6eS3HTh/oNJEm8qJXF0ZfrAYgHKmgg99ZSomsiz+79QpM3RcVfpSkc5TkPHIUv4mBTy
G5Pi4NoVgczJP+9h1hxGLEkBIwsj/+XOcBf40iXwvjNwJMMZv8L3Qubj+xMJEdgMoXd8lFD3KwSS
xFsJG9DgRaf+tvrO8ZXLPg8sdHSSjfFZwFe4H0N8th2olcqC/rGbpo0OQtDfW8xdqTYRANYHz3BV
wzNUmJSTcGk+vb6SjDFf92Z1oA8DRRixqca8EmMxcK+/7/ezug6EX5wKB0c67qsuD2W6kFQ83fzA
ITKbOCKpOwwa+9goFM7YNHP51KpOJIS56k4PTSCVIjKPRzzDzyNGohUL2JA/DAE/inm2fudQsqTX
lz0/tTrp7Hlh5YXP0x+J6adIHeRxv5AABLIFxW7iiFiyDTt/DXHppY79jPYmZ6KL17/J9YPsZdTZ
KG4YyNL9HXYa8Rqcdi1q2vcogyIQZfdojimUItM55gzING1LmSnE/iQTy7TLxhwX7c/PGhh73ysf
r2xBU68/FvlzgAh3HZwuEf1yI4Xw4gp7sTAD8PgDrGHzHncQMZuDhq/KgvMXS68n6dloZ4vrIIH5
yqlKqz6niXm7dwgns2Xd64mw86UkSgPi8I84M79JtamFMFD3LwBFjZFGGJrwfVM4zWfm+1/aOK1/
JYPLVZRP2kGnFnVNOw66Y3eEgmsR0Ga/0EFo9ahPmeQ0KkfkpzPe/9DefWWs2llh8A29Y6zriuHi
yAGG5eEjAHm5I6DNgc6nCWExkMrIpQGko/AkLMbEr/+iOT7lHX85l4mI+SIygmHDwM6BSYt33I1W
C0+AHh7pvE1P2qEQ0mpVUi58GtKOKV+B9OSAm0jeKAEIFPFYfrVnzW4Uvodzgwqzek7RMmpN4Hgz
xuzH4+00AUu8hXycRYfuhxEwAP8SL1PO0FRHcuooYO3bV9ErGDSrQcgnyoldy3rsbpIXA5m089mw
SCIrjKD/jQriKJLhQOqUSS5WDiUjzVzwE6LU7lZ/LnlQwkbIADSgZhvfTp3k4ji73h/w0FvS2joD
GqYKxxoh73y5jgFsYYWAGDRuR/1u0DK7Lfv71TYt/dXnlvj7d1PHEUNQ6bXBGyCz/Gjxgo+6/Hod
DOzZbS5+zMlxV8xMZe4sgW8Jw8cDTBqfADN98JWLo7girLwRojcCm+eugRReYue7kwucH7DC6cXQ
mwymytQeXPUug2LYrkNp7dbbc/pcTG3JSwmBhx9MTwToBAs6C6TxyaN4ydoG3LyJv/fBh+lWylfZ
+IkckaGAIE8jvyHyCTEfauBMQFWn7mTp/Yg7mBaLuM/QC5/qqbCr/c85kya6TNIr3TAJ0J4sc/nQ
64UW9cAaoq6jh3kYEc2K+3iBzO+NELE0slVeLXLdXCigneJ2b7IDZv8m63w2Miwi/GP42D8LEdh5
tUB/SSlD0PPOeMnAjqPiNKtKOeqCDUk1hMP8fEwZYq3/Zma4SWyeMR6bPfcBL2jRhtX7nOVtJXM/
IPg5NF34k8PLh+AcH4ehbcl0f40TPcb2z9lk+Dtu77oDNdgy38cZ1/XBSQV+rZCpyE5IlBah6Zol
6XSO+8KUFxtwU5fPIhoI0ISiOO7zHv90/YohLqCbedX7wj5oIKx9uk4pX9ndpdklhpFgqjRQ/obD
BVZfnR//1GLDCHu3OmcTGquWnYUbxcvqpuNaxOLz42J1+E/Qqt/HEKdZHw9mHdNF3O9/QRFKLxJr
Ubi/AqWtqyFsIj/oUrSjEalFul5fbE+hwEz4+lksBYINr4yqySrvuneROY03jdzSf3owFB7XGXsr
YpOdIbaszKT6TlcuFbGVN7cHdS0u+3g6N0lkgjZpHYAicOpiGqdxlLIem1A6dsSth9pCNO6oThHc
WGZY9wuAWboIulRkQyUv5y9HTrDxHoz6ekj7yf0rg6iJDdD8CgRnOTl3NHSIhygTWFG4D/HpRagO
M+tU7cZLgK3Y8upbXFME67vpO3dc3KjN1NpRn4paBGsK0DRsivRskhoueXQoqPtNjjJDxNLTVOmB
TdoJmm3HZ0yJ9YYuBV8PRe4oALB9TOct9HM1dMFGDIHoPocRUd0HJN68PDQCXAPNdKCWLbs63Xoe
FpAUPoitrkEqAsOeuiXtKCyTyVr9YLqgwDWjflZqAKJfwX4Twx7Pi4Qp29NL9bDRvQ4LMDTRnj+X
7QqzsdbbF177fasVVc2Jm/6mK3culNU+JbowST5AFwlvVDiMG1Zi6ra6BsaSuIwGQGlAkpgsIk5f
JsyBABmU/oOzCC4jNDB6xThLgM2Pj9cWk1Ciopi2UZdNUW92orJBnRlhdTN9KrZ1rfBGwwpFzcrD
SGKQkToDFrTF/CC6gPVYJri/c2MZ2YtXTtJLjuyq/eFLznVHE6c7i+3Qd3EuF1LOl6SNYzdS/6+U
hOkMPWIlM8ovlC2qSAM50Kq7ivjJrf4UL19nC9vmKKF7NOawqnHai2LfRBI+lzDoWXoPgxq/SYra
1cUf5FSrNW/qThOHwtStsQD478g6jhogbD6mT/4waq0AQQXpvMKLrxheeKDvk789cFz/hFGx/DJu
0hiolW1KRmHTXiR8w/o2EWF8PDnnMb9uuqpkOkNTC85qH91m8aqx9xEwsNDjyifimK4MV0rKseui
JOAKO18Ifvbtr10+JzGOSDVC4ELbsBFOZ3PAubnrWJJugndfzZ3ICjwiquoXLsfCRFeQA4he495r
Z5W5uvbVZfH0q6tXUGITW7Qeo+09SgV1k3Pmw1lgxNByVwNUTtadmosJsCGRRfuI7C4T/dsb2K33
EEOyaTFa3F7DgNayyguhsiUHI3AdY22fxREuIyF5a4dPg4ieOjLWqClxdGHreyvmximUs8ML68s7
Bo/MYsUmP9DBYxKAzaMUu04di82hCpLfCV/Qr6quCpJ0c6+AsTvXTxTz//tuYv32bZtyKUZTCBJY
mV2RN3QFhIOMWYqca2+t3yfHhK+WBSM7XA9BcUyxflTTdJDq9k/M4m+FPN7AZZm2oyYBC5eJzGMW
UkvHRIqKG3Lrlp5JQXJ65TEig3P+ERblyY6gUxzVJNvnycE2CBi/+DlKlqWW3vxMV3xXdFRdKX7G
WRl7jMfFVuI0vklumY0Ki4UCXJvwnBXYJTdAjkc1WcIkTQ4m5oFdABD6xNlCkwBycu889O0VBuJk
Lqw/RlgGRyV+zDv25m1QygIv3jOumUcaNB7hiBedT33HT6+qKcM6+90xJNwwp2G+/TpZx87jk1Qf
EQpmV7mb76l3PJJRlP4Mc/fYJWyz3OAa0gVkCDYHvFX4yGyIRcI6AXHBKibpeI80MZ+KUITnRK10
pQkxtwptGq28LHI4d6WfCLxzpboyRbYjGQYjmDKyyi/i6PYtczPAxS37gxNc4VdbMsaMyypPLmgK
2jLhVCDdpvSZdUQd48erJ2jfGMTGyBG4qYt/9I0d3Oz7WnowZqf8YEiCQ4rP1Z9700UrSFW6x5Wg
3NhBVu2Ic2j6WnYMvqPDsKv6ESFtUS3FJvzARwI2pTyAZMB4A7EekOC+7EvZEjDJXIYs24iFXzdE
Dhesv9UxlPTq8ztqVpel8q7LdOzAxaQUak3xwLDltn2y307QzVT4pDguail0fNpalthSJkGqlEcN
PyryUzOBPPQmTX8W03ox67fcZJ8APmIou5X/+iNBOYuu5qr950pGS+GyerTRk7eT6Qy2bNtzqla3
ui/8Rxk4d1fkR2O0icydQ3ve0ViTpwRjoe8inEYrCPvHVZxlXIzB6qwgCiRVeLwCumKV9Qdw3Bi+
nYwOwuHtlbQtbXaUYc3nXGcmvxo38AipI2Qz1RJbU4/LGDSeXetsoghby9FgeYXwpZjZCfVd/50l
GwbX1QPa/Dd8JBnhum+MDV+kaOJ0poOlOTPqO4SbeunMMXjYj8dX4R6yY+F01z+R6JLmLna0+czx
Y1m9+HVJRVApPsNbvpfJyrr2SvjNhraYii8BQ+Vli5qJBwMuPtg58L+NndqqG59yhr1PeZ5tViQP
zFLRwt4wZRwA1QW33QVljCrDOjBrO0A4dDEAYxvHLq3L3rVBTFz3gs94G/IdYVfQ1K1y7k6f+pKW
tnulev6wPoOImJmd8FkVVkVCXQCAevvL3cg+nrHcqgFYNnyM2qsw5uaXshYbIWk3GeD/hnH9egC5
xqslFYP0FKiW119Wg2UbuntwObQmzixQmRLO+ody+dKuy0Gs19TaWu+FTvkYpzyhyvRSPIwEzf0W
KQsNBb99PKcjCUxW9R2S2lYHnpyfRKlhVMEXmYVQAKMcPN58q2tdpyEJ9zdXdPObwbkuowxZH6OJ
aJC/hwhLwvjMryEgqFsM4+MzK8nQjXqB8l9Zeyt61ZQYFH4UdihFurAs81khiUTMsnuAc1gy1Dwg
nOFXBEYgunVp+18025socfNG2SzZ3NIONJ3Eti8vjEz/I6WtdYaRJzvzxpE97YrnmZtTieg/saW/
0dBkrch7GsacL7UR2HyEwMr+9kEPbvlZitiJxaH6ktuQtpbcYBD/seivSk7Elndos6CLif7YDDsc
ho3KbmRSVrx+SrntPfPbpCX+TmhCtpplxmAo5Ac2MUVhGBehQwfC6necY6sDDiMfj03kgbry2iMB
7pG7+NCpUOh5jtXqddk43d8pY+O+0UAsUpW/XyBjhFsiWwbEXzEkG/xySuRGVBCcw8iDdtPzzNzw
0A11U/lsIs5D24R0N7ZTdaSdhe1aPx4g88UKgk8enGg8GVqz0PQcMaNaHbQFhTwHyLH8Hm0ZIRGi
4Y/it0DQagdLuJjU12q46MNrgpCWq3a04Af1EXCJPvAVE3w628HX4O9E/1k1htwydZmq92zysx8C
hIEpSuEEOMxcJ7G33TgLA2/bgPqLvz9pt9yND5AtcboWm0ekpLK9Kbqe4Q9FLaQdYtPOemd1kttx
IqI/z1mDyuA6Ll6CF4mIFEw9PfjgiWyxJd6ASgyme2GAbVwFUWvFRsB+ACqPkEiKp9zCOmdkDiCP
/W9Zmnf/BvHbAK5+O2LDn+KB1drS5LdTdRpPGi6PprsqbapVFbTr3cSdihGXBvO7apYqTYnODtuJ
nprrEfFxbNpyrUDEBu1GGyHdMKfC6XbD2f1B2pozru6e1Rts13cgXRBgQ6/9axGlcFvt6Mc1k2LV
iFuBUwctGm0q3V3xmICcKrzlsVwsnBASyM1TjJTbzhpfi+agnaFtCQ5rnC17tkoUobvGsQv6C+1a
JFmdXascjEAvUsIs03OhrFA9KOMVOmAwNEfDLO+5EnXhVR5NGLuW9xHNYE2YRrt/cvFkNjVWbgiX
UOxlDX3lZSzgVn8BhU6/TutWW9FEC0NDNSrpxegglmCTj4fVQ4V8sOqg+nhYd4YmGcpRSavz5h7y
eO7TL9YCz3FROyB8zhxSAFrzuYy71E+29ByIEW1q6JXJsxLDmqTY2cTv01GD5VQffjYNqFIB0t3m
6HQ5JTQahqQCsWN4J7bEEyfU9tk/3O+i41w+enzy6iMb3sYZ1oxXPG+q/k6bcDdhQrVeKpPzyM2d
zBrhOlr3lINOjLCnMgHwoLKhMuve1gLhxE5+Yk+ynXIRLpZ0PoTyFXU2yJF4MdjcOckXnQm8Y4h6
w43FGHAuYpZWOE1ks3TcSKPpUWnGhpYg5kf0G3lG0CL3LlHRGCzf5Z2CDvMtNgRAjkz6HKsxC0Ws
7JlLDo14EoqCYCJWg1o2cg8HC2SbgqcxdZ3k90g+EU/XgD59XbxArQsUz8hWRlYzXhBtAkm3vGw0
YKF3SJjULJGiDkkU4F7wC/BDfOgsaMwIe2wd+sOiHBkoXrSibEt7IYzp58OW4zgsfBeMMn2O8jPa
r1PVLRF8NFF6PFr4KtqnkyX3i11UTn55AVuheuDXb2wRhfF9KPke4i2Vu+HAj1+Zlup2n6jbHpeE
goDqBCGBNcFuVZOg1TiV05cBs5vF7l3YIbjCz177GpXzwME0lXeDsNHu0EHg5BxqCoD0kkmZlqeM
dVdqQbA9+Wj7FOOWtwr5utNE6t7pAqbxDd3aAhawTEfVzeS2Rlq2s07Bc3Pjzna1aBze6cB24gJ0
oQIdeQH0gsTzTx2Jxjz2Wsb9spwLxp0ukL/b0D0qLPvemYlPL4SSHQiXuev3cbAfSXwZvv2gttMi
Z8FP52G13GtlkcaDIMUL0cJZ/3+YtTCNBw+bn/JLFEPuT5i1Ct7DyiK3Pi7j9S/WhD+jBHJ1l5lQ
Nrw0Kb1YeQHTgN49dzbLEu14yn9QbhbefAfKtXnYGOvIX/glsXCBe6v6iqYQMDPVZ5T57QohQI1f
ADNDBvnU9+NZtsoWIHB4ftRDlvma/dxE5AQA0NegJX7xFCNoS0k9rKd94N/W4XVbPnqe1wTOnY2x
NW+6fVyfNaIvNKJzrSobm2zaybaVeKgtoBX9j3Pd4zTEXX01+y1dHhoWjJD69y4RHyYd8DO4Qey/
ZoGaX56cjgEnITSCuiQyS6PhGjo459clS1a+Dc/6exqsTwflBPiTeAGTZ5+zh4+t8aAJrfLu6xBo
0VsB4eFxwdWM67d9syhwAmBcMNeyj1N8FsEUy870AhDeUA8omU/bXRdig/4Y1dp93E7OxlhDtEyy
/EV5GU9bC09nfflwgxTshEPqDoizUKaL5rR4IL6HDa//Dd8LXO+IJxoAl8kEC/M4wHRVSw1SaVJU
xRectn2KV8Sm9RfTVlnsw7H4WG/M2FxRcfLPrku99oIWASZR8NFHk9EjRNkLRzzBioBiOTf60ECW
oBeJX61gyPEecQQH6SXoEzUb4lDaR709wLK7g+f5X1qVtrSiRDXf1kAVuop04wT4Z7+QFs3DVT66
qvcpQ/lcVsw59n6BDNChaHc555JUdvVl/zh+NPCIInd13urrzyY03Dpk62Im9MQFj8d204aIZWJM
3A5LpHt0ALkodVKUaKaTxuc05sqmgppqYiRiD7pYXER0g1j0ivqIXSlkWn/WTUYJNWIBNN5P6o45
krrh2qrLo2LybYNrbgULZU4mkvP9Msn7YiNViS9ok2AeLcukai4VJs/mGgOJKzjAn+GggPbIAs+v
0rmKRySXr1gdU2MiuJzodmd+Qh9jKM16C4CnhyqDF0rXtqLjlkBD/v2XS8BuGOfLQmMBkLc3LzQM
garDQtvBHnBCdCNG7uT9PKqQ3wc6qCd8XiPZ8d7YTB/+BHmlrxA8iEWBvhK/mFexd6vLLIw77bjf
Oj5+TIq3txN3jE+WOi886m9jvMEo2cU384Uwv4LJPCD3mp8/yW+5oHbrFRKDVCqniL7iHXjvvN/B
Sniot97GF+3qMDVROt156amOVtHaV9udNBUQvBWqBRGNbRGhx/A2Et8+4RvfLoxmMzEmncEBKhXB
nw7fD9B/8AXWAMZTkfUaCrNEY7QmZ15SraMlIj41pG7VPSYdkK7orezm+JTfoMqSz+MGjNbPXKLu
Bcnq6EF04Jlv+4YCVQ7w4uULFudP/7qvMqGcFMJpnmlboT1zduZymQvQG5AVgmtpe3z2u7MT70ZU
fssZuWK0bgpXHbAJLrVn412180ULQdGIuYfuwW0Dbu+1KztI8dI3W+HYCeCGIVMWa1bE1GGItEeO
anwmppVSE4WcdsUV5iK1744MYag+27boQOTMNlfDGeT4As3FRtx73HZGJcsuKM32O8ZZdsaAOY3q
u1JYnYRcJk6CZ1Sywa3I0J9X6031mMvB5/JjfoiZYAiPkUn+0qgMLeFaZfwrsEi4JkRxCcnLHf0F
10V3O0eY6QHEb6v6XS2McoHwErtxuq5UYsTAd55zlS9pUgotVzEaodVp7md5cesdHuMvChVc3V5K
/W3j5/5B2vgxX5yzMGQ/pMx4LPQvIQjj8krV8pFm83zgVkF4knQaa3kL6ELoZ6igxlwGg/OzlslG
H3B8sbxy6/8l6OmhVwfhrAzmAUOimFCPp+GDHQZ+e7N8MHul10faRKsS2tPXwWnjb6r6Flb8CsKR
IsqQj3APoXdPtR9l+Pw2mBiTiFEklj0d7OmQhg4ySfUgk9y9paqiPzlpMXhTWIJyckfM3b6yQwll
fe/I1tWrwkOH4EGfOwf5axQ+Nj91iqvMfehAFEfGxAiLGGCEsqskp3FhbrgPep8Q6tve9EQ1Cbg+
rv7H79+vJm7EXe92uFKvRFoFEAMw5ZKS0n027rNSWOm2rzZq6tQNi50P7MSNGYO3eMVnvS5QWnwr
htnqDQGkHy7/2Q5aH90YBKD4CjWhlqzniGBwvDdtPGHCM2YhYZHwFVqSyGPzJkNHwjelkG7qlIVb
BVDtnIWsfGvE7Q1tDs+jxVB7YCtc3l25dnrfD68txJwi88Xk4aVw3wWJ61FCP9vwo+degD5DIh8u
sFCluGqkD2Du5GG+5G+37aehoM3ti2kGm1xC1pzd7pUtKfh/vIu/lA2P/CHkiU1vrCulj/84tvwz
Kwup4zU0fq+HzbIAmUxHiCeP5eEWHKqUBpfJk6lGy6/WqCTeRBs1vg2iszmQgYMRndT0o7w5XMwo
hdiH09UnD1yb5aO8b5KdNrOVGiadquvydsA7DGLddesFNkmifPFvlW76L3LJv0Doa4QqVve/vxkl
wTW90qcaF5hA7myxYv4iC82yFZ3lEma/KlD9B7+zojpPdlAGgMYR/+EbBNMJRMundW0xkt9Wfljt
YEs/xKQv2/XI6nwpyYdymJiTmI2cVPuNs1lA3tBNy9NAADQ09rjr1k3BqwbzklVkoECywXPAFbd6
iPAfB5XDimPms/qAt25ozT1B63+2HYtYczTfziYuw45dtkg6FOilCSQZna75XHYmB4nfiE4gtZvt
h756jeQE83vHSHuwyCOzsUF6ggkDf1sigN8xzTgzHE+LbRhKvaYou7LUv1bG7US3K3lvZJucHi7H
OtXvh/5oLyEXv/x0BBpmfp216DIXofmBP6963qtSWHW8cje3Inz4T13pHWlFAarrgOnQx0RIPyrY
W6RaJgk0hu5k5GzDQjL7IPxaO0ZXNev/uqLjh8FwXdL/j+N/oa4TkFXR4ucFP9zIHqwhRvLAEap5
beXtLE9Y9qFa0tuvyw5nzuVg7yveb/UB+/RR5qsAhuVyqUMB4U6GAdYmxwOPg1KGEWu8spwwcCoI
FqY0vlM5JsuxwEk4hTC30aISsC+3gSpTPQuEw4GspqNlWCb2D9xNVUSFRRNh6n3BEWMMoHDKnzJd
ZdsTqaG+U+WPVs0BHpK+RK3ldIUdDWp++19ULmQC3GkpuRyOIf1gEHYuVqdaifiJz50bQSNDDGXr
L9ayRB91Ct4Jg/Nf0WwG+dFUNNFTUVtYnOm7YiyjEFOdb9TctiAUIffGpvwjysDOtZD260gwwxlI
fp13msML54uX7PfdlNXWcvzGjIUcAomcChbIExNIGDNyrPR81JrLRbfpg0Kxz6S2f0Y7r7u0ritB
4goqE63ikSr+6pkf7mspQBXKLRZlt6odHZGlMNvx934NF+qp88SZLRUjmGxvcSGYXN9Q4H8FUnDn
C/pHY+a3GLte2D0djgbtbUgA4VefOF5w603Ra0+e8qHoYARSNbH5FWnkpnU1mT9lSKkIPfX94vlL
OCaSTvaCTO6LmeONYDrTaQa+F34CiWKUnvkBKY1p4my8CxwHZ9yLVnyD5PKEuP2yiObGtgOzqet3
xP/B79doWcxPiFEyETfDNZob425YJ17UOMy24PhOn6uKJH+X127N5hPcncS/4LxQ6FaDWlSTGFFu
LnBJiwn+7EKQyWbZR5DK3JqAsY8y1ezF1/XILTvqqYmA2/vT476QfJ5j9X9W34LtG5DEsX5X/rb6
J6MDP6k7OXKlQ3W8/A+5Dv8zf7VxNiNhLhuDpbmBzK9M9m3+QvQwDCE9v6L3xYScBkaP+6EPEWz6
zIfDGU8U0arOUZMHP5Vci80Xuk2l0WRBawWZ6X9Q1WPFMuBKI4nGpAzYultNScEICjya+Avyck6q
4Gl1MAibygwz5Y63gd494KeRTfYYWYZL5Lia3XoxYoIEj89onA2L7EpRNYh7+s+Xl5tLtE8kHe+Y
o/Fry63U9JSZ6714IZkafubRYO733XYFf5vSS3ni4omOvJBNHkxesCcg7YZ7e2bmiC3yfSEOkfip
6TZQ/8bp+5Q0fpUWHtpu5eYniClkn52M17/w9Jz1l1JEWn2vLRSJiD/JoRkE7dFWZHSGRbMS/v+W
QKeAscLCe9s3kH8TomWLUufv3gbEzsPtU3OxzHfJB/3owlGKXrl1VBQK+Gxz8q0UbekW9ZLBld3o
NR27B8kO/JYQt7s1XlVI2WM1HbkRnhwamG88/pL4XzwwoVF6CtSfrvF6E4U4C+SQp5gk2Ib5P8Ad
6c4xPyro2GhOxsi4Otc2tBmooWwWko3D/oPK+BWLPvX15AEO+OkffaG6hmZ7Wip7Ny74tZi6M+Vl
JWenQp9RGxkxGUekTkpuRg+WrFHOI4EdP+UXx+OrjsWg+8R5claanpv3ckZWai/HTIDwYI8MDdE4
2r2KhhEzx0EBqzR8V05SZ/MEq2I+MSaSvb6i0X29eEo6Yqv8LIq+wbxprakvTervyiDyifAI2fBX
GLZqHLIT4tg9w5Pow9opazI7PpXcWBiGdQvFFS51ic1Q+85WNFyMdkHpS7Dgaqmyk82WUj956gC8
XFvxY6gU++1HGPy4XYwdALSEtMh8GFg4Xdcp+HngKPSceCwiaA0F5W9RoOtfynD5pahfYrWz/wgo
h5aWTaCncVGGqtAutYenPjFuv7DzyW4EkRNnP0Q00xpomIYrZ4Yh3B5Ms91QrY/qKntIeuudAhx0
kBVrp/VMu4Jmc5QtFXN2y7NfR4nxPMziJnuxj2MwbOVoyHThEnn3ai7U9Ian4Pw2dkfWmgZaE4LP
VG1JHbQWYeJAnHB0UjHdGesKntzbd5LUd/kW703yDJ1gBVka64QjCp91VjI7Ly5Deprw55yXGvJw
BAeLtGUq5RAZ9Nj7KNUxL1nsAUSoZ6VLb9E4QP/tIF7ypySQby3Yzb9JX7dE7gxtHI1WVGC1L7ra
BTF6HvKBzuQHtXDFAR2lryUgIUlmY5QbiUdcND+dYb1TtR5uj3zlqcbmfpDgXHSfTaiPCc8x4ktY
M+KBx/KXbRxh1R201XyEXa0OivY4H5gW5sQ7MJ8ebiWVS2jBt5cugYefNM0VEEqJGhUtQDZ85oLB
N2cw4DDx0J5n4wDjiw1bih1MKIhUM9d5aafk8xy5D9O3AFpzcreghjcC23Rfrm5BRcNONlWkSQjA
88ISnAR73YNnfXCM/siLNRDnJoBnabBFStHTsRN4bJhZ47ELsZ3qQ+RmrBGm6bbtJ1GelxExQ9li
QI/UFXX+2OdR0/pF5TYO4gcGumyw5ZK1MYgw6htmCU0qWPR96lNEQ9vnXhVJJVSDh0YnBpqGCpUI
Gx7Sm/vRyFQQBcwqtV7Ujzj5e+QyD0FEJQ/ak7nh/1cgGmB+S+FjaOYH1xaEfbIxk1Kqr2nhyU+Y
UFRIBagE6C50YP6gAtwXJTMbS+lt4BCtjI6OFRN7o1kIef4ZnwyqMrn1jIYWKXog7mVA7wcU2DHl
m4MS84ynoCwtyWVMdt/WXyEvLN/Mj93JQDWjLWRNsovO7+jZZotwg3upOflia1NhCFDhOPXSgLzE
rLyn2BLFuNHVCwuRJaWAvF+1ok5COInf3zBhoa3hKv0v/D4D+Pki7mUkEsXpn9QaA/QxK3CrjD2K
TEBPnLwUzALjyEm1xeesQoKohfHyxxVjqBXD0FQtHEENq7bV+ObxyJQfU39Bcj3q7sGeT7Z1loA1
dl4gRP/C8J1snljwaH/frpBV+GMG9qs4/IhplZ6aR9oVGGEgT6zKmVykmdnj3jiogDwvoo/NAnrM
1eS9jloKe/JTMRsKtU3zI5cVmyJSfEe2rdz8hkDBcKHMfGNPclJI/RHdfdtWIX5ZBW1RS4pw5xzT
OS0T3KwBp2wIHoBBoMOgHTvdHkHWGk64ZF6IBY5TugzdKnbUOZsb5m0+q7pcA7RyaFD+ftlAR/Ie
2wXYH9pJbeQiiID+OkVr8OsXgvmdlXS27ao2wBUMjEohdt0eJBpIHv3sVqTbPzX6c05ij3Fp3VKr
7wiBNBJNEA4Xc0TB+SW++1J/C2l/MPz8HSr9T/OqtTau8QD84+MRyhLEjMoKiTTsojE46UFuJDnD
UYFPZ4+R5Dw+jqaaCS7glk6TgDmOMcDQMGLVf3e3pQC4G4y7rIMVGzlouNOalwP1JqK+4HFibaeE
xv9vP6yLk45+jbvnXfKgXLE+I/Mxehqz4iotVzIuB9lHc2easNfthU578YyLshiNSJRXlAApbJwa
WaOoeNmP21mMQ2jD9oee/DmMQvDQMTsvcF5qwGbZZTUct8Byjg+358C/5VTMfGlSMzUtY7ILI7od
F0oYat2v7DvOfg+9V1fUwo9wPm00JcshwZ/yXPI5CteiSseBtUqLt4EB9VsvUdvZwpB+QuHLzEDE
RaA56E+kmxICAwMEFUCWXY+JgPXogXFit+l8+jbwWrF349t9u4cwo9zQ5cT88s/jxPxEK6NGNZtD
kem1ooov6LAKe7lA5YIYkNAIPhNM7PEEv0po9wP+3Zd8y3lGfKEsLA63Ac0o6rOrTWup2EUx1D3R
g9IqqesJZObCerqexDtnNh8T45BY+jGk8UMzMyh572cdixlq9h7iUqvhwnJOVKe1FLHZzJaDXfPN
xCVBkJQPriDu4dYFItcx2SVWyv0EqYIei+g2L/PwUv3mH77y5WzYhnqHi+jxQTGPlunG9nr0/tgj
LC5o5/2djeioe54M1YqnXYvnqzg27wWfG1/8LDQayZQQbST57wWNifuVYI8af/RikTWPrkwCuqWq
LBhZ14rpp8D3VSffdAIgZnvxNjsfkELSeRBpd5Nxv+NVAM0NOgrsnapv549h7KzCP18vMkyndD2W
ua6CBw4mwfzMK9rHSURvKTfgeJbCsdAVSkOnmGDCDaEJN2oOGJxHIb2ubcexK7XSGpUfU4xz8FWF
uCHbLN2pYfYdOZbqfSLMISnPN+JwBcyChAwiMEvhUaCsLiuMzP67h5/6pplcgxrLLlxZxY/N2Snd
4mc9hu92WQzmjm5K/FS+fBCdI8IQ/rfxqljocFO0PC4r8++w2As2lohVfg48azO4WOd49CZWTBug
RbjU809dzcNzFDR3Z0VHe0h22bkQ8DusDPOfxFR5M6y22MEpbj+MO6LaLQC3pKATNro0atfeC0fK
ZLzu04LnOR8j3K5TqVTejTqSzby4Xg/dPY4TbRh9C1QKx9J/NWsxbK6I3okYBlSY2petUxr7WyMp
+ZLIQMsUPbNM2gEwgCt+7voC/MovXinsCDFqQlAleRZ3lodd7wyJz4B4YcK2C2uvMJXnmwMlhMSz
lHlRrtykc0xECdYhHQ7dchRAqRKaji6YmRw4CS2W+jtEorbtNgGVGQ1wpIFM/Qad7OXwHaRn0cqp
UG/4Hi0Ck7n90fecaIily00KbHW87rYi8GgFnKUg3mGwxc2OG3ltkt3GfxklU/es5V6usLW0LDfP
/9EtHI02kzzWEGcTKdw7Zm1IklNn1qOpPRprflz6P1a4X+1vItpgTXoePE5f8IROOfZDYVMhYbnk
solaZ1ynEaOcP+uANyOp1pAlLKPISL8sK9M1LorLKqxLktJuwQ1CXosDDkY1L7ipIrYeK7NfCJ+W
ch6dxCDvsr0Nma/+XNpb2ZzzmHjWOdQ8lMm0EBoGKFVoHmoBx0z7Oz6ngWcRxVBNJMZAktfwbg+t
3c8ZeHL4d70W/Mt8+tGP03EO+pTbXsTW27AjPG3n8IN5GDZ/z7Upb4k0/yf3ZCsskDxI99847buh
9thuk5GG/FodEIsI5LI5ZLsGspgtgfBFJyCv9b2Dvv30GWo5540ul7hjqoY6+EfslGu9a5o2qH1U
ex/kxHPi/rfVjsBqehMlGJtJRBUr+Zs8eUPy/kPJOPiV73/VcrzPWzkEYCAyLApiHQ+Ey63zfZDs
thUkp0hBvjE2YGbE1SaN0Fv9eXDTqT/WQriFkf2lGzkK6Bg/oI80Wdufrf49woltyfhZxHDQwb+M
Lik2sXbUvf9jw3UwCftJHdQMCV0NUo86yj9B/mj7jo/yySSBbuVjtWoXCI4e4d9NyLR3QeoP1R4U
1NIfSc5uOiKCT/XoAnCQIvn/c8XP2J+mY3PIZH9IxHJ5MN5xKA4CSWY89wUe2x74blzNEk6/f/iG
M2/wCIqLh8rYciLLFlF+pymWwFrECTmlpoFUBz01JW88rtDwvPGzp85xNSU3yqHytJq3NEWAOXuj
D5AAQFBuEJEowG+FVbRv01cUleuUTCqE/hv4Zb5fv7TW91MeeJoqCPCXKw93v76DwEjAzGjyc/Uq
9iMjKfe/zfMzm2WCYpFmKBcQL0nXArjavpPFI77B5tkn7rh/4zYhGZ6XtgBo08e0f6SOPsvCVZOS
PZe9Z/+9KpZf0JEmyLl2Dm6WOqcVdgPMIUf37xetYPO78aC5D/QDiDEiO+2wqljEb/TMQsXy3f4P
BHaoWdH/9A6xlCPeI541ElQW7NFH9aHTgq9oOkLh8vSbpZM7dizy7N+orBWaZ2K7QbOBYCJrPqkr
OJLnIkU0j/6BiD3Lu4o1dQa0VD/qeH912tQZdGA6CGLM6PoB0gm5/LaSbiUyQdgpSW1o0YsxzAS8
vOqPUlGblciqvvSNSkg9JPr3JPlhbTKJagC9tO7kOg0nz04IRiBlE15kxByUXiUHiNvGUYK0iTie
6wYbdAT1wFZNMh4gSde8zbThSecG01OJt8LQtqVyFik1Bcx9uDKHU/0fr+i8LtolbLbg+KS42tl2
j5WQg2qLgkQTj55IqCNUhk8cUVqMi/P6ZbSYbYPD4xUwHkYlUAVK5o+a53MQTf3VRR4Go1GaEvzm
o+gxg94yu3B8HmQnj5aqvhLjgMktZa1iuoThN0N0MfWY2k74cxPuIiY9ihiKK1HxW7lnr1JEgY1v
oyTfqGqGwXGAoodStlv2h+0MFCQlnMqpxSWpKnsy6940yVJxTCrygqiiWuAzBEx5A/IVqBF2Uo8f
beFpjqeBnUqUVM2X/Fj5oVF5VoYxjxeAbfB6+k93eGGJZYMvOzVYpy3MmbHnsj6NWaFlXLDd3Vbz
ZjhokD38cWyuNnc4VcD2fL/nusdtj7+y7xHhbbIQ8NpzyQKBHYxq5qsAZPcmjLKHjuFDNWa6E2O4
nYmgjmEXM07Dr4nrxpinSXcOSAkh4BwCPlZCIwYjpWATGZV8L+MSYLvzERxsV6LNnIs/lvsy18Ap
HimuSrnMDq1LSU7E4bqVpQM/x1IJu8tJZXsY39kH6+osPK0I6Emr3I2i4nw6p8lG3RajZSfSTcRa
c7SHr2PMrlBKgfkxSj35iQPauaThdKIeGuq9/NvtWakiqibfaCbbXexrQRIZYnHbfGss5mshi/4l
8MYIzFpI3L4pUEtIcZLOqAHWJ2cO8tW/U6ppaBNK6DUq8dsv8g7QJqa7iA7h0ms2FaOfX+wVo0cQ
qGq01Ol0/DvwpAUPH6uKSFC8LVthqOVEvS4A9Iux6j8WnC9fk5EgIH8eaKH6+bTCLZxJB3SWcfIZ
yiTKN9rE2aabcy+CcyUZe6Hk+CujBW+HW8JKdvk0p//Cw/mmSMueeN1dNplpqYR4EkuAskh1/WoP
WD5BLf1s6A6QgjQ9pN3fAa1xu3USjMe2Rihw0hGxoTr6GSbl1mT4+bDlRKrfZQevo7xVUMY2mmN6
WY2OkAsc/OnkMmQ+ToekgsAddMr3AyGXWy14wjwi8OnQFTPwoIPpl4/9JmNaZyqegQ3ILzRj1ztE
+JdNj1umzIcCkYuF+Vd6JFcb0kjhqfh0CxQ5HGDxE05rcugDBE1SKg4/xvW8y3PEwg1nnJr9FAhG
JmjlbIKX1ExPG0H2XwXq7Xz91374s7FjNev2pEKEA2Eqa5h5ZX+WSlb0TGaGD16o7mt5sj8zHzvX
hHV3e1YK432d0BAPsoodDTl/5VVq64GQPSV73y/LhI0S5JBgysOiw9Y9Mbq9TiRUaMNWdmCJ/nES
82ugCt1tJUXayBa42cZ8G8yULOwvKJiTUV7Q8FKMTNiGsxGwnngICLbCCGD+dg20HL//1bbZdXzx
5vTsIpwKMxPqMNBbT+eG1iFoZIPTJyDQ42IQtgSmQ2zip8hgisMprmFHipou9zBmw24eisGoMpOm
k7Wkj9wMwvEQ6uI0LH2X4xa+2ZrReQxSwBoP1eFtUZbTTt+bQrxr+S8I1V7F8ibwYYJoySK3VWyv
xypqn22Er938dihgxD9riK/MRbW6QVlSmVEmaqHgiTJM6ijCHcqLPEMdAAsdMF56VnEv5XOkbKYQ
iytzHKBEehk54ZmoJCdfAOs9xTox3fOjiQHT+rZh8Cf2E12YOfjBcGtbNiduw3GGmExgmjNUP675
7weCurkHT//c1gvVkeiNWrT1oHB+VN56yfn/S5q9oWwOXeGa2B0DxI7XHoHWo9iptRDikO3dpIk8
YJ29lwAnEKJWJFKygZkKaIst2t1yBB8MtVK/14tjk0UxZvX6etU4aQBzMzfE+V2dPY2S/yBKxFiB
WyqgA5ZMqnmqBvNvw+eRpphuVhGSf1mF95OaN85wg4jYGUXbq9ZHztbRYfMjcjKrLLT5RJ3068VH
RWZ6TUjM7Zm6n3l/pW6Ukui50Qv4Ly43A74ty4EM8MBNRqNLu6JSuHUsZd8xKgN9s7rCA3WRBgBD
KuGjzfR/0GQCEoj/cM6RjMlhzU5kyuhVYufJBDl90kZoR1GkyVRWQMLvk2rQxpYktvfLBHT6PXDT
Ui4Cq47Urge9Z2AJxJUe7vF4Fov041BNpwZOwqKAYsDyw4ylZ0sSGLJ4tkE45wtAqjaMc2Gmlg/S
HESeK3+YjfOgL56pMaBP3SY4EoHpQbZulL/xUwaiFWlEuBASsnG9iBYmQK8JBwgKsatknr4HC1pc
VSwKMHSWiisL8h3Ix17UN442DtSrrLNSgne4RovqCWtFOugTqDYJLRp3vulgCRKLUIqIMX5kdfKu
cxzFYXkFOfM02aDdni1TiUMiBsIvuoiuOhbEPmUou28zNXdclA3zRcihurTuZDf3zsiVSZYuaRLi
oTaFSUHHkI0sjdg9wbUpmJ2D3uk9vdbN3eq/0vyJlUGObHv0I89fhjxwaLLxhyK7GWo1iaLQ565f
o3P7tB+I+D/U1dJNVItjVHbfhRHNfTasFYILSP06vpWLul71eBd8gmtIv2FkYgwQIDR7gYeMcJJI
SHo/b16NNGGUIgvbOebIb2/ZWZNFIqgJBbDPNlDCBk+Arpi5oZDjL1IJ5UPYKhddo525EkHmNRie
PCgNRHxwXjmnTElQ9rc1IiWogvoMbXtPew0qd1gW71ZyyKWJDSJXj0IxiyjD6Z3E//vwMvQow5PI
3uaBE7+p2d8Z+uossVaWTUXLVDPVuQsgzzbZigcUmDw/eCOmb3Ndcfk5u9IcoMQ2OBlSYzM0KMzg
6dTyOkvQ7aNRLceY+XP86uFzdBa1InLt7fr2AARy9VUZVaL/ELYqm4PIZIlzwJvsxY+QEFIx18EV
OwmD0CpQz/Nkh06OXsroweo2cTXLCvsRrL+P+nm6c1srnlNZWAyRz6df8GJhpC1VXNdSZUtH+CZw
IVzm3yhMOSa4YabzwJeAy5UL6LeASLzrQDZvsCrCDbzdgzMes2mAXcQNjkoFuvrz2g1KZwWednd6
b3iorlfpS4twQMrPpQ79pDH32PD7uFNsImKkZAoZg+dZPPMJx5+BnNT3PwMLHkbSB9+3XYUITOtr
r9ijKStrujNasB0QkG3c9+2Q+d3MrTv+8OOKQWT5Mxw67IK9q49fF+ZSCF3zZy68ziixg17PrntI
dh4l/thjpXgYV8E7H+5BtHCJX2Ghzz7L41kIPQThxaF0iD6Afg9FU58vF2j+lI0AFo9LzQXKH9Z4
LSU0BIYCLh8fwGfvORH9dUmRo0FY+3ziAR4+aP5yo5Yjj3ERaf4hC+xy5zWB4DtP9JoZBVh/e5xx
pJJb5GRXNh2H7+VStk1FWeheR5QmpfGjiiKl2g7srw2b+faAPT0EZxYZim3Og4RzSqj2lrNwv/7J
vCt7PWB3F4IoKUIiBUt5LEkZdlqlPf3QUrTvcqHHCeEgifVGLhfUHkWOCdSR47SiACbHxihQ9csd
GjehAzSElSX/TAdyy/6TfREBqFE6VuFWdWLTF/xR6rndHwwxocY3Yr9AcaOF9WJxs9bwK8ybigdQ
gn65jdXYEz0Vbxg6RgIQlmUg1lpPrSyyw1oJLa8D62f8BYXv3HWdPertftq2AtZnWBmShatp3O/c
4a9nCrxYUxdS04a1gLwOVg/pIUx/JIRqnyjH+BK8c+X2IVY7Jt20VZahmPjOLcOECEuvDv7i9un9
K6CTWLbnHCB4STYV3PRKTZ8rAmm5srV05iEEOG+FPe+RFlY89DOXXSA2C7m94KOOmuTK6BoMJQ7P
QfM7tBNamBu5bDjtTq1W7tPQinFJOlLGa+J9xskhbm1FTpWdmYB5IDMUupomEp1j8fR1R7B/9HIB
/7QrTQRRdDSsgayg8s1lhxqMMOlQtyUAN+WsYx/+NEAyuUkMDgh1z3806B/xymtHWUTFPFqZHT5j
rIDgNrHIXa7Zsuqr8NDUVaKQkXJK+faBkqQo6eifhSZs1eeWjLdqGDERLe1FZ8NyvplwyPgnGfqw
KTiyBFFUOKzTWAJS8NTncjilLHBWYQEgSOTm7m4hk/VPSRoZZ3yfUavN/7aUY2fvPij2yp3Sae5b
pmnAkpK2TryqbhGNHpHS4n9RtOwYIe8XLJwNroIecPMlnF2miCkqhJch6IMoFoS5+FwhHjR5j+rv
fK5PQIELOGgbOx1xYfsrivbu4yPyH3v12x9ThSuAlPIyum23z7Yxtx7G+iIKmTLV3HIrxJ03qVY/
zKZBuz8w9xUC5uEVTNe0oKVxYe21BfSrFMFzjlsbrYGs4fzmHZpbSkup27vNH9VKlXt5oGB5cwqD
lIqoK89KjmczCFpVNZe7w4KLSZplR+EP/jvG66jqnRDJ3xFHTbyLmqkC9CcW98x/vuVTrwtK6ak2
QMDzuLnf+MOJB1PbY7qj8P55PMwDK6iQQUW6IHDTpwsGFs5WfeccCJtlE3zBFTUpGD7jzswduBaB
0655/dpEUYFWGcYwK1r3vO9kUFi9mN5bLpve65NesIYvb1ERh9kM08XKlvZgaZtd+KYL8TjOqYDS
RFakfWsUZiocyya3XeIjS6asP/PuNDxQt/D7HeZcGfzJjd3FkiqQnO1DaBNdtnaSWAX5Aa97188B
kShCuQvbmwHSG3AYbF62SUQpAWv77Yk5dXaGNjaSONs/zhwsUIfyg0dJJA+3LKzdw217fQcLYPHC
vpFzGB6leClfWdgEz8fCkbXtSfLeasLT7vtCKCWwlaoeVlm5aBX7IKqxaDDNbtG7FIYH/kzRh2Jb
jNyvsheZ/fNLECzzuK514d6+Hhf4Iv2lPaUzoc/CsdJhQyXPkwZ9JPEOWhJZdI/3xjx9khO/NTNI
B85LJVq1HmPnDeU9yl+9K68HYsexqzXYfdChsH+7gPb1U1UdmwXS/hkrd5ka7qfDXgxiTJHOwJgD
evlhy2R6n9+vqbCY0nu6wsbLfQ7tiE/WoM2KnqqnrQQIA2FdKamvZGyvLxIGQzojKhDTWHLjCves
fEDCfBe7fdaohaIrJ3VHSNlE+fM69X335cC3d9+/r49C5lv52Di85RGtAlp1DQl4sqmZKHWB4mIi
T0SLVhiN4/q+QJC+5IjVk9Ql3jqO0Mayio9fNbaYPOk5E+r/4AOsZU1yVR7cVFGojQDF/dJ0H3TI
PiFF5ThsLlA/slohbGv7RwvhP8vWx1ac8LhzwLDyAir0xzy36i9hPh1PU3sF4E8yNAHSkGTG1yAA
R41rb4rGE6CTKnJieRhtMy+XyCZWGVjb+CxkQ44ZOuv8+kENXt72iUIMV78ybxjPZQf3YLRI8Am9
ByTxgJeqgpUl0wSGEv8/q4jg70l6nUj6yDyS9uuKO4P+YDsC32R9P7R8BaQul+7NA4Ar20JvmmAz
jTDYa3BJivAKT22lA2EMzJCWq6E7ei8ojIIjSk7bRGQt9P7dzhpRgBb/Q8EA/y1chyp61JXh7MzV
8UtHSEknFiEerHRAjiRUVUnXCRSB3Iss8kerC0RUw2QFeSPYKFTttL3qM+IzXHaQvI6Bspxe+Lcd
YlIdj3qYiczfDRE+LP8ZXDfbgnYqpuCxPO2Vq2klWeJOMGgnEEiCE6nUhDKWG87S2Qt8YYxCUn9j
kZ3VZzTOgmwA0gHMEW6cDWmwLmN/fYbfoQOsGCCZJ3gdU7bmUc7y9+64dfifws5o7kBnw6e1P6Nl
N4rDXPtGPPmM9B8npsxYF1C7vmYqEneeJAbDeHwLEB9RjDcHnsg7rY/74P65x3Nghr7nh3yPzcw9
gxGNeeCJxuyOBj0Ja90MPc/TTSfpAfvmQRkP4OotyRBJVCMc9M+NuGNX3xB9HL+bwgEXFEi+zFlp
Tfcd6GMPGpcxX/MksuxmtcltjC6c4dutTgrcxMO4TvrRIL+ADxhf6wZZzOaROKOeUCEbXJFJIFIS
Gv9E0pA3suLiNzHQD87p7QS3UYNZ7cZicXJz+2N2T9e486E7K3ysnHVzI5Amt+WeWDEGt2J+4mSx
WxCWNvAK/MB2gDeN8c94x2GMhMaKb/s+01RYWlpTBk0xV8lacQoJpNwmRZTYIx3SnXw3aKSZ4bBW
G5BCDVtn8Fti47206um9JZeSb2KMXpH1fzHeYrqQVJVILPFaDLXGEhLanqgvM0+hdBmcQfnu9Dtl
lSt8+b2tSpW7hTMkA6r6APAv6y0i0rsqwbsbHoOre1+uOL7goY/U3zbIxUmsnWzzkbIPohk0skvh
L/B2Fdpi9Qk4UI5VklFmeSEuH7E0eDLSu9cXFndHOHhpcNK68GEZzuDDaw2mh00P4kOfuCpUc/02
CVR9fXCWuSkhI5tNVHPCRgxX1lRop4BHfBB+adxLXs4cupuK+UX2gXi3F35VoLGEEsclsaVX2ViZ
JTv0WxrnNPDszc5cBmJHxcisVrgoqyVUcTdYx+lc0DIZOJeKtHy1tqZIrKHWybjAdrSRrX2g4KA8
khoAsAZi7Fl0lvbJM1vBk268nfGWwgZDj0/ySDt0WVdUVwd8P0wswAKXLOELKtds4RaVkerD7Adr
8JYz7DtyjAC+3LPCDL5RDczlGnd0h3maLoS6W7M7Qnw1IIwUwWr3tvQOmWC5h6Q8j3PH0e/N2tmY
Awm5EVwt5N40Nu3G9kSUYFhFiiJejJfVARJFLNfSMGAdbL0TMdPSLmwxSFe6R49Ct1n2ecE7fieG
fgKYVlBQLDYHZSpJtQCYs5QDRHHJ/Fqo41PBVovOJDNBzm1uBPkc/WWrwZNjI3EnpeiKSTmzZXQZ
4vOk+ZF7HJ/oAYhnbfhMzSGJmXzmMmoeaLq6j0oVjjEZrM9leM1/1RQwYZoIKagOaiVu2ffbggoe
LXZNgyOQ3I6oR7I6RaXV1EJCZFJrq/3jwp0La+NQUhVoxHXMKSZzlYXkypJDCOa04+ekZpQE+sAO
3IXUsFia1IflLTJXOauBb8QbyEH4QG4hCZgf3EXASCiZ9kAy4hoH5JPnC1lxxK4kQvaiQ9F2fscM
Pv+HSL0PVmbAKTd2f72uE7CjcZ08D4GT0RSMOQnfWNVtcM/QL3aUIy2uXjMAHzNBKeGyNTYhuBLn
wxr55j54SwyhvzbVYbenM8QfP4VRhfmGV8TUVBEzx/fN/dcXCYjBbKvNu+tCaZFiwxKBQ4/IoANZ
E5cN/up84mbQEz0Tfg8tF6nn9nAD0Tem+t1F08JZDu1JUtrQawS2+hZpLSgDq+pkMIQjgs6skF1N
5PIADDfu/yu4NhjKLSIrV3o5I6mVcFbMzkcIj2KlkPr3/+o9KFZewXyzg8w4M44pP8NlpMkwqsdF
w+dM3P9BPWGeoU7f2RT3DWNIUvJN+7b1IzFjpGYe6qhgk3gSOnbNztK78/9pYzApkVBDP0OR7pHw
D+fwOBtMQCpq8pbhrsyxiExLiZ9B0DmqjDFoS5VCvEBoxUIY1mF1GMzHCVRrVDUbn5gIeCEL/vmc
qjkVO1FnoQ/Vbjsa9ApOHwmi+BH3r1y27BCa2QckDOXwGGzERkLvNxGvGI2eBSCoNJFiv8aTAdZG
XyrDna1m2Gv3Ae7FtBYhj+JIfW5J6Jh92ctM8r+h2YLy7vDh/q40wAm254Vt04QBDujMSP2vK/wL
T4AfEdG54SXqOu1Fbma6xtEYPDZsBswZ11Nwn6rpEVamg10KxsmV4L1ueyOYjiNzNSbkOHaarb5w
706v41JHs5elNHnCT76Su0sypjglEG1XUY4G/NFcjFyk3nQzphhgEQw+Ho1QQl06LGFPNCwd+OB5
AhMW55MMNjuVmQerppmKFbazuoivUXckccOs7kyijVyDQd56vvP10Xb8z+DG+P6XxxKnG22BUfIG
tXL4QSaCkgVgBjUoCMvOWHkKkqWrE9WVySMn5jVSXoER06tYZ+OJgT3FbWJ1ADi2F6f1nD3wdpiA
33MKVD0iKcMUwD0DZmLN8jZbSXmwp3gxYIGzxho/8gBWLxP8Z7uwoUt6Ypm3v1Sl9DG9KJKoQ2EJ
ar9oZCF9icGc+sA7zQKR4nRuq/IiSCJ0CVOxixSsCb8BH+M4hHSCKEj3v4NTeHS9qSbzy/9Kntgo
JzaGQsuHSIO2ZrHI4CgWPtEUBmKdSFUhvhahz6XU28ColE5zImglYxULFNzzHBLlVnpZIytpcBzy
Wn70pExU2l/AGaD+GzKxvCVclu1gNVMSF4I8P9Buf2167wcXjIzS9GSWcHoDMsKFQ+fQVdoJWq/W
KEyNeWXdREy28g5dDsrTUUuUq2n8o+d/g/AfWs59urHgkd1am8jx9tlLPKF9znOhJKQAbSreKh2B
J4t0f0wBaNSfV5RL51y0Vk2u2P5rXht2LTlMW5tIfx1gbHxBpu9BwPMcVXpzWPtjfI4FgkKH4fJl
VYwbjazTjrdaV74wjHH6GHtM+kzZ9gzZk3n80E0A7CWMZligM+sR7ifTyYHYG/qjsqfJkc8Ns8C3
l3ygOppUtc6G+NSSAOMg1PHrodryhyh9VYxv7c4v/UHDfLjMDmOYirNFpmHpsecowu0bvzg13Rom
H8lUs+8ca6O1mYeWLZ4m10vSi1ALMt4oGRyhwYgpaIqSJ+sSqCrJ6j/yThxTcSxzl06la6+/2qFm
LD6ds53ZruSIIVwxm9amzQSN1covyX0EByYKQWp9ALGcHeE9h9HblzCYg14RkTAWb8eH1vPZsjwM
Zcb0NhZCtppI+4yIPe6EVkrr7gJ7fbx/a/dsd9sVT/6EvnI9MHzc0yHFqnQCSG0iWu4v3HFu3a5J
rNhT6twpoLhLZvxgY0SAyUAB16FIvrIzz9H+PBl9ksova0/HkQNzXT/9dXF5VoDNzmVX6xerpDDU
vzy+6Jr94I4QGO0EElGUXtpA/S9BC1pvSwml/rmxfuPfl5GiKNZSMnDLzT7g6+T93uPIIY/mAd+4
lUk+JNPyWcK+AvKOr5SCFmxGqQBJ34a/w7hj22Vi1bSnvWzsujlYt5YE6aDoShrSmRvkNsdzpOIs
wrqGCGbtrG8Xx3jiFxDNJbetb7LR0BWOLMBeiPqqvnhzTHjxaUkYqfhbReeA6tLDhyiW99s2SuM7
fBuAXlNIi5eYweflSeXGwOT0wwJN2aV8Hi5RUoiy0zchHx9xkbthUUsb9NEc+5wUs+cPRhAHCAnW
1kpAgDUv4kInRyA9GRWaT2SosOwgiJJErSuRRyB2z+zxpLLi+TLYKEu5BZnzRcRVqIE2yn/A4+PN
6d0juG3mbEwR1GDtPZNfNur+udsUC3ktBNqV1FeHWiCpkzuIX673AZT0cIkv7gfnG5LgQbkFbUqi
DB7MVns04oIwzC9rK/RoRg6jRKOSr5+fSydHhBmmMNaReQ6BXd4AcSf6flZWAWqP7p+QHEM6IP9E
/pc5ai5N4If0iNqHTNBpP+Oe+SPAXc06dyR84An5tEppM7yceZXG8+riAL+Wk6sV35xnvfYw4rka
e9mt83KR3PUcFBMHkT7FhnYiapWYS+dUKUqPzHqdJQ6AxQvudTPP2yYJD40GMK6h0+PdwlsXY3rd
pP4Uewy8TSNVswf4QkRMWxdvd1AfVblDwYMuOA/ziWw5kfQpaOWMUeADeO9Z4vOB8xN1vPn8W2ju
SeCTWvvhv7WmSNJAXgofOu9+WSXejVlKZ0NE3cLjrSrOdOOB13DLUrpGExXtsqtKKLrUlLp4h9ZA
LOVQQ25t6TnGiLa0C6lK/vQoM/15JiDrblBSb4uMvbM0MkypjKRs8eABZ6D4HtdY/q4kBcqh1PE0
MwTt/r5PCvJS7qri+x2cIonsFUYwtzbP/6Nw078rPRN//sYRXR2fEazr4tctLNsBE15E1jlj6XMc
aBs/tzcgnlvj9mw1tXsAyVvOcTLBjS78Er1vOOsuEs9SY0m7Xqb9xQ3dGC8rYYQuYBtq+i2k/qNu
j26UzZb4LkDGe50U1ui09Y2m4pPOpDASEZ5eu72erYfPgA2OzialXuPGIQpomtXY4x5jpI70yfoZ
4FA3V9zntZHuWcxyv/rJCRJOnCD1oCeddoFNMDaRIAlXJPe1LwFPko2HDDWG2Bk6/Pn8Q6/ND4UX
tsyu17ytqYrI4pox8xiBJ74mbgHCjn/JEp6Z8AKIRSBP6JXSbsqRoWCgC3KAf2MYRBb/pI+PtD8z
ztiF/ooeK8MMc/z+BlaBS5B7IQmBW5HKt1X/8Ev9OdKcgtrQSIvabbAlbUSjKDE9IG8C2SG4vm2X
Prs7LD6Toq2tdlLSy2I1fGL71VX7GsH/nst1qNkR+tqG2Z5WziKx71C+iczrSAUHG90f0YNnXQIj
foTe0DkVz4cgJrBn4ONz9BK5q/uWVT2UrnFx44uZ/l5KkakpepqOSiMW529lgbdCq4cNBS89oVJk
804+nkxrW5RTavxxnrnzbRnxIcjCeFOWDY7oUnp2iZJdmvwbHhrEefXyEv69DIu1noC7nkzqwZSj
k+PEgcqWNomH15o4C2gDx7q7LLvR/lM0GmWCkcQCUXW7urTmH/v5qUtKdOj5RYfOISYUY/HrwkfO
moTdVHKk4A8e0wJbHJwxT1e/SDfCP/PDC2vcOW1N3+kblfOhLil/facixVovLakPEN6d0XS4lC/D
UiHCHAuSnOghQg1sGd+F7gH+5a+4eELY2JzHrBSmlyN6MbAUyhtY0Evl5Dwq6LAbWMVF92xykG1p
P2EKLdxw6Dn+BWC3VU/TNjdTr28XxYdsJbr8ijanxlRfDKOcumPZMeK/aQWP/OsPjbDXw6Uyv7nc
I4nIW/0kdjL+XnDbu2hALpXOe+aqLYYEFpOTNuoxBnM4xfPnCfcZtKn79kDRFgnoShOZ2JcXHmBe
ks7k3uLbBdikbWtI5DP8uGlFu28Y0C3fyrz9YK/aiyOWUSLcVsBn5LFw/h/qlTZeYWy5KUgdbBNZ
ZF+ZB+kjnD86xUuW6HrwWRjJbHs0tLOz1gzfGkR4NrE/z2XhIp946dKCQZTNoLbDCy3SCrRYKyrH
Fu7DmzMokkkkMqrP5n5HvQU1MFTRJXz7em1acX508IRBDbR1Fr+mLEQUttmbWVzh7ivG5Mm99Kng
qX8t14Hnw7ocyHb0hhQNBUQFUIBE8QAD4Gzp+49VB2V8sp3FAYXiBidNoGV10u+wTdUXyKtQ9oFU
Pjfx0cDpoqdaGQYd9AGlXd4cQJ1y6212eesxd8VIr6/jJnMLfQx7JRWP12dw99WRzcChwC4SwDKm
twyPY/8RJAdUyLVNV5Mmv6SQDHoxU7B4gJjGggUuQlNWkWhyXbpIs08AEmHl+sou7FftKVXa9j6a
AsvIeE/+K8CTHJniDPr5f3bbIH6m1ymKPpL7V4pXKKp7rS1Tk1RuNDt8z7kl+6oiF3nmg4g3Rd+8
Yt4PCJBjCgW70Bqi6fPuTekA3oV0pkG2qzR7nuOAKgl0YDRdD/s6l8axPvOaAUonB0Gb56rgk30B
x1xD66fd92C+kWa8J9vxUZu8vlAom7q3QrkWxeq4gmPxrFijXuOHu/HFplEA20e9bFDEPv59ZyDE
YvwO1i8HlaA7m1z35UmDckPyNEZdutgyd108Cm8WNmmLcvpSxDu3gOmkLEDUPT1WkVYAaiA90hLG
aH/gnCXvTz2y+lxqKIAuo9EIVcZ+IbRu+szLeEoYYJhHHyGZuS1fgrfIqKDdnki590OJZ7fQUdp/
x1KPZatvmYzw7NUXJZYJfEI6rytMBQm0yxTCsM+APfObZmpH2NTAuJ0h9YjWG3CtRQB9fEzoXF/U
FCgsOevOFOL5T47M1BHsSReBFDUzX7hbfQiADaiE2OEA7XszQkg8UmUrZtBh+Q16W4wHH/OnU7kr
Mzpk1iPxiLZlJFeMs4RS37Z4FZe/4F8LoGkoILYLkYXPOUPoIFWXGCEm3HpKH5ewq8Nl08QHW0aZ
zJgtzkNANISE+vU9MaHRLDeTbddJ1EpbHVQwdkyaxLUUR+l6xlBoIzpdxzpXnwMJfg14HL2c83fW
8tzSYBKQxXmEtk4J+DYazZkKHGdYseQu4X2FKr6alifjVyKYOOBtJPv2PMlnquX+s9JGAvOxXGmq
Q7xoIepXttlEGboq8w029Lqb2FgPbYNCBIFcYiyoefzo0Sl80HeKASv3D8MH3gsT7wRHedlb8+MU
JdiHiV/Hi9xPFTtf6FA7WVw6uf4Y8No1kIBBdTrlaqFz4OJ3tleNU6lpbPvaKu4qtmby+Ui/WvCf
DwWy7fANRWtNNMXL9XgrqCnVCN7RWWBG4f/FevdJpCJomUnheUzOB0nKwEwze8pju1cXPImaZliW
C1km3hqY/PSsccD0M9BlES6qrebJO2yyDmBtRygOK4nU7kZlv8U0LqQJy9upgsCVhP/WM5I29VZm
G7PNxaRG9H8r0bpLAZ8dd9Enzq2rW0bQ16xWixm9vesjb2DiBZpvr8IpC6zc7KMFjiFrGmYGUOEc
x5S9bpVA2ygF3fNSa2Am1zNdQdqn48Gi2YVZFA7o6l+Liphs28HrZ5Z5LPeFSiqNw07IhD1RqwK9
F/Te3edq1DwXMfK3cDxXs7c5Lt86Wb2fdZ7MYIpisMOflyl7D4fttzsVZln5F9P0iIlmaH4cdTDh
dThMGdE/4KDFNVrqbkGP3+I8+1/7bYIYkA+BHltaF2Yo/YcXhFgAdLU7YlHo3VBY6q/rP2ZQ6Tn0
T3pgrd73wCXgtCiHVWFKlTNgdxeZXSp4Ft7J54lb1g391iIlBtvkQC9ngcwBmSw8Mu/SYarVRam+
syiSzkK6fva5JzKlijlLx97mUeZqLhjAomqQSV021Fs/CiZADhv2de2UOCulWLEHBs423spvT5ol
xeEsUZZmjdsOO72HR/HQ9VwEB3zwpc8q1xsrG7YZTN/ZdjU24bagKFA6FLy6BaiyceIs7/Q1S75Y
RWOp7NU5j8WwjCfcI24lHEhGS4Kutkw68R9qshoF0bzvgzV6P5HqDXT07rgMYi6sFxjqm2G2/W5A
TferJDjIZtyjU7P9WHbQHGq/lwx1lHvrFTgCTPqxCoi2stPrtCSz9EcdwddIgEHFUczFBAAmaOvy
cT0A0aDMinGS7K3PGZhBRUVyU/wARLOfePtBAzQooauYYnB698dzzwMw1aQ4pBx7347+Zxr7mh+b
OtC5F0Fn7+sKLutts5SuE3ZsxZIvJBE655wFXE5Fiq/9BX/pz6YzCRZwFMOlrZ42jQqGdMitIrTL
S2n5dDm/MXyDcc7H3dJFLBKTRlbYI4d3uneoPuA4t38RQ06gXfuaUvBV0vSXFC9MYnDMA2L9fCFR
Y2YIeTAj/FhFNjRvAZbDrPHAykOnYcNM6vi1hz4BC6dYt+K+HWejI64a2wTVbwEFFEg1OFitZ2zY
3H4sjEi+c8+GgKnKN1d3Decv8B1NsiTu8SjJfM+ZM1geWD6Snymbb3YCBMRgSPLLU3DHy9j60d5I
4S/4TWJHCoMmQ2etu1MQK9Vq74s5vgEC33Y2PBuriMKfAMKh8Y7/iiwUuqIV3OwL/Fruoz2NSqY4
A+3Y74Kys+b2toHqjFWAS6U2/g07CV17YlK4+31hZOx4pfED4+Wh8iEQ8r5/E4EguuL+mkeZvZHH
93h0/fiIWE8+Vy9H9nY29QdnmUU9t0os7egGycXyPk8WgPRk3yqpBcHcNwclLDCCpmmrqZ4GKfBm
8NQhXOXC/cFzdBtfppK5WWYykku9K9NtQCSPUav43C4PKVdLoLWA/nEwbygy5cEl3ys6pnK4q8Xh
N7TJNlM2wQ2DZVmhsqh7VdzGlZxq1DBphJvryt7HIZzu57les6sNorPmf6OYadG/iLLCFTq7F4KA
sPDQlhBapwYQbxDkSk5FdGD4i/tpZqUrwQQwgOpDnySYPwxF4WFyThdcE/pGtLVkg0OouMk01HQ+
5k35BlxrJK+rOqGQEXs+xw//QLdwn8/UbZkyZ9p28Jddl/KZNRn7lKeD88LL2dfY7BkD0wOUghWo
JCCa0RgN7Me1pY4SrNrmT5zlRpKDxxLAXzs4QaazomlPsVe1R+wqjNfvWlR1j8LSspHGI0+H01X8
IROVeddIlaGR1v36nPE/8sUfVmTViLLWJPWYZ26DUyJYnFCp26pk+nXtW3mS3SdhbSkLqem5uM1t
16abyCEcPew11IIENUfXUfaGXv7RS2qn7YkvxBlYApIQVYFKbyuW1wVt2sqEboC7VMJi3YzJY2Gq
zsibbZTi/vC0BmZrm8MmvNWdB64fleOUrnYp3TDUkRrK8jRlFCi1BI6+wJMHYbXknfc0wcwQYcx0
/mV16NQm2NicUqDMGMRInh8X3hEicQgPeCFYMfjsfU/tPKBHoaCZfr2qbLNPKS/BrexSyBvMReJX
ui1qeK6fGGTDIIGZ3L8G1c/kfHejga8/B7yybBOUDuxXW4nTFnrWjHrwKysyccg8FJ48CSl6lf2d
aB9VmM6Z3ke9bHE6oJzHeePpGuPV4Ht307hfkG2X/lVSN3ZASaAjknqAaUtYuUYRMFolGI4SaZ8k
hT/xBkN33X650HtRZnb9bY69Zi80a0a64et/cK+s6O9bFM3z4YuDOhgB/2rnrluonVGwGScgRnNl
wyekGP2JLrqMEH/PPmYmqYgdsEEFLf7H9eKYoHw3mHOFKSlNclzxs/pKUxGghOckQmcfHeICw983
nnvD/4gz2dlfu0mtaj/I7rW+rM+o4mwbvTyqNi77VFAhYSgoLwDrVxzzMvS89XhGNzITjyOdY6D+
L9Ptx11R/BKnEcejOHPTxIFM64A+0YD49oy1XHIcyqGOIMn/MqbdxtP5Kuw5sEUT1I2RL38ni4Dc
xbL7OwbCPzU3yExT07cxFrCV1AYHe5DjXeJBA5nDEpTQfSm2TgbcKorqpyIHz8gynOxznyhn/fnl
6gX1jSUkHUCAS5nEC+qn8fL6hu/kXHHRIkR7veC0Tx25eJbriveZUs8DbYVHu2cAwszKx63M+aaA
apB0HzgH1tAu5yazQQlaI6VH7ZzfmjfDme8v7gOgV1iAXilGPAk9q6zaNWpv7A+YSKfgb3H7gwYe
ZVAcGEWT9X1sOmrVXGEahz7t+eZ6pBlLXRb+4jmMRjbRF+MYWa8azILIrWtyDuHaJ6oG6dNQJbM+
4197FhCvA1UCWEyj4riVFJ8/sjq8kaOWSQqlmJCOr68LrBdO52EEGxhew/wuiX29ZHdDtlPqACAI
ggBBjULIIMy84J7wQyBOFZZ3tOjvQ8lp9qkK/gbMNzIeNPcT5lGFKZQfu8N2exqJs3zCbdSWITsB
sec8A8nJ75Jfv7d3+D7K1TBOoG0TbcsD5wgBYzXnNmSv8TF5Hb1O6r3m6ixs/YLasNY95eWQ3pIx
IsfTN89WtoCvp/PaQShg31CZD8xp3ukvxbGVM8SQieo/EuQ9oulP49nMo/u9SkmySqugcxLYt5DO
kID/WTgRlQ8LoR+bCeWDl6p96ZUqc1KU/eKsbjNBBLwErDKwBQCkHuWzGwpwcSg8xRuExLjgyTTF
JANAQUO2GtpuLF8hFnWwFTUC350vmeKKcNKQrNPKVDHc2obk0IQQVrHSyYdkNG3fN0fKUgwCo3sN
dduvZMK4wFZxBQ0LpJoXDWsFc9KGd8K2O2hXG5vN5Xt3Oz5vIL22jekiJCx/Fv806bnguOgXhUkk
vsCgemorF7LxPl9dw84QUeph8DADgJTMqbjKQV6gZAh3VpsHlpTXmgjsOwSC1GdV/d3SNnUH2syE
bZO1ne2sP3RPpckHUEIzMjRKFoYHBY67panzwLcIr8WKlGXnvyGxY7EVi1KpBu1e+7HnUmSpA9Iw
I6YRWTFM+8QRVmf3g0jJc1RB9l6gfqzvRWJOKeb17crRuOC1pI0GVpAJcFIt4SyRppqwr7w2qrFP
HkejYaUCrPai1U6/aBhaN9yn3UTgdQh5Qa1DnUM+/TS/Kn4D6LL2FdxNnB5fcxcuIdhA2uAfhpL0
RYELUCWrmgRH3qeDZLdZqlZuVBWcefhb0Pk6kRYKdw5vlI76D2GPECNV4ioWzW8UfFLGWYbEOk6B
VqZWDhU+TxUMY6OFWntE8jtuccayDQIuBFqcSlr2RX9ZRvu+DQ11YcgNHJVD5XeisxRO4MFVbAXY
zyOWqnuHPgFYgFUlV0nDcMIqSkDJsdFeITpeBEKN3ChXJcCMLXVHdPC3N8+iWLXDnujkTWdYTYvu
FsXMzGO9zbC1q6fnme2uvEAgsuX5PtbmAipaMFQ7nM116hgBnlalh353lDQzOSFK3iGPmdvlgPQF
gPC0prmtoeh2FJ6eM+tNZDbXq5QRs0WSecBgAvjp7UUelVzmEGlomNCrzBAAjppL40TZwuD+VZX3
p0MWOwP5cTsmQ9EuziMkgL0FAAuZKXwt3AwNAfokBSPxkWSRP81N8rt/ztI2sictQsgnvRcaurp4
sMmWe4izOwZUGL2NxC9/kWZzUjbKSfQbkmgIug0aKwfYPEmOPR+0Za+/Br7cErfi2VHeBtxS0DbG
WZhCpIPc3IAM0TcApTi85EAw//jOiiFtUgAwL6BhczrAy5iapBKfHgploN9+Zuc6nqmFsslyX2lh
tknU+n8jLfV+mSqAKwWPRXC8GM6g7KrdIRHZIUADTjiw3XicjvjaodbzK3xKQzXPrQdF6OPgS5IR
41OS4nzgp8yGbNNOnkaH6ZAoqON/BKLEHr440Kc94PWcsHHXd1Jyl+tjJvwVE1xX4KbQ1iun6kYs
zBXdcCwvwFEb+1Dt325oQ3nMaWwQqiqmIFQjvortwalwkTan+Vjd/veyYiuOANM4qr1bIfEkJTGk
QawtWgk5N/vhk2tSqM1soMWUB/03RRBGZIApnzEK91UVWNOcFOftKJIrnMX3mgC5DzUwQGjH9mSk
O+d/ffOM1OXQPkLjBXSjwv0BinWW1Cwi7wMN7+ocqsyxkzIn47K2s/zb3iDKckuTBceF9uPTLYXP
AXS1sPOsyVVSJuljb8RJVS12WEQZl14Hjvk5ai/6Ba3ttfJi0qk4u3p//7c8qgXEgzYFmZnlGfOV
MQ5x9ivujFwsSgRJJ1l3L2PlnbJryd+NemnTFGDvhhCX2CjU8Z6udEnxn2rRIyiXKD4fx9tlQwd1
bbXT5SXgGdiOBRtwEGwGRJle2rbvUPDbtRwV1q15Kk3SCydmxe1z+tpUuT19xedNb/ojjRMUv8qR
YCgDHpjQXwi7J2uglMvubr5MOUgJuRU10Wpr1UWkXo3uJ0pvnlbcw6bsHKGMPKil94xcuu4ig+p+
WKNEa3SqQuJHf/morrtSDKlDYqXuXNWAfn1jnaYoy6Ho0fzhGoKVYgYyjwWU7QaUDiBNgdUH6/rp
+cGgYH/eW0Y3p4gVlOJToP7kuk4Mbp3L8Lm/UPRI3lUuhX7wZY3mBFm5T4GSQwF4BiVid0V7/fy7
NXQKRas5YfJL/nxq+ArARa//SvxBVcTPZMLZKfe5I7DeoRHSn1r2BUgHsCtt4VRluMjrBxNIC9EC
zNmTI+Zb8zl29zP+fIyVnt54udRMQv+B3vqQLZHtayPbHhP+5Q+PM0HlyGBFHPITj2lCxgBw4+zd
se2yte5Nqkeg9Ru6L6Nhdv4qXjNSnLp205+uXFvBcstNZ284heEvp7SZTYZ1/cT3DGM0HCJRIOZs
sOmw3xCSP/Y746ZcaMQbqM2T9KZUAYlUoKb97sOkUiKSUvZh4ZIAz626fI7eThudeo4pVZDbQw5m
2zuIvBiq75qLqDbHJgJD37L6KCwTcyA1R+zEhu2R/Rzoy4eg+xOtSJez0f+6XjHcUkBgb/TsrnPf
8O9c9gOMhrY8k3E9YIXCxARftN9XvmPTrhy89kQedwcAP2hT0u4eSC/iIJfbqZqZrphsE980+xwg
KPMjKtXwZvdnmmtvLlQPlE2nhqXDbPw1DU7+bD9GKdPdXUEOXi6zj3bkQrTFNPiqCLNEyw4dpuwN
Keg6mh4gL7ySCJi0UEMXWaBuIPnyaw03iZ9FlLPEKrHVTGPhVDX2t+uX0jTBZGwEyPqkuQppFfa7
Tj/NB4IgxdtvFCQLVGZ+SV/sHwzPRKiQqkN9tvCeLzfl1XCZnIrhq1CIjoKKY5YLZSB1LhiHM2Ed
R/Nknyg3bGU5e/lQIP6gpbP2ZWxmILyXbby2Idudlc7ykbfU56PwSHj3qwmrwidZhpsHaWie8/3F
H+aXmNyHrhMu4SRird/NRDMjnpifqsKNTSUGpUbyhEtNDlSli7121Lr5DNXDK6kuuP0XTIcnvjQt
eQTVEPtpVROzAeEOdRsGboElZ3kNpsfvjyItuCBC0gpgb/Dbum5Zsdbcb9CNTdCfiBEOx61HL/yW
dR1hNJBTx+QZZR2umTR8c+awYyUDFQGi5BHO7TQuXr/XmSruYwOCoivt8L1APV4AQsjPG1JadQ4V
i3pc7xBsQ8lGqziHEgxJ1BEUdsQlgiwZtwNN1o0evxXar3TmcmkdP+k6MiiDDWsqGaMqok4N75xi
LOMPKWt///wIu8u7fT3DiOIlPT1/CiW2O6BcLNdLGNgutYLeA3+GnTMzAYSJNbOBvrdO7Hf2H0Ki
rWBLMYIQjl8G66WB4U7C6RVzCQHPKPFiBXfVk8fKyL+5OqfeGQzPi/D6NpsB8s9TuZvsazZV27uK
5b6MIRp8hKwpAwFtfn3nN0trHrv9xSC97qNH99YxRD77CMNNkkYPb/wrJNetNEhGQVF8rJm0TO9j
5F7/B0XUydQJ6ngNXXPjrXQ8mdS5XfbBP9S3HqaxVUlWd87KCzSRgLJKYgssXgqa4ZDkwMsN2WP2
urRtAqiipJRX9SZgs49G0wvqYsH4r0/vYoAWmcBqatktsyHwAXXek0m9JrRd4ESJ2vAu3vSqFIOG
cDCyU5BHU94ac8aKd6VV0Bpzfb777nRIEJL/YC8EbqWf1SXGr130loxTDaaH66WDwH4Zbso7CSEP
8Xi/0yzDViC9OEKGl3enlEOd6g7p2+/Y1bqOX7APlaJVjdWxCtxb8QOb2lt6/aps/iYwJVa6QkB0
uSio3xTlpYd0duG7sS+pmumY0xfg5hCtPijLwSxECWdurT21eZ1n43oDAS5EaAi7OanGldoJCVRs
e6BBoGUk4G5M8rnxDtvTgBPm9psN6czbT13d+ksJL4tJ0ZI+Slu7PluDijU2lpF+oUsSQb8XfEEs
l+1pXZ5f5NhBKH34ZsBUN5ibBTP0Ofj7wEeeTuq2DdrQO/vxwlo1h3Dcviot0VNDCM1Be/znHHqS
KfizJhn+Q4YcoQO/uEF3rvoMpfsIJvJnv8/ihKtNkAwDAoNpdXQ8eVW0wFo6E38Xos9i6oLfqnTc
C9DbzHamtTvqsUtwu8cXJSAf7lMU6SBmq7sPXplejByyOiUWGrg0SXnbQoQz6h+QTQ0DAiGfasTO
T0JVn5GMxnbK/Acbk99idgE/L2LAPtaWKAU3XBvpFeVK+ilacfpScld+1aTKOQ9Drbvbicp3XMfN
iegpTY3X+3HBygCeOb4raoYOgHP9UtcGB4/x1cxipCuQLVc1Pcu8fBBPA8IqzmDLKgh3T8Cihq0i
j7eGJ1FcfYB9OWN/dpcl8WqUEpTrF6l9h+SSK6ClmOotG1z2Vo/Paz4zbi36aRfgD7cZjTPturA3
F9SuDw5aG0K0MgK9qcHYkc1wWoh6HiO0RghhVwY6H+rnKwwTwoN2tF/hYC6FoOH4BxDytK5xOp4Y
hXqH1iYq6LRCTt0YHtf2KtProrgUsHO+hnQ/Bk54Sh30T/07d8Yk8uV/UFzRzB1488sT8bFuZXce
vOKWVJxeiOSUDxfEaUeOYX1YYHeezut8Cb8iBBVa2KRKUxyPFP4d+qScURbbjhuaxa26n3bxg9iy
dgsQ+7Z3kjgOK7quAOd7Byi2nDo6sPfjshmEZnPPSUkOjH2ICIwBa2kGPsAqTLKTQSn0yIGPs0k/
ix0Cc24nb0mBqqcn45yHUnNXtzGplyCh0pD7Odi9crzuGsoB1RlutirQI4HE1Tjyltt3jRnKaUfp
Dzw3d7V5RgRvW+oeMO2nyFLGvLYpmBf98sgNqSil82SaZrjQ4EGwE5S1lb02AFUx1QkUmFM6yQXg
AqkW/R18+kZ6KX+NkIM2R1m0zv/u9EMusPOUNdz3d3jajTKgJ4jNEmLky2JtgIbB7/wXXP+GZ+e+
aveiLykb6UvjTSF84NSNRPqjNmljcqi3ocz/iz1a220L1EBda0j6GsTKAV3LWa3ZVGMREEILJAAP
priRn3wiTNHnvI/qnNP1AK3zENdOVlu/toXj5YFjPXyERvGYJYd3p6wFcLie2PEeF/c+SX1zc6HH
XrQS7A2M0NYldsWYc7w9XxrZG+EZz1DnGYe5wItXFvILjaBCfcssZYKj2w+ipN/Drj6jQamS+s7w
dL03eZ8sguOfqqhDrN0RQedRDdX6jpVQnniSZS0Btt5XMJL5pCbkCo70fOXAodLN31GKOvdX3CcF
klDny8Dgn9spmPaYQQo3jXukH4eVXjoYmX49gpOWXhzPFNW/WIvPaPUz838cG1dwid2pWgTyGKQi
uv1yyrgeTnnD3N5UR/us3dsbsJ7apzORVbreJ/OqK3zpURtb/eX0BxQna5NddxesY2HMVUCfYT1J
mi13T1cN2zNS+vTezU27VELhzOMFbghTMeom6J/5dalTnKWoL8WUhcUctSN/dY/ZJ6DjDZas9Ev/
O8HNkwxPBCS25KwV5c0ZgvhQrpBaJCNMqKI4CGWNqUCp8CRKICi8TAUQ1HFrFxd2ad9Rq+kUHqSi
qBmBadpgWtYdJKiDtjukj8YF+Z4HtMAdiSbu/09mlY6YMoN1cL9UMxUkPYzwp4B7iE6+4A/Z+2hV
dc/eCVS4jMztSstmXvNGwuePE2wgQrpjwt+RBHimsCHYqEx+ibPcfnByRiLXRNL215Ih+3tNOAIs
o8QJjsmjQDDIx1qZiwsW69KY0LJGZxPhRKfxTJw68STQ2TxC3/DjklzEAKxPrR3x7Q8AM01oe6T+
JFDyTfOoq68Mh26uZG75kl3FwG2Byk3xjnGns2cPqLyVlyCiCuqGlbYwh+TvUF+Y0ak5hYyX5hDI
1gja0Xn0VKMI2WXoaulQc96v8Vs5c/8wH/Y96HT63BPZs2JrdbgOlDR6jalmF1Ahv9HyZhPpwsH8
4OhveDTonroEHQA0h5LOIhZGCcTtPvKlQorfFYRDPIYGu3S3eds9uBC9Za+g/lKB4A8NEjNjMV+I
EGikg1+rDHHj2D8lQdD+V8b1Wn7rdDgRyrhRxM43EBAd99bI/yG5tK0H97BIZc8wWxM7FwuLvpHN
ABbcnTFAd1Y2jJ/wS5CYXKw6FksQkT2VSTgqtn0GHQQTTwLwKlC9n+/LYmnV0LSZP2zr1og9Pd7p
7h4jJ+6+uAjEb0I4NpmCREXx+pVI+hSaTlH0uQrcVikHJJGDMar+sZOKe1abHyOcXqikKBoW3v1e
JpLpDwLWujeEwsUF4+0l0VbBiMEMFn4OQ8eUsDu4HXWoAfSKM/F2q+mLul6rWyb4uXFi7VVi2AGj
w3xL6H2BB5oc4QhwvdpQxVsv0Nxu7TWWsOTeyXoYzIMG0hlITvzkOu+7O1oHsju0epvWH5nCpnt2
StTkxa+bhNmVf8DJIw86nDhnxrYfzDmOJFTKFiUY62siPjcSVxLp9ZSN9xJiY/m0xXM0HHjr4WfR
X+Mjsw7+j7kV9wgHzRYJhTJTgiHf37qbotjXihgeGcydmFdZSdQKIanEx4fT2cExPFtMpTu7PmEX
Lmei5ArZSl5x78Ogoq16b0r9NKI5VFOmKxQRaqAgqm47FFuYX/G1hRGKmEBaEacjW33dRgttuOCj
YTZxJN1f6IvPfz4M4dCJ2jRWQlBMT0IwEc4Xh0QFqVy4BTzqaARpm7CQRDcxeILFSnr4cd4eGuvJ
TJaSxv2DEgFUS86NviUUU4VBLGZ3MvgKBYmJBL8wfaiOv3I2scX6mKuXIcsOIOZI6J/pp5F1g3hZ
5TGvCcYdc47AtktsqPmG+JwYyPjaQJpgQaM3u/yKj+fb+Su43tw5v1recQBfJxuLfCIZ/qsmdQqR
YE0GllcKMhONZ5DDgoVq/yCWhL7/fo7mZnvhAA8YdytiO7ogp2JL5nqBRqMZyRU2SmkaofUjXwdu
QueHXTl910whqUA+JUqojOS2tEGoS3Gm2e2qvOaTRzwlOaETfniyevSLumV0Yl13Ezv/oTYsZPit
J4qWsjE2TRxCTS7dcCPYbKG86AxNovCvJ/EZ2YwvTNqbRq/URCeUZZEE2kC4N8NEYudlgDPZURAT
WEGr3zoLFzsSqmQrbGrvfm2gSOZvptbEpIX/DU+SE3l3zdIuPc03VbOpQ7pRVXaATBh4F1xEsA5C
swVnJbQ9I8G8UOW2zQ2hhS2pouRCouOEBJg1+SKJt9Al+wzkTzPkvP6Zl7Ot/RxYb1MJgV0xM0zo
wIpk+/xS7qCj3QgQMGlwHy9KLMgY80+rFwJSesJZS2i4BURteFTCET/jWpazHy06fUY+SuyPG/is
wkgfGFgjauTWskaUgVMzk6UMAwa28ACeWbjm36a4Rl+0ZsckhL7qFAdQ1iLLQxn40fE1Sy6sCvFs
o8RMJdlRBO43Euaf2t11ostL9Q0v9hamNIZPDU1K2FpCYUrWRwsfggvDFmjZJEWxpG9DU9Gu+2hC
nU0NcbwMWbJX6DCKX+DuJY+BpyuN2ko1KDlcdFWOxsTnfjbw2InF3DenMzSd/ibsTak+S+PQkSHA
UmC9oRXGoIq8c14w5K6YW9js+N8eP3Chsh1R1ZHapbtDXgc4L2AFq4QVaAD7YILxdNoAMd3wUuBw
9QTxhrEsxioTBsRYK7dWWiw14r2ObDKu7mv/HCy+DQg1OfbYM98GfQ3J3ln2BzBU3KnsecEIBph2
MTwp4eotIbeZfA1cUm1fIJEmIn5O4rjy4uVFZRI2GlW5pErFM2GmkxfJhhCud+YO+IiNHcQ9Q3Mx
uvsmjdAhBSWmpA2OMiVoaemy9RIslyEyV5uX4SnPuZwFMjMN43X1moKsNT1UVHMRK9iy9JCHR6WF
HSAFvwm2ZuZ8jPsyuQGgh/kORmq0u/ZyjbO5Sl5/p3fDc1ks0eQRo8XQaWCgcNgZ16e+LVVBRyKX
EEFOA7t25SIfzN30+M02WrdTeHnwvX8vQhyyyZZo3Ihyai6V5AL5gTRYkTYfAIlWodLUI8Kdc9U4
rHtnpvNnSJQ93MssvQGgEJUFLlSC78AAvE9llw+RyOx7zqvnmO/Co8tLAXqiPyJFAk7/Q/02MoPY
R6sl4v03tqadbBG0Ks9APrOQuWj2qjuKrQ5yQJ0WHOwdUVVVHvX8xqJFk/V8otPDe791cBOcsUsJ
bwZs3R6jKa1LcJmuiwoScHU3SgzkQZV5BKReT7j8+bdUaRTb88qxTu5GxKlUI+WHC4BRMth6Tkn8
5cN3mUsITzcotVpVU0wVs84TyTdKPiojEo9PE36dmljGmRX1GLB47VReSV4HWPgvW6SYla8jjkuR
G9nQcLClO6cGmALpqoUS4Ui4wmq4pUyCXQWtW+0G19WVAEGLCAio9NTPy8KQPD4YuskdT4A/tyRM
4Aw0HHs0iVxPyE7uMp0/xCGWi9tcZL/fpKpIChaiBFes+xkPPQVpPCQkgSmkFBhBjNRzXZJ1JjO/
+yCZaMZNrdbRsmke078tbohq/asNqnx0BZ9i1gKl1BUg6fbH7/1ox2b46tN94+NEKwekC1zVn1lR
IW9Q51WdZr2FegkkyTMaIhO9oJXO0pvx1N+GqpCKgnFsY6/3yRWvoNuLSPBvQ97OPfFBf5TCu8JM
NiVjD81bnTmDrjO69LGOVwcM47tZofYkSkTzgQ4+o4jOvrZGJWpItItUAKS4Qbhs9Lb7bBE4c9IX
v0YFl5qIaQguqLPBqHUMoxHsPE6WzRFvWo5JL5/a2d/FBWoTmAvO+027sjYUZQKX7H+e9CQRw+O9
TYVBWp18ntHsT+kYqYCTrjo3GXk/aZdKVE1BfV81dJ8Jjg7FgD8TxadYoEMMCjwampZZ6ZMPh4oR
Hf62qyYkF7mwy1MyrzSmDNlS32XeVDw+jEDI29i3wyOOCMjKXygs2EsUsIEgRQrD4z7nc8Uz1hp3
om+bUrW5AEa7jWK6sgOAp7YN2ZaLkFgzC4RoQnbIReFPoUmsYkKvdHE5gzT9yw/GKffCstJ5KI7Y
pRoyLCyiAD2QVvn3RJmNfc77qZyBOhvqninT+xPU3IzYbb14cpjCP5qCsQ7cgbF1KmnVF982ZCr4
NbjKcupwbq1cF7DsmqVL/ubCi/N3UL88ntFWWdJBcQXAnWTw3ZHeqGGIHO3u1N5xZj7EU0Noy2Wx
Ekpj9eRSleT21lxXkX1nE/9/gsN8nOKWtrrvwaK/LP1YbmnITqr0GU/rkhJgkeukDu/T0N5Clxiq
W2qauhMT0vHX+thZfXsNVioXXFpRTeftGm4F5QijLj+FXaR7q91vwq/38MIcqsSodovSJK3iZ9+G
jxxH3zbvOQJYKEjsQt/IY2g5GDFQRqWDu/Fpl5xWS/W0qglIzRf0D+ZAmlSPeNHrB+tIAG4Dsx8A
4kFMSkSRFOdppngx7LzBuvZtVrB63Qn6O2X2wfbJ2NTmbeYK9WqVeyTrpnxsoly18iWnlPsFWMBi
jsSnlYTXFZ5VEaYEbx3Yymf5QKeEXYZHGpLua26kBXJTny2Sf0wYbGJBoz5xOCXfx4f6wz5SbIhb
laRaeVIg0FRKPeUMOLzvWYaLDHnLqn5vFoj/DdLAsk9A2LQozA4gVj/auBlrHBqUWVFi0lVFr6DI
HNrZWK8LbGowOElzCLvxjdn0/yjpnp9m4CTGzRvXwpR+tjb3lFlRxOZnNNsBFc+fXGUPGu+zeffk
KF5ZyqYdw0T0feQgDSx5pUzluikwFHmeNavL4SMR1buZQHmvpXOG2lfFCGz9kjSG9WTtn63xRw3y
Lu7iGi/UoMTFp18MBTihuSuRgYqoF5LmU4gxrhg+RWQG0i4LkLcjkHb/9DNgRrdfpWfXtuHqVMDC
n0siclUoCn8TEMoTMFXRpJFsSQSAOZDmuKdM+WoO0Q6iz+Vrvjn/acqzvdIfTOsEvU3Cl5fL7hvX
MqptAwE0iqKVT0KIf/NsoqB7WmSw9C52Vnd/rk/FN4GoFJGgRNsNdk4PLT1QFqCmpZIKtAW91c0h
M9RDqwkcqeC3jzRWrhsBONIJy411VELrCV0+J7IEL1Ep8gtkm3UBwqjRSp97Wt7nqMa4NO3FaCKn
81aHwooDKQs+6U90FxWmVeWgcA/UXmMVS/qH+eQ+zKLSpbIdLMfDhLc6FCbLW8MXTBdUTFj/o0yU
OT2B3eZmHO4ZFbYakyOdQf/82BF3jf52BcPbv6dibMtB9zkHO8zAuwgQ45Q3IQZ2cW7W7urXpLSE
9HMyki8hvTo3U+1KmgH9mv7JGsf9C+itVmW5wqH3hpzoxI7iRI0hc5KJRHrijdRKxGMAtmh9nEF6
pY4RlW/WOI9YGUnNlb1w0Fimm492aRIIz8OqPnza2ec7FY+jkmQvg6BV98tyM32gXkeE5sb3Wd4+
oB9rRUDRlqTPJbb3IehJZTzp60qVUvXh9ob59A1DloZYdmIktV5DPeQi4Y6SRg1JHDQdTCyYYC1x
zIlfWk0SdM/G14qMlchLtw8rf719e2T09YxV9nA2Umq5g8wE6Nr3f1f69UTV7sS25P/Bbtby2x6I
9Jh3R1P+1UaZ/RaTXnUhCG/OsdfrLNhKGPnnkqRk65Hv6kgqVCDrhWOGxF89FywN88BZ/6bjYolJ
0H7jUqDk8HoEq/VLvoUalP/efi9Ky1r/NvbP9ROKaESYPrlIuVO58xmhJabDCj0W/lvTZanMF9hy
fQ0hBiOwc8YofoL9SnfmtKUAVCs+Ra7fgcTOSpwsFw8LxD34MofFcRjic/IUjxH30JcSX3QMLgcK
yjprD+M6DFQHQb8VsUfwZo8cRHNgd5k4MQe8n4gxd8g9OZ0s1a0R8c8D4iE/9RSMghPMWDN1exAN
wwqE3CEZ6tC4Ep/tqzyS5INgh9V9OKkX78P+6hqMLnTHepmPePLb52Eu0e9QrmtYHDrPHf30/RG+
/27Sd2vWs45yFhfbMyDgB7h/R5e7VGr+XuXZA6Ug/sTuBlpoZah/t4Pyl95vw6dGtBwHt9aZwUd2
4unD1nzV4/M2YnxFo18kTJAsi4JYm8tDWPPqVcILvJ/NA/VEBQYiVpoJZUBkquNacUmnScTLxuhv
SeaoN8GbtIURF2PYlE6RViB+tDalm31oXPkNGEpNdrUN6tmdcUgkUs81+h+tKWjjmcRn4rZ89hzE
42iqfGd6OlztiI1nUWk7PftNRv6taqlyuSjExmi6AmJEKplbB60KPYBjFyxwml5Vlg0qty+lWn1d
63Iec/64GNwZnxUBJzGU0lHqzv5Xmid0OYevVDrpOoMiWE/ejIRTXoyIrl/buog//L6xPwr6Etfs
PKR2TME1VdnTaprD+B0kJ71cIRI2xWr2yScS1uXbq0bVPAWAaq1S4I5DiCPcCODqYeJxO8KbE6Dx
1d9YYeeaPDkJ3ictPG3+wRiMYLK6A64QAeWEh+ksOCVlYYeU4P074l5Ijbb1rwXNcgMe3nt8OpPq
KdoeercERfZdD0YdnTRk9FJANN/2AIQTnKcKGAh+6C2TdbTxzgtib/u7k5J7+ghwQ9qVrkoWKLmC
G1ezUbZUM76z1bOUKV8F5ygQ0v63Xl+0bTr0GX+PzDTFynD3uVyB5k1XWt8eB8z4t3xWvOlaxvES
Vm8P4r+CQaNRu30JEWU/o4+Lo0CY2KMgMIqCv+5EnJ88ukp1vOmq4Vpd1Wd+GPjzjwRgUY8MWC42
h37tEqSfL6BhlErK7Ph4Isc3kk4iSYQo7oIa7C1U4BGn2oz0l49tFod2d3/H4ZY4JICcZxkRZ5lI
nepZlENKVmseXegmnxtYLivXGNYlf6OYzWulzSvQVE7jCfkO/vkG2xsnxoV3Elw506QgFZo15vTv
9tyH5C7V1y4Peg+8z5as3po+YoS7yrvZoHeKiEs2+ZPWFKfz9c7e6d2t6ufecKfCYEXyeptN1Vfh
UVxDi1ud2JnhevfwJW3CXaJ1NpjXQi4/2PP2a+xzSCf8Uw9/hZbWvihT2ANenyf65uIcHwUfsk6j
qqXaiTQlN79RJ0h/f58ZQrrTNb1J0o6ufcmHxDoJMuxiZzY9f8E/5LkN+KxP36ZTCbQEtCzzqX5J
cLGJr1ZxfVFxz/ntZOXbO5ORqBT+9zGux1/1PxXldLHJuEq+c/BfM+6zr0mDOQMsyJLlYLKluB/f
nvMdjaIYqiDM4ttBG7F75t61SZlVC/UPqKD/7VpucP8rsMU9XW8dzgqECLRZxcRSo44E1z2nO5zq
29SiBYlfV8DuOBp5+URL3dS9nb9TVWRzh8pPTNMOzdefXhJXJsJ82YZdRBo0YBmeJ/ymejvn6stW
356hMwd9QK02awl2y11KsegbBZilNP4PQIuf153ZCy7oiP8NZNDMViw03ydQdPwczDu2PbuVNC81
iVCOwx8om8Yj/IzcQELGF0Qx9jcelAnj8HhlA0o7sVvClmSVHHjdWI/aejz339bw1AEpo8PZm/VI
8Q4bjnv7zUg8KEsIhodvoO43P1nwssVckxaRxOJwakcx0mzpVzuE8jUVm4DQIpj9Uf3OngG1Hizx
PqjsMlhAzSSPzw560BiCC2zZPD274FLi+1wDgBgO7kD42XKU1K80lruFDK8B2JPeQuBH7R9wDnpp
Z8ehY/2JXKlC4wC7rv6KqLkvReejLqP366liIuxHe+3I9NuJbMG6JowukCCnTDHC3wZfqAxr2GrU
MmqUaGhnZVaP7P+RDex9jUetmzlfJVqWZsdcTWonV5lQNExqXSGGk1bOJBBnkItA9vs4EfUp6Nd+
tvp3gl++gVApeOEn1CqRUFJ5cFYkrzZ3qg1uif6BbjzxHXfEAB6nQxQIEy0L+kKVwDSKxPwv6sA6
RTgiUS+RLwoj1mWleJ/wU+ChBMVikpf0jhLVtloAtrLBEKLnoCfECSykH5N18hTO6kTqAjYDTcsL
6bg7Am9xvvQmpx5ybpgXLe94jx/XvF0YjzcFodfalhqqt3AEJ5OgcyZIl943EA1u4WVyCIZOEC+i
69FPdtqXXGWJu5nz/fdlfDkmEGWTaL8XaLwSnSm/3vdRiH/0QFppRsaDFcl3ltPLHFWYZSmjXjqS
bPw2e2ymRwdV0SMmYWzE6eit2M20njL4ftolKxNuRPVJZA/dByQO+qddpUUz6945Q1xm7m+q1kXV
G2F3l61DmgNH+mo2AQhIVS04AlXPWqAzEgNoe54D7l0W2QBJdflVZTx1Xn+P2HGouYy3WWnjYowd
rWIXvRoNPUFTezknGLSg0D7wX5XDthw5aGZJ2uFLD1xgfslOdn6vwQCA1TQcOWg/xXaYyW0cSzO+
r/zXw5IhsVY7AXIhYXH+EeKoyxfhJiT8uHHwgFCNC1GGrB3/5gfIBRjumvwgXYL081PNfdQMVTPB
sOkUk53JWEYpejxvKkGOOpQoD81JpVIBTsCzSpPcTd1CUCq0oQ0AAqXiAMGK4Llp8pTJIeo3U488
Es10Rn78dlA9TfRdqkjx5RNC5gOvaXvgpkBQM+PHf/vXPCYBnaNRanUyv00c24FAipM3r9I7At/C
+TJzeLuBpgk1bjDC4Vu7hQ7tdrb0IE3SPvLCXRp5FlAn6JywBo61yU6YvexvdNDzBh7LH6iCD5+e
tGJt9wdGIMZNtiiC1JHB6xB0ByLj5UzSopUOt+BplYInE49Mnbfy0V4r7Gf7sFc460WNFFrKUZvK
fFE8oaf/6DasRIbRfyuesj9fSy7AlfaskIDJNa5lnd2jO93l03vug3NMCe2EKqU8a9OqwrXyh3wv
CJQKYNZomjrrspvEZDC6W8IVLGQva/+5adoDogR80FLduSOXrU3vQs6aqygAMScbfCYrZQE3z8Mr
yYaq8yj6b/upVyHmAKU92o57O7Kx2HqWia+NxVZ9Hp/VEsKrbKOi5fWJDxN9a4ZmefMJkhF/j9ut
0bj/+Jd4hayW5OwIIk/pIln6dTXC3KrILae+xJZHfNeCOlWfm9zNxW4n0+Zaxdzi0Wx1l+3KINKV
Zr40dvfp++FI2CiCDB64eiT86e5OZyGC3gwEYgr72UCm9sW7xuK2GOCptHmXHRtAfZwJQgRnLpWL
OK2tk7gr/t2Lcl1CQqIvpiT7RQ5WWw67CsNbws7wyUzljKQ0fWlTqQ4wwWFokuAFBo/3djhzmx2N
WaMAOfr0zQgRfVTdjv+A60JJl4l3S/uLS7f5WboJlGbkXQmvqrSOaG7vlm14a5K8HdRHoQ6O9FAs
8eBXriIEmpeKlrSwB+XsWWkOBJtmKkcZQcNWrnysAUyXke3ifU3lXTGjgnd2sUhFan8295AI3O4o
yFzvRnHbIjS1W/TMUM3Joma/NY9JoYmj1PJsPub89eLnK+0bLqdZNj7IyW+ahcxkNLQG2mnf+2PZ
vnzVBjt5KufP86HzBQXX8fNGJZpZdtwQGkhNB68okZLnSoIKVWlJv+H6OqPxD+yuU62F/BpgNorv
1johIIaCFw3rXu1Q8rI7sYE1roITkXrRQ1pM8Mn+lL+3Im2oPjkm1I0/mbAVSHDRy4+b525a6Yae
NQOHetN5HujoLgVgr1mvGUvd9qXWovR3xeGMn8rpjC32v0z5m6iyA4ptxAc+pg8/biYHGHk7zqwP
xzuPHff56pz7YzdpR9ZPqNFTbcTKTjXT9G+KKQh6b6aARLQO3Zibef+ca30QwbCW2/6JZKqEhn0v
ipQys9vDmmbnJjFEXf434/orX1lrMKWfzadcQOwSrajhC2cqaR0NqevbPjlY6y23qVPyC+X7hlwn
E6zgd/hANQhauJ/wZ7Ybd0x+RKXeM+HVQk3AK25bSHBseIwr0BOFmoDV67EnhK9RsdQTaxcyLP7q
K5fS2EB4eJha3kAPlWHCl9M7qkGRSPZqrj2x5UDGSynsrMXxkxif5RCdaOZV69fsLJ3M7n7xGAVW
UgVfxHsOjf0JOS6oh6RsF4XUAeVQqh9D+4FJD+ly5rCyW92VtaDCnJnxLKHMVG3Jx7DQO+8xK3nv
rpXtJTclN+dQjwLjRmukmPOEAtEwFAN5N3vttZQAqs6i+g0bJb2enonTuheAuagDeH3kR+GKwdaG
qbg7kL3wuOHrkYwX44NlMbrK+TjonLt0zFPPvTwHYznFMtAO507pOictn+E3Tzc6oqANnCruMLr0
zXYLV8eCTXKZ3Z9jRob8M72O/ZYbRIk3JdF+Bxhdi2rW3aWjAqF3E6M+nh6VRrI9rZpgCdAAW0x4
am5vFBghfVvqJiyC60RCMXnD6JCe/qHRQ1vLRfQkxxjHZBSmj5iRmzMkQTa87gHqonEH8Zul3Vkr
QAgsnwAwxaNPXXoAK9w2HvrpsBLcD/HVuKYcVO5CpGNhljTIyGY7cfk2cJIuMS3Z5tyTNW4AuQ54
RqSkD2kkCfeCN26NKpjzAxd8WjYrOr3nQKqaRFLWZFAxYLQZfNzn1zU/7UG+ZVTcF41ptGmbtmVj
FUnL/8vVZ5Svt1TTKeSHzSSNEbQM1zXcXSRWokCUl2y8n7aXo97rYb9j8QxIavJLfD/Ivk5jcadX
mZg8ux9at1qAoW2G97rEjua2pMjAJDnz2Iu70lI2D8O1tLEbXUAkZheP7mK5nFvzBGw6mLjPuYGz
/xP7iloKWqBYoNC6JiWFqjI8BE7y8sitE/M+jeNXEYEtd4eB8xwiTU84FTINZTe/8/aWLdXxH4ag
VYX6FFiwHx5AZ/agpe4vDhvVX/VFdBvBVnWtbeVQStKgN6TSPCteLZf8OI/x3ylDx4eqz4OfnZ4v
+yjkX8jZw/uo5yMKVq4jpWH6MTEJvD1jzluP70u0298dyan8M5E2vvMRI1pd30n1NcJhJaYI3IXe
bydFzAr2Gr98AyMG3DYYz5W+cheoUqA7OWhtoF/ab/1G8Lt2vv4DctrEZsmXPxDSCQy1SQpJJ+i3
Qqk1CT6JJLLvfUgMHy0I3VpfDgaqsXbFID0rZkLLp8tLFHwxkHcOyOENfv6265BQ+SXDzgsQxkjR
GC/UT3FfKmJKlL5Wuyp5+WnI5Al8oq/OK0g9zYv2ACHL4n81/dPYoWdqGGGHr2j71pdMboGdO39C
wFzxuXH1+HYEEjX474E5DzgP+cCRkdoILlP/Uwh75ty8yL3SlL0N8Uz9qOVgcapHYKYVVunhu+up
zSzP9MKWSLDN+Dvj7bWxyxWYf/8f0KFfD1nL/t2IPruUz75wwBdkhngxHa9br8uwgIv/PplTMadl
ClvYLlC04a8/0vT7afwG68bTNgR9JVg1VjP3+ZJP7VAEHqwDierPyYc4tUPKdHEjQx5cQ11AzgFd
1DbYSHtfT2SVlCDf3WqyGsF7VcFEnEXmE0NExNvr19cSBAXKkdXMCj4HLt8964N1RLsyZVgg+xHQ
3FHK5cdw2LAItWx3PR0ANmNcOjNrKkvxwGYseD0LcVME+HECEYv9+58lSNccy9nPYl/UoqSclzr8
hLoQDVxOdhTWKzmXrDL2NGkaEuwSV3e6SytmXBZhRc7gnhg2B7WHyWVFJAepvrTMqP59Rwt9W0qw
+379mAu3YJaytvrbmBTg1xdEE8qcihUlozUCLcMrmnnYMJYMwUMDTIQTtKRVJFzrMkfJTzGVNbQk
qqvE347viShmy4M5Ddz4md59DHCA4gmDbXOiiViZRGhf7AyXDi/G7W/oT+HGP1lWvq3sNhQneSvS
bsMstZu/hQM4vJd9iy/W/3mNszZ2438VY1ObVAIHBs5VdlC0FmIPJYyukDNgFlYqTWtqm2WCjVhg
K6Ihrl74Waparc5sTlzLumjk+L9Ll0WMah0c+/avyOdnvZiuMljHPlONs3tH6aTnCQqEq568ypnU
/HhC94OyRQb396NE3NQdSRQ+pxZh2FO4SukMlHsUO/AreV3TzhmE9cnp/qoXvrmF73hMjCTRUicW
eGCgY7ibajKiIpm2CECHMgtTGRNH5VzYzFQBxAiRItCq0Vg4/ftc1cIspumMErdarZbmU+q+0WPX
rFNYrUZEG0jqE5xvL1wmF6a2akiVWB1BnH5kzd0lxFfQxwPPdzfUGOQctTOXGjRNGcgnTgut/5C5
krP3MGYrSy9MU5CskvKHjbNgBUrL3iVEo4wHMIeBu+dI1/kNfAHKat6Tl/6R8fsg5rWJEOQJz8fX
aFTU0eb9ejD1Lj+y+p37leBciwumii7ldV2rN8ES8CQ9Lni7X0qGd7yo+np4BhcfVLh0SHqgNIji
VASNwzdZP5ULqOfK2WXNhXbc+XBIIjZAZJxOGypCVwRz1KZnpMGrCfIF9Ur3hExV5oOL8URAFR1O
PTZg/oZYvVLtCgy3qzTx2gwMF/54hByETvdpmDqoHD37vCk8PKIm+O25ojL9nTZOKOWblT26qXU3
nvWrBxyeNaiwUlBW7sD+0sGBagYwNN/L/o22Qq396ePIf0tM8gJn7GX2hzxXzeYpeQgDkJ79yN14
Z/qdRu7vu9MiiY95XReOQv0PHhy7Rz7efAet0uKu6b3RnQWhjiRZTcDXB3/ECgQNna2yo0FfDAbX
mdPisrXuZ0LNHCVvanzpyWy0Vo1wtTgbRwO0+vvCJ9tAzzUyESsKV9SwVowUt3gWDEYrfMz70f3W
PkPJvhxCMF96loM5u9q4HitqRi9B/3aOcf16fkB0fTGQnZDfsgzyN31iNJoMzN7MCnt69FB570/m
zMvk3Ie9MdsCgbT55iUr1a3HluzYQWjzYkSLMAusD/Fq1PlnKllbBD9OhPAwPtUJ7Xkd7JOkCCLU
7LJytk2HlaSsPKwoVZOH9Xd+EU1LrutB3p9n1tQ1ReHmFoS/oHzmdtm0WCxMLPc1bt5E8W9M5snF
66ylxO+Il7lL39gmZOrCxnqNWyR5B6/pF2DnXzFNe2j9ZCCMhtlOgjhrTKTj/NqFqs2VEz2uIWoa
mpVw1/32961CT1fklss0f5VNsh/iL8G9joqTC7NNsNnySv+KLoVr7E5XV6uv91RejPD03tbtTefN
5KB8ceKn6aJUKQ0onHXcBwygEPvbjdDBrFIWWqeA66hf5piXNG4oejGZU8cZATs/wP1fHBosqDyK
iW7wA75CpA785LX4gUzc3+7SKVx6UqgPQXemqFl8FZAvvtLelhjTvXdPoDxtEOVNK0Kf/R/vWyvT
XK9rVu4jHeFIPumI7J4/ykVhynQgV69MRC4hobBADfHj34JEYrvTq/y5YOaUKye1etbjKuFegpCQ
ZUBOn2q2jPJWOOFFFCvWtmn8qzFaH4ukHiPYkf8/6MrYbd4UGQ7I5nlBupE7loU5pnIa/2LTCBre
4Qq+RDUbdIxZB0eNq9mF9R/wtZMTbM0rei/NHImeVX9W4gLfZrw28QbEq2fpemY/qnA6HpU7XK4W
3AVHSc2tYALDHjGw8znqc2t3UujZHkML1MEv4J2w8yUu/sTZSrrIGWFgWhAOOyvaIgU/YFqGalyb
lc/9g+xvqRCk8Ch5E+wX0bby6r9zXJvQ1nmxSYfKdeBB0vOB1jxXzLKu7Vv/ijwTJiHkxWGU6IPK
z9H19kgDlXbEx9NlbhEtBQ+DDg8CZDZ8H5s7KosUHj7ew5mpJZMmXEWAwmWRsZtmqGziHIwcJroA
ejB07ivSm7jGOof1miiE0lvQelvCMhi2pH9rKTczPXVLdqzpgVZIMH19KAphSCEpTaVgFcHt+uKC
nuR57e84NE8qKbHWNeuYP8KkvS9xFdoe/LgKQ+Tn3hv5ZFHTXimgwAI0KGIqxiSHCannWRbuu79Q
aU5z+qX2TpdjOYGgzHLZQNFheMZxboYdvxUJqHFCh0T+n0tNgZ7wvKRjCfi+sHmBEVzjTDIEv70S
XcIpiCn+JRs0gczafeOotzpI/WhgNahE9E+Hzq5YhnzkZVnTIhvbUVGQq2/FJxDFPfB7IPhBWkEu
rBbnpw+1YHMdwRcRhaxrGkgxqGsfFoShHzEnDnoeH8b8z4igCyYN/VMANmpWk5SsgVoslfV1/tFr
xs9kRqUqcSIGfaSrv/ffkn+KbMB1zhEfUULgevtuwkrXTKmk+QH52KbQMJg26bXUOQ10PDKxCkOs
N56+PgTLKyNu5cOk8Nl+UV5La3RDM7qP5xVg9JOs1xqG2e4eMMty+emcpE/V01VmYPubiCp5hR/L
z7g1Pg7g9+68jH1WX+FIIGMjtNSk+g6mszr3jdQflZhhJdo9hyqTXo3OTv4ShVZ9f2APgG2H8XMQ
Ae6q/v85GJzBNWheqgrZU1XiOa84oRBdZ5F+JtbH2l8tjDe6EbiSfM8il8R+YmqH3rRimnha7QY7
U7igYZNe+9ZvXYfO1pygOD0th0LWpjg2dsbtLTDPds/GTxK4sNywEm7p5PIaWHFGjUe+9SdbPOj4
W57IlmBtu66Q3VrBov49N7Cm/H+UgauHR32bgxCS3JE4doahg+k22CqCG7c971xv+C4y6s6S0sO/
t33U3aStWR8iKfgEhaDbQPtsnomZLBUFiP81+Bgtk4NgMpDolYvj0twrpRI5E7EOV2ygv9CRS5J4
CKn1T0mmfm/l1443Yo6XaWdSIWDse3D9+m0WmUFyJp0cYUCkzmk6aY13hiEtJt/OR0p94BG3qwVr
UqT38YLwdBhctVgt3A3qhuPtKdgZ+VDOyZbesIPJ/Re3CDTmqqjLua8/7jXfuiNj9Lylyy77AhO4
I0fnYgg0BO2Hn5TmKxOTUQebaYnOqJ+H0JNumunCRBIF2TBDPvHc0R8UT0CRffWxfle2Y8y/cWpz
yIXfVf8DPX1qOA3RCm8XD/RLoovk4ehvRmboAGv7LzNtL159O9wDrJa33MZGdGiEe2+0gR9g3ejS
l8cYGBGvUcq4mNjC7wSO0S16DIahsVjw0jkr3LtnHmgcPZmG+3a2mikOVh1unUWt0N2dPoodcyxv
kMaC+JxZgkEdJ5S1fOVhRi8D3Ozo6DToXsqDYINGmu9MTZ+b6+b1ubE3ERjtcAkMd+hN6v0YYpni
ElUqznzveGXNgpS88oOtCX/v2i6G0ZMQfIsFE0VEMPVwGZwgN33ReYUdbQH/87TY7fj3Bjz3HYrN
HrB9lR5xHzPgPevpbG5V4UkCbOgzQNpq+CNn5KjGSiFNI8XvdpISGHeB0rz0q4G5NB0ucD7wgOpq
UUhaf24qzRLrcRSQ3VxvKGB0Awi9UDOkCnUTmbf/3zIYZbo86DLpVj2Sg/+uxeWLp1aEB6HnRKrR
al2otpwUsaBqahBkPiSbSu0HTxNx4OLabV0AXzUJrmFyAElcJsBm8aeWjO01qvaLwmNVD1e3jSsW
4gcrzNCf90rFIKOtWMZ/Dr9xNo+nUuMlkxqpEyaPD8sYANgJCGUnyLIWEE273i2fu2W0gE5av5cd
yRm1Vmjr+4/W2gF+SnNQOyrS+BbF4eR0uO/yCM5LCpIBSn0ib4pQQHA0MasliM0uSlTfUMobx9/5
MuV/IHtGay9GIbRcjbv/iM+0Uu/G4iixzU6J6tTnllOIsUHIOYThnsQ3mCjlZUL3LE0YkWwOsFQe
7QPOeav2ts7PbXAzj1V7W3g7ho5lhOK8NeX3WJ9zARJBZ5Ed+YR1R+ikvoc+Z/uvLAZNvehzHV2e
bBfJ11zAgd8/8+Jov2OZB6dkBIWACacWtAV/dzRn8jkbj+R6+aYMc09WHKx2fzXTEn1ay0OEa2zR
sJoqCKtig1eicG02TsW++ze4320pRoWv0i1qdzyMv0vhulM7tlhT/aQV1iWBDm0+Bs5/tIqbNHP9
gNWpZ/U8b7biikC5BOybXTGYe5XrGEnL7H9Ru5CWLRSZ3a296IEPBXQ73ucsWblOYIKwzx4XscVR
JrwMsh7deLtW2s6Aq2RKvU6sus3B83N2VDRfWfk1PdVRuwbIx4DkR8NBt8BZZobQrwzKhntJn3pa
iL0klu7qULcbd1/jpJmXwe57BXvlErM15oSsp0x//NyXzcRTlbD305UlZqHz1yeOMMEqQmYZzOa8
fucSxz9HMMr1j7PO/f0FkEk8NWkKjI5MkvpqwQoK19/U0zvr4+vEBaw1h6ktdobmSVcUEQAzPFpN
zmzAGD73uResevGOKSQy1yeDXn4GM2Tw42F8iMB0lO3XuK6Hb/06fGGG1I9In0SdaKcIiXkCn060
/dNt0rry0DZ93giPNlyL5od5k7OQriSct+YgYvg7mNk/3Q6frr7VDgpc6iwxQ0VYciV1KuKyYGhH
9Xcv44ZMOHliIC+ImT+KhKGno6FShIDe3KyXTnKOoNmkA+CM/7Ku6yR3yEALHoNL9pNi77r+8ci5
Wff4cWDj+zDA4u744V7pN4JMy14uu6NOL4Ny5juJWqwE6R39RuatGPbC+CK4QDX8sqhGnVXyYurx
eJpgF+uUXGJhrBHyBuAiSjhFIaX52O1nnrnziMw5VZjX+vRKwZeAXG/BdRsdDu+LiF8wMzEqh8J9
hVJriMvaTkFnYGqSxCxwXfqAcUHyIjp3K95pnJT1NcZjtMCzcWdRfLWi8Md6qL0V0FvGXdnnKt+z
ZqxH3JTBShR/tMl3ajE9vucwC3iB9PN7dKpZm8CY1KfyjEX0Dj9F/CfCQU4nx18pKMp+FCaiIkDe
e1JWaDQAMhDWNtfIka+nTvGIfGxT+AEw6l+P1naGD4H1jI06zE31v1TvX7UHrWGJfe7vgwTt//B8
6jCe0ml3mi3SnErdc/YgKuW2II7qDEky0J2eBSLrSOfe2DIdv3GS3PnDgLEIBhs2KFkJvUWMtqLH
VA0AJG2KppeyAS9OzLM/X7bBUFNUg/gW7sDxHWbcxSktl1eRcOx9YkM1oE2Xp0hoedImNOd3gSH+
2T43q8fGzQgoGIZt1RVXluO0giIR02wN5/aZZWNJlTnIxXqrYeEpEs/3eC8zuj+j3T8k+12Q65rw
Qlp3NqimNhnR5E4c8LzyQCoEskashX0cCSFwayV7CCbCS5530sLanYOXRP/nd0TgMJ2g1OKvVjMK
wK+gBUNEpQdsCsy5x8Y12adYDeUq7y40NmG9L22vOyqzHpbJIS/a/2YmUM6sVT582RvfClHoRt6P
NIg8c5m1yUn4VJhW+azBAtgfMA23La0o5fzJcAMoOhw9xgSryRmieKS6cnDIulv0VauyJmJNzKJz
48TuQkizpLFZhq9hvbuo2Cjfv7e7INKgas4aDU9X2bAXnEELEW6lr6z5PDeHxa55IEK4rj6f4uZe
NoMEh5zB8OQcKz85Cc+GABM4YjfESsCT58/uAHTlSmJY/Ny619dWlB33jpQT4zbqZzbGqZOIRVCA
224fg1Pj4sufS50brQ8a2Lml0P9iDLe7Mhh+oq/m8BUqhIWbO+nOV+Fdgq+JiFW+puf2aluok3wH
r2q6Pxi7Uox57j1jiXIzyWAF1pJepzv3lc9GQ+kzU3vQ1dgXpeNb2H1MpS6tkGqtZpl3ssdLFvnt
A+HNLiJIereYRAf1yUC8PRBbuusfL5gBYyP3ZLKtcZiBA6Ky/x7i+EoRodDQKIMJrrDXJhCpEXeK
YE8uiAerImi8fxl6T9HmqAzWvkkxDM1fUJe3yDmfvqHSVgN3eiQolnpYg7ujG4Fms3rXeZUuvg==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
