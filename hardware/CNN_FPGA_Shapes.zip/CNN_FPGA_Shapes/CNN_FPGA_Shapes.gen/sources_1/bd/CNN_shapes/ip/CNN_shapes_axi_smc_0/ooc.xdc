# aclk {FREQ_HZ 83333336 CLK_DOMAIN CNN_shapes_processing_system7_0_0_FCLK_CLK0 PHASE 0.0}
# Clock Domain: CNN_shapes_processing_system7_0_0_FCLK_CLK0
create_clock -name aclk -period 12.000 [get_ports aclk]
# Generated clocks
