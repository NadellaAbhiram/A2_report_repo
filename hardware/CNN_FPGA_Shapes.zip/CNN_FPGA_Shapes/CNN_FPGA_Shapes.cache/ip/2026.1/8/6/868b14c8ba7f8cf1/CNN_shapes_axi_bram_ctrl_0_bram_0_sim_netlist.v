// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Tue Nov 17 14:24:06 2026
// Host        : Nadella running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ CNN_shapes_axi_bram_ctrl_0_bram_0_sim_netlist.v
// Design      : CNN_shapes_axi_bram_ctrl_0_bram_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CNN_shapes_axi_bram_ctrl_0_bram_0,blk_mem_gen_v8_4_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_13,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    rsta,
    ena,
    wea,
    addra,
    dina,
    douta,
    rsta_busy);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE BRAM_CTRL, READ_WRITE_MODE READ_WRITE, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA RST" *) input rsta;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [3:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [31:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [31:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;
  output rsta_busy;

  wire [31:0]addra;
  wire clka;
  wire [31:0]dina;
  wire [31:0]douta;
  wire ena;
  wire rsta;
  wire rsta_busy;
  wire [3:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [31:0]NLW_U0_doutb_UNCONNECTED;
  wire [31:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "32" *) 
  (* C_ADDRB_WIDTH = "32" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "8" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "0" *) 
  (* C_COUNT_36K_BRAM = "2" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "1" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "1" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     5.3746 mW" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "1" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "NONE" *) 
  (* C_INIT_FILE_NAME = "no_coe_file_loaded" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "0" *) 
  (* C_MEMORY_OPTIMIZATION = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "2048" *) 
  (* C_READ_DEPTH_B = "2048" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "32" *) 
  (* C_READ_WIDTH_B = "32" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "1" *) 
  (* C_USE_BYTE_WEA = "1" *) 
  (* C_USE_BYTE_WEB = "1" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "4" *) 
  (* C_WEB_WIDTH = "4" *) 
  (* C_WRITE_DEPTH_A = "2048" *) 
  (* C_WRITE_DEPTH_B = "2048" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "32" *) 
  (* C_WRITE_WIDTH_B = "32" *) 
  (* C_XDEVICEFAMILY = "zynq" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_13 U0
       (.addra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addra[12:2],1'b0,1'b0}),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[31:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[31:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(rsta),
        .rsta_busy(rsta_busy),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[31:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[31:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web({1'b0,1'b0,1'b0,1'b0}));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2026.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
kZgFhM2d/jlaPzxpf6XHBAvY3udA2n90sVrL5ios3dCU6DHMG01BptGv7AEkMGv1nBWc9wOv8Ao5
MO+RYUWfJloAgvE9oz3EJHrmhQHk1oDdQ/EpnejIRbEZCjmfHUEI21gyKS6oLdkyx2gHs3HX+wks
75MnE8jDP5XEe0wRk70=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CotVlRfEkpF8whBUKgocdcjhKyrcMEGPZvHkGVHISj+GCXwa3Gdeme07eFJpz/ZotBRm0H+nvk9U
c+cu76zAYcGZA4BB8k5S5CN9te+cdcMud4cLzxM3NWHdGuMLRnzIf+YH7ADhhyN/3GRT3GlBC9un
8gg46/rnawNHyJnmhY8sUwhYJFSC6Zp+YpCreJEMMsSSR0D4CM0VZx3eT8IWhFsOz6ekLOhifcRk
JdWdOdywGnTqpOq97/LmRPbfEGBiYB5YDEex+rP8S+WkdfZSRXRcMfIMDifCL2F9vyvALaXXU/HK
kczWE+R+OoMRMGX7ipHLpx7Q08Lk2uu9pJiE9Q==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
tZnJNN2Qmv8npxJcsUh1oNo5AcwWv4Go3b6+WqtB8cYERd3tAiuYpzM9E8x0/NSOgU2lO+XGGWqL
PXOFRGE6+vT9Uw+MMZ7IhiFhNUxakIUv/kmA/Kpo9+5Y8aWN581krtWN9KT8/ccdMg7//qZ5aT8D
c323EB+407vCn2c62Ug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
KKZGVVr56cxydgpa10+BIppw9vsPylE78OMiTW7WTk1ML6QnGGk6Ufm83Q5BYCGjf79wKt+EDVr2
Faz5O4p7NqDjYc+6UH+r3tYhzg8ax3QQ/lL0h4ROXjjznYZN4GT3jpmEVd5M9uz0VZRUklNggvzs
aHgFve9gt7F5cG1cwxr+CFWUfKcsH6XCTrNM3UP1/Ye33LxT6qzhZVuCb4w1zybXO9K1HZRARNeE
XmaMeB1MHLiswqCVSWCi3ahqMoTIL8Nkwb7LISvYxN88qxMca/sR/Y59W48DrGDRBBzZ48hIpVXK
9wpPb6wF5zA03FsVqRSc5JxQzfKhTSxAnXSVMA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ywVnQUL8hRlFZUGP9Kpsx7UfX2m6K2oMp1dIrzsl1e7ahG0jDMr0uZjciYiQvVpl++f7jBR3qTGo
/E63+MEs3aH3oSmrd0H/Etz+j2FU3ASZNwvS98uACXUBPzAeEwFUuJ9/8jqLJsiNybXigf8spDDy
xB/JnUfJl4/mmyClxySXyscK3aOnErzAZ9B9i8PeHPttmRn6onzR+wukt29Z0ETtVcyKKb9JQeO5
4ipDn79/o1IPYLzFyyiP5/oKUP/4zmX/6pbiO6bdzi2kdrhBtRE6ztlUGTI0WBHPOO+nZcIlF5S4
jckQo17l4fcqBJC8p6S7fb4eyfp+IU8PFj6wDQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GUQu/hEzrCx6whrKX9cnRKGYwu/EkGwKC+5ZIAahvY/upngQfvNVWyz4hLS5Q+jQdoupTTPWruY8
5QnccTfRLO/UNkPmbg8atB4asCjrKgLIhzPG1pqhoH9BtKKby74jLu4vyRH0Hk9XOXkAXLos7eBX
Nudw/vzxy74RzWXjstE5NRhMqfXi+jrP7VLV+NT9AN7PZQ8SsVifNwD2P2HwGzqQT/beYW8LvNbr
bRbtDAwcCcJomfkUvNb4pYE7MuJK22aox2ar8nUAviLnxnmy/ASVSGou0mCxgkZKW88UP70HDIhl
aueFj0IyK2H6IPJM9GCgGAwEeA0w0rzI7faPlg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YHSFaIRKyhIVU+ZO/EyZESP/nTM928AcWJGbKx6Nxkm8PEl7yBr3z8S8G0MbToKUpAO14Ei843y2
QSES26grec+g5bQHTjG1w5mR0gi3IRbGAT8ctIbI6qe8HxLmMViuDiYNb2JRHPBhpGjx1o9s0K53
1FVtSLcIMPdvZ6vGzYYlswxXiOA7D0qdnIFeJXb/6BzeYM/ZSO3kXFNYZVuhaNU0AcFxQzxAe/sK
lx5QdNGpyfexd+UnTCdHIul+eFr91+gTUaOVHDR7qvAiX+c3k+nbn4d1gBOExbPG5xXxO9QzpWZH
pkGcv5/2mmPVGGa6bx1rd+/wxxqJYs2r4GBQhQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
SuOFRD2tIt83R5vOz6fwY9Uj1WJom9jlw00FrgpAa9zzHh8NDaN1pvHliEpw0RI/EXGai+RqFTtv
ODI2Qchq2R+Ohalo8v9B//WzHrQEoZOqY8ExEpKNbhp2IJiwsZKz4enjUze+QgFiZFFBQSuEtvRx
6PvI0tTjXp4d4nJZP6HbKHFzj2SEggoTEvkYm2QqrEIRu3HQ9cXOaM9B77eWbQvHHj8yGYRw4A5u
Grwq5j0VzH8/eaysSLlB32jy65hpz1XiigFMnu01jNTA/Fh2qkMYpJeiiityiftiHDGBeEi78AUU
DCNlSbHo0NgXbyxwgV82OqxM0bTJUXK6Gh6/8xgla6TEAub1vTzQH5Uche+S6QnV24o6ll5HwYyV
RoBr27Aj0mceN3MNqSTnsoEMthFh1MLmp0imxgG/6NjNFKABJTDuaGPLE9XjU59knvKP1VKk9Fp5
rI7Y3IvGFhu0bHKEhV60LLTosXWr9gzS3uKCMCb0T38cAx5GX6FcChb0

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
WC3gV9hDsJlJGDWXD9/OXXBzEn6vsr7+oOdKz7gm4Rk/FFR50y93jhYmcWd1K2InGg42AOhIHo2Z
TvhSjky9Smc6kaftDv0qbAD/y3awUgVWMhvanfJnlEuAZfoFEJGwGr9jYg55AvfvuX1rQTtKoUFi
ACZ7pJVaLnkCKFVPNuhRAQxCs7KLW7cG1ALcdtOdnRrcG3bh4dHzct2JzL2/VK03C8gPKr3uM6DE
9O0lltoTf/AzP3jfV2LZekZChJx+UY4WWMhnVCiQKoa9voReSAKbrxHl/hqJvWQiYa6CFpABdUpX
fjEHVkVIdpnVpslTz0sOxXMvpxX7F8T6O5KvOA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Iqc6J3NDm5J0Ukvjev1H/S4Q4RmJahnBq0A8nClyXeu33t4xanh+aGq3+WcR0KQRtSZvQDrbXWvy
VpRaHzQu/lgwraB5780gv5qhqt1D3uYyerl5fx6fl2ozWlr8yZKs/qaDlktEWGF0MPUsJuYE6ZcM
72yOpO5/ynMUgwJs9FVcK5pRasgkXgOUeN1tA6mmLAiYCor4CtxoB2CGVa0z1Xsrai6cNrXCDd8I
D1f10kYi4ICIsU7uhC3hLMQ66OSpgzGDdHUq52hVB7ESc7B/fk4nrcm0mSK0cPc0un7O8vvvykdb
kA7qDovHJqWd0VWle0m3J0DvA2pKJUU4AmG51A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Y+N5GKAwdOuN9nS/lU52Y4ZNhFpP5Eg6jiLvP1rQk7jt7v332HLd3dDgIcKOvTZ+cT2qc/fEH3km
qRW6R6MDwiTEv5NDgR96180FbWhHKmyQ/AZmvgAhcSnKARj27eDEkTFcUfN+RgRNycooCPjQ2LvE
RAHSYS+ob7G8GxymUfgoG2pJ1BZF8n98Yv+Aj+fx3pPWyFx63XYQu0VIla5KV1WkhDxakW9v4pJh
kWzHMGwdhrs9q2KAQjFgZaDXVv5oFd/wcJWXkvkbsRdm3Ok9s3OwuaW9LsKnBGReVg6ii5BR+7Za
9w0kFZHcWjmf5ns8L/rFEzHcIGqE15ZlLKYekg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 52848)
`pragma protect data_block
+WvM16UZ1QAr11A6Mm3r18DJ5MAOPQep8QBndG1OIIcCvQh09huwlmh+pq//fflANnRvtzSd8juv
q/F6Esmad5GJVFnwNR+5tEvkCa5Bk/lNCwvLsCRGtkqyQqKJB8rdwk0WSWprBkLkLmcOkS9Qo5JF
WA6lLa6CfBJ4+LfUtOVfd0E+kLDIq1lJwdwITqfcV1dWzecoa0NTt/I9EqQb3Me9W2NZ3Jtjmd+c
VBD1IPN3tMXWADdxO/dIn+5x8hBbiJEEJqH51wx9A4BwclWyam7htG8blK7RwBFyJYBEpyn5KJDd
B38wKRt6DqvTaMdWSlZ+R5TabTGXisejcZnGGL3ExmnSCW6J46z6vPVVuhbmEVFysQfhwTHCPvY/
Re5bm/StFioBBWFMu02ea91LTm3JuJMs4294+fZ6lhU+tzzSeEPxlP0uM3LQlIgtF50LRdy6qKRB
JeepOSiMNSQu0AtFwg7pxYN2EcYWHDWWidVmkrRwzIpnEeJAkpMLvg/LRBkh0xHmOqu565sVzgJV
U89zsduxsr/la6zecadwIXzXaP/Ni8wqnNQACnd8/I2aOG36v/LxzSrIDh6qVxoiROaOe5/P6OHI
MUubDr+GgaSuxzFN/MMGF7D+MFQkkKDBE1k6hVzGkBYlllgfVcYl+mnzqQ4M5joxcPx4mRZvV6Aa
kNeDWv1YvKHU6RSBeaZAHfXVE27Fy+1BDNcuYRJSm6+BnIDtqPeMRwCCiqCcm3oNWwk4bTSLFnjg
0pK/Ja3oMpEiMhBOXmfNGtNDrv2TcuRyr9n5ioBoOIXHGnAW+TGYV4KY/0effVbvAuQsyB2T2Few
RPSPPCvF3tC4Rzh2CwXtLCXICWoZg7q1kWSD6CF67TTNLVwKLbq46uZ6Tepy/kiwZyc71fBXwWUv
pphZczzB9ER5alBUWPoznu7EUZmEigeFaqhSL6d6kFJ1bvjNsjSnu2AMHTkeR0OphbUKpt85PeV0
z/KTsz6n+UaTD1sn+6WAWSJcZqin9GC+udZwBVSsixmGGp5KZKGPAWQtDbCVDD1OCOT8x0tH4yh+
sKV8eG3mPr0EXbpuxuBqgtMZCTVy/Rh7nxHcQxi8FDB+SwLi+1rAfjvxPmzuE93TnFQEsoBLypbT
P/1cZnP9Qp52fqZxLnKicfXqZq6jBvNVNnSdbACzNp2nKtuiKu2yBygqpUX9G2wD9k4v5fmSDWQs
aWv/Slv4kwaefl4FOAbxfbGYuAXkJiREtr4soTGwtgo6GJstEdHQ+ML2nc5ecYjcHqOQM2MCZRFl
JzwApaBAlPm+RmkBGSkesQO0BSt7bZWoqWArOpMvB8X7LKbl4ivsuych75jOVbsLLg0kTBhbzglF
j3wRjeErEaV83K81vv3iQmdbUgT4CQmTQl8yaS9j4iedhoGWtjsqlFsI+VEX+zq9L7CxoMV5PIOM
37Bxi+pI7KVSrCkMaTmRbG1eQTzrMD36q6GI6XHhEoIupguLQFJ0CvGkk/OW3G2o6pz8ZK9/j+lZ
C7qI099F+dR8F6TtVwvx+1efqWVj1O0y0ryvGkUY+aAvQjljryZgybmD3uRdgd1aUEiju3rog0hJ
+9RSRe79vHw4fcMXbbeaGs6HSSVmFxsH4Q0M3p7MUUAC9zrDV45SZQmKhENPcj+QqgIhqpOSjtaw
iggOKfiA1sLstRVUmrx9Av3wrhDOB3sVygwOzr7g7Tl0oGghvwMYYly+cINXSDUrNFJGUJLXDlcu
JIfE7AgzXzu9qntglRQWV3ocs4n1UkNdMv7CGiKJ8kLPODYS9H3JKv8/DFgfyo5NmJwPLA2b+iYm
8pZMPCpoeRAHidWOjnxGl3OiwSWhnOGfAmC2A5df7IxjtZojRBOBm5EX1/kh1A0u5rg1EaG8Q89h
5P9zSL4dWLhlReLoK2fc/vseIGP5ItNc28+aO4fwrVQDc9ZxQrMD5gfI179IVd+ZzctQ/sc+Xyac
z+izXq/khViW+O87t3s0WqYKi2wFGG+1ppl1DuB0x+cA9xsJPmuS1DirAY28eVr/yDOQFirbHibB
xqi0TRIKr2/PcHN6ic9ybYDp/ciyQFA0V2PIIMywy13dLkv2TKhXkJbZVHdmPxBi0RDhmDhHamQy
SVoEVs3uL1SeTG2tfJy9N+DJNjh30MmPuP6Dep3/OTELtk5cvtTQh76FAbmkJ8d9NlDQWSFKKdTb
vktRcJC3GzK2ZN0/p+QU/qIDIBPIb/Oc3SZi8Wh43zw7cyl98DrJZT1YRlmfwJMHcRar1J7reDee
WXMZrsV6InGY98d7rTQ31qh/AGRTgRupcFLA6D5TmII5ex602g+D5iEzoFFxViU1pHxQmPHhMCje
DD8/zkeyujyo12XU9gBcnZzIY12kIllZsiPuFfPHh20Mw2VWH0zrx1foqV4BzFRph2gt2BOeN7xo
CmLq9E86lhJfAG4EbylIb0ue6fZ0JCna8FpN4C73C1Lq/Kg+c+t6hdIgQn8/e0z339sDLOykNN8Q
89BpmktREmF+hoTb2rwcCr9rr0P1YvKGFGk/tMFg49pkmDki0QxjYsCKBcpiiHhuIFtywGTzUP3C
AqvhtPSoEwbfQikWJ3D2RYxHDkEhdEc15CRsChHhC323ToW0e7WxeD/eob8IW7Qv4FdAHQv5qNwI
+vIi/0ttbvoVff2ifocK0EVKi+S6b/MZ/26kYQxixd6zF2ERFqVDtxyOCeURlsF41w+gRItU8Zag
zR9ln4r/i+Osd5JUEyKuvT+j5j5GumAYneJpY8WeVPkRLCOcPv7AKrXqYfEyw5rWQCIhCQ43hZbF
Ijm51RzLTFcKGr8FMCPH2zG7jPQCrwQfT40dLpJ2xn//AgUzRbqfNDpD6M+qHJoC5xzK3uihGvRo
Y1jutX6c4ZrxvMIkK63SGxg9dT8j3VI3Wssj+/0KyHL04twxornN/jCsZv9vWOI26lmGjMg6+BIl
9eUdjliGBBvenTqRzKR/Olk9VjKxOsGkrJdbkMS3dbVfRL+8pLaPcFIWtUtsjgKYOFj4oGBekVQo
xpRlmgJ/s6hjAdfDkf/4tZd66H5Fw2IKwvU1xpY/sp9/lumIKV4l7DsKeKbnyfGA4GSnV1xOT5xG
jIlTNjU6Szjov+gs3HapNprqnutv88nNWflfjbCgHtqXXXe84gMEbuFXIuRj9JXBdO9C12Sj/UPV
xn0FjGTAQX9VQpAeJOacD70/V5fup76dQC729eLKvKUgUDBoL45M/6rgzwPc8CO4lH0d1ehtyQGx
PQ9f4oyEsZlpjEfAaTjyd8ljsA29IQ18ZGI4ao5jjo46fQQe2jU3C/b0Rle0HYUKkT2o0L4sgqdk
fCcgVJDCK9x+JSr/3CpCymcj50KnBoFlgY/IqyG2tozqtY2sBD0HyqXy8yMt+UFm37TFqqlnRGk4
s6kU/FW03mPxBwJWkpA663fBm3rAyXbCahKM+FlRUf8Gu82tW7ng2bhL/GpdDjjcuoZuZzcd5UMD
1sbhm9HJi4xSEIIPsyYh1J4aEglaA4G4uuGFI2cF8qwZupvIP5q6r8qJDA0ReImqcgWt9FjwZ7I6
ytW/b1/+V6aiakkFX3hmpxi1W4XQbSUg58O5WkBX1/GHX0rQvMVUgi6A/9b3oI3SsmlRTsTEWqbR
aFfRLZla3d9VOSDGNqIMTLvWfHWHA6sMjlSzjBHZ8DQ3zDjr9wDHe/rQReYe+rvhNC3MKhycq8et
MTxEAODrTQynk4n9CFWfQWBq9WEF1873kBPOTiQbl8mLejorwkvD+XLEJgA9x/bunWRqnrDc0NJ6
0oWryfRkqla5pQnsr3LItB4M3V2xJqZe45PPw8VqREyX1JP4KgcB9gp/P/9PC/3kPOKMmwPizyn2
kMe5XAoUflMqs3fZSTfbYH+MXjdPVRdaBkmDHKZJLV26w/SpKdMuKNOiC9r9ReoueXHzpofwAfc9
E9jra1cNLkAfBn4qmiHZpy4O3221zEv649e7U0o5XaovEw1Tb0fsJ4tBCgFjmgltwIn5cV6ibmBV
vjZVV8ARJyPzeLb6CG8fxU3oFKCYi2dJWhFtHWGRNarK6EBQ4a/nA6C8MNMg8VlEIqnmGkzk3bnJ
mR0HWsvJ1jK6omY7TOFTJNu0/nGs/75fLCXSi9jWxzZO94Fndjluzxf1VS1pReAFq7f0V4dVEuGL
Cbe9QBT3sM/w4uuECWVGhcQvMm4tbIOGB7v8r/dKAcAzVkQ8VVSxkSpnPnzj7J6xDn9qjqYDzt2a
on63+rPoWZGgEDwxUpeOu3YLfZoOdDOU8rmEyPhof3DAhoJmoxbh/6M1VnsI8f8j/I5AtsyGi3Du
idFX/801FaYmT32bsYBZpxSo9yt9A+uIgac1GLWOJBdxwS7Q7eOkTz6ASoRpgdj0x8dzgleEehDt
eOgBTQD99QmVLjleUsP6pHKyP+6cKapq9WEPJv2/JmBTj4vL3MU7ml6QrY3ra/h6DSopp7/MHkGK
o21QGjErfb8eQIg8ulBoypYLdz85xp6Mo93Ev4x/QIJF3hhjC79qVWAaoV3ybE4gpwRg8xsb3nyr
blG5ClGZRCZCJz8/O+MB8EQuaFJbAOn3VbeR0dk3I8NA/a36i6G55zz8NjTuEQF8IIU3dHLeqxm7
UVaA4MM68iLX+Ph/opt7W8NHWzqRK9Y7Et+/szMU7VsLeXsGT9HX0Wtk8HdkmocTzcR4B1+GbFVL
GljSMXKMYGoqMf1FDv24fIhc5EB5U8lMLs4YnhSirxCIY2dT0+/hTr5CPtWyeYPaQHRbTxSIHovy
5bTtIy4U7WHhgrnnrwQGRohE5ashO3j/NEr8CZpPNf8L9V62jwNq6cK3p6PIcjmXsnvP1yaG5OoO
Nt2i6GUZowhq4D8gngy6a1EsRuO+rEx1Gd0jFQ+gEz71QPpcJlq/jsVtVm9GfWvgxOAqDl4foAO6
ECOF/DfC+FcTo9QQwiL5Pq+pZUcPbtQs2IWw9KgEpq8RtPawB6C0icJxOGglHfqctVJBTXE5DakX
bV2Egiul3wkdj6nwfE8vfbllDJC8Qag5AldLzKVwIIAiB3Cfi6dAusMiYbCq3ICrOr/61ImyzZOG
S0p8ANaYNy6KrhC3ZXL8qOzfTKNpTrYkMfW8QV+IaglPl50gW/+4Rv8cpSVg0C+rtnewWutzS/SB
qBWwgonWNbsa1mipA+Kd6D/Om0qSeW5yopRwNd9Q/6RP8CC5DvIUPvPf8GjOocdTLKZcfuMs/xBS
p/JmCAlzoJ1dv2RsJgejA549cR0h4+1X+9D2RixGT/mj8c4cW3IGCuVbm1v9wlpop8zm2qyssnu4
333dlVP4z/5GfpJAUYLTTLRZo6dCmQV4YHpeTdZ9+DIeStqZ9QdpfippmXg/zhURBlmAVVmN/g0M
n8wNGKeLnHC9Ny4VLBG8apc7iXIg8wS1yseitcLXcYTEmjRQOQwTWE7LygfLF2Xo93alCQPZdlwW
MljA/OI4o0SLofiD6WiKLbhCj6YV+dv+dOy9J/15L4YlUwHJSfZ0jNSlpaP3eC2hF98w89iDZVWu
NXICfzwgxWUNnwHWZN/mu0+NgACqC/9eqEh19Deav9t0gDnjzLVI+898tmd/24CfryTgOUzNlo13
yRYmO9C5QatUgO8JrtgicwuESUzVtQOZ3D5LhTM/V4sAMl5eifFskhDVosY+EVHqYKDsKgdCyvDC
GgYsXpBWSeEgF6Vqs77nYFkc+3mJA5YD4ZMpfZbBumG88nIo9WBDuIzVp6ZeGyXmU6ekl5BTMEdi
Fa8it2PH0ju5cpv6O7Imye7EDAo/O/sASaSoiiSddXYhLfJ2aR4Crzmcd80mHHM+V5MsSZ79csnn
Mddks9ZtkPcq+PRoV+VDrwvSP+ViO99rAD3g0qBDTNgkmEzDdid2GIh3UK/NqbyXj1vj2QLle9wY
l610DyKn6LJO1LUVoOw5jIYTEiDqy9xisqvPZx8dw3gTOPQCp4ETJKbouxXRiqe7OVYKeC0ImRIx
k6L9Av2Y2otqfiaYXnsaVeeA6AxRtpTXqciupfAixfJyJ3ddV0dEZcUe50RPjHR+TyabaR5uXa6h
xPm05ETKpbYCIrYbywxt/9Gi9EPXHMNPULJFJzSjsYlvTofGblC5vcpdh0fBr01B54xIg0A0ry99
MY0gY4GjBgcZs4eUBHGtpXWcCB1qlrvYWZohWJBOOYw2kio7/MoelFjnvCIAZkSnOX+Do9JucCSo
7f6XcwWK3RCPpDSvJKxlbszNWwyCxm1Iq4PzMMYPwVrbClSyOHM5KWMvXkXmXUfv/SSgz81pHnsn
8MlQZTGtsSLXZDtf43Wc0h5dEtPsCdElY5E9+lK/b3fE8GymmW/j5f4GhITmsM4helw9VMcq9b4F
vtGGsMDRK7IrpilnltgFwgnukp5Mp33+j8WCmFCFxUgMZApCDzo6ocJS43GWSFR4tJUZu4+WwBXB
0ylrz3K7/GK8LP+hEZPm2d+cxuGJ6+ui8o5fWSEf/aangIF29rBxKPDc3oVWN+BEzY45QfKR8vfN
WZYJPC32jGDma7iP67022JAilRStNEYJ7x65dt0NKwKPGr/7vQHj8txf4f1wBuIxQlbDuJ/tpND/
U4ZsPo4A/HY/JNineTnpiXC7aE2mEVtHdynHnQyy+DjzP4ke1P2DKbOejWRRuRokythtr/PhCzf1
MvAaChRSnTxakCMEJjk1kpCH3DnNuI0mMXiVsa+htrMsOL4oWd7oh97gtXtT9J+nyMVZynHW3pH3
Ma7PDOO4g/RZEatnSSlxm9SboP4SbES078IKDU97EhNP90lSbASFCMjBbT42sVAY5K7g2ia9aBT4
rq58nstQB7Z6O2+CPsMsuCRdWrcvTyThBtGUuEJ5Rxmt+PQ38Pwt7bvjbZurIFRNqXAFL+CvxdmQ
VjexV6I6CR+uAiQf5jzA3JveUFrzHOYGzAc1EOFPSGbfH2qM7LOCXQQb8IwoUr2RQ8VtYVqUoayk
NJVZAoYpet3RpuGb3uJ6Jt55qvYG4laGnU96WyChNbjfn64b5hY5qOnxPZd/rgQ52IW/8gqZb2xn
L/HXjeln6Snd+jIRgDluJXIqV4omLcMrfEFuP7zd8n3epEEklHPsZeV4LzS1yQmMrPnnQj1vdk6W
aue+dAAWMP5H5uJLMnyILaASWdAGmp+yu+6KqrUtz/PdWh5okJ2W6QjF+RKWCd57SIhmGRgkMw1v
pPJhA6VJbc7yV0b47cJN/8p5BCAiq1DZ3ElgHQgEDB5peBoqfmAViscuMlOXIJomakGfq8jzJwCx
LYalbWdri2Sh9YBmCYZ3SIK69i5T1gyyX/JXZJPcNTNFgAgjMnA4y9OFweX2ROFyMzztKwopB+2/
RuC0XOYWl0Ucllj9aAZUybh57Elkv4p9hR8iB5sx2xjxyy967R5CTeRX42NbQSO80GjVrTzk7HGo
mHQ1NSBlPLHu4i+3bg8NVkSOFLaBfLIzKtqznD09UFdkf2yoN9gdFBJDOaXBftHC3kqLbehHmsnV
qb+FaoIaIacYOcaGScI7OZ5x7G1/Oo64shvsxcF4d0niyrNyJ8lmkh2d1Fwv4cYzKwG33yFm+UPj
oIsst1bQaA2aNFZulKo9cj28zUrhwo2kaS02JYVOyIlyh6QFnDJD4BucTjTHRWNWzoQnIKPUymVX
gm+2EZeGQUX8+AjDF030Wi+g5PnOteMM6F6Wec+z+GKTU//j77vfjzi1EegJGzbczf2QRolVOe0+
1sJeVx1dga6PCnwg2uyWyOi8Uoz/gH0Gp1EZkF9SldrC4F8HepoTeVeUiL2yz5pnJbTPzATq5ufA
o9NpOGOH2LW/ewE9Q/cUq2Dl5E88d51LfPGKeVVh7lgyg/u+SwBiC6oVbNooAhlJP5gKHcB4LMcR
WlI0+PT3ZUkmegp3cXFu99VeoKtUfOowcGkDqhPwBdKxSI0kL5nzqRgdxGPPbOr6focUHRYX4LAe
Zqi8zI3QyiBvIhPxhFSpfEPdIgLIfwVt0DtcXqMJQSdBqclvLN6IIB3sJhRWEKPKXjMo1MJJLytM
vB0J0TieIb6IqxPAUYplPHsPFbpSq983A9f+gerQ8x5cP7B1VRPJrsZn06PcTiJ8C6M5sySQqZ2r
Ik9WZ4g8sgH6zhQtJHtYgjGH7R5FsV3sPvnuYJc0OYllqI1HP34UCdxBFZKx9SCnyULX5mqW25AJ
TTU9p0c2pb8HgvzJJDJynWuH5uKBGquMNBB/JFVQsNSD8vDZaZvtJIkYDRYa2hZ81sFT+d0vKJUO
oChMURBOXCepqhmld+pZeh9o0JWYcv73K6rpX/nN7OPTOzxFjGW1rVhNPlr5dafWRyVD3tRYh8pD
fDAyhIfrLqLoWiXwFBZOvJK3PoeDCEFfj4EKPEgwc6DfQaTEMqdQUDx2iVeufxrCo0nfQrMwHZDu
SqheVmSpBuhctzJXBKGWyRxTHxgCXJIOClPqZs7ukRYaYaSRyIVYfMRmL/n1Opv5M/X4Dj6Cd8N9
P75cXmHpj/nxTRI42Ss6S2XPdMv/8mJJO3RI/CXC9jRZn7tmMo0dzq7f+wFVCt+tqbDn2ASl3kZb
LPJOdQG7MbA3IJhvtASD4Ecg5d99HWMJBD35GI3GWYrdZh1PHVkUoqP1abbb62PiGVuyGfXAvk7U
rkz96YDvjQSwcQvKOYH0l2k/HFdJBeu1ze2U1+ea1ogtQ1paApMgD2VWi7OF+HX6INirZM/7vGtZ
wnK3OzHkN4c+nEoqUxcX/cFaLEHjFhVWXQ8T+2NMffi7+dx9tRaeZZXDZBN+/bNnEubXuI4GL+aR
kcU1EIPwRwnhqqLZJWGi2kVcJyx1LGOngLtWCb8OVWcwhEG0S5yqrCZi+7qwYxh9gls+qXh3TIaa
9xOoao/eL0mzn0vJXOBQ6d9c2ZrmR80EsEmWm2XDsWYWMZcrL7RppE+B8QtHqpxTLV/+EBy2Yb0b
K7AvyG5nk9ETXDgl7MtD++G5y5s8tz0Ud2zSVNKMnDtzDM3j2ScaFICTDkI4De/8CbH/vU0/Aw7C
8xsT1uQJP9r+WbsR2FIBcAtQ5L5XTD2UEkxaBM8n3x+9WVDJy/GL2lu7z8kVCVB9qTdbVScY2ukB
DmmVLuSU46PiPQqrnLEGkwRbZhzvh822O6nwXZascxuqWw348YhLhcrUzu8rrG2Y3+OFxrhPsmwx
gEjKXkdjc73silFva5sYvbgdQzNdK0WRinoglEH5P4lh6M2TaRM+/D0dv5SdeIhLAaBxJcXv9iOY
P+i3eC5vwwiIxMHUUsMm8m4baaIuM7gqqfoq7UTOLbRtkIsNPqE/tnxt2xG6C3UQQQs4G/sqbnib
z6DMb8nUT5eJMl29Ixn6m3qj6lE6dplV9FidOgyWcs3KQg+sKEqlmAAR64134Uz10ghWkiQlnnyN
gV9i3uAzFCh3XLzGHSeKtgRrema2E8YZNn3IPEMVZIxw1iqS15EWzdoxCFw3GOZ1v4FhqYGOsd5l
UA6bxDr9mNBzOrOZ9wn2qR0wiVbTpCu0t5xZrEfxvXixwacRP178gBlhWAzU6VJZW19e3l8Ptjlb
BKWHr9z6QiB68xoB0iJLJUKGSnQ9uijezz7MbvhJThbB1OCh8mRGBG6DpUshDfBiLV7HsgeU4WUp
pzSy7Q1sIQDNTRHU3oAuNF1QIu1NgzRv4bzukGqYHQV7ucvdOqLu06hjlj3LtmubwaIYmAjEVplh
LpaJczWOem3/gVZJUP5VQqSwYaSxQXrusjlATRS73y4Kk2H3e3Qtq+Cxsh17/9gZibIwFLSMJIdG
VnAnd9d2rO0MCOMM3V2OT0pX+/Ec9mBxzNPpt6G7DP+zugb9mftrzeFvIPI3/T6DCQRdiLFxuVMF
JZqD7dsbgZq88O1ll69vCG26UIULvpD3I46cFB4ER9cnrP8xNSNdxyKZJY+635OMeZDKGDL/iiUX
dnOuUykj2/5hCA+b930DvH0ZTWoMUGnWqkPFDO25tcvDtChTZUzjZFwUo3OEfLz1PvLrvhn4l/Uc
Izf20Wp4BOsqcg7zceEcgnDR7ouKs21Y0IyQgfwUlS6Oi+PQpj2YbWb5KU7f1ms6MmOipxCUa/my
p3IjrPvrmcdsXn3WukC6KN5kBQ2NZLEv99Kph8FOKK3SQ59YjmCvYtxrJnZP2lCKY9Z8+Y60/eBS
sYM7OrfF+QiyoPNZ2vpz1JQ8h6mnk8h8sVPYCVzqkUK6lqd+drSRfHMuJ7yPTNN4wSRWzu7W1GpO
NVSnlJOxAEaS0MXwZk11VMD1IDgzQ3uL+guglMK8NhcHTdcY3yXZgRZV9DLNRCIqSxGTfYYDul2e
JBuJpQXYj/hnYrfja+619Bqpem2JdNR50fnS4FxW1L8Alc9OYm2VTiaGz/X1YcsIpQAsqljcadoD
DvbTWL4j4AuVZ9uQMS1dN+4OmW1cutVs23vBhiHQTpaRtVZOl4ilvGtfcXwkZedS/DnAFNPIOqzh
EUTxSKY1Ih+pcxLar8utB2Cn3cYjj/Y5xureywiSIZTLQsg6iF4/hLN8+E9SAIaTQWI5NMoWiR98
Xxyz7w54r1mRPv78dt+kzHa8R+qhA0CVfLLs73MR4nBUOPTJ0x38BG8OfoqYDpnDrfzKK11Kjrmx
/6ozpTeZiKmjl1b7X14R4R0ggoG4/QlEBRA/1QmgnyXANrSmV+aFMj+paLOHreXXFJCQK1aKDWTw
f8KS/1Qs4rDVamJKBqs2zGGuh2djGBly+ziZjTF1IXvaWp+VvwUBJz6AoxTyfW3fq1TnOC/11Vnk
0yQg+AGEWPu40DbtrQaBSDe12CLDhqqQfkYpQIheNfWuEawJLwDr0cngjRawrq5fsXCTfwxQpEUq
w9BoO/oWU6XiOlbMZ8Uu5fX7BTzEDgDW70DOVx4KzeT41sSsPB4A7zLhSWqcs1PTZgWrWVLTZ3c+
xJusPzQp+uM4xNunNPSJE81wO1NCP8RVnOnynuE79g6w4agfAqX4V72yT9sU6vTFu0BCmxIG5miX
ija38sYkA4wzozVmUdMhXWlYx2N5OgutIWJaX0Fg84jOg+zTUzY66Fhzr/mmA3rsupyDhmTo1Gi4
xPZWg6dXUHq663HVxaL+7UndAiH7me8GY3Rv+QIGdAb2eQzoUpfzrYL67m7jEGdMx/t+pr+MrTao
aoM5RmjhPTlc4hmpPc2JaJv/aZ1ebNkhnaAGvVHdgkK6Ruzs2FKM0sC/jBrRWeCndGUQK0PWFvf5
caZK6gBWJ/sd5vadG/qjGKK3EI1w60y62pWyPbHRzTx+QKs/Jy5UxldECFx6bnQ8GE7PStFjilV/
9onGE3JJAznXx0NCu6p6RRqrC23CMxpc0yAmz055lkPZ+IYnI8WbTUkk8VDQFyA2mJbPMVjDirVg
dix5edteQPuFqSZW7AQSP1s9nS7vYHDTB0PT2fKt4VJfbS7eaDDIeSaUFuOMIrNhrny0w/RpuZuY
WA+gUFFmB8jHriwpcNC8R0ka83Eu0sG3VzUkOq78nvg+fgYftaV21YJo7NP300MeB+oPJrwwuVTK
ep/dOhrp8wqpq2/afd7ftPIK7VVKrdCg0YTt9JPc7j1PW59/snP4JeQXoh3EvoN/+kvUIjMbznmM
E2U3Vyqg7pMsqMZVoQ9xj9AlTePEgnaSjwEt2xz0yavWYR7eHRL8AUEwr+/pQe/jK59YjfgS4arV
BYlu76yfIVa9XmtjIlJSwQBOMbSFWsZAw1fG8HisfXhv7ZEQ487JRaGT9eJ771T40P3XsVGVK4JK
3Lw21dcpmcnVHcNGOfX2YJuDcXjiMuGvRyCKJ2iWUoc23iisBPPMgjIbmMvkmrFsB++eM1KHDbDW
qH/Wt6LlTcRQ0P7CHrAk6FQ718tLvG3A/ppY8StLQpgGqetuNKnUfLoYUO0VQFtdSOHuoQLyA//e
XcneyAXREEINPpsn0O5va1SYrSxUYUSoFNnVibn2hu6B1BGUa6IbT4XdBDnAjI2C2g/ZmNq4MY04
Pj1N1PrDaLZKfa9DTgxkW3kzK0RxpEouV45PN4sStewBYmMF2SXp7qz9YFEa28dZj6kDMx8zatSe
vZep8k4IZFxIYeiuf92t8EqFvsPu/z0baPTSEnaD6jPPaY/CRMjC1qPdj3PXRKI8sfLapBMb2McU
qykmZqLWdJ7LTVGtjMiHjJxTe6oPOIp7rGrwzt+wv4VuCoQYBuJWOVMvTrfVwyaBKZi3hrC0M4h2
7awztp7VnvNhjtLPVOB6wo1UBxhACsWwj2DZqr1SsZhdZFSWL52KlowfMGxmAJGukglwmG+YU1jg
YJ6yC4A2ADNp7TbNd+79Zkxs9fa84cpyz/zrluc7lfvv2YKPEBP5oQGO+T9/XM25416PzDo2SWhl
/Z+5rwUygaL8tPPCB3y1f8TATw6OW4ilZPUInXJqaUe83OvU0kljbvgkk70Gs9olOIKvAP0Q3wML
O5VGSEXMJd40iTE0SNBV4AyHcyXXxET84Z8LkTJVwzcEkjmn7mlb8SN9b6kfRrni9yOXNn8XVlxP
w/77ncCsQVo1AP0dxCKJEh8bAKGnea38nPqlqUQp8pzlNk9ii868z2y4HQ61MuvlKJHI+Q97L+g6
FeJnkco3E7AZ2pI0oP4ry1zRu+sb/L5sD+73NS+RGmiIZLiFnzR8XeYEbd39Dy5VQGYk90K4Jau6
D88HIqaN+10KqIJoWeR0vjlJj6qFLIuMdNg/8OJCpgZ35mQApM119owjFrmSy9n6wHK0i9NMBugO
pWaQVnwpN1ujHfbdR3VFlw8ffFzN3H/u/bRzIfZLEyM7abA07g/tnyozyaJgKWwTXverUn0fu8SR
yhTn6rgM0cxjaAVH+whQoJAqlYO0tVzciKDUnKtXkp6rNrS4GSoFDuzKSRGRnWYzFMrpyResiJsm
GShIGPbbUNLYa8Zb8Bh4vkbvlk+WP0/XJxhv0W4SK+pvEDScm5cdBlZthF7vs3MttWnOJoMiIWsd
1d6aKWqc0+/s9LahuNn2NPG6+xRU3ia/cEMhcRmeFmTs8PpzFR52ICSb/Vbk+ZE6uxqf+N2OGSOS
dDuAyBcV7bxPM6KK7pN7zHxxXE8FY0aGzfYR85P/b+OPccJM6on/OchR4rFiYTe8TGtItPvEGdUY
QJUzZhciIT41KNMMpF9TnOgxSnOtZYeSrd6LXqeiBX6Vnt/l6OTMBVHIyU0HVfIgQIvc5BTy21bg
pCsOrwMoJONeP1k4GyaMEYeivoChJW+S4nT2U+UZr9DXhqhwNhSwJY6exR9Uo5TP6oC3ohkUr2vi
X5ddY69kgKxBWhAB2x+8oJsJAl8T6u6LXN+jHAf+pEila/LvRvU2wOU71aLBsQW3IqdUJCiyNs9f
wJA3BpL3EAtHTFVGbYriPgON6KF1S0/8LgsyPMeWyC8GK4C87ksz5n3dEcsPsG/WlB+siGDHurar
GT8RS97hNDWOp+ioE34ckFw76EGdf4MaaCiSZAbbXAeX9GUkp2nR31OJaOy2rXu0EhejC8dXfnty
mP5cP8cvkxJiaAXi8NSmKsGRObK4IYuPyXo9hLme038PlDZER+HAPLy8pRICsBtq6pLNDNMZpuoi
h8rgQLsRpE7zB/kTofUxO2FPyD8+P952AtEMOhmSusrLuKtdAmCOgA4FR4ZQcre/pOvlcatYdanQ
XKCIYV9cLizOgy0/WKeqMmmlbL/8dKffc0+XxchvmV4FCvlkBTnpDDgA08/cnrUJpI9a+g0u7kuB
KzhWS+0uRSURCJxOLtphZTJYPUGPqTqBGtT3jazi70PONIHebbrc4iX1VoKVyVm0cg/tnVJWP2vF
DhIHM9t2SgRvOendX5kQHV8YekUTZ7yFQypLBvvGr9h5fMFAkD0AVql2+Dfjj6/i9gCRKN33b/BV
0Y1/BWjL2ETdqIlqcA2nPS1nf83SkDbqSSSXXTFFZzArH0hXD4NyZJL5P7ru04W+zLRMrHg7y19A
EA3f7swuR0K0gXblBZPUL0ENFTRK3nM7w4EYNK4eRpLjgSNRzCdYafTZeLOP6JNgVKSVvH/wjHql
hA8NaUIXe2Qarq+yCX5dTLkjKeax3fQLlHqB99zoT2qyiAYM8mWePHgVU6jarQuQ1jPvL8ih1jPw
aDpBH4rY1PhNDZmEMl8fU9riAAvrVWZZLoHiRkjYZSX8yAvv/VfkGBgL1xWhPeueTqfpiRnr1F+m
/uIG7KAL8rBH8MVFK2C1TZV/DH88AINuhUXOVfpidxj7KFEvozaqVsj3P3Fq4mSqI7HfYetrxJtV
PQRDtC7tScDo9ITVBe6iN2o+rAWtkKZ1ZFUPt1IEYQIRdv4nIGVef16xZ2voBQBTASkaOeJCrdls
gIoCylH96Dc4hST+Yvv9wCwcqps5ORs2jwGoKPiCb0LfWSpzSLEAIhlqUgIhoGl+YtR5iI4kJxCQ
AcBwUryG4gyBoZN//wIaG2sFB3yrMP+iB+MgVpuEANmu3aRfvkQAov/n7ghjhuuYM0i3cslOX0hB
sEiJU3W9AQuGjVIC44PrDb1TIBOzkNy1a8H8wjQR3d/oxXju79FT23o30gwvsReUeXdXGLz3Zxjv
igk0SYJCNqwjFp2hMX1NMLfl7jgC8JZkEEvMuv9H+Dze/xg9BLgcxvlcu4HGsMMBW0Ju2Ym0QKKs
96pSR/Dk/fyW959mMx55XMJIVHU7LpHEoIGnw76dKjHHXSeas0ZOjOn8nW+Zbcb7Tvk5+pKnLvA8
dllXByFq62KTlqiA+E8mPXPQufUzWdfWVtLKrQdDIMEqq9XHgj0K9PQBWtNWc3zog82aOqW3AJS2
xuqWf/FqjWeU+bsXjmH8M+0knZi+YVNZ0IWXJPX1Ow9mpiO9g174df0P8QP6vBvv5+hWFsg5eNon
FQ8+VhcgvjoGytQ2Ky5BrrECL1744GiYHDbpClwzB0k4iTmGYMaSVfzI1I6BtNfB04weqpWxU796
lApeDveMIbaJwDFgubc6bHxgi+wRrgdjtZF+6UD4pdNeMuWrzFZG3NI7R2Jow51e0WOC35SIYQon
dTUwmMr33tbMoUenrl8P9Tcx0S3C8B7sUL56Ojg5NmawmEUsEEUE6/G4txsLuHKnTsyyWYqD/vtl
rGvEPnZj82I7eg2TE2TsxWlG0aiMFQMXnXd2tHDSnGVGS65JTPftmE8MoA4zzV5rqqNfmAwa7sKV
DX+O8reYZTFMxv9UhbOSMocvKY819nKnP6Bx9u5QeC7G3J05wJCwjXamqn7sYpaPUKkT9eOvIYAH
wDTGQ+i0Sj1aNd6iNTc7TixDzu0rLZJKCyn9NEmn9JGRHM8MGOVVozuoGMI9FiGgsOwuz3bGj1/8
ZABcgrOUoNqiePuuMq4zAQNW+hd67+7Vuh9t1OkIP77oMirPiSmgxjisbghC1VWq41CfDGWBry8p
+xlY2WRRxZd7uOC2tvYyJzUgDQjNdGXY4sXiVcY2K8yCMQygtnME8kGjQlt3LtIsK1Kuog2YExLt
oXBRil9GIg0hZAUUlwvDUMxVzP7l5ooQypo4Q+TTrnI7ndFR26yUYmBggX7WOMPFZ9D1A33c6w4F
/hpYVZsw0PlC2HmVLYL0aYMycF+jxMQs6wBZbw/D5cltWZ6RUaXqYqle7DCt/nivVLzSp0kmVAwn
Rugp9MwbxMteQ2C9h0ewVtN0WIn5DcyE1zvBss+/GcxY7icQQD7GS95fUmshvV9oSe1PmeLeqQid
aobNuZLBgOQ/jf8a9pKKWLmq3scHB4idzjNlaEmnFi4ACsGcecW7bZfx3NZpoPFkbY9thwg5u2jW
Q7x1ButqteVqy+0QaaEw2czliaHOFZsW+my/GniMKRNCVXk4nfB8yG6NQPX/Tm33eleGe7HEuk3o
lAWoW3cxVQY8IOCiffCd9GjpplEEJNG5K7Yonfd1ACLsINRJWy2Tf9Mgf3qx9y0oL95WAMtSgGyj
/OkvI8+j8LswypgdwvOvyURRpc0UfWVF7vOZxPWJ84NP21Lz1/jidi3fbczPVwON79YJDC6sAYv0
JQL8hgbYaiqEdtMhBk2NVK0276OFEIKkJGnd1El47iOYJSRGkJj3NLRtRnK0hO0EIvJS//5vooiz
M3wYpUgxG9kApD6OfJOnPLxSfdqc4XK97ynUKk794ZMzNNxM6ep0ax4sjWn1/ta7cuaJMtJItIcK
twBNoA8Ze8VC4cdTka3PMwQD4xy+D47F4Ppz7MwCKTAd2jxZSb82NJZl9bCOJJTRe9o9ZFiXX4jP
85JUjvYdU9l6RIejjEF7eKw4+LTFRwL8qtyRaowzjjSwe4uYiTwPLSwIrQvx5g+z/00OhfTcnCvF
JSCkDgDXgkJ3pELyIuubzqzmJnozUUKlMEAmI6mDxSq5ctbu8Gp1HK6VFQjWtVgWZblT4ZOouwer
Hy6ewiS+4HQ9FsaDn7fC5ksf1stpOBHLGgOIRpJ5OMlxZA/Cag19h272JStuOQw6NryW4VJe1/A1
hKbzRDMAgt90ioIPQjyQ6F32q6Pni5IvqJL2ZYItvdHat4GIdWtdtchuZvx0+OVZRpG+n85sQGE3
iRJzJyskO5NXOdUI9wSwo1z6fOa8cZLwKR3dMZyq30Om1A6wAS6ZaG9rZQxkf/z1bvB8TAgr6Bkb
wjMzPYci203ry2c7jMQ1RkIKw3xudJve73a5FnnGWclwrBMSBInRv4KDRCJB8HuJWaCV5xGkBc2D
ZSjN2aII6OEV4xLEbWzPNpVTUtpyd1y/qloSztsbJ5NM5M7k5NvNCMdilFlls9rIstmMKOG+gANb
STfhrc/9pWd0g+AMF+auAjtFASvvbeEgv3mZ8ZZEh+ABiN8RVmO7f0p1pj5J4Q/8ZnXwpIR+yKdB
dNDppNXgeX7vBgo2ttJwtUX4/BzFcDUNE6HH6ild95zSOnJwinL6XYl30Dr4Gct1g9QYs6f6OLTV
3cwdLs/nAR8HQO+MafjE6s2XtvY4whRl9cqEeedv7THe41LU3YNUaXKfL2/pxlyEccwArJSXPy2d
vZo+lXRRWnXsIpDtsyRpjufmGaoY1EwNzqDP9RNwwI78ve69YO7ghdzBA95lnNQtSypAIMXhgXeK
2a2e8fSpHLx7OhasP3FtP8zv8mPRf/FzoRr0y1c/nU+RSUOXmqqJvTMvk+n+9k2mdlfo2IXn4Y58
WSWoPsu+Rsb8frbVSnSJ5AKMMBk3p8EVO+2Kvv7UGwNP3DzoTaPjMBqFKVsoVvQd5KU2XloTnikK
aHG6sIXkb4TiuLkFsy6iZL39PxafuEl2XJKCGPKhvVGleXY49QCfH0atVimJXsWmIPn4bTAb5d5B
LgN78pHsuP0t/elstMb6YEq7zl1fRnJmwFscBqbNO1teX0q5rNWSKP/BL4XoL5agZ4b7nG5m6YAN
mFvLSw29vPnxMDNrG3PBhv5ejcTvS4oHEbX1MFa/ba03ov8KKRGoaRr6IzrBUCDL8p6GrOHzeTyi
NAOBoQ3Pyo47tFhwJMVxmYNXivWkCBdoYGCDCwWjSectTFxTIqy18eIi1uNoODSxyMFAK43LZwV5
VfUO+s9mvVX/aq/qQ01vK4Cy60KIxMuiZ8SFmVlv678mf3IJv7sIUgfX5X6ipqyQx0o6kzKpegel
e6sXkFi6obcvnsTyyzlhlps6gaf8qmVHA5wTFlDZr+ZGoOP1y+N1/dc23lLZUlYTZxzIhNccGkkP
Dz/Q9KoBu4cfW59eAfaMgpmhR3xaj2syeUJAE+3En4UiIFNWknFSrDY8a5hrnGHCX7bqYp0amZ5D
YFwPgchn6JZDIkZkDCAu26kZgsyl2fM9MSV1w/6LhqvQazL1F8aBODKiYkAqLt/rt3KpKbhDSI4f
8F0IXFRSkruRk5ratElcZqm10Kdh5WecVw4rKLXJFPbBvrPqaz+E+bUcEVAGW9K5R1DCy9vAjVFG
6HM6x811OCbnf4IWzkw4cPUUNkKVuFjXKBp1NjpceJ7wRyh9W0Xr/o4pZRFnshgvfwfUgQoSse5w
LaNnNk/AUy9zXNdeKkoYwK1pU4L/cP9igVDqVMB/2x2t2sAXCNehoOOhik2doyvQ3pfIEEeku9Zd
aldtRQjtxkphleesRXe0wPrVrBdVHZOEKj7bVib+IYYYrR3L74vbLrtr4v5VdU0bLRdWHqlQuGlb
tDs7bRMwfNfm+VhvilMEbkeC1l5FwQ12hRzPTyBj/h967FrwArfntSO9FAOkz98PtoFPa4FWrok4
cSjT23xfzc5XKKtq390EizKl4DR/12fFDTnclfcA2pFH8rDXSqCdEhQkKeAAg9hAFNpb4yR4YjKV
fBM/wdUNnNPEt/ZNLZzpyzhpa50vd73WG3c9YGvfmGJJw+FfHy5c0sB5gc103glTyY+AjsaE9DDx
xOW25JEQSc46WJBaPQXEchWQzJyztXU3uRb3KoeoXYt5dV7mS9tirO/AlVt5VWSVzresTRfdvNGg
/Dn0lTW+kfCm0joNZPxuskAD1hvKNjzh38327sFK26eYLRbvazA4B7Zc/AvoWpW3lTo8hbenM4e+
v+Kl28Xryjd7l2mJLe9yar1J21v4BulqX2dP04NhvrsHuZewaBXcLiiE6jWzanjZB84f8cMCCjOG
GtcM1eKXrpxV50I581udSbLS4rPTXH6xRdvqGyfPUvWdLu+yJFvCLkkJ654FEctWjIpL//4r7AQZ
zLBMiaRfk5gP7ON+6AneuAK7TihBbYLYA4/YZHEx1Dz+uv+v7Kcvl7csiAEXO4MgjlbmQF71a9aJ
uzYoY10zVZyUg6omnGUUbLNCrwVyCKCXHECAV5u+2qfwA8wsUF/o89eFwu8rqUKdbKZjdNYR/93Q
jmYbX7K4f/aMD/HdVfankpSPB1rUeKOJOLH3++qAygsao4DY6/+BBdwmXSkDqIcW6e3XSFNS7wLD
TAVLg4a67xZ7j3+QWzVtttf0rq8ztzknWz/nsra9WX3T2q9HCrsgSFURYe2XteJrlA6Dg++G2Yi5
jin/g2SFpabZ6kZ8CTu/+bri0V2s7YGMqmFJl+z4W+54mR0DEF4zPIsc/ECSEoqjC64wjg6l/EWt
yeiXdkG48I3guV4O6Gpclmz3QIxYrY8Bc7qff0FOkyyLIccQi883P9t/19u2IG+0QrcEGLqci/Sb
45N3M5GxwUkdeNIHeohDMwCI5lt7STkTscd7QC3QopobQOGxftTUSWz9OhTq9TdglpKqO5CrLW43
3iewPaOzCZUp9Ygi4ctowdJO7Y1LTgyRC3zmWRsjhwiQRhrMzrJIUDq1SQyvcz+qyPGVuah2oxd9
5qBopXQLhwD19Qn/ql01su5r92t1uq/xJIUqdmwpMAOd0QRSTDRCGzQfeeoNYVg3XdQxyqD6h9UW
Ob2WNj12ORh5kzYUVyCYdzeusNK5lXsfq6nH9MwP5/S7qj7ZoR3hTsRDBt2B3hxLn1nMOP4ev2fO
U86iTHsQGtNhNEvhPvUjQ6l1tj+RAWaVuIN6afplOdHdogVpBysuLLsZBAJ6b/Y4GariTt7nwZzs
KfiG/ethkZl0Gv8krELwFn7zsANCDQscQZvB3WIDhW3cagcqE3XiTqOP7sTev8KjRuNUA4YcK1EM
//PqiO15GYGMxSvrqlK3/UK9xntkAIR6xbrdKrGfzv5DYfUyhntCS2ID6zCU3jzUIENT0mD3cN+w
+41C37to98pknLJBrx0z/uL5j/i7Z1qarOcbKoNQHqU+dQAT4EqDghNg14uX4GcBhBqH95lBDnNB
doxC4sP3Aj2mMbyr0giFeJyLs2JtoKetzCEnXBY6FVKH5Kdf3RhraYc1CJA2PDepkZ2OCCwJJ5kG
KKJ5kBoW3cyZdkbxxZNYC1ysSIyQGKn1ylKKwW1ula85AzhXfAMAM0qA58X1sZCMta9fXeom541E
A5nPvlMnU7ifWkcevNrdI+M7Gzc1ZyyrwcVcL1yZIaz7Lp/iFNNF/H25r9C4hPtzkZa/F1HiNTCW
pzZlpANzZKbWoOriPH+k4N3N3iaqWPbIaWpzBHn8Tn0sjtyAUJKgf1as4g+eKrjvCOziBrhuM3AH
YVLFzsS+HcZ/RILD6hXIehFWkaW/8ldM+1eV5kRWWVmS5ssw65/vK3aSdyWkYSH6LISQlJgTgOAz
8LFdbnR5gSu1ROWlqFkm1qrHgWQTIipvCoaJfcipp9V4QFWGyBO3rxKe6YZczpLR0jwx1QuTUXkl
K/Qo4fx0uaDrtX0W6uqYO32BW1dL+hCwcZpdIj0JeYC6ltzCYJUAT2071ZXQk0cfZylIokEtYn0O
EqLHQ/nSoR2valIVhEKQfz58R0MhG86OWoJTNlOttTFF3rXH1E9d2EMKoINquaDXUSK+BE74nadY
pn3YL+s96l1/uxt2mBS71JFdw4ZA1lnWVa8SmjCDyfYDB4NxNDgnlwDSDCXKlVr+JpAQMcyYJiik
tAhakOd5/Qk7Ju+s9aqxmhqZjOMDfK9/5F5bk4jBGis+cUip8x503IHcsN0vM7THOCKBtC75kSt6
oXfg+afgN7Bp3VMetLC7/bp5QUucWwR0eGFiWcLyle0NcQg6eLFUos+epOp1W4W37AsNTDB562Kf
3aPZVDGA015a51XlVYxTPpd5Z5yUQOTXF+Yim0TWPJAPLMhKToBo6Iu+FnKYawMqRLpMX2iRCJXN
TQ79snL080f7wYRb648n+mfaU+BOImi9wMnKbQm0R6bnEpHTgoKmvPQoeICX36rj4nYFdR5K0WSU
rM2rlAvfBWhztCtf6gMF0XMK2pThRI5j4lG1Tlp/ivbMvmLrewam3j7OA7MTn27FgM3h9+RXbJih
WO0W8xiqTIozAE0oNPPVgTXr1a5MUFxtp36fatqfLtRxMnrZVEMNfeTr38/ENwq+jvuBXHuZPBHB
PbV2sj87k3InufX5FjjehkavGLx2WZPXLDkKFfex7NY+Wo002+8Gi+xszMCgrLDRMbgwl/iOdvD7
XQqnu6pQXJaZ6JTuShYbcvS8EqQCEGwcagndyb+KvMACktHh7VTRUfUzg+eNUBmfj36Xtd+DgLdo
7VZtKtjlQzot7aE2sFH1IoDLqPo6J4eAI3rX2NYckYSryuKRCUkA3tKuDj2lPknSkrVwcF0piyzo
dRe/kqcFUgZEdTDHc9YPatnNxZX92rf7aLQg5X/r5isG8R40ieu0nlX6/nsksD0L3OGMp0mSWPJC
JegRloagAypUp8dM+CgtAIH1n2o0a+dxduuFCGsLEkmLVGPl1MlJBvsQWnmeNy5kpCWHdZRwN60l
PtvQzj3FAkYrAqEqPhxJpDdJzkD1QqhAl61gbaP1s7Nvp2KT3HAq4LgcQmtkv5UlG2YbPNqyLkZW
/pCwRBDd+lxppfgqbmC0o5kpKMB52EgoUwHuFp6mJyvnajetshT3VG4cjuVJIyV4y/XDzZ9KlgAq
mZl9NFxArkKNuqpOQXnbP9cIpACctiX65RFIKCLIenC3B51dL0EZ7j+AjvTKFMi37cSPYVo1Qm6M
AvYOzlPm2RSmrvDJgEZI844cDFiSQlTxR86GgG7xEpXZaG2v3XzzAr1LfdQ/+kZRYJsoFONLS5D6
xVOiVtwbtc9uo8GZvA6JUDBkl05aRk533ZoV3NqtuWy8UKQArfs5SRAIT/1nIMFapaDtOuyA0W9g
Uhh4YtzZNu9JnE39OuFGFr5viWqrh8qdPcO8Wb8cQZoaGEBA8Uqgxup7A+u2Aa00l54VhwXNPwB1
o8KM0kUOa4eWn7cCEe03CjI6D/GsBlq/ALNPRVTGYrrLRGKTIwoWHDkXIrEXdkc9hX2n9Afie7Z3
cfRpoKfYemf5NbG+ISvVMIf98x9bZKRARy0MdkwnDupf05vWHz0ghOPPxVlDJ1PZ9JPqNGObYvGG
dYXnTZ5rFScPyvD8blL2HNG+eEvsFKB3ecvpBQMqzwNE6ru0mpK6PnhK5qfvVBpoX2+GQzJxq2lT
yq9OvgTXVxfa3zQXG46yOISaUIxwrOhb0OzfBp6XtNi2/cQitwmP1XvDaOZTFPJqDlTk5BsOfkhc
2EDDRJjRH3pZRjsURPLBdQm0VmpD0PyGiW5NwWOGu6AvK8z9OSiPJLm3tROBXvqWTjzBxk7vIB0e
AayG4o6kfO5nHFuKemndut1ZSzrstb0dc8LA/ynBJwiZoXrHdob9Ih1X1jtl/TpqUKRbpGpvv7a/
jBm2JUtwVrV1v7GGuRXPSP2hvEfNKJKfQgtipHaTyQLhz5Vj83Di26tHzShWCfHLOXWHE2E2C9mA
d+eioTa2A92BAuIaPk+2RoOhbKRbC4Uarwn1izii1Pd6Ke8Kxb4dxa9lATa3OjVc1H0Y+Qulg1Wh
1PX50CvdE/GxoCYMPNimT6yfLrWaT1aJWt7kflFnSc43v4hovJS1Gj6L+r6p3QIFso9lgysLcOPP
56Pu5PIwExonsEw4uj2afNvsG3XAEnVAvbcEWNem/4/f5ko3EbhPcvK+plEcdZcdRRA5sW1IhR9I
YWGXmaVbtufGKjxoWYskrXlGYcws/EBddMb6vBn/Mex3w8w+F1npmV7WYjrXi3MkSF8stD2hYxva
y9TxGk1Z/CKSHnLE2vy+vXTJNvVbQkixhrLn11Rorvf+TsKOmD/NNQHyXTdZ+Lkr9mFbxHeEBSQw
q2tasYBQ6qDQR4wlf9HiToORoU0/LnL41IvPHULfiPUVsHBiBMzjIj6RgqgtIw3r/3S5+bDX4zeQ
xf4fE6q0WtAXZ3AuWjy0FWZnYZm2c9Uz0D6AhDc7okJt2tDByBe933HnEqPWu+y9OKRhD9vXBDlD
crDIuEU5Q/7wgzxXxfK2mrU/dRW+FqFsNj2m6vJLj48/QN7P/zho6LhfB0CvR3mW+CYqphQvoV1v
oEsnyCGAmcOsF8Q1DnnTRTyIvcKqKAgfR3MFo13MiHPHJ7+PQ1InPU0Mdri6aiA0ElxcgTJ4E9kh
Xk8euJSzlpHOwrw1NKlsd7ur7BChi/UiTA26JqabYlDb9CzlLfQe36uSLxDthW7KnmvmICyUiqz8
EbQjZ3OfTYt34qoIgJItcRaL8KD58ghuN+lh1MKXnmKEY56OvEK5EaYnGuvI/Ps/Pjm8bB7KLBIN
jlnUqKjZC1KGyxyVaaK0trBbCPR1eIcSdvTFr3l17IcUFQwdjHgWEscNjiB6LDNb4AsCPU6GpoNP
KQPpWClPrLiKWVyrOr29+nBI9eXigu0LrSo0xeqSa57LiWZC/BXQ9wpaecis1ckMaspLMSf8zmZL
r6sJC2htYg1XmmfbYIY8MNhQlB0yB5+R78k1xFF9p5zjmdefm6GeFgPd4tlzlq08gz6YHKXkr7wy
4AwwmnaNMan/V4OJmD3pBjthCSzqJvCVFYMxfqVUcNtbdDiRPC7PTpEBck7WfimU9317X1nEekS/
wYIu/JjjUBo6s8LFdKGKvZMtHPwnNN8qHuPA7CT7L7KQXJLXlwR69r56AmXEZRSDy/Le3x0iu6at
AoPCzw8HdlNeRIwQ8CjuCs8CxAleW1A/DlcQUlluSCmaLnqi1UyS5gDrMnoPLh7F/oNtdRlyxkDO
vbigDAwkI+zAC9dbtgc2XvPr1pEVGECjawtTKCMJlALUZn+t5iNPGpxBkMcNBn1roG5GG3am33sM
3L/Dul+lEVSJDav9Oop2eki6Fldt3Zd4DqMWKa3CIpddtz6jnjBcI25fhQCPkQRSLoKfbGcnhGCo
H5sEH7WB+6JtPxJfzRLLOLb0VyEYaOjfMpin7sECqlK07mHqbbXedrXMAZL4+VqPEEi4USjOHsjw
ofPIYlPOs6oLBovb88TwsnGVDHm55tV67nyKagKz3rOCJrj71EXXGnHpiqkyeG/vhEQcrtqpJ6hG
GmTIQUUJ/qVDvkQGz5djU1APIQKIFjc3cQXSba4ZKAbkABADKvyf4D0dd4y+BzJVqIexQ/j07Cen
L6WIxL0PNr17YCMgZVtVLvz91zDSF0i901FRHEHdChKWrHKc89j1sVKxI+8kyyDc6BUl2DXsxH6i
IF8F5Y2tvyXzA/NEGa072zEbLBnmdwEgbRrK7ERMce/SPP4jSjJfVE70aoSvGfF7xx4t7iPRM5+4
8OU9Wnsi73rXCPvWCIM8GEdIVJ75hBfgOrRgq0yT4bqwsC6RDuOBEN8ygKEpjl8FZxo/68aNpH8J
+m2snu2Lg8J4DDW6T3ITcRbhjoWzjBcJNmvLVJVme742txWJ5V3U8Hyr9RxZsIHg4oEh0uFLl8vS
F2P25wWtGc9lZRhREv+AMcmMpyY9z76fkRL/RJSlcRvvkoEHMq5dBa0pv62tQX5erTSls7qzLRcE
q0GppsZ4EklorRtVjVPwH8IP65U0j2EavA3xtJJOA0HI26dW1r5RHywPFcry5x84oUT0dF13IKYo
RSoDC9SGS6TWxKgl7b8K0umcT6vau+JLYohyTHWO63p+AewBU1jf0vSWBXy9DyR6zvprn3GWLUSI
tZ5ekc7uUS2k5+iMv+05/7Z0yBYNugKot1OPLDfOysrenXiqf0xxlicA4zuKMVXc0LVNBGkpXrTG
zQsDkUEse6Qsxm1+V9P1ic2Rh6qAq4HUuLjORXPGajtdvveO0YvVcrJhkZHDbaKlLrtGrZjWX5Bm
cdW919AzNAqoJDjG6qjpCx1iuXYdj5IW/7IcXlaiLpVD8ha8YgnjsHmyn/tfRPXwu5nC88S6fhBn
Lm7C6AgtKZ2Yi1rEftwZJvGOXq3L5TIcKkbFn3nadeNwYWFZJLZjBZEBHDLB0PigIvuUsc43tGvV
zhXMaJFdtQ8zzF0pP+1aYp490e0jwNBd+DcnxP6uuDZB7aui9Qoe2D2pv2s51OvI2vnxRVjcBNn4
KipVvNFWUdBySmvouEIpCi33yX+hiyIjpO7i5zH9+JoGi8i88pvALiCTq+M4y6ifM+j3RRQiXNDv
ZmWo9VeoBOeUC2aCce18AqT83z43jc1I3Yz+U4UriX2SIwVolQIeZ8c6bjaN8EUL8HThj4flFWvM
05ZCtL0OpCoAahQhlHNXrEcBF3W/yvOGt9h8S5sYtWobzp7WWDkTnWRoYlQC8Mw1XLykVx4ty900
9bRLiqDy+ux11w5cqs9WuOi7+bbjnEU6NYMYLLMNjNYZejysOfk4b3BWSF12Dsbis6X23dAOwaDD
4j05Re28I/U+UZA9fYRWGp8dHyF5knJKw36mCbNexM9j4jKLLoKckRfkMDYhpXfINbpIEzAlozvt
VABSpd/GldsbSRJsr3dd7dQW7T0L4KegmwQGZVoxpkzfy2goMfDGIi5sKGTcx8gaffnD55a808fY
2qNh9iJwzEBrX22qbnPLkfWr70EdHmcEHZJA+dqWD9ZKAyPGt7gZN840AnqZrVmLEXkZZhH/Tf7Q
8xvZmCRkNkyWgWH0Bp2UkCTIVPt/02guKl5C8VtP9/Qs/7ghzDrD+TWzIQ0Guk1T9r67Y+xPnSBS
tbkspJc+9Z0ZwpgRdFC9RrkxwJE8VrBYEYrQ4qYZUD09rFa+i2l+ij4OyzNsrLoT0uzpebhl3Ows
AO15RaBZWZnXluYqZlauXvDqZ/I3PkrgR71ID7/yCfMH4IF333VsPfzil4EcAIUiIP7USemqTgYr
4U/+kOu/crK+BFaC1pxFb+ZqPNksUPwuAJbPbQAGgBbgSXCj9GLoi5KF6CpxeF4qpUhl3rfY0KFY
bTjAkKMAS+3Muqn21eTM81M53ibwY6Xg5eigaSFWfnhZnZ8nxvdMd7oP3b90oo+SM3oM4ettp4DW
sF7HiQ/tP+AEfC+8P3tFSTKT1oaf6vX2uIrDrn1lCe7NO+683OcYnp8aW2LWfsO51yBIhh915XCL
QFz5Q4Ku9HqsffkPxnmZSrARayc7uG7tksl+6YFwC+e+BA7zUVQb4O0U3hB2ca2/yF6xDf8e6Nzh
PaljIgNiUaAw1FBhOZNeAgPl9wCQ55xM/NUzyfCajg9LQwV4KyJTy3ukaDnIcOkFvLcGZkCJFc2U
fq+rFbyHz0svPnesN1Zg4SpGPCcKPImXXOBJtD+EV1OCkTIUWpXEBNbfKW4KXgV4zBSivHKls7rT
gGSpRgtU7O41RfdNr/J+bfpan2OOskdUgD76iVEz1nYzc5yT82893+XIyDRMrbllyNNCc3hcGJkC
SO5kLWuAH7zbo4uFJh3HFe8jnVUJN2b/mcexkqsri4e1Riyf+ZQ9CBMQNQwzPxCLD8jpyiJM9vKy
8dt2roCKyqP98fgKlaRt42rLxRp/fYC+2PgI2+5UEXP0qcqOvOciAdQ0mLAf2+aHnXj9+jSm8+1j
riI9jHI5fTsPMa6WtN3UoXKgp+gGScF/HTdzuUmo0fBzSL8IKTOKPqpuhkEJRLqXjequVIic5zbd
s/tuv0s+Opei50xu82bF8ZfcnqBD5EoqGTotIDTyfCzYAUtbLzya/wDk4G0shb+UyZj7rdLivMaf
mZfjJknX7dTDqGh+V1Ddts62RRGU7mbksQLQ80jt+UZaIuEz/3IYUlqS7Dm8MMQ6SZGSvcAGHVNt
XHLtEgkMbhHDw3icgNVYSS1QkUhkWJJnhc3aBU6FehbLrg1yhDWeTZmp6JC8GcY/Qs8+/7uJZRIg
0bLslYQSlY6Qlby01t+tyK9jDR51OYi4kjuQnMHdlXIrsYCphJaNp1pATcpuKACojGuQ4BS8YKhG
ACElQA9AjVJNSJlxp3jXmhKvhY36vCKZ5uY9aKQvjxKOLzQYtbpF9abbtwPi/YLOEIujzbxDnLv9
/7R6FtW5R3PRp3XgDv69jw8BOWGzFYIL7m6VQaPBIBMjbbNdbhdGT5gV68WMe0I/fAOMCm0TbDol
LFvmb+QxdE76n1OW5AodWIAK+DNOEgS+4wnF30vBGbpy0Se7KR5VprhC+GQSo62zn7bOImMtMKwj
SoN1HHEjkmC8bFfoEXQtMT0p8bxGQQTGG5g+bpf+58wVa7ShAUpkOZlPEG5GrwJwm/xhZlFLQJJt
ZoWuIHTHmkOi6+fFxbTLJzL9yErgfBxBw9HnIu8qc63HsO4VviLZJemV4MEwUcOX8jF4vrukhruW
MCQmViqsSrcqcQ6dYKFZm8uUxQlqSwO8VWrA1HGZ3U/GBIYzneTxxvmGp3kwDUPpd1JYnIY8Reu2
SFYne8rRCEFh4h4yT9UsW2CzFeeagbgImPMZ6EpOfWAUBXXMkOrcpuPpK4iqaf1lkC3+TZTD9CRQ
5kIjWwACwrmb2Up58U1KfXGEZBCGNCQag3+pbbV9QWwTsUF2Ecb9x61MmrKu3URtpoUYIJLP3lAi
UNBtSoUSGTflpV0T71EC8IvRJy4sVU5+XPqMjt2eT0pmBSLkPV+0wYs1D2PKF+3RNSkWqh9Ubvy7
vcSylmOJ2Bl38vnsdKv/qEChkMumugcoougLb27gCJSzyVEY6IMbQhQ1QmAPCEuIkhnFRepzGL5m
QdglbP6pT/q7pMpRklRkIFLSYTNi+f69lxhLPxqs5K75KTHrzHq3zXSlDDfBTh0RfdLcqJ82+MfU
JMwefYClDWOnsJ8dmdj+ipNrNxvHMDDVW4VVGcgcvFXbCJiqynQLGYkot8rbIAannjcZaNfC924K
EBKgSj2COlCOhYuLscOg9iqDr5Nt3N8Xu37o9pdGcKYofFbBgk1RAI9VdGckYmyiEsse/5rRcpQx
Xreu+8sSjVs7Pftd+BYPvXFgmmEByvlYMKEN0G6x1la6mzy0TH59iGwVZA9eEFrTAZj3KqZf3PtB
+Ghe1j6ASZyNxnR9Ey198DdcJ8dLx2hgiTS1eyMUh37ylgAKiqupvCnnMPe/TGOb9ul3E3qZovwp
mmrhJNY93y3GOjXRNS5GtuhEmwPrppKRDfEhCnhRuAE0Jqg3QNHPlsV170lxy2Q8Roxy9Y++UHZu
LK0GpI6aHjMRqzZgSJDwAt4c3zKr19lnnvlTsAuNPZOY+iW4nj46g2d0ptCyje7/6ioJsKKDHDL3
4m6LNdcjm6xqpvmw5wBHSX8Vd2cn0ahW7w9sesSJBMz1HrcwGBqkaW72U7m8PDu8l3eR8HfeBNkv
GnCqmSCNjaAFGjb5XqQmr16wwXEwcjcaRt3r1+8PEYVturDJWxYrkOuBsl/sZRlci2of24z8eH7z
rLS9S+8h2e3gI3LZD5s68FPQpTts8nHTA+9TEcBsC7CjszNsvhfwnPS3BrXxjovOaQZGpksdkRMw
SM0zin6iMCxdUzaz6hkC2pNnCt3/iRl740XLqrHjDhzRoQkiKjmCyO9JDt8aoqQ3/v8U4lBGxyTY
jjOj7SDHKfk+8o1pWRC3lQ8GNHy1RtWUA7tdKVDH0YRmsCnBQpQTb5v8b0AaU0SzDRvy//EpVeRU
kG84iIAQ/vyC5Z39L2Ts8tVDYTlt9KP5bsYyBZlh12IdKDG87VYJ6pknMyLMQgzcj4NwUbaq0wmf
6jrLcRPWPFGBduxEgB145b4gKuqNxPjA1PpPPdccWtW/YL4tWrRBtp+XpNxa+UxFuvGc6qToNJG4
jI70kjqgLS4SRpedADMCLmJ5I72U5cqgWkik/pnceX5iyyucctTdnycYvvG5gjs91q/R1a8uB4HK
++7Et4/hrYVfM4VeQYeHYsq7TkWpoVOXVJZzC1NA/u1gCps4Yu6W5CKMWBcziQaIy1uYOGbSWmps
3f2YElBLdBB8aRGiZn1SsCzs28ORjBurXPLWjEoo24f9z9Vvt/kgDyNtO5HsOT+VGFstZJjk+im1
P05RYbdkmOP76iW3XTLorXPJbEFLZ+DPlCdGsOoOsulSNvVsGcc1kOKP/atkh70JfI4tVez2d8lb
mC89YIxcqgmNqWGxDK2aRDQItuX5NYGcwW3m+Yz1a2+ycYbEvfBbwJfwuD6sJSKmi32mCv+OfRfG
ABQqoeCX7DUQ/PTI8UqXqeuV1NiKHYCG1qsMWQqH3aUM2uqGzYnBPcmL4QmVMbx4bre6AvyTqCr0
KwEILgZtjWklkUDJ7ZVdC45Dc8NI4h+ttgXBNa9nUom10R7WhM9X3bp5vOJduiFpaujtEwAsypq3
5eo0S0S/TqG0xu/IEIx7hkFmTGcXRoavA8To0b6RzMpHEj44aHJHpYlcdOcQhoxIC00H87iKAwwf
odMU1+vng1Y89O1D3Hmf3ROR3m7AJ978BXLi1oaeL1Q071Rij5ry3+/YAVOioXMVWDQ4MqMHNc40
Zo9P70VqS08bfDEKEcdffwR+0+Rhb9HWNNLyiUBh4LrmKFdY+6V2l/V0KsJEt2xwI9aAsEnqez8E
dtlkCKljTTnqVeaNlTnW52h/7rYTbd0bCcWlIJcYYjZW/GFc5khJRXiM9sKQ2dMe3c4mP6x2K3kg
yqpXZkeVyC6d0DdiCfcBueTfGolUsoj0tfjXn88i89ZmpH8bLSyGa2Wz4bMAoLOazQZDykVeWeBE
9Ieg55GI4SjXTlj56wAg7jouzh761ZxHiJinV2iVkJQkEFvQLw5WllLGR0sg7+PL7sNAwcGAfxR5
/3VtLBwGYbF5HKCvfhVaIwwFMTP9dcfJzVFudbMNDVa5aB79uXAJuivKVGlW5PBd1avXjNDCbySr
rcAenoNjmxoZeQoPrhQMDvMyH3r4RAnFOZEEi5Tx8e5Ew09aQEzWIqS+PcsKsQmln+g0fK8F7EZG
lIxYR4tsB98v4QLzCMrkt6ffLimZ8Z2GvK8MnVvlUlMdMB4Y0DH2klThLufHfaTJDIUW41KNOWAO
tLi3TWbJClXDM28xuIscRZc+zIxajy37UnbJsUhjWLpyVO0SVtyV4qm2PQQ8nEilPkN27/iETcbJ
EsN1gn0SGXSP4mFgIOA6o+psSLMWtKOZkfWqo4vW+16Vkj1ZUs68bqWK+rNzaFyQm7D2K19QJLG2
pmAPnBgCnl0luCMGAOhCFIa92py9AyyG/Kkal1bMTDFo0ffFxH8J41tenWBaaiHtfXOToHC6SpHC
NIW3S9Dm+bNbvb7daXvArsWoGPwJ/RsihjJTaFIwt1GQ+cK6sX1SJmHS+xfiQrq8AitNhv4RFit/
xTlwiq3bQR/N8+g19lvMUupVzeppQ/WwgS2GUJ+7opkNWAphIt+sELnq4wAOJyXTlls7BS0PfjqS
Vm2QcfUoA8S1SzOQhi14gMDk8cx3LHhGDznQi+gwnmLrwqy621S6kvYBoREajXeCUUQejgohT/gc
UAL9+XBbEXlrP37e8xyWOrVyIVBtSA96c71H0q5sY7Br5S2LDO3TMhy30iy7Kq3D3g2amIeZAAne
Et6TlHRID+NAG4QLhRm+PuAPEJSdJ2jLSlNgZ5QvXk/t+PVf+s8aUAlbxi3Xoe37ZAgf0RbI9MjK
BsKd9FxdoSnGVLPj6VsklcJEZ63HNIHXgtblekhZp8JQ+uw28FOJhbHBuYPxPPIFoyXtHP5d6xqH
T8+0hUgYrnWUO88HPsur8LrTnQl9FMqCR3VcGPG5NrH5I75AYaAYIq/3VYwJksLCwz7l1pxs3dvh
HzydQwjF/tKGuPOL3Gn9r/BE4eTG6y6fFCDJDSa00yZSYa0UCJxxzWpnurvqT14Ps6lD5bdedYSJ
nd8vsWoQCVbVqWOFn6KsKAFEAnCcfWf+UdZtMl03UhsgXnTMAG7WtAibHocYWGVSH8TboaPKUydh
vME94ez6dir13GP4qsxUOG4lggHMje7wRmEQ3VQDanrMPd0luHHYAiajJqPKZtLXccTXcL1vp1QM
G9xlTU+oqgb1al0K+vuqcbpLCKLrxWmznHSGWyZgeD4/XH0/bMyHS/SREiwpFKsJRHntw49bQsGr
UJ8NrYqN8hpL/rZxAZLS2nD+rxzxAsPz/IZ0Hk2fn8LXwVlj3JnDKqHGleujdIfP2cTUv0jgtoGb
u4zUnuZEByFX4YTHnSH7b+t/wWLQDq1KANJlvMe34pXjHBRBT99jeNPEvGNIBh3paxjCR3bwhLiu
P9BbtbiVWR0Q94M1wba22i3n+ztmkrcZXczDOKknRdW1hW4xVTlulSDVbqovaNgB31PSPq9+P5ut
PTvkmpk8CY36aH1Hhvu8TIngyDHt9rRDsPr0Tr/2fEvkT2E3CREOB0qV0nnnmx3TUoHUvHaqeP9c
vTH9kbyz74BaGir8cwfUnlmWfLfVU4KicxOY1bfO0kC+LjpJx5Y1CgUX9OEsvBy5hLe1+QP1MAF2
hSUCafBtW8eJ+/ruPSNLNg6ub/dDSkNhZjrTiturKxnAUeC9Ysg1hjWFYv+mZjk8i4u47LY/JMGZ
kJj0wN0U+TyGmTBlRLLubo/v+HTQ96t9rcAU4ZmS83U7DXHwThTAnbUsisKUX4zvMRe6rdWx3hLI
dOE0Anz/vPqo1mYZ2kkvUPodEp7hkxsIncQPdcjuASv3CqNC+IJuyCp2Kh9ondzTWUbdmqwBzF/V
GGVl5FWF/w30KGB+Jz0HJWqY/vjIghntIgxX1+NLOOYncjNR/4pvB/XsGNPBHcwvLksF7QSBUHJC
hn2zUktgAR9OiMSEjuW2f3EraJ5mx38vatr3cgVYCLggFp3/LIO3RAjI8BsqW4kkAHGM+L1Z8NfW
35W4q/a6TsReKcwx6+/5zjfGKcya4Xc5PJkgY1oWGVotfvVk0LEKlQmgqjxgKNUxH3aD4szzUlzL
Qg5JUwleV+QpP4zES7Y5y5f70cbfqel2FPgR9fNTZsYb/b8P1PnnMvC7/xDrc5yBSvW0Fl2qxnTV
RVEJKFkb6PNCxOb//cRE2ERjQp+3EQAVwgRu1wbEN5+Zyn8KEO6cesryPE+WwvqvyCUSxrhRmqiu
/XDD2u5FkzrI/ib7bn4Kgi2xTS/pfLhwXzsks/cW65zwrEQ/UO+8Cq2RBRYazmZiZU1xM3Y7r5cE
mx1kjbx0zjMfTj3IlDzVorb9103JuMPkZFTDIzE3G+RxBciwvqsI9eWVw/B+5PdxuZp8hvbJPWfH
lTHtaQ4rxZe+o6EkvlsRSIp1RG/IRoLg912hNOTJflozmsT6AhvfwWOdOoJc4oumdgPRbCU2OBJL
5TOxBPg5wloYTv67coecQx5WYpt375v6jfUfhhq+19LqUlt2mObN27qwDc2TfUG/hTyaKteeUq6P
JFg6KaIBs/r853EdszaGPT7yyzPJ8IDjGaroC+b0E8B69ulzgIE2TOv5m3jlWxeooDET3XjdwbR6
geXlRJXpZL7sdNTvsp+jvhL11aSdTsgdRRQs5MnpOYGdBCTnFm0gBoVpXjyir6I0xj/CKX6QhynF
hyTnJoaVjhpXdSVxiyedRk+kZK4/JHlVF1qnlBxA8XUwELDDX2/h/k3kSQx/GtWNTdzmMx+fFHh1
Uvl0W3Bv0UVrqZ06W9PmSRYWYxrOBwaf4sQry+m8b9Yp3MFy0H0F0yPhnKeOP3L+KJ5LXHKRhZTE
XX/nKYKnD5lBG103LUtMyRUlSrym+45B+C8BOwfIqb50wh1vd/7G9LlcfHi6XiPlyUla3k+rDkWi
AHrenywQJr3RBF6kox7piYwKA6odhVotvGIYdfw+V2q2dKmSaYx8UTOVNFMf/ujO7yRiYcYMvlcs
80sX/X1iZu4VXqL7lqIA1nXsOc3Rnl3+FeyhPgDC/x+HRtKYqoX1ME+8KGFWeLu4ykWZ96sxGGsb
/DY0+Q/FZ6Q3uYjj3CtjyLKE/wi3B0ZamSduscS6PaRNKNsebouQ4uZtetZMIHB1mZ/wjxuFDUIh
zmX+dxtjgDeSonV00zI3P+4vqmWKptpF2lFFnUvQxiryFso3T0PtZrgZ8DyZqiOA5wDjHoiJ7mwk
SALSYEqdLa+J9GJv0mcpjDUuCxKzCxa+8IO+VqvlawvVRtfyxQ/TgnqZDkqO8k9sDryZU4vO0lwa
s2dMyuB0PAbHOg+8Id8AJROClVw/9u+oMsYo9PeiPDTekQKij6uEjfyuzhHUuxeIOvUdkcxmPy1u
sPIccprTEYG7BPH8DShts+rsFBtYdu06mUwscfuk2jjL/wpzNvEcmm6RIJE/dSZjzTpPm9kS6BIO
Osi6dCiN0iPDqA4C4CW5veNvZ6tT2a63+c/YIC/q/8LEvpmbht+w1QudSlX2o0DlBPmclAQq8K3S
rikwq9woKNCAh52WcCpi8kmqj1c4olmH8ljXAjK5IIkkxFshuznp1ipNt1UU+2nB6uqlu7u85PiI
cEE+G1J4krfr1/TlOcr0Q2QKqvn2a5sM+ho3mWkV4RS1yg2cRhS58B3wvjQj+NjZcjwLwBrk0LXO
arFnWaIPMeHeOACEMk3TldX3YDwi+KkF04v4cmJjWleIxAv93qdTf81wmRM+7Gq8WUNmR/TbHHke
KxeJ3pZtlc63UDhTpU5oRDkEnGtzOm1B7IH6Dl3enAbN+/nr3/PoiQL3dDvNf0+I8vr95TLIUiXr
kUf5ONdN81VZQKq+QBydJwU0D2HTso+jNK8nIINF4iOEfODsH2U9298tHomjG8sw7PUlONyQ+EJz
ve4R+NLbcm0ZNusrMRqODm5ztptIEnwIH17jDAMHsbYIo7CLknSN3VGp54Qgn4tRpNhlv+gAnrtk
XSqPQ/iksUySaAUnG69YH55cbMvypnV71sjUyF38Wx+TKJa3SwmzZuA2OHeNbU3CVp1qrwRPwYaJ
WroXO2Sv6Ug6Pp6a96ecdirKJcX0wz/L4xg65xDJdKpO2QRy/fyMaXtZ+wNZb8/gJsMtmriwB892
IKIEQ5lUErz55q39cjtOjjN23OUBuOX4+zKd50gFGXyUnIN7InCJMar804SMm8LsF8jbHI1JvIyc
bszlyFjlxJbkpa5GCRli96pDD3v1vRgSz+EjwZB60HWl0tx1dlfx3GMG49Su+rnxqJ7HcE3U4lZ7
pVeLjq8kL1fxgGwKXePnH5Tk/K96DiTwfhH93fooV6VxgLfMWloKBcdy0e2Dsm+zO6E+KBhO6xzq
gcriZVDgGPNWm4soJs8Ez9FkMC4liOHUMotNb+NF4DrDOQ4dqhgD8me5D2wdXmOVQbnLT3MNL8jW
ooq2m3pVuA1/hU+tprk5+SG3FDsWsw5Zw+AjfG1FZ1tx6NnZQZfa9Bc1xowgMqzxbc8CbZecQq5t
fNLTd5eWjV1vAoMhJkcf/zU5FDJgDWDKmH76LuKItCjW5Me+rph5FnJhynHJTCAJtEp7hZYb89Oi
cNpmEhOmpr5MFFq8xFuWHQLYqZDiDMac6BziDUjxslYQt9utu3NxXjIHzyWmiFN5nCTku+oGtKbt
ADygOJE7hffvvVaVbvpUQdaG4orvU6bPBGv8m6jRhxpiU1eatCwAfIjSXO4Y625/wcBSG5rNrili
Z9o2AN1SZJaJ5aFkJiKhINanf0SvxV/AWCeKS3I3UIdM6CS5iSbT2YogA9j+FBReIpdRIXfjzOmn
niqN1GYB/Ejk4irqpBbKYZY5TBGz+PcqAK2M102NuRvgvfTO9kcMmDjpkh1K0B+wl4rusa2K0sEd
Yb+p6Tvfrb8Yle2VnHdGgkXDb+Sx9n/o19jSNB0V3yIm51S1BuvbO+hdl52dNZHUpNHW7iKGI1iP
KVT2J6Ml4qz8UXlRQiM+CQfa6bRxsrQ2Zgv3HHpKYNxUL6zi+cpCFj8YDkny9OnB5hmUQ0+ziWwN
GEVDdusKdtWcZOXlKjucgZP4vcNRIDAmmVziuLzD3hma6BE3eyvP/uZnIZu1VKUMFgTgexxTRecn
NeuS5JpZQDjurTIjPkD82PQ9mjIdH7XLYlguIGQJgiERUWdNNX/K8zCHdui2KLUCHElmKPPCnvXv
bEYq6eGOg45MlrQVFqcOns1iZA+7O6azPxNBaDuGULZre6NZQsmglRgjPEEj78P9FuwTpdHgx4e3
9V0aEOOOtiSTAbWND79ODVsSZthmIQkN34G98WEgNmO3YfQ+GNA+Wl2gzt9kh3dVLDcVdXnbIz+K
+Dd8xGZu1qc4lUPbhuf0z9rwsG/ANP7pULG13BdfKibzfG1R9rNlhRe/j8P6iyiiOm0Afq++RG4Z
Sp1Fh3StPBGpdGFGVAtGXfIQ9ZRQaAc6f2fWnZNwAEcQvQlyzGSFkI2SWkVzycereG7zBK5DaoYV
7X5Xg7SmK2NxXCBVDScmjmFyBCv02PqI3YulaIgiGD+TlPFY3lj3wqLlNTCr8wWmEruEWrHsfETu
lGr0jm0klhyn3a/ziI+21k6Xafq2KQqdPZPLiHSDk3p9XlNCqkYbtgAkLFRNNDwsR6ISVsJY6tUd
EGSxU0+MtFl7tRS83pJlofZy5u+lqI2tgvuPYzKzZ2atX+Nr0sd/XoYx8dA26l5iAyfzF9hBfcti
binl7Hyf1EHR7fqO70Y5G5Jel1ctBsElxjW3rUeChSMx/jBC2TOO6vWtuF8ZmE9dUvu4iIYePPOx
uz52nEnQQKQuPsGcJTkJ2A1EQ7OsJ2rw035DlLtFG6KC8BBmiXhGeTCf7r7pZ9QiwvZlGQCg2nLx
hnFJdf+4FPg3W2sX9AuwgTDECJsAcIkmtG/eSI29qFuFKiW7WAAFN3F3pfWwUUVuEUfsWlyG6aio
+qiIEmpF6Xx3qpKewuSPMKTS8iIv2rtti2yd49q9aSUP88wlSK+IMiJwnzKbZCi7X1sr289xlCtl
JMi2CIAxWvQC/qXcsgoObuoWxQ6p6B8QfZ2ml5viRUfAKQI0+aI1gI1qqQBXbOybcIJBU1SihmBI
eNhXzHHRLrAqDLQkNhYIvuFdAUOI/pmZsSuddDnfCc2JXxj+JLBFcwypN453wLLvBLX73vakFh1e
hXlFhBx/Vv9dzN0V8fv4KQXmeChRY8MJiyVl1F4rGZGyIgRyYr0LvSoSjzKrcEc3TdxSv4/3Iw4h
P+wlqzNoHW1Ua+a/n8YL9DzGm++2D06U82Svkx8O6wv3vueUQcxp3ipItzqqiJe/puqlxgVsDA6t
hQEz5vNHTfaEXLMeVCHfR+wFcfvkZxZrsXZRV9Bv36FNGq7oXY/VONgPpMurvQhyGtMNOgYCSeah
VgaWkC+cFGy6VESLdnGL/k5sqQRTP4z1mRiZLRpE/ZGTpyEod11dIRBXOT2Zjlu87pTyIik72MAO
VTCxdfBk2n8182ZarFEbk4Oxa2RzQ5F5Fngu7ZY75Vx5i7rHUyi0G/NVJISZurBLE1ecqa0EZ61y
x4qmle103n4XIQLEoI1YSIQnalkZEhRvXOMg8rGWDM6EXwtpjDXKUIfH9cKrLrCAN7ZlpUONB5pe
2iKXMHEujr2UWZsyyBQYbteTsV04+8ksK+FLnEaFG6kj6fy4fTQvexkzKmrOl5SUuuzzbnDUARB1
sPILSWPmsUe4oSJIsua/74MBJiqe94FMW23f8ur5mKSVbuDqPLc7WMgQqEe6VonoERuz9IWJpHn5
tkRWHvMO6kNMAaWHlQqAH9D+O6NH5QsC2bAtbkrB3EFv2ThOeuk2h7bxCbuRPluy4c3QXXwhMD/d
hQuXw0EeGRG/U9ssBvwLucYrJZUMB83YzWLff0QuN5wQ05QTUpr3ovDW8yWmcRBrhvWttIb46MQJ
wh4bR7uHOe7d6dpGWKkQzLWtnw0NLBAK+A0aX4e98Kdtj16BxV3Dm+rhO0Em+Ijord8m5nacydyk
Xo90frcCpCWZ5dbu6OM2gyMZYYEoh5jJ9rBWK0+xL6gL38InztYcgHNZpSXz06xxukp8/p/U/JCf
d0HC/r1iNzHO855VKA0+gGuYCbSaAqCeURsbb95RrI25wMAAI6QlziVX9It5amalo1aAc22Ki0ew
HTFmQh/AQQ8LfBW78Q29qlNxV1wDebG94Y78+5a208cRlVybgOKFg5ziLtR/YtPiDl04PN0D1eX1
bXfPFrV7jaCQgRr+ci4wQnvHmm+UziMv+wk3z5u64QxyLIp/QafAgfjChiLSBMhs2hld5VD9qycV
FG+THrPMdO3qBjLyILb3Ji14B4MnkTdKS+BdikaqJ3dLDwzpqpPS1KELtKjzyjM5x+kLmQAzapZb
ERj/7gQ7L74gblSHDVISF9cibiU563c9HZjB/8Bf/IulNLVM7DKKB5bD4LJ7kUW8bMgpwcYytDP2
i9aRbNnXRMAlRN6ZsfV1t5AUo/5xGtAkGG0d82Pm0HqDQwXhCrnVnWe2FVurlPjFm3MecRSb3Q5W
Ea9vFaeiqErFpSPLVP/tK8GtBOjFASu90tm14Xn5O5MjntCEtcttxz9+LPcEIbuocoW7syCcoFat
g/ZRfIV5qp0hb2nyj4mUeJdsaOoG9DQWR+zwJ/6qVCAFHoAzPVF01pB6wbMppFGT1wT0Tl0gnCYe
XXh7fhZmZ1umpvVy2pNt6nz67RdwolS11dkZUbwXR6/5zit3uKCWZmO/hEaYj14nl6Md2gy+ngmv
cg+IznT/a/n1uSNx9jgmD9atNvs/tRakYdhDk1CBrxTO1EnJcQpVxYPnlPpvZnZfR1kD/BKqKcEO
2W9wtBeKECgTwJ0rbJs8xB+yMpdWrrLLVT5iK4KPGq7O3EIMwUHWXfoUJ0KeBtlZ60pdhxOr1cuA
N8SXjfcdPDu1D+naYFRisFKPw2jLZdmzyi4dUcTqeHtP2H+/ZNSooK5gPLbdZBm7sBdJVLaxZb93
DiQCVuupA0BC6QF6oeiMOf8N0bF2KKFf+XrvVZLjvjYAY8fevPODOo+gLNoWBacB9bBhqIqp4hBt
xQR6EmGfVcgM8t4TsDdq5uwd5oI1ORoaDfZnn4fCVCoy/ovs9rVVPsF/Q/LsMjCSCCulc2TSfkt1
vzyLp7VRNQzJxjfbbEFbyJxB8SgwaInIw85V0UZ3JWRHAXAYAMyDuTDliD4M6afcV/zme2/Ufd10
3YDaP/vP5iPCs7vPFcyiZUNq8t6sIpeOJ+lCq9g3qg/nOOJewim+CQg08/LBJwhQnH/jKu1lXOIm
HZNmdUPVioSTEU7IMjrh0enfP7kp5MYq8/m5XoYTdm/cWAKMVdPeoOcE9TCTHYtIRRpHHKlsa6jW
up91LJ5zaNxo55PofsZA5IgVXlQvI4Yu2HJxc8tUHg7ccgrKJ516sEWIoa9l6JFBme12ynSv+PMs
uEq1BHhoferivr4cZtBC44MQjdhCImlfGeUKYi33lc6MrcF3ybCbnl59htPvxFGBXSAQ//Pl7Jiz
BnaGv3cBHueoIBaHhP5sGBSb9M2J/9QbUUwG5xKbwgoQjePFW/2RwbHhjmhvH+cHOcZ3omrx2ff2
M7XdVH8RSFntnIPPrc0xttO1UmLN4HeXgU1lBDcACn+n/P+XgSwO2cbYpvFY9yXPx12/a7thlvIj
RcBsh2S71vcBp5QXfnC8x47QbBpBAPc2Re0IOPzKLwsxRwrFLcyE6re2+H94vNdkwg1hEKg+Pijz
sSPHqLZdPht1+w2ISJzsnv4vf0sbeIuIXOwkjYe/cVdL5lUJ9tAEfQbNNDIedURiFi7miAv7DAxg
Hp0aaKaf/TiZtaz24pof+U93hkUo7N9DdUFIRdQNLXuUAZZXM0EBE9I80+cOE2NdHwK7RQ3tJ1iL
X4f2GvMo85yXvRZXEmJM7qZQo05HKe10gkz7w+T4XT5OiqwA68Sy5M9J29JLosSqjwcAiR+0k9aR
u+eS04nqCYX673R6LfvaxtAm4KdCOySgHEp+kmCi7+irng5n/PXgnGv7MVydS5OUkHF7S/l/GQ+j
QcQIAGECGyeVXHYR650HqBJJ+YKmmHKALfQqswJ3/OrtpwxkAh0duGDWXmlo+/41H8TqAvQ6KedP
EvfO/kGB+V0HOj8uxwxiaBiAx37cbj2sSwdJvYL9MMTFjHkJpHgUwtXtM5XPcOYoBjjOW/xsWRT5
LBeHFgb6dRLJ9ocC+cjaQtrrFT0gaMmnnvK5gio2GaekHAw49pUyFQU9NDItvpq54Re6OUU3UhJr
sQ938jubACS+xhjZrj21h6kEmqALEs1lXm89oaAxizxU/cv36RTsOqY5mNQw8mnESjib4d5tSv1w
HBGbI1vyeVsjf5cRgUdvWpnSxEzdqiLi3PkXIB9c0i+c3AnlGgcstzGgoMzGrVJiwrbqu27xz7cN
TTP53hGOgFNAea1SJQX8ixBQXbAdZGi8Lz3gmBNXx0+v0kKg2JdDmxsAoCbk88xnBkNZE3RDJ7U1
+Sh0mfrUAr2o5SFRLM3IGoLkXQf0P13D3s/VYCyDmvO5xFaKhs7Q3sEFVLErRq9RZ9EwtwUNowlN
A93Hjia9cFunkqcDxnYHsO1IPdwv+OfE1faECnqdtTKFomEflnI9m6cID/RzKVyrAQXIvQvLt6Jj
Tz8ohxngpNuNncI0z4H/imCrveukyxSznb0/sJHnpkmwS6TrTwrJwianH6JExpUKXMqQqmiLHOv2
anhnkB048kmg1JyyoNucwbPd+wfXJQHs4krVv1azbj4wL0YdKHy5pUZXtRfH0AQwbZC4xeP71Sh7
gwWnoYrXhfnVSd9kUSp4Dt3yoReLJH/PLt2EGjy63eZxwOiXPa/T53JKbQD4+sPDg/Nqm35tcWiF
4cYDKVu8kZVcXD0PpV7KzfUZbFDE5gdjRuaqIEua3SPaMvpp+Dk9Ov93yltdRfIGWQNrwb23Ai5n
lpzwrqYBK0NgjnPBP2XXrDwyJmRHO5X+9o0jVG5PyHmg7CXY4e/a9CMPVkbEzTavFismmWbhqpek
vM5FK8sjNM+e01XXZKoXea4vjDSmRx1dKNYlj39TRhRC8rRPz8nJOTnxMeW24akElS/AmWZZWvu2
x5L5epxvOUPmM5M4kXJTA2SER6lSeyyGN1bmmC766NzDy9EM+WXDUxhdYMj31W6n1z62mKLhxMCY
iFVU6/9OpOUycIOPjPs8YP0tcyZiX1eD0w+SybO6Z8x0VJK1Q9KYh/HzSjY+Ucuyw129/ySUDYnd
JJ/QA1mjIvEUPnzSLbjQOQNW7kaxxOEs9Peo5MvWd8c26vKbLkSpz7VuU2FmjX8urkPEz+rOtaYH
N7Kh4Vy6jjVQF6Map9wGZTleIe1hIcx/2bnMNAo8pDa3Lz67GUnL/zYtlQJXq+DVY1cfFvKnFL1O
lTEhAd+Gjj2JvaBwGpslf7uifa29TzGFBZb215ZMGPMGO5nT0szAAmAk7uuscShjqZYOtILgNXVy
1Uixlky2cEnemT0hYsG1yfq5tIj1rhmWiZIaXF1E4gJqrJbQtGTh/wVg7EDPCAAbxBqYFwWOeyt6
TO9ydn548FRTNutaJbkSf7lLIX0HWt1i8IHhNvmiNEFPwybsbBMvoD83TMJf21W6CqA0OIS/buUP
/sdbMB/hNIxlnLD2OL5LmgcB721u6tMroFXV24SsmWN4Bh6r5rlP7PTqhUJOnEAc0gxWra/jTQRh
91aiBlL1bTpTDGci2zRKdiu3z7oN2RPUnMfXAuVC5IQPVUwSQ8kIl/WedM9J1Ywb1H1NVLQRk6wR
uI9jliRO83GYBflZLea+NrP4dyZ3T/b38g5eiItpMgCLEAtRLj5dGsw/iVe2AO9WEWLx/WlrB52s
p8IoOnlBgk9F3A+WR65JUhAL6P8FEcWPkyWJmagvHjkqEr+LUSn19nocKvFfK3lEltPjpNFVc8Ju
D+YoL1VxqiMxVftFC8K01MnM6LgDO0x/MvLrO7mYuMmBiEzH12+QzezHZVuMZX17IXuH95KvkfZx
xbMwl/KLqI8DiR5T7yvs23McJNFU100xmegfYrUQ+YaLbKR32LqkP/3SjEsPrJI/Wy6Az5CetX3a
OW1P2RUEn4q1K6xoC9DylA2JGLVJsQ56HK361oS3IeQuqP021Lf+ZQMkZz+nV9BuCb1Cq05HzeUS
umQMMcXZpsH6X7Vv4BYhapBwayEa7GaVXgLAhb5wJuRB0eI3zfJuQzudOfQMb5hCwaSXUvF/YFXD
ytJ2LA1RgPXuoohDVyESbHDcn6bOqmeKe9TWdPLxnoq5wAytm1wFtZ5/IbrUoJmv+n9LQJ3TS5HB
lQiGmIASV5k/1boZTBojNKtDENDelRpZaIImdz/7NqHUC3flh05PKPCP6+CROuVWgAF/v1nbHDdy
xHqNvkNYR13tpLg9XXbTOyCGYU9+JnSEtYJBLh71ptoJ1ki5SbL5IexDlWTkvG0jLKEenJxgBr8p
ODMqqGJ/vMd2K4BgtdAEPnCp31j9U0jp3rWaFnA6Ovq76fU4H3HLgVeMm7O12WmMg+TAKw5NsYQR
UQX7OQlARgo1XQ5vS8etb+x1MGobsbfv+P8keGkeDxHSaILRugCNBRVpNZAfQRXnJi6kR4KjtlKj
8hBjOTU68qUq9JFX7bv9LvOBLrUsjtHfBXgxD9DM8wm3cBdUpbNG5PUq6b5jaCiMueEBxo0HL9po
pg6+aLtI0NSHGLbFgjqZQph5t3/Ufow6JfLdED1Uh/mSd1/4cO5Pe9s2XBpuDj/ScoGdv4NHaYK0
1ksAxA+WKLkri96s3iy8sPLfuJw5/I01brqjDFdhorfDere2xsSBkxfvuqWS8e5ykgUoOmkEXY8W
JMw5AMPncpEL8KipA05JIGPZ+b3oozemNKUpNTmyAvrgSYeitjTHZvpsm4zlgv3keVvJoEgeB4cz
QC0pR5rDBnehZNH8nlLQw8LhJonp5lH76UjgJ9vub+GvuvnNApBhjPSWHNcdw+FUXk2Ddd5bPsqA
sggxDAUcOpoGvCyQkQUamlzHXDtEpZ6KrRMWDIvjAAAjySGEu2uHpF0WSuW2CfgLlFl6zYOOcdDW
QuAe8CN/cBRZQEr9+lojzvdgXTLn6gvb0bxyY2kEmOFgCtsOikJBzJDugQiNBNcbjhgBxbhpiaLe
/JzYH2ZeNYx7NXesqMsvPHYpDOEtS0YSYjiYHHNcPnobmIkwjC2Yom7keXzBVJxzj9xRoKMgF5/N
yIw/N8skaH7i819CTu7Iqm14TKsuwz6DdqJ+HFRkbXRLT74Pd/qhvTe9GSPOaYVxb5tKrKjFjQkE
nnb5sRXtx+RNyl9iCuLT/zzCYJWKm3HY5MngzI3KcAoJfrBWdMhhXgG1XjDwohXKefIM3kAV6JjP
lNziGqwDc6ku/0dQLeFmWxZEz56+F8tpY0FOm1CnOZe7h1c/FIVo3wOGKw/FFpjhAoDQ51PZIpcJ
G2p6FrieeAJjvrhPGSNbM4F3QSIfV26nMFGWCfOsatv9CXrKpOm1q31greDDcHSBnAlo6B2aB+ON
51cF7ML0DpUKHQ6RFzjAOq221Mg/Sf5YJjCXx7NReCGVJ+80CIp5EA7BQqVsF1z7Fqlo2tl6H6tb
wGpi9LvYQfmriPDWUC4XuVqJwqr8589nRzxssSa6oJkfzW5gv+eHoN6lR42l+uxfRifuLkZIEQxl
nFwrJeQyjOS7JAeEmXsl2Okw0lUuVa9wO74w6/ZcaeLoqxEV5Xa0AB7+FHuucvGOgzUROvqdEC/b
lnaztO4e/P0oAkJkQGje3o1RglUw/TSou3LtvCvSvau21Sdg4wtWmkakfcfR9pj//4l3u6+293eO
QpxxSlXotjvlo+MhWL5csOT4yviyeBYN9/8/daN6Y19WAX041SYIG9CXSFVEbVfKG/gv3zUvKU6U
CMD2NzFe9R/SXAiZfX6FZYeXQxqyKHD+EliU/Wr+3gNVulXiJf3Tz8PtKfEfIjjwI1djnjWCFBzS
IO/zYr/3duqmqK2G8IqGeDHXdpUb2x2moGOn7eq0oV13SaXLsoU37uzhpOs34NxsPLeNMNM25Zs+
eG2wQwene4mdVPbTs/ysryVFR/i7DkT6RVOoEh1ty6tIjuhVvYspnYxeijeKnYlYn5jbr8OkVTcg
XOtsAO48q79d4sP77E1p4vsKVABfwnHpZDGR9k4sLQngSLCj8K3Yt9YYHN+w51ixehRrGLYXCKHO
N1gaRylyjmNe2kiojELf9vBMrEnAsSIzntOH2CcFMMrTJh1qp4+v7/oDQEFnrw2T+uFM44aK7eKq
UXiGzMuESydvbTdhx8FxwAEUkTv+ieS5KflUjeds8xirq1T+dtQCeYq7Czh+NN0PuXzsstONYcx8
UsAoruepJJIblna/WVioOdIBvtxoZfyx4Acq1qThRjVBQ1lMzkPoMRVET3j68ATetD+IEOVgyz/v
uucMvcXsZJIA/Xqlt0baKwRMrNUV4C8TjTnxbk7BtCl+fI6wEcoHY56ECweOfMvWjdR5D2hpF4Gy
LviudWjMwFyIE0scv2zI5pKENN6cXxitHN7hIJeREb0thcl2iDM1S8Fc7g3/+WDBFO4aAE68ggAA
aTI8uqPqmjTeaX3Mnp43UHOWzya0LewSyc7MW+KpRTr51hDKGosBm8+DSRnUzDqNyw8TbBERrfKT
RBRrzzZR2xvEgh2GfDMZY+/ZSFCrrX4BOT+C2DOHE0o1o6p0kZDGKo5lEAXT1Duq3c6NCmSpOEdF
OdyN0hR2Fmnrlvz3M62uwdUPmAibdfpeh73BbGrhtldDH1uG98OXb2GNv2jMMvedtHLyC40aHmX1
NZWC80l+PSJCsV91yKclRcSQQszV1aWXWKAt9tSuN2610HPJciVATLL85GDQ5jhaT17E6ooqLiXE
MGUjSu8mfyPEocI1CCL27S8rgZFBbcx9zwJDxm+xNxKLjEDJ4t5QlI4psFAvuKr6rSN/EyDYhXz2
XPy7socNyEoRV6eALNPSjZhht+BhwkBPptrcvPFXDOsbE/+0dnlK/0MP3c7FJhKguq8pLLpP4YQR
RhHF1jLYowEOFvCD0ONQ90rpQJHF2hwWY2PMRYWof9FpGAiGPEVUgcoZvEMOBhbae07YJug4CEf+
jLjSKdou105lidT8f28sNSM4XHOIimfHnbeU7FTMahmcbkaTA4WuXz9caRH2ysFf1u1ywbbPEwUN
IKxY3icoMmVJl63g1wbeJA8fXHxPPSEgksHwE5oPuEvdhxlCWUnu4LEocz5HBx7IFynVHNCxj8DN
I56Ex8EWbFDnt42rA/FZFaPF7wO1yq/MPnFrNI8HZ7Yif2UJvUNK7XGrkaBPar+F0fucyD5lci1u
3r8VMX5fk4iq5p7m+xg9y2d2lRxiwLtbEtiRJn98F0kbBjJxRIKAg7TKtRbMx5KJ8nJrWjdivtYa
zuRQp2UedVeKJfNsz1AxUem1kXuz9JlJJCqjidAgncaLc81ErKeU+E9lILRPbaoEwROaAoCuSH6I
Q5Stkpnd5cDr1hXM2kEtzaxYqtYov494ZIJZV8cqXP1B+0fdtwvsCyb5pxqnc6PzZojpJOfDhN3J
LllYDarX2qethIJ4AQg4RdUcTQnVOagOdg2Vm15Rw8Hkys3uds2tZVltIPrAX1ljE5JcypiTjmPw
jkeZQLQ2BCdKr2Royxo3BXLyzXMCkbBi3ON7kTrVTp9Rvwqob4K5FsQEGzbvUYxd4bvoDSH4vsah
dCieLwUMuVVfIKVEwITJIIQkFwH/H1mV2jUDqToDYhPFy4WRq7K4u4nnIPoD8quPflkOZtEUkRZU
lMd40E4xPOrhlEl01BDmI8ELqk0lg0zzHtkIFN/Ip655OyNRKRtyks2PYGvBow7rrjZg3g8tvmlM
HfLwKiko+2oHBBvscFGW2N64QPYfqoDEi3cb1Oh9C3LyEx3yJVtzWJtmZBhtyI1l4Dm21TD2T6ZR
d2XHvVuD6UbglnnurTEoIq6TBobD4N8nEB//Mnkk89IXSCaFc3J9wXRnlSIwoo8tB0xRq8O25Qt6
nRQHcvuiFZAuji6c7Mp5tg5KHsEkL6SGci2Hap3zcDz/H+O5W2YlputDQxloBwn1EURc9HKZ3Z8I
v3pYYZ5H8658b+LFYyLLfVNYU7TxE1cSW6BElUk7c+gv45XCW6bPVaUFutlZhs5yMY0N/6ASfDZE
326gVDnmF9Yvqt6s80IajWZXiZkmaq++lGB/lraSEsRdQZLx12sznygm3OK4QKP+2hUdNJw1KG8t
RBbbkPR9JuTe1jqgdaw5ZyitJA0E1ms8jZNajJLk2xENYrri1HlEBJJJpZy+fBwO5yZlzI8HNeMx
+XKbMJUOpik88NxuflLysQkpliuk9rwjzPQZONwHinjbkP2EVYFrk46ARC6ROW6KbobOwD8W0oFr
TQGsdomlFma9I+K9zNzCjsSCAhKdHaaTjty1PDkO5PLXK2taaDb9vF3Vdnk5yWLkA5c6u+TtGnhd
Fkm5mkzkBnZmKINYOBB/A2h8jQH3tjQZzCcb4mQqqSG9SPMC98PdLtxDVAAbm9x6jkhUQKxEb8YF
+FJvYFmbwoEysbmUfuY01mNRVJ1gOXjFb/nBdl+sZApJmjP9MQFgvsA+nu4+iOawr421dB+5GoYM
924W9gL2p+9zVWdSIYTsn19CoJHlVg86LTZA9vvIa8NIiDn+bLBHehQwbrgxQGx3+EYkzJZHwnzF
Q8wa7pvm9bVcHrfLQr+yy+jGlpYM0lcwOYCDqzhdRXPYfjcfJrXTxBwyCU1DudYciVcsxeSW4ki5
fCdSAx87JuaGpJjLEHwZLkQbOAdF7RfeyUbkHuWe8F54paN+Z/klQwHepwl1YUtNcG8vMZO/XJoX
saTczf5eUB55QnbzMzUSxOJHB2h40flzi40EVxOuQIXKJ/B7hn3BjXXI6OwtGZeZ/HT3PSY/HWWS
b+idUt/v90PMOLE66Zmg+8VkMp4wLb0N++wP/9Bd9aFm+MyEkcEjbRFtmy81Ucw3RS3/sRIZtnNX
pRMqwt1VY16XpA8+7ywGAqH+zYplZOsFeaQvAl67GYjuMWjTsIHQxQq35TvWpdt5OvOu4OcjrpnF
dPE91U29osOfUfgAQdxOZ1BpY6ahx1kD+3wZIMtyLpvnw8xv5tmdcu6w3uYDROoWmuToYK0U/0xY
8d0vDEfs1J3X39vAicWuGSMZM6jBrhmMJElic4MepwNgQgc6D66TBR2lic3CzSXaUsv+jxGnRvBv
Qr+vNings1hGXexyWVQ8h8fZ29iqg85ZfXKNbfvGiIqzIrSmN81kV0IKJ7M/1YesBcoqswFNd6XA
TWLsUqwHOOhQac85oBhwSY9JbKoBQmNKEaVxvp+RY7EgnSHorld9Agg33Ce5YPL66FU1nFSvenMH
fFXMSN9PDIoJu5hrXfMhrRDRLswTW+xfsMWSLYSrD7VJ5SsKBN7HQSlZvRY4vwSMZv6nYqDRWj78
WfP1qCz288T8tUAdO2mBrZwgXHj52ijX8lBMMuJJwTeCjl6XzhIxD4gIQslqZ6TTti9FQqCqAhoF
ya9EyhvwBXuNl1UnZv2Jc4gSQD8+8vqSTTjUohnkjqn+zxxwBlAPoDnWwl03NT2M7Adc7XNsnfPk
+RQjqwRMYM/sbgQWqiAMRYeDtO3Fyic8cgWq4UkoTkJS/V7wGHEz4NNSsW6nZOT7X+gNpw9lHzA5
KgAPj3t39q9al9ZdgQkItqYyqCPBI80cZPyVZLDdAtwg7Y+seRCJ2gt5Avul73Ibnw7x73d/HCY3
wV9PHrNmHovMAv8AyQ4YYfZeJoCqp4lsK6pU2s0mUdRyalR4ucoWPSbBD0KbPs3STvHcEibYPCx6
IojCToxiIKg4PmIvlkaYTeL0fB8G6YPmiMzHKScXQKB19qD+XbpRj6ll/DnJhWIsEJ8rqqEbEni+
TNx7tHMr11FZgU55mhiIFE8MwfFhwfTach/ITCffpGoHeslHgpfPdrxvraYqheae6dvOpJvzsXxh
epkGqiC/lAJRwiwpzcQJVuuscpBOBvKXdRyKokBdjiE0YuayAZqPoScSYtSWj3BarZ0CLpqbWTil
d9kl/O+jAOVlzh+aaIkb2P69YcQe+G/nJjzH/G9ptPPNC78heyWL+ZrOH/Jl+UujQURJGdUStdT9
os7jiMRCpEStHXua6m5O/OGAMy65zcJDEJQCmcJ9nEUqopKvw+8vNDJHp/ABuxR65gPp6+xUHjAt
/W4JjycVTh769qJS9jep5Gbr2qv+HmczM17o1zz8Ot8tstBSgnBLGfWrqKwoYMSb/b1e81Xw+0kt
6w4xZRPCKjje/YYAJynu3CQd3cOaQxF1FDsPIFPHwgK41bfmjZK3IZzM90ESc3OCRHFeMzVvCKiA
+5xUEnY+864DJQ9Fe1gmlZ9sgtfE+JHuvZH5qQBKwcZYodWv2B9UwFu72PiBe9MwaF+2jH0HUzli
agyBhNchYp7o3Q7DEIRT0wjjD9UtMBDrYdPfKrpwx0jNSh9lXZfz+Xm1EiPOL0KAE4ve8RNNwWGf
fLbewEgb5AWs62ueq1iFF2qywBdP3ojzkTRGYQqLTxuQ1MkeHQK5sEpRg5tz8KNAvSJG9ul/qedG
ZeHO6VhPQFUgcGN7rdLNU+U7TL/sUKZtsB2t3omqDTVFlNqklpfetOigDv3jTIyYcn72Ps8OmsvC
VomEDoBFaGWnNZanfTywZns0+mq0DaMWVzhdJra/Ka0Rmo7uZYYZFZ4/dN5IO9NFPTcGJbpGGEty
4Ku6pL4QGxhggukIXjQ69+Gq7UOROxvk+1jaydIXUyxLLYo8ARpPYyzKUMXI3uFQ3RYBAJWRo7p2
Vi2qW2HL/x++EYUv/mP+O9jHkLZerZ998Jt5KG62riUL0AVxLdXdxkpM1nw0bPlmohHqsnoyry31
DY+JM4KBPZ0nvZ1gd9d0rpGTX0MvPPgJFJu5jOh7BzayX6NT/X7x6k4qtZZxAK5ehUTPS9b0Yo3w
8u0vMO4RcdGa9NTRhX3y+aegMbt7pT2bcK6FH0hDSJtOZhELniZeQhPsxL+fJpehnd9XaF3tVOWJ
EVEETIx7f0eYF0xnGFkSkEIdaTmBzzoK5CQFSub4aSLnmvzu6n/bNMOvpzqeT/jJhhOob7MsjHS6
Nm8yBvcRcZvfgQgdP3JRUlBeXrUwUDWBknP5gtrzIRIK114J61b1atvt5Bx3iIMwLx/QqCHnj55M
XGpABO17PWFwbnitf8sHFJipCfM4AIpVNZBkQxugYbbRJCp73QbUW4bzyfUfP0LmfLMPYKViSxGw
zCt4s5VEiHzsLgErmcmvgXUGVR4ezyOFaMNHYcE9lj28vMveR0qIfHFLHPqOimjOeOFVsGgJnMiz
v7zIZeMnS8ldmb3pTwLDMGJUaHbaPmmR1Lq8g+U6Si+cEejcSxxPtZ6b2RzdI1IrmvfHGnuyeY+N
La534HbLDfd6jlvOQERiBSYz9m/AA/602FZbWQch4t/+ZRn0dUjWKIWKLkFsTAKDITWJHONW/HVG
EP15NHrAGPLcUQJ1keaz6RpMKygfGl+AiYH8qRQowO8bc/N37Gr70W9EcHlewNTcV9EPOSp3YPji
+wx5+rt6uRbSrE5yYwlU2cOuPO/BzN/UV66207jCnvLs0UYUqcDhXsMo+ZAHo/jGa4iap3NK81bp
CrMTJnVz5xYOMYWwn+Erv7mk3mYFWeYFPcA273XuUNY2Sa0mQ1bL4654ibN+ecAqc3g0s+OdFwzl
Qw7YMGj4frrzgHg81j1WUM/+0/pUGb6MWLGbd2sgmCsSkeKWAzIYcGwohaym5nIxPpPFZ3lvoHwU
Q3+mNX96Y6yzFvsmF+qLWvK/2uc+g9xjkXd1NK2ztP6mRxsRbuia1Gc2MyHjvLevuQ5bsLl+4N8c
zjRjnURi0gPONjtlUxZizYWhLXc3U+eoblYQEZLnOL/S2biFWlponvAvglp3ufHaoGyFl3iIkMPJ
FPW7rVW3ObTll4Ho19DM0kkykJ9I2kC13sAuwcSJq8ANTUEnFHrEXuyysCl9rOQ60h7MHJiVWHtk
ImfbHa0g+VXu6C8O6Ovr/YCnN99aIH/Y0hFOxf+QriYAmsAoH9soaU+xcs4wCUNoPhEPkDY152ss
FXrOx8VBxDO9khlOGxi1wKDajJa+6ctSqDCzUckSeq/CcxnVf4f4JuBzBtv6Xlv0L1Dz8XsGG2wd
hoNHmx8/9JBsZb+7WyWN7wb4BXrBC9UDcp7PrRYz/Ag0aoyNr+HFxtk1Qx2r/J8oaCfo61mSrbKm
84yeQBoj+kflO16OLiCzU2rF2n9bNjls/OJg8pmh8Q30wKFdcBcPaWvxpG9x9W00Qta6O5TQWm+k
MRoG4nshGCtvb/cwJxdQTGP0iI/HnIQWaesbtXCJfVMtcHOLXjwKMMkBNk19oPD1raniMlzgiKTv
4uZjLofnRv5dBtPU2xuzjBel7jz45z0MU7fUgL0DvklNTE6HGJkfoX4ccUB8L4i0TIlNuJj9FT/P
203QvJiQ9FYNE7R+QxWHGVV3acg8KNk0nL3tjjck7mPumZkj5nVSiXidZAcB5fZDm01Arp6fqU9W
f7Wbx5M9VkIRCt+uol8odLC/STGDBpZAOapC0dHeJY2IdJfOzST7MG+qd/VLJb0/PD54mcGuDQtw
0Q37BDAO5WWyDFubAsx0UCrEms4l2VQ2pbCtkDDrvoXNUe0hxerZOv3HSrUOlLshfNKjojV4Bvp8
LjPLN+R8PqWCCE+JjIu0bCOlaDHBUahnjshE5EiIYTXkZgQ6gTwtGbnJ4gWZmupyyW8m1czNuAOH
TAaH/HXdqytBIj7FIvYC/VgdzYpvoo1ZVXj8WIo3oUhHMB4BUEc/2Fb0BapA406FhMOXVu9eAZ4s
o/C0yQaujPIbKxsHRNweBRbn1miBocqiOmmObXqgHj0YvYC0fAlNn08Z5iZTJ9NAfXuAnaSUtYks
76mgqVUD9XTr7T5XV9E3nsO9lGC9uGJlgiQJ8nAZRh/z6DGsFZINQ802oR1qbamZkFofo6t1O8bv
3TqY++fcC8E1zL3GWVNbaBOjatE0FlSrgDk/783xo/Oq5hU8BEOUFnTw0y6BQ0anMEZF6P1eVmv3
DsMP9pppbC1PxNEKgI++72lnHnwnxUQDNO0Wnf4aHwonsC8kqqDYBYpGJg6C2h4ODL1XIth9erIo
PxR4sq1HQ+Ekn3Xxr4ltUK4StFLATZqvCyv+DPWghrYgCC3y3Qorzzm3gVYaLGN/gTeLOXoPg1aP
r64kOtZYQ3jNnFtGDAoQqf9LWhdYLjwaOJTKu+9m368ux9UwbYraL3h4+9st4XYuhg7wJmXs/+Xl
5klXYX+LZqdGmjRoDMmrPC9R+RLX078dYESHMuwY+6XVPSut4mSJoUfkdfz9MxLLgP8UVuje85i3
iFJChmgR7qhjHK7go5F9HxDxQmlrOFuciSQzoEr+ELMCoaikmT8OaQo+VlsjweDS1hx7RWl1muHl
Mx9akEDA5KEYOCOyA7nwj7q1oeH/rmVANmiABsvI7ygxRtWctFPGCo4AFnao+F2q9XI+tRZ4NUuU
iPboeJHt20F9ddfj/TyAbdHqotCL8NrnF0thhZxgYQVpKkIg/TTJclqOOxlNKMKrrBCeLmjrIcv1
M6+3uqFEOzFjy2qTWaQjp2c75riWzcutT/wOVCK1uehm2s1Mqlq5s2lvBMSlAGluOGqAa3vAaeUc
6iTJPTSFuDO6lqeVv88N1KZaUyGBSevFe8IE5+hFaOTmBG2sfYBbEdslIb1mahB7FRgg380Wcx+j
IIzheVfgzGbnT0mKQqqgBt30b13tB/0/2OrRd2yta9oi6/4g8+3g3nfWE4zO9gL8/y2I0T9N/RAI
Bl19pL66nFzeotQ4KIYbE9fm3a0jv1KOZQxCQ3XIzN1wEJy6CUGRHA24olnT21RExdVzOCaFYT2F
vSoNgh1eNGux0Eb6kD9eOFAQFYXOvgC4S0EdvFFPLebpIJzRTmyEmoley+pcQBD8TL4NkTxaY0cs
n25hcUOdmDPSXoQTg0ZwxnqQGDsYIvBAKmkv8Lf6RRv/edoC7AbLlTapTPCVVqN+6zLZhprNicVW
/GrABgx04M142FWbBNklj14YPlBSgmcH0q1kH5Mt9++nyy/05tAEGOLwvWK/0bVJ5hAl5bxDhDRR
v6MlAfRkY8OMmaW07UPJaBmymFZ0PxxBGoik9NmcBHb4bCV6LSXOQVgmdZeelcFRxYQd2MxKB2mb
eQ00Aqd6SJ7BUJPljhB6EkVUJVM06UgP0UNTljzMX4Xwl9u/i76UXOiR+Pk/z7KWN/aG+WwZnZi3
eyZtAgFXKyo4Z0626gVzCnHtIhVOpocCeW059HMXxfuGDaerzH3PXhwpuFMO3jPhuwjBqBWIecOH
xOXFCArsiTYrgRQoNoHg+n4n64iJ5+KtQiEEwk/Zm1lSdq2U35otTF3mPB5HVwXMFdrHiZSLPjC9
VGhElS5U1qh4re4VryAhHkQ4KypI3IGNMYz8MS6rdTwUr+K/VsQsKEWhZitfuUbvdnHDgGzzFkGJ
89pW3nHzCcPLZfFAHhPMYnd7pmZ4zqVdY0KKq8QjQ70t6y2KvpKcAXBVuo/uDdJexWF+0f/sL5Kz
8fX/iesBOWUYm8A4lJkpY11pcrOdueuq8bMwrKhjpStl5aOZlvfYjbyCH9hBlDD23Upp1Ed9YCQb
IX35RBmX2Y6uSReIbIStz1yzi8VC4NPij2WC1tTukY2Iexe08mdfw6ntxpTubBj9FWiROHIZqt/V
Sr2h75yS11r9OZst0UL+fp8X5lzWwe2ofyHIFjDoxDcMkqcH41nVVNqzAKRvE2UK+67cZ3SSlTIz
Wr6c/TED23ghsVcfqozYIN4nypUrTNl4pT7XBaaPk2UZgHfhwECACkQPKLJoYJO4Rccxbv41CtLV
OKROEhhUKuMkU4sTOrNDqzvhQq9izagsOMbez8cYu02N/qjIZVAMHw2UAdnxAm10Nwo44wAKHWLk
NugJ//FB5zDw/kBY9pCi9nO78w+krMUYq/JEbweQjlZ8lLwfI9gYDMzL8HH7W0j8H3Il1hMX+wtF
dCu6RVGBEyHuObKhtfMBlOOYEXNzyFo2SVVC0rwPml229NuUw9RQitFh4dA61lPcrOD6EGal/PAq
KZniEDp+nGH1PT6cFwRz51pG8FtErWPAQPRy5AVr8PnI3EIBwzHPRIX+9qN3uZbhryIMyx8jZRRW
T/s6+J4/Yu8RDAsHKCi1vL1mk8XvVwGlw5wj0ircIn7VdcR2gTki0rcibOvNDXlhBet6nf6RxN0Y
QFenGxWM4VMp0LVmFYBkmzksVuAGXHMFITVVfkoAG82VlVsvyk92WhXOkBppRWvyedax/OyGzMYx
AwgXmF5IiqNctkY4XyRM87PqEHpO5hEtohXNb+0nBLhU+dpcyAbxncd32btwwaDbc8+sx//iOAoG
Wmz0XqH55bbB9gU15zkvn4OZCJ6DNMt//gGTuyQziyysbrWBzHgVmYJZC2h+0AuuhxcooHzxMKSn
ELB1zNH2yN7K67rKs2y4Oxkbl4TR7O/9weMnqG4zXu5TK1flzKoaWywZljnI8u/Mnl2xJH5M5gU8
O/N/bnjC28tUrIVEe2U5EER2m7nnhSevAvXXH++nMnH2Bpg/rHmyKQmZJN4LDy+IBUxqTE+vjQH+
AOKIKSGmXkvZ/arlccBl1kNufAZ1amBzNLk0SUpyUMWBmdwQM8WKSriCVxKlkoWunrk8fKL/OgTh
qFOBA0TklpaT+w/7Ec9Ig2CdtTuLSiZhqHOhhl+Up+DTnvznkJYHlvvIvC+qijtOmsRvrZqgiagL
6RNMysWmdrJY2523Y8Kvjx+ARTSqwfvCfChMOv/9gyMuFjvkQWkLi1Nymzia6G+k+Y4C/ZHwIZvT
nBFWQcSIx1XWTBWoN0+//9CYkdrUr8mgXvqjSseJ5plv1HThV8WJTGxkbFcU4TFrTAlvPBSCbwr/
TcFhpsGRTM/FstxVstVBQM3T+TkP+s2WrqkuX3IRfYmQus0chsIw8L5N7DbAxwXOM3lwvmiI5TRw
vnzDLpq4LNSzLMB/XMKEkZtu91ADGuKUkE1mwPD8n9sxKjSbs3fTWag8FAjxi2PjTSLLpDWaH5Nr
VBooMhmkg8zrYCd7lbsZDPD4HKPCtkBhA1VceMr7CF6V/H4rdOnlgbuhBRu4jf8rWzNwrpxKKseE
Wqo9gawbkXZexOVOLixI4a3wU0jtsANMS9ZYNKO8j9XQ250JQGiN7xekPrOJgoKD2Ia3kWy7jp6f
aLnCaIMhGgsxfMFJNivUyHgRAQC7K4MObqdx3A9gOYx8ofpHAWRYXUl8xM4YmTBpD9aE/cmDJRR/
cmMWkHUOMuWCKinXJs1bUkwLk6Y0eqeK3uto52BeVoMdpt2y0davZp6yZmjA6uF1iyMhdTHYIm+5
CLH9Rq+zWBuQjjzbh0gLVcuCHLYcj11A/7bFYlIWpSYtElkXl5BfaasHqZzwvYu0dMKtFIXqNuzJ
WgpZmWtSHO73BJLq3rbA/2+Qf38eahe79pkBCaBIdchXepLzETFRgPgt62uSypgkh7/vjkxC4WdB
Ltq7gV+pONtGcblSFQQ1LV6D+5wMxH8M0DaKwL6fOrCfYt85GGj4BchH4hSZPOtI/O3XYs9k93VL
KRWU4b9aHIjTXNeW5KtVjmnoXPmRaPABtL4Y+D2Wtu++VmCxAwjHS+GXKS9EE9tly0k7hf/Shpko
gi+V0DeatAG0MjRiZ6krx1PqHEIuP3gwZCzcW3KtuRNAshZcGv6ecR6azZ5tDrL8V/XCcQtqzM/c
ct07GDwtFpTQOqf3BWoHyPdJ+g3meP4Z6XYRLVlBYvULP1nuqm89cMq3+sKzDXQ+acp4w3N6yMPK
psV/NarR+rqBzKuUSkpgry9sWsEEJK/zhnbEQY0CtZr+gejMSeYoL9G3KHK75byCCD7hMprEfR4L
pSj190TsgSmTsr3Q3VVGMNOqbx9BETWJfi3cxzWfWbUylaXJ+QO2NB3xOqNOjpWwefjxYfA2cYUn
z0WAYc7677DLUQW6Bk3DdsZiGvTqIsegwjgJnKc63CyGTw5axl5MjEmfM4TdKlRkX7TcK4cecaOy
E58bYFZhyjaAHRdhAzlU+9bVNUJCFfVSIDpPBjhr7J2TJo1OQlj72SDrjOuAsffMWsK9An30w0LX
U2k0aNDH1lI+CAKEXq7IEwC+wJ5AtTqQmWkJ3rpVA0T2G4FI8ULC6YJ++9jmEubymIWnc5YNAGzk
/eJxG5alEES+g/iA1C7tOvNj2QZkjlYPuRtIOxzCfrnsL9Ct4JEWG866vaZOaKABuRIDA1xEZmz9
kMygmjTUais3PmgvyZGlvMDeURiRlnuK+YfmswU5PxFyERCH7fmKgh+ngyBSYFAABjHt0lAeFysN
gdkWOQLbmhkAUqMiL7GmSgyFphwcKlj53jzd6V2sccMZtA3oF1pzE2Aq44sOWco0Kq4EW5PZd6UL
Fvg8SFSPMoR10U1K0KnQpAQETdDbheTt2p+yr8oiQ5sc8aPdv4xCpxHIsh1/uryX3bEuytHOBlRT
t/PrdG5ldMRKmoVOJrsYi5ZM8odVQgfzHBIdVhzcUEf8DJHzR53RtBpII61jFosms0GXIHsGZMyo
n4xKiS2EB/seUDd+vbIhd2l054D03DNCV/BPXhsl4WIhwkDwLRtU2fgALJxwNAcsZ4VIACM0j2Wh
+WQtNtG3t/wAZOqz2zIcAnscSqaw3+wdor6GCNYiXHynpvDssadLye/LBld5txfU3nrjDk97mrfJ
cJ9PuQOk+M+uehaqJhZ8klLFja4oFVFbe/FPgcwf1hvg+94bvJ5djn+TrRTprKU8uOf61r9j/FCk
956qS+vt3sqdl0CqpHA3pOSOcEOCOxmW2uxIHcOW0UJHbA5GH+4OG4WWuGe5PTI+eA+xz48Igapn
1yIu+DKXChXjjn29dkFDVk5OSbdObYXamiIxgSnn4BPEz6K5iYRJUgGg7RQDYf8v6XrU2lpcwV7z
0M6xpyVJwQqCjTCostRjJsR/EPjHhocJQomf0iemHqg7DanKt3AsmuVeVYHvFTZP06Fx5u/L5rGO
c0tr7b/zJ0vvi0lvA1wXZksIWBjngIDvdKC23ZSgg1evrBjxvbSEk4YiBBUcazZd5edln4pbo9ic
0bVjF1nm9Z2qf38TBuCR+3jgsfHCgxW8QD+JgN3SwcicFti4N+Cc4cnh6VqFqLHQSDHNi1ribdrA
fDEa0TBEWIa0qjzr3YivOy1c0XiDpfGZd+z/LbK+N6GRFecsUjrBuNd4bEevnYijsa9cosgP4hy8
waFqUEGdEPcq6DJQVuiUU/5+hyqD3kJZWfLR/fI0lrnjmV+KR46MXEJjy3DhR1bClIeBBiKzNzLB
/MOAGJ6bV0zcUuVqbLrH3iSuadeqAanOhihpd0N2zYcOOeb2thVSmWwOlhiI1tca5YLmBzCQgm9x
C7kfGb3+f2RsJPNIcn/S2EsU7qLHYXRFMkyw4+nMvppW4SpQIjVuPjmE5UAQAVhkwC4Rss19990t
IjrdFW5q754kBvn/iSx8MSS/LnsLmlSNne9Ea5Hs2Y5V6uMnPpXZ/DxBu7ESzOIoa0X7qgqF1MyY
StSZV8Fy3hlFQOIXGr9hmvd3W1CipxqotNlpzOiWdcTbhavo4IL1RfDc0XL1cKuXWPV+MZe82Zif
O4PtWhC0KQPj2jpRqQ2YPcUpKBU0KmeoZCHFXbfphscK3kc2zsjh0Nzb6ZgPLppFZpzC4Bg14bPN
QTPPFzLIjLQaxN2WUA6t+1s1SCBJXRSNvo+jnKfOgpwuiMNYzkM7WFFoh9sTfujUeNNeI4f5Pz6z
+A9S7S4huS0fjRP6Y81yMjLe0hLDLpgbyT0VZUUTIHIFCVH9NUpZK3TvWvb2jyBo84IiNNRdo/VH
Omb6WdjHn8OUQ+oncAvpj2CcjM6X/etEB5QiJF47dmD/LgEla55qQE7BVjDJPRoHooTfKLIGgeXb
Ufgfs3pKE6xyl0p5V07LXjJCEA6dyRS85RDkHlZr9l7WtNd8wriGE+srpVTMvK2v8uyxcNaa9TXt
Fayg5UwHAtAAlGgCNYafsDqlZ9+tiNmnf0n5jfH5bXyddo1Txm6S3amsYKQOm+5Gy+87h5kYoB9k
kz8sAitqFitTn0IVEA87OUvEkUDAqAYeRxRtEd0dTixd+rOTpJSsQEzYRJaeD+Cu7+J5Da2ZmJzI
a8ha+IRdyx/vCYEpCnozXfD6tlmK0LeBX4On43ztDHm+Duovw9HALN08y639Dzd2O7zFgGht3BMI
+CdibSEYv53NIMtOXUqGZdz71veG5MbTcAH487JoR5CdZ69/nniL5dvr2TmYpjT54Y+soEzXZ4YM
tBste7t/xyqPNmdasx+ErH+HdZsNNzR8aLDofpIE7zqfVpm90IfreJ7IZB1Pkt+AGwBFgiryDJ6p
hQ8L4E2lugxGxYyUYclnjkPpNpw9/ABvzkMJ0tqlG27XVVnPx6qSvX6EB7XfaFCs5qBPUWs02x6W
Qw9pQDwOc9OQv8K2mD2f4x4gPkdWH19aW3Cci3w9pIP0j1617hUA3z/Na+wlOP9x4c6JWGJuuDsk
p6MSjAHWbqy1NvJwRSzkDGyIQ/GLM88K2D0lsWtvRiKQzeOsTMZIdjdsjHV1wKVyH/4oOC4q9CaF
9WQXTKAtYzpr80XjjaLwAbnzsxHKKjzQhi0I7oMfbGm6webjnuLkou+ERSuEjJIngth1/BfHnn29
6VcMfXp7XAqjiMD5qLu/E4b33pQ68TnITTdCNkm/VK12ugN060zzNmTn94UvocBHshpdMh138hLd
r9TUQlMXufsbM+7NZg745ARmDDM0kSNbynY1b9JMizG+rreTTAomMJ4bCI/YUm2MSC1T41fq16pf
vuGHdo7BdwpbrfgAoIQ3IOSHjJfoqM07GKgs1vmj9kmH/PzDK78D9TNmmJBVlPoLhiz7mI17Ql+s
DHKn1HEUxr68l1nOR5+iqWTyTeNe/R2Bj/78YDiVRpzmv4IgT2d7sBkpBfCSCvjd1O3hkudtnXeO
qU32svc+KiyNpCzZoDcEiNvGC5vQEnArotdZnIlpmGhF290dOtnkHnTvfZS6p+uczairPeewuemb
v1pcj0UTQAP9oNawwNUeTb42oK1N4WYlzOUpM0uisOcQ7qc+0u12Fe6EEnspCpsDX3dT9qH2B43F
Jkrr4L0kC9/PrcrIat0nRqKB7hZjhBAqtKZCz804V/Tbb0xi4OXfGV9foPtZnzRQzY+9zHJoGyFP
Zro7rzGi0RFWBXUp0SJ0Ues6q1+t7kTqZeNb3N3LnUeUjSgu/CzbLoM7+NMOzaO5sBbyTDS5liyO
VsITRKgZ8JP0cPyRYBXCz8SChDwv4OUly41aADBTAVaJem74K0Ck+TwAWVZC1pSktPAQpjGp+6Qp
y2gXwIOcarEm8kqYmzYmu5H3K9GGGhki74wc+260yAN9srkTfLNlYzyHBqygXIfpQHhl6YOGYVVi
UTZusWW7kf4BQi81DHTYp+8CaygFyKHaQNBK8oeBs2F4ImOP2AjD30D1zQzS0Pw9epqkyliu82zk
nnsXTSIQWS8vOdsYZ7MAkTBifK3OnaNW6gacMGrsgKhKrtGbCu0NsYxJJQzeVRT0h7DDYMNxgC19
dyz/AGMRBZMTZKO71LF+d4OULU40IBCro+fROKB07ROORs0dTqYU+jWly0q9ltZbCoqlG3e+/mw/
MfjgE1IYXBrn5OZkSp+HDk5RSmYROr6hGJ4F9yf/AvgBfLcLV2jTVBfTofwVvgJxoUQSxIobbncn
XttOJ76dVYileNjpUBCM8tiypeuWIJhiOuW3Je0dDAr+vdT3qEZG9Y2DT47fLAXmjwsCXv8z5nm5
ADmCFluOZ7Va8rTPs9VnQd8LSqRPdP+TCR1+v1sD4FbRiZq+bKfJAniQs47kqEn8+PjcJXmFSOAP
h60m4oq04DHtQtqkVXUVyv/o870UsPstJY9j5h8Mks6kDPA3LZ3OSBe5NN0K+WMAkhCf+XC9nK3H
xpJuCEfgk/VoZ3Io+Ez+dYY+ho046sNHtncPPWYLZhzSdaw+ktI1dFCpr7gk5D6IzxlqXe4HTeVy
5KeyG/RzBOT8Kwm/3Ir1up2lrIT3NA/A3r1lY14GIzt1nxYRP1q5v3YuHzoAAwn7RXdou8Pklmuz
AbkU5HZqMd1OwgZI9rfJ/7flps+G7osokoz3XvvWmncyb0tk1t84BWPVPbhdV3NIhRLh5ZGQ4HmE
edAVdjOfOfZR2bkFHHx0PioHIDoH6qqF2M08PRQgzNtKMcmXsfpqquIIaCgPFhS3S/IvoGOizSQx
jaOStRESULn2aJCNkgRfe0/sZuGEGIgy1G+dXQ6KPTIsCXHdPDx5yYpJM+2+xO3SQwxcuTQswE2u
C5i+kVLT4Ljp0mSfIAP5069Dk0I4+qiI1/lbraZ9jXWPjooblcjDQ4whl9t2sDup6JFvX0ET1o4z
YlGc9QYlpls1/aSNN/JWq+6HiabhbzbuF/6V/4wCw8JkfbRPb9IampmcYNO27eLsS6NoD7KKY+os
g1zYkQP4fxGLbpfON/vMkqx1J1k7NRatFDlb/N87V3f0k4Fof5ppBiECT+CTScj0GibO9NdGoZDA
L62FxXFc83k/MIc5QYgBFV+NSYzwIGxbQdqyEhqJLWOaoG9/VkN9rAwzKayEXdv83jZWGjvwk4Vl
uN25+u3+XDf3oHD+aS0xQFLvmHU0fo9OUJadgb6fIyEDtr9MLFusEXvoEkPeD9OdAts7c6B2pTf9
zhTJXXzrazxJ9iZJ1nMzkjFFh1TA32xk7VmLIp+Guw9vjAdTGIpmHL0wfkGlt8IMZ1NtUxDKULt2
oHX+S4MviVZviCW5s2b73bP4CQLzB5Tr4J+7P0tT26LLkbw8YtgdiSA47weFz1zT2EB1PUPOogmx
PkdEFRs8qTgJv/9zvcN1+Xdb2ZzY/it1jnzAu8xM3yuW5ZV45uM9oeLZYehHdVESQAFhnr90at4m
PkdJ5a5B2/i6Pr1zz8AB6Aevz9u/H+EDFyl/lNtNwewVMMmWMWHV5ycQC0BMaSWnSld3ubjhIJLM
5nYxbVHJ+C9neGTaSvz3GOe8UIhGWxgzSK8N/5BfZbY5Hd5TKVwROHJR1UOz2Lco4cX8PaPmCb3g
Hlb3BvwnWhJtN9daa0Mv/ZO3KeH15ao0E0iCDLviH4w+XoRNz8I2tv7eWGyI3DZsqeEiPQPeAkc4
efDqQXKoV7rbmn5yNN8NPrxz12bT91xrq2hDaKlnck7OeNqy24nrt+T3KD6czKgQVNqpb1Tk1JsY
aRNGHhGtTX96qqr1dbveMHbVoWTrs5Du1ooD6lyy1w7DFo3Gg1CEhP/f9gOV1yPlXtnVTyfkKCw0
aQmOEVn4/UAdNHoHlsLGiKveBL22E80DABF1XklUSQfDVmuzDVWQILX3596hN+N4uhUc4WeaZYD8
LAP/vS2maoPntoQ5QmG1K24zY1rhie98bu5D59veL3Ul6G+LMzN/XtEUKLGAycVAwJq79HnYgGOP
tNupNNkOZKy3eJMFPN++m9MGvFZjX1feVHgbruw4z0Poy5AgZiv41N1FeT7lQU1GDEtLksgCiuR2
LbcRBX0wlmHq3VwAmKG8mevj5ITZZRyVVUAfwZO8pYVFnc8kOufAZzmo5kDHZxrmn0gGakMaFIxT
kbP9Md4swC69wdP5T5+9No3v06waKrEYY+sVthQL4kL4DZWbEisR8EvXFKyR0/6eyzWp1QZWFTMk
dA8iH87/paRbpePTT7c/em1o3xmw65k2oCgISI4pQVdu+hxVIQjWjIPT13AH0Om2XTEucfKJHO+7
CmPdVG2e2nb4GmSluZtGTOJLv1xrJ/dWjihhloS0C4NyfJDMWdKni7KQIsLnMByBm6jtc5mRF6B+
5sN8vYx5MWDQfveNJt22vScMds48qfe8VdYRxPFzYQLo/ayFc8McJdDS7i1bCLmuYcGGggjxMxff
mJZdbyqtDjtMZjU4R3y/sx+p+pNb+K2qwg+3yVu8MVuYagk9DyVly5RV1eIoEgTuaw49I+bRnAcK
p758Z1kjCg1d9cIOYR3yGjvNcQa5hYktieu2OAE17b2aAf06G+jl5otShLSFC9n3IwjF5WENWA00
4EREdqDJ3JEVE9mcfahhgVAH47a25HcfckhQ6ssvDLpQC848SXFSW6T43GSSdw9TdfvHG7ZiWDe+
y1uoU895Jkw6aYfKvbwJtK7IKWbJrq3IHEJ0qh4DxiY3ee4zGk0Hb/+cXzVRUmj0s5k4pv3y0uvc
jeR/Rn+sN3eGxVJ4YRyPO6MJbSSfO78o5ESCBsEOhYNQEYGlOffjBvcTrvhplr9JvTAXStgArMy4
ckqEhtM5X9aZX06TtxL8B4MHwNte9fvB2RfSKTiynAav8w83g4I/hEK6GaNxJMzyH0eDq+9PJQXd
8Ly4eu2lCComri3dR79HLxSHN1GA5Z0mL6ZFWHPoSEAHtrEVnO0vVgX3RUTNnekgG3hGuqOtjtp8
WalR4zmmrZtnoQ69By0R/AnNZknHRVHV7CoL84PKfzMZ4MfVgn5g0gt856jbPB4EmCLZ+lQfV9S9
+a+MHYOyi4T8sFfG3YSwMYpol5kZXalXvUhAtCHRuU3KW+KuPHAZ9l2pskxR/JqeuUZi467y1Jf9
W7qaXP9iOittQo+2DrX8haD5QLoWSTuE0q/WYEJrRlYY0zHQ5aSKsw5c93wc7b2Lbk7qrZs1y3gu
MGSpQNqhp8QLekKMre08gLdWlKiutziKCJ+AchEkn1pQjlnFZh+H2JqJImeW4WZLvwphOD+chuLC
ivNJ1z8Wt8myw8VOUbcdzpX9/JRgvh/MBkkL3d4Ki1BsC9yjS5UygZGOZiQ3ARQO3tw/YcgUHT3Q
cD2m+pfJWnCyoTYPoHnmah02lIaRS3dn9UynSVRR8whnoGYq0695B/HElEIobB8zsdqVQqqABgQG
hQz4oEBHulDnR+yZzuGRsG8U9d+FLGwutD2UsjDzr/9PIqcJ4RPxGGoQytfMwOYhR1D8Rf5kloVI
qdIvF1xODhtXyFospg1exEj0kL1EBYVWvfX86UepRVyicJBPIqj8QEa47WSCNjwPMH8oEQFKP2rG
i6jjIS7YKj+00zD5CkH2M3oI7QsHn+C07149XfkvfHKXCdT1Z0bRyJOJlHjm0GamsRFJoV0RJVhe
gxsesWnPvyljMI9vC5/j4/fSMEnL58jU2YAoO38yQGX34Jv/X0gHpMQYFMGlxsk2QnS2BakJmmaD
nfcEY9eH0HUbOQrpTffiiacww6Q3yqJNJiL3U0UhUJTRoeVJtL4hOL7BzTWYmfVLpCkfurlDnQl0
m1vEeneE0v+E46nDzi0Z9G7SN08z5bjIThIdJu65W0oV3U+RWtvM9XbdDo4/07wQVgfzrVCLMM8t
QG1Maa7u2IXOWechQO5CFaWRG5y6f1LvOU3lwX/H1k1AIdEU3wCd3uZnCXGTNLp1EGvt+3uJ5tVs
C9EK5w+D9t/CnmwPAGb2rN5x7uaqviQAVcMR69Sp6TpJP/rdCwjsUHF2nWkPULg990P2kjZe3yH6
A2iITtYzDAXw2KReNyVaz712I2jXuD5UrLqWPBIdb5BYmLgKd4JRmmWUle3j0pu9At9oazt9zGbh
jxD1b6dMmezaUyP6lJ59pLTmy+lgYhbJHKGCMQd1ZP/GipbE515RlnPB9uR6jzl3W1jK91ZlgM1e
gDE/lnMwBrubkmIUVip1n44JiKuxMHvwacWR32zEGA3OMRASM5/6HoUza/cRDxv/61lzWwNeuvvp
orz66LehODKz4aK3J7bueKMIOoVE6o9itfcULJ5gm6jKl/EDzfuVK9Z9FqRaz1fGfZ71NFOVMmCh
+PV55m91BdVFP6/jbqs5/amyqUH02cvL6LAM7uDvHke5BhQe8JKdkliwBpA3pKjcUNZzxOWrs+HF
d9SBdJ2I/EgpTYaN+X030+O4yP3UosSmvKz1tNgS0JwgL4ibnpU3wcLBklXyplYy3CZYJTkXbdyU
F/fg09uA7YQtk48qxhBPiak6sZUiadeO6ksRVCUrkktOllta6I+Aycsmj/HRHddM4eSrGenq0OsT
ScwoG53vyXf0VHqChF6nh3wmGMz517lC7X3OT/0hASHRRFlirun0cC4nin9ADKH+EgqfA5ENjzju
GSboF4FbhcodfjJiD5cvgIyFDpwiwpIyLnyrfSbAIe/XYR6rJJgZ5bGGVNJK8Pte0ensRRX3WPxd
glWq1Hzd4Zx7h50Ehcn10n8pJPTPMktP6r+PCLdCsABcErLwF13eLXGLvcvmGzW1FNl/G+EciTFj
8PSc8eTcYxbFuA4B4maPNDbcB8sup/pRHfitBPuHojChrFi3kikhWaIIM2Qmol3MYtE7NpT3sudx
SQMtoqbTir3k9uscNE2IzJt7U/AcKccQ/U9/ewaozbwNBWnr7ard8b/tSEVT9Di7bbdw+A0TYiq6
jAUSp20QLxlk0VVNVOnWwkxnJ5gON3pHCQVVOpBwEKYf2b2J1W7EBAUMJFgtdK/0m+6zg8S4FMM6
xQVLmn8sbDtnlCNi55X7NhzW19fbC/ss9Qtmv5n4Q57RxSU47rTyuAedFz0lBQCVmdR8PcMq9FED
oBwON8aMRZ1C/WNTM7eDJIKLF0Rn23bGLzaugSg6vA21glaF31/SZf+G4/SvZeemdonHMIB2GLMU
oQqaQbCF0pygeTT7RWqU5OIg/Eg+K0CJR97nA7pIPQ8V3WC5eq5gd/G+u0cmZbJiYvillW3A0xKy
6yK9pYvxeC9C2KjshE0BA/QNSdS0UiPU/MMBQ0UBl0xmCbny77GBPIHqg77mE0KdAzWPpLNt7ni8
OBlncvCH8YxaJKxRcgjUGUKdvlYIT67oV/VOvK95nGn6SO4CwkX9TjckLj6GURw2zkGYV5hSzYyv
MMAkcy74sn4FcvRL7W4kqSMr93XhJTrZQOJ2PisDxKXDayOuvdTDo+ti+9IACLYydipT9rOV8beX
1FWR3jCyFVM57fgzElb2GZk8ritecFdP64uZcXkfm4uOOAbllCPPmr2DtXHYQNzkcbOnpvQwFGRM
263DKxeTlDQlaVYrNEo958Oyu2GxVfIPKzEd5MvxudRQXJlbFaB4GDG5oOe5zR/NwR4dCAhVxjwc
4E7FTyK2+dHy4TPx88hh2c4Viynbu9DohBC9nBQjHHKlrAyjKkfbudNj8gAt7wqVnN60tMcsK9VP
9lpX2cMcRl8z2KQ6kMZT/xuSEMyb2NcltMfHbGkhXOPa169Q6Q4kMWaxypbxdT1bg0n4qXryYQAb
i8g25yDlMmusRjY9LdY1kx9071J14P39aoqdRwFlubeUigkj6kesYPbxg90yWfpW1Me6fk5zKpGS
tVc/bFfKkPFWTx7+3xDJnU0cpMSh7qqIPyTr+A8dQ2ZHiZ/QxfzY6uO0sWmiNe988vhegSmmoLou
9escuhYUe4FdqtG7b6Bj+Z/rHkY7Oftkiq6QESsjE09Ci5ZraQ4Sqw7ZsRQyREM/A1o5p3bH2A00
lRVhAxim3+x+B5Yr3AQS6lO86HfGHaAbCJQImBrgwb1ZY+vVIsOt1B3IfyN2SyGZqaUW3zR/VhY4
TL3exL4m/voISlVLsSn6aUo7w1PzregOA4n16jjPjD9P77eALOvJk2pADJYB4Edyi9u9lg9KEcpJ
ni77DZEaUbrCbhftqvZ2VAi9373dndbvjPbv+Zr/VUno7rDssnZuIIEqgXZgF3mZ9GLjW2hMn2r/
bB31EeqUkDAZV11UoYykh9LmHFyEuB7TiYZGA/zVbynZ1EphlJkKNviJBfNmJ0NBN4f8wC/EmlAb
uL8nBRc3HtD8B4MOvknQN0wP7PLnoXNGKlCdbkMXCQ/tgfwQvN+6Q/00jRtmsWWlHPHCB1ifCxYO
Xef/6/6fNTYPJxYLGoiPT8nsoP1MkiqrW15xCYTECFgUS+fmuNH0fgJHW2G8qqWxUmpaGHX1oUuv
a0Oq3B+2C+090/WcDY3NHjyyxQ3VM3XnJm6H0DxiJmg+65CZKk0FMmWGSNksrzgAvhPci0O25+jy
v9YugDuPP8g1lp+SC/GF0Q3bjm3VE3HSAmL4vzMrDP4FazlhcA4CGnJEvH23dtGq6iopuastNorP
/yYJoUeRwxG3tiv05IAYdBcgr+OiIyT0cLT5mdCiXvnRn+d1UkgnQQkw2V0ktQvxp8JuS68GUJRj
BLl/N8IPjrI65sOpaLdjejEx66Fs+8tx4Cba6e5gwMVbauaOiZIk+LFX+CCxQ2KXE3bTnzjcUaLM
jpGKTMfPnYur6tDlO7Xj8e2rX5F/n7LgO0Rppi7zL9kSFRM7v1B78o37CWEZAz+0OVgTPmenyENg
16vPYxhXpqH9SCJWtzPsxTQe1zB4f6C610H6McFhYZzrgzxX6ZwfTMkNQRw4pvvXTBUtKgI/mife
tj9p6+TK/tA28ir/bJM4202pBnPHFMiqBMHwrnZTxw6znLwdSpz6QbQ0sUaMWRg+zTwRxlRhxngJ
D57ry/bVOEZg/Tezta27B8toZBlgUfs1PJmmIAYGiHH1DhNnIkXZUJxF9+6UXONpKOoRUuGAu3kx
MP8BKFskV72/uDKohVRz0X/BsleV359vXysz8pbanVAsS/EchbpEcYqa9Ikwa9Yq05gRunk4qf3B
v7FYQDg2Bpoy2G2Zx7I8zH35/L1EuMxJ/5F+kCjT08V93ZUBOWqoIKnelBJvucxvwNb5EZajqIKP
R74v6VO+kSFxfhH4Zave2Bf1S8jsqNwyhWLWtJvSwbnD1nRFWMhmDXuQdL2fGCAQyVmoU7gMzDZ8
xVClme5ZX58q50Q8Zu2WHork2Dy1XTR52hMq9nSkxQLD0lhbXZ4A371G+Kwzzm39yuP8F35kKueo
dk+oVr6BItkMCJOAmR97OegTPzD6EAbqwo4qkmSwJEfBULPb49fhN5GSN1C6E52i/dZLuyPMTxbc
TTa11eroWByE+zZ7sYpbKlLZeNmNeXUY0h2h7hjCm3/uE21rnrAXvV+fMhno/3Jhy26XzbIGTLO7
MXEr0XKXJHWN6XgN38b8LG4azqWjreMMM3+utYU1d7099q+E9Z3w2q5/HZBoJl5OtsdL03wddjIv
a/sgRJ57UMmTHMS7r8MNBUPlORUSNr7PkxXYkubDxIwgE5/g4CplfZiaq1kgU0PRgUk08m6W/Ztp
hw51fCwiB1fy67brTrYYvSZQGhKSQtKG8DN+5KQS0bZCsMNM+N7hkj/d6G1/fG/BuhhTXQpFqPgA
9oDMK9hvrrKFwOLxAYaUZTD6CVWhWm0gLvtJ2l3yQeeM7ELM1fdRg23C6pyhgc4awsO8nB5kvn9F
wzoRZEiy/z5pV+FtlWVDHPkxIphgQjrXOM+xwZzW+ny27DcL+TGmS7Uwr0Gph1+CUZda2SNYLY16
FRnZXboz+MK3omVT0nJt02If6qmvnXQZOohXrl0AopPqMnELo7tllO9WX+QPIhfugCLRdx5DyVqH
sqJqxExy8GLQjGCld26WRe3JoX3QciswuGK0tTm561H+3YPqsK6meVyahsrHBk5ECvYKzxJ1OIQK
bp27WCblFPK0KpiUYcYI8ZcRSYc5tgnE6IkjIVkI+eRx5nEkpim18hTMD/V8ipJEWYGpAFy3IGPR
1Ws9bkSxtA8N3DTbLAZpB0W9fYwwpVwNGB0Q82Yqr/esLA3cyPxwXm6nIzucu/Bo6RllFaWfhS8r
x+bgq9IuxdQBTuDCfFcdrPIXHXBxJk4g+ZvtKk2AdCo1KdjFK2E/yilfTlVsZHle+IqxRgc56ffs
Q9SdJl4Vo9Ys/AEB+oRL4ug/je96l1ggiPvxAtam97+Aaz0yxfbnuWtrXjXq1ctdGfMYMobM5/pi
PffXc7pKoFHsZETsIUJvQx+p7aj+nfMNPm1pHPPfHg1J0l7UMR5MGBaiQzUKzO/5WcxqtWuyhq7+
/64WMDSyDf7peTKPZCIYIkfeM5f/xXzg+OAlQoa+L3cx0x/DdMh69k8FD20p1DDfiieQiXcaXPIu
XQZIqf3KI2IjgBOrhormR85uTNvGgHQw07gQbsOMuRprmjRAxd30bqgKowPq8Ecs+7V3yszTShYK
BzJU1lsdAyPRuHSYRPhBkG+K0pPivg36yUm/gS6tjcsYODpPbJpCrqV7QyPVL29vZueZIrdgJ7h4
/m8wPFeNuTrFuPvpyYRgK45h6kLBlzLFuqO74z4Se18e17xgPgnUpQvgF4SdzO2i1MnK11Pj4mH+
CHA5vKKs6dqIWfDlOK8DqbFBG+0ltl/INXW1DDqQnNdclIMYmivGvqteDZkiGTsQ4NPIam/fpkJ5
oQDDnYjsMRX/Fu7RqUZzW4/d1P9olu88gnR9y3QtXu0GkFAo0uVHZ7c1Yp10APifQSSgvrgBd860
ri7Na9Bhk+Mocgvdc768YxhNvnOEomJB/PQwfGHPkxv0DIVp141n8HsFxAcWVwaRVAKB4owlSdwe
Ats5aMAo4iParEdcGPJol/Bc1YsPFTG4HzEKxlwS2rWtakyeT/VslHodIXzJhNXF81yrOjZdeFjq
E7qAJEfvVJOPd9Q5tE0WjfnoRyVxmQUrOmiIQS7394g9ZnIVxT7P+gJKaXZXrGmxyPVPahNATyR1
4ScZe9XMrV1KKugXzY858ShqfgkQ6vU2L3oAeM5t2M+ZYslf8a0zNkz02QANWEVIm2VLLSDgfE/7
b/wx5BUZPobxWqEqw7eckVuAZQg7gZJW4MsMBGzf+MLlVx5KzW3Spu/F4mB54c/ZaEw6OKpdBdPH
Rnuqe8opaHiStVpHTSXjNijaLSCCGK5BaPzd2NPflRflYZ3sC/vWykiK+Pqus6Un34DZw7hrFk8z
rrKpATh1q8d/6dLx1rcslxH+pAICKySSXgw/H9vnuLPk8lhI+naZngVoRhYyr4BYWr+IMovT40Ek
4D3Ul2BVyoYuPmDChMukVo2czFBoeE6zCo9PkLSM84EggQVfjN6jmWDHiCIFXIuqUfVc8gAj3ni1
7WcoYhTkMBpjhrsCfqXqvR/+gM7zn2qF1Sq2QpSrxnhI29t4es2zY40XhvCnGY/5PBUoVZBsW2m7
IfY0HjbQaCarbYQmKOIMrlY7cqoyC8HAHCbPOyu9h541pNwcQIgIHwpVSbO0FpdZb91XjFQUor2J
S39l5yu4sf/ce+gdfTr+RuPR4xpxAkzVum3AzafgM9DyNECQ311utxJfUrheqKC4vXRg7ArMZcem
nOxmoXuRWUMaKa14Ls972cNX4GyZPVAYTFIeO08GL7BbU4W/PAz8SyWIgxBvNTg5Os55zt4utADW
wIQcymAKANm8toCu3rJBYUn55UfG2UY1wvHBHrD1bFGh3lonO1K16abFyw9oqku5wfOyJYo/g8Fj
0ny2+lShavohBPnKgVYt90PbABcdKZfeF5dGZzchfk6aQBvwsbYnqVFgVhRHdhsqgngE1crj4tya
aEmh3kLqJjAR2hFPaDXJ1wHKjUYjag/742C5jhh3fEjAhPq/3xpOn5ehs8LC++tVIW7+HChf9MNu
ZYE+ta/ZWdLuIa/D3bscuZflr32yASoIW6JlrtaPePzcFdGwRvoHOdoUUvUlUpIflArXoFJg1GBo
So59cakanNQy81bT4pVNh+KphImb3KfDvIs0px3rYir99vvbXRadXS4kUHQtGW3qu89cZr0YhrAp
QGoaywG1eorftcp3M1KQTh71DT7k3Cz4lG/3x5PQZMNxZOfF0K9DJC6t5kg1z9APsa34XXRAKNVk
XAd9MG4KzwqJmsk+uJpFxOlFTXvQ8AjnWSw1hO19ZOCW50BJdcSkg6/PqleByDhiPD5Aml5aWmXf
NLCTy6/p/mCeZlq/AL2qWriLbIhxzc/RYlQ66vPh35EZR6o249EBafnP+qxDXd9LIynEA2oW9lhF
+qYghNHAqisCwNFqXAG4DsF+3rLqzlw5NZR+FcGwI2PUQ4pEQcbUGX5+no8SpeSb1+Az3Id1PHgI
HzAHk71hgeX3TsqMYSriKBjV2cZRRqmX3CZLFEL/MS/Gm7Bm33IC5S7HoYWZv8xTmgyg1h0MIG33
6PPwzC8W2Vi1SdW36Qp9L6T+ow0VSfUb8+nIkl96zZ08naKkXdchCiOJLyS1sLan+3yN/o5NGldw
kFjhyY0V3D0/D8t6aZ9nwyvCj7j6WyIFvoPcSRHPLpLsIQs2BF4FQl1DjdXPi4gT4YIBJpr4MZ8E
3Y9gbW56igHCvRFFxmUOqzBLcSDdauf3OdIMOu4UhuFhUL/O1fTp6KbTyLwXbDZi8ZJeNiiwSZT8
0Ge48WdC5AvilxQDKEGnZUxGwYQpzgIrHI/t2XUKy9ePyeW/Y/riFtk6rQC2PLTZOT6uxjqcZfcC
LvrzOX2pgKkw1sduimXLB4hMyKEGVhRWXSPqCTqOS9rsnam1OOLBUEAawzKbTrSMImgz623aL69/
m91DVxo9e9OJztNAla5WZWseQsL8bCqD5Z0PYrsAy6Bi8VbrwdvA8P03l8ObiCI2Yuf3hcq8uSy0
uHHJ22d01PyrVGPI8cFjc+t2cZs9vJOL/olIX+BCOuYvX96iISqTfYU2fDeY+kTV5vY0P/1sf4xz
y9cGPfjH89FQQ3sRJKt1n5fAoxAAi8ahTqCMdUq4lTFAxyIpuZ9bGt+f6np62F5Z2BE8tVqte/P6
6q1OBHmQpfjAgS9ARbHc4pv82MahhzY+pLRb4ACD2W3UvkzZMvnSnmRsUB2NoFFabp3sXcBSVdFd
0ILJzECubzwYhs3C4f9H2o29gE/9/iF5dTXc/ArjIzWtjss6qvyhNaDlEtTTqkq2U5Ht6WA4nV3c
b0IL3q6154Fu4v/Z/iC6jL4alzeBRUAnU6g+UOv77Ds2OwULHD6gv7ewHD2XaDPPonQl6rnV5uWy
RPHol2o+2lqnMXbEIrTZsGRhLEU67UZlkT7QxFRdX609bnpTL0KTwtF8XQe2sPyXSVTcKEiN8s1L
yTeDpJJbRNQ4XvXZxWO3LyCSHK16LflspSRRGkhsd9AYFzC05tK5cTY6/RU/zY0yLKX5jxEv3xrr
S299GBbGNnHADlmL3siAqwfHLyFg9sGOYIF1R7/L6A/lUjmS52+br0Vxqs+MgpScDt57jiaX5ayy
4/d8yoC2ZyN5uaj0I+qm20lcx+ccNPu9zNx4i2amjsJdg839HFmSau3wduX2wCur1UVDzk68R6p4
Js0+cFW/n46tY11CaSezPhHXnIdxBHnIOkx5A/kzj2AXebLCSxTAJNKffXnOzAIlXq2/cELGaxzp
mg6am6mAEA1TXd0vdNRTGbgd676BhQBHka7weX4f5HaNYcg/B8XpONJJCNryiICULSL56SG/THic
Fh0iEPrP+DCH9NVT3+xfoeW6Kms7BYcAFoiM1X1Suj77VlHHe+pL8SzjXqI8ck7gffIFiQ5mvzdt
8liQkJDPPJkHV040EJ/4rJKc5A4yk77UYQCMc5yapmaiNigMjUxKOsJ41cv2DNu6u+TL6WcxmLhq
H1UuFsnIW7y64c65tx6GWZ2q3Jj3zMSxudqV4xLb9aZKG357qQvIdN6jLG9FtNJ6mLuCfk9TpmXm
QlDzHyfc0VJRA5m2ccPsAC5LhwqkocCUv23WrMXa0FczKoP4DqoUjJcgfk5RyVIuruQQMMGngoVF
G68AqsecyWsm/jkY7eY3UXOrFxreL7Ot63nxqMURlrohFnqX812FS1wSttxRowsV8ASedEbJUW3W
Nfa3YCFWSuMDY5+TQWvoz81Ao0SQnRyBZICvEImOP2hzpXFB9R6s0ZLwtA8YAiVEWy3EqlbSSSy5
dUijKSTShxFU66xnBocpC8EfoxVGL9xSh0NbMhs+5uM8+fru966EervML+u6WDptyDrNmNc/iDFg
8J7ekqpMDKuaVtlv66queZLxzHnSdvOFFKN0SSEDAz7ZTytZDevjYADMzg/q4///IJcFE8gx1HXh
ShgfTmVh8YMfXKlXngtBWXgu5HQ9tS+vgQgPnOA7PfTBVFZQNP2pFS0SIawiS+3ZeLXysR4cYCEB
9YykLHzTnleFCSlTCwLu2ZjrAYc29O4BRw+y27hl3xif6/0g+xCotndtTmiZe/I8XCgR6tSYiJOb
upOytaXE+xiOZSrL7d0f4kWE8NdCMaGv+STFMR3z+x0W0f2thrsEhmYOkpBgBP4Ai8mxx8UDQt6F
byjDeVVYotF7QkAOF0BqONjFeZV3sQh5glOXLwdHXpPowT808wxW4qI8EgRFexC53zr/dzr7Hk9T
FawZRt5mWzjQYBlidkSJ8JxG5a1lcdqBqUU5VoRrMevuLmHy4GDpbjgBpxt4DXnWhzFpzeBS5/ov
eeLLyBizUInBxZWxhPlguR28clcdOU1StqAOedU79habZ/dWfxrFekfVtGxPukIXmvCRKdMc1wva
pkbiJ82wMbVJmC9/vdy+L2m5c+Xc3r61HZ3j2bghMPHckeDpEXuBvc/DLk2/pkbZp13pqU2JFszI
tUInGMwvYs01jMNzuwGmn10+2atK+l9COzCR1C9e4SLG4kaVEUzyr+tDP5ZKj0brKnIjLTgkF50Z
ENgoxv8YbgyE6GDCjEEyqx7FYmUNY55QEcSpTo0veDO0+oGL683AiSpCH5G9n3gos3skEgpjszMA
IEtjL1kOToY+yRKLhlckAZMNkmxnFDc7iAWVecvixv1KZDur5PWD6f9Iliperwuk8ZaeErhQK1Eq
s3LcEHYs5X3G
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
