// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Thu Nov 19 23:34:33 2026
// Host        : Nadella running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/EmbeddedSystems_E26/Assignment2/SNN_FPGA_Shapes/SNN_FPGA_Shapes.gen/sources_1/bd/SNN_FPGA_Shapes/ip/SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0/SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0_sim_netlist.v
// Design      : SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0,blk_mem_gen_v8_4_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_13,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0
   (clka,
    rsta,
    ena,
    wea,
    addra,
    dina,
    douta,
    rsta_busy);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE BRAM_CTRL, READ_WRITE_MODE READ_WRITE, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA RST" *) input rsta;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [3:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [31:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [31:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;
  output rsta_busy;

  wire [31:0]addra;
  wire clka;
  wire [31:0]dina;
  wire [31:0]douta;
  wire ena;
  wire rsta;
  wire rsta_busy;
  wire [3:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [31:0]NLW_U0_doutb_UNCONNECTED;
  wire [31:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "32" *) 
  (* C_ADDRB_WIDTH = "32" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "8" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "0" *) 
  (* C_COUNT_36K_BRAM = "2" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "1" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "1" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     5.3746 mW" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "1" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "NONE" *) 
  (* C_INIT_FILE_NAME = "no_coe_file_loaded" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "0" *) 
  (* C_MEMORY_OPTIMIZATION = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "2048" *) 
  (* C_READ_DEPTH_B = "2048" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "32" *) 
  (* C_READ_WIDTH_B = "32" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "1" *) 
  (* C_USE_BYTE_WEA = "1" *) 
  (* C_USE_BYTE_WEB = "1" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "4" *) 
  (* C_WEB_WIDTH = "4" *) 
  (* C_WRITE_DEPTH_A = "2048" *) 
  (* C_WRITE_DEPTH_B = "2048" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "32" *) 
  (* C_WRITE_WIDTH_B = "32" *) 
  (* C_XDEVICEFAMILY = "zynq" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0_blk_mem_gen_v8_4_13 U0
       (.addra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addra[12:2],1'b0,1'b0}),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[31:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[31:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(rsta),
        .rsta_busy(rsta_busy),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[31:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[31:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web({1'b0,1'b0,1'b0,1'b0}));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2026.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
kZgFhM2d/jlaPzxpf6XHBAvY3udA2n90sVrL5ios3dCU6DHMG01BptGv7AEkMGv1nBWc9wOv8Ao5
MO+RYUWfJloAgvE9oz3EJHrmhQHk1oDdQ/EpnejIRbEZCjmfHUEI21gyKS6oLdkyx2gHs3HX+wks
75MnE8jDP5XEe0wRk70=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CotVlRfEkpF8whBUKgocdcjhKyrcMEGPZvHkGVHISj+GCXwa3Gdeme07eFJpz/ZotBRm0H+nvk9U
c+cu76zAYcGZA4BB8k5S5CN9te+cdcMud4cLzxM3NWHdGuMLRnzIf+YH7ADhhyN/3GRT3GlBC9un
8gg46/rnawNHyJnmhY8sUwhYJFSC6Zp+YpCreJEMMsSSR0D4CM0VZx3eT8IWhFsOz6ekLOhifcRk
JdWdOdywGnTqpOq97/LmRPbfEGBiYB5YDEex+rP8S+WkdfZSRXRcMfIMDifCL2F9vyvALaXXU/HK
kczWE+R+OoMRMGX7ipHLpx7Q08Lk2uu9pJiE9Q==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
tZnJNN2Qmv8npxJcsUh1oNo5AcwWv4Go3b6+WqtB8cYERd3tAiuYpzM9E8x0/NSOgU2lO+XGGWqL
PXOFRGE6+vT9Uw+MMZ7IhiFhNUxakIUv/kmA/Kpo9+5Y8aWN581krtWN9KT8/ccdMg7//qZ5aT8D
c323EB+407vCn2c62Ug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
KKZGVVr56cxydgpa10+BIppw9vsPylE78OMiTW7WTk1ML6QnGGk6Ufm83Q5BYCGjf79wKt+EDVr2
Faz5O4p7NqDjYc+6UH+r3tYhzg8ax3QQ/lL0h4ROXjjznYZN4GT3jpmEVd5M9uz0VZRUklNggvzs
aHgFve9gt7F5cG1cwxr+CFWUfKcsH6XCTrNM3UP1/Ye33LxT6qzhZVuCb4w1zybXO9K1HZRARNeE
XmaMeB1MHLiswqCVSWCi3ahqMoTIL8Nkwb7LISvYxN88qxMca/sR/Y59W48DrGDRBBzZ48hIpVXK
9wpPb6wF5zA03FsVqRSc5JxQzfKhTSxAnXSVMA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ywVnQUL8hRlFZUGP9Kpsx7UfX2m6K2oMp1dIrzsl1e7ahG0jDMr0uZjciYiQvVpl++f7jBR3qTGo
/E63+MEs3aH3oSmrd0H/Etz+j2FU3ASZNwvS98uACXUBPzAeEwFUuJ9/8jqLJsiNybXigf8spDDy
xB/JnUfJl4/mmyClxySXyscK3aOnErzAZ9B9i8PeHPttmRn6onzR+wukt29Z0ETtVcyKKb9JQeO5
4ipDn79/o1IPYLzFyyiP5/oKUP/4zmX/6pbiO6bdzi2kdrhBtRE6ztlUGTI0WBHPOO+nZcIlF5S4
jckQo17l4fcqBJC8p6S7fb4eyfp+IU8PFj6wDQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GUQu/hEzrCx6whrKX9cnRKGYwu/EkGwKC+5ZIAahvY/upngQfvNVWyz4hLS5Q+jQdoupTTPWruY8
5QnccTfRLO/UNkPmbg8atB4asCjrKgLIhzPG1pqhoH9BtKKby74jLu4vyRH0Hk9XOXkAXLos7eBX
Nudw/vzxy74RzWXjstE5NRhMqfXi+jrP7VLV+NT9AN7PZQ8SsVifNwD2P2HwGzqQT/beYW8LvNbr
bRbtDAwcCcJomfkUvNb4pYE7MuJK22aox2ar8nUAviLnxnmy/ASVSGou0mCxgkZKW88UP70HDIhl
aueFj0IyK2H6IPJM9GCgGAwEeA0w0rzI7faPlg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YHSFaIRKyhIVU+ZO/EyZESP/nTM928AcWJGbKx6Nxkm8PEl7yBr3z8S8G0MbToKUpAO14Ei843y2
QSES26grec+g5bQHTjG1w5mR0gi3IRbGAT8ctIbI6qe8HxLmMViuDiYNb2JRHPBhpGjx1o9s0K53
1FVtSLcIMPdvZ6vGzYYlswxXiOA7D0qdnIFeJXb/6BzeYM/ZSO3kXFNYZVuhaNU0AcFxQzxAe/sK
lx5QdNGpyfexd+UnTCdHIul+eFr91+gTUaOVHDR7qvAiX+c3k+nbn4d1gBOExbPG5xXxO9QzpWZH
pkGcv5/2mmPVGGa6bx1rd+/wxxqJYs2r4GBQhQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
SuOFRD2tIt83R5vOz6fwY9Uj1WJom9jlw00FrgpAa9zzHh8NDaN1pvHliEpw0RI/EXGai+RqFTtv
ODI2Qchq2R+Ohalo8v9B//WzHrQEoZOqY8ExEpKNbhp2IJiwsZKz4enjUze+QgFiZFFBQSuEtvRx
6PvI0tTjXp4d4nJZP6HbKHFzj2SEggoTEvkYm2QqrEIRu3HQ9cXOaM9B77eWbQvHHj8yGYRw4A5u
Grwq5j0VzH8/eaysSLlB32jy65hpz1XiigFMnu01jNTA/Fh2qkMYpJeiiityiftiHDGBeEi78AUU
DCNlSbHo0NgXbyxwgV82OqxM0bTJUXK6Gh6/8xgla6TEAub1vTzQH5Uche+S6QnV24o6ll5HwYyV
RoBr27Aj0mceN3MNqSTnsoEMthFh1MLmp0imxgG/6NjNFKABJTDuaGPLE9XjU59knvKP1VKk9Fp5
rI7Y3IvGFhu0bHKEhV60LLTosXWr9gzS3uKCMCb0T38cAx5GX6FcChb0

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
WC3gV9hDsJlJGDWXD9/OXXBzEn6vsr7+oOdKz7gm4Rk/FFR50y93jhYmcWd1K2InGg42AOhIHo2Z
TvhSjky9Smc6kaftDv0qbAD/y3awUgVWMhvanfJnlEuAZfoFEJGwGr9jYg55AvfvuX1rQTtKoUFi
ACZ7pJVaLnkCKFVPNuhRAQxCs7KLW7cG1ALcdtOdnRrcG3bh4dHzct2JzL2/VK03C8gPKr3uM6DE
9O0lltoTf/AzP3jfV2LZekZChJx+UY4WWMhnVCiQKoa9voReSAKbrxHl/hqJvWQiYa6CFpABdUpX
fjEHVkVIdpnVpslTz0sOxXMvpxX7F8T6O5KvOA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Iqc6J3NDm5J0Ukvjev1H/S4Q4RmJahnBq0A8nClyXeu33t4xanh+aGq3+WcR0KQRtSZvQDrbXWvy
VpRaHzQu/lgwraB5780gv5qhqt1D3uYyerl5fx6fl2ozWlr8yZKs/qaDlktEWGF0MPUsJuYE6ZcM
72yOpO5/ynMUgwJs9FVcK5pRasgkXgOUeN1tA6mmLAiYCor4CtxoB2CGVa0z1Xsrai6cNrXCDd8I
D1f10kYi4ICIsU7uhC3hLMQ66OSpgzGDdHUq52hVB7ESc7B/fk4nrcm0mSK0cPc0un7O8vvvykdb
kA7qDovHJqWd0VWle0m3J0DvA2pKJUU4AmG51A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Y+N5GKAwdOuN9nS/lU52Y4ZNhFpP5Eg6jiLvP1rQk7jt7v332HLd3dDgIcKOvTZ+cT2qc/fEH3km
qRW6R6MDwiTEv5NDgR96180FbWhHKmyQ/AZmvgAhcSnKARj27eDEkTFcUfN+RgRNycooCPjQ2LvE
RAHSYS+ob7G8GxymUfgoG2pJ1BZF8n98Yv+Aj+fx3pPWyFx63XYQu0VIla5KV1WkhDxakW9v4pJh
kWzHMGwdhrs9q2KAQjFgZaDXVv5oFd/wcJWXkvkbsRdm3Ok9s3OwuaW9LsKnBGReVg6ii5BR+7Za
9w0kFZHcWjmf5ns8L/rFEzHcIGqE15ZlLKYekg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 53088)
`pragma protect data_block
oIIhkLvYAA4Gh+FLj+ffdPtGWyvxuuZi0o42tHnSQX+IFj+oNax1VQHLbR3jKoKxxwnud55ln++H
jU1b9sogSIpRo+xE7r/pFInFokkLYZtel7u+yQ7D/S5kjdiODcgldLMlvPoC1k5/8gCFCAZ8M3ce
euJkSULVctTodOPpcCux3INkqedIvwlUKPm1ElGoWr2GzQNsBawUeS6WCe5IowtzJ5NsPCvKjvxT
1gUNXB3ApiffdBM4pQa55t+TBbMvM0g88whxEdF4CAiuEGwBqiH1eL2dJmldLEYQqRMWKSSKA10s
QZ02vM9ktaa/TSCkKvVKISTWI9Bb5sKVlkBsnWPJ5F0E2LRRDKSs9yNDMnQb55+ZtG/IFwQjfl87
AGuNmw/0V+v6Du8OdoHLMtqUDGR2Rs0omIopN6+2w856/YLpaSmSxoK0oplmYoG7bGuLEp7LNlW7
tSDoZHmrJLVjgU+XCS9W7KPffUsl2sBcvDhd0ILM3AJVzUr9wiUELzaffo4ppG18iMw0evK3Ek9J
Z6t9jcmUg5IUg71HSS791+OGByalTwPyjWsf12G3sQODE9fPz27uA3mCXvgg8KO4iFuPMF+xLHPT
66gqxUt6JrccUhZkfIiYVG+AjoJh4fBZKj++kLVd8rOznn3t8PUsw0diprqFVJ8Rsp1//muSaJNI
9hZ23GXjQAAeqf1lTLjTuPCaGcU9qMlQqfPEUjC1gG8tlCc1KbzfyGhEG3K/o1dX4tjdgFV5R1UN
62uGd5BMZ0Cekkm85fQfEjNw8ycJ5DbcJ0NBJ7q0Kv0N8wJv1VuwV2xAvc24pT7KAUBb4nkQZhr/
Z4Gx5C4egdtlavEZbQOM3fq12NV7r8Q2xCrKfrPXT//Ij3ux3ZFISfIij6c46sPfcTVf52nlctec
v3GgbF4ZKmaVtQeKZnKkfKdHUzWiSJsPSjFKqqlhBzlopVqCeGIW8y1DOQioVT04gaQq3AUHCfv3
z4T70fMWqGtGvJJunXz/Br5fqYXb6MVgL9u5NrNkDA/vOfKoysjq423sZOp0x/BBG9g/GPAmKUyQ
lhycP3R4jsHw5ZSZNq0Jk9qbSc6pcqRSaHKFzCfUD05bGBYJdZpt3pehhMN317QZ4KJOO+KUXDTf
nQOeKHP26U6ESBmtrAUzvEluR36AUHQLIxKy+X6so7jbx5QEsj/20hA1TF+vJnWgXWWRoRtf5XKX
cgAqB2amFRRiMQMpCNI7oCkDhXd/N0Ld+wEp3RlVy1rQjGKgasDOp9pdEcl4YzQi4p+K3kmUReh4
FIE4I0ieP25fZfNVmgjj7AUYlY3Cvp0Mzaxqen3FKU9gFKkz6RtbFwL0ejMEPkjflohe4UITyAbo
9TeDYAQVy7zdYA3Bkt4W3ESLhNnL40tbQhNhUpjRF4o3IcxGrztGhYRy8oge9acuNn8ShmXQD8kK
RpBI/bYjRiOEehETLHkgq7LRE9KJfdSQCy212RqZC8Td/l144yIY8iQRW+DXZ6Q4D+Du8Ulzw4RM
poquP19YAObnF91sGq8hX0yb7kaNfpbFhwy0K4Raz6yh+ibmsA4KMgMjjoqoZphmQ9zuPGKwz5/U
j5kCo16kfiLbjDOSG8K8C/LtLo01oEFnuo2yfWTd6l+VyW6oLlsfDkZ1hykKSw4Y0tRXfvsR3/x7
LsLm+5ZVrjlX2kpVu6+2rvpBF50TlfFbj8yMEgTlPEYG3BMLEpphkqnvDZ3qsFeFodMqtr3cI+i3
LMOtJKumsQlNrf33aB7gCtEJrB0bLvOaDAPgYYKD7IYtGooTeB0eFiSr51bq229XpVnvo/K6pkzC
UHr7on26rY+a9KoJxX4nXZGI4UCQxfDaoWcBvWvBaeAPVcp8oFIvNTCw8HpSMoI7iQ5r1agQj0rN
VIniI3ohQuZBurtovorQXmlQ0YO8phF85Wx3vEmusTYKTO2u93yLdPArzHnYRqZwOJiU3PqDWYFJ
MwkdQZtoMlA2TLPD3Etn70Y3itScY4sXoyheJvsQyt6cX5Ly5K4rSaPZTYB4FGvyl1vA5yUSKYhS
3qpACNfoqbm+dM+L0hvdI81MFLxPpKuaijyuLmuJ45lH1R6TaKu6EmFRkfTU/MLZlIWzLE27SVYh
Jg1UYMZsU6WH06K4K8lX7SLHZES+ac8jeaj95kV+1L77tCvlp0rSzkRYJvH5IMWAeSd2dgvxscpM
oMtN1WDD5K0N2UGa6xFRXEgrTgRQpTI+UvPTT38O9SCzzGCgV+hfY9UBia6zteZqSqHfPlaVbnd0
XbG5+7xEZaJzPf+EjG3cXleiji7mIS/A0N6wd+A3k9bWgSokFTi9COPLQ3GpO5IwrAjgmONFJSUw
+KsH/z6yMdL0if9APLyHNaxPbjdn9Ogbqm1j9kBiiHJ81n+5zGu5Da8xJZpjxGkAm7muGHoEF0MQ
dJCuERWuOr8QWsQtzDjsuZVu2Ul7SQpwfxhPjGFR7Q1cF0wM3nK8hGy9tUNXFiwZgYvlEoFF/lRD
q4clncCoXQ58Dyb8Pc7gpqe8qqfsx4uiLSVK+s1WVydFY6/0bCfHPAAFZ2k0+rppp9zHnKGk/R4B
r1jpZQsDuRmtYM5N/LHm2Peokyjo1S8rUKvaJ/i6AwMIhKCPicyebJtntfoimwvi+U4ur7zcB9tP
R0cKnnviv3pRh330WztCCFQZ6tDaAmRHu6LfrevC9CAKKR30DQKwG1mcCSwLug1MxAFnT9jy8wca
HmY+qSHLfKfsudWIruq+pYLNTpNURWtklKwOi7uWQuKj8/ulz2LGbTwb6nSnnQRqdx3WUUjxlaYz
/5EhN5GU/ZP987M8XyQsgu0bqbqXJyP/eJpv3UQDHhwXR+CPhO8xjcbIVJPfCq/KjTM344kcclAI
eDpGNpUkIghtn9ZOrz0XV69iV7Qg3Ad5Q9q61oDEd/NHeM5F2mo40cCCe+Pt3PCXkCeDTo6OzmCz
qmBlOz5Pa0P3mw6FCOJkkkd/2ZunxcERJ4qnJcVFFHn2adwbY17mvD/aUn2whWpQYhX9vFCJLtMx
Suhyp3fWIaX3eC6w/1csGVHswxggseWwskt26Lba6bRxLtihJlYnJdWZCN0U8UgdSLVE6D0KP9a+
++AruZQqitFffzII0BOF0eh5eeSRugspq3j+iKFVU/DCbP4QZmrfu9iXdtViDP2W7qIQAS3qxF3T
e8vEwgxLNJiU7lP3vl00ou1TYYQGC1Gruu5uFFMbuyaAtiqa9OXrN16zyMF+SyoAS+AeumaJxoFL
ArlV3Kmo/uv/u7+DZZybn12R8qlI0gRaZNQRENoxaQzy9rcYIqSoamX9ngeYqK6ApBr7v9uloz3u
6QmK1DYSmRd0DTJXg4HZ7nEvc+r+ufpIoBLyslF2iK2sCZN6PhRCcQ2Z8tmilFqtAFmLXMUUi8VE
PImVugW+VTuR3vz6mt/a5WhQpOch56w+VmstCAxIkqDFWnIvzKhUm2BlZgQG4qDHl9pURJbHNKwr
qYXyNSebvNRfl62ZaoJt0QRRh4AmFDxRj2XO6QyHuldC287SFJc3IPuXePMDEErTYzgeK5NoQ0Q5
dO4VEpsPlRtyL1OyKWYQbyqhoqJHIZakJuxCxZn56PXKz9VhWxrLtZBPxpNxDGaoTkimigx/iZjT
WGaHWmJqq9DtAdsWFRE4MKBwI5hZIOG2fFCw4D4jShkiTEp3Ei1nMeGsAIf8lMleQkSLpOKUmJrI
4BkbqRbkyHn1doQn6BypLjQnx02GBKFNCPTMZpEmOeRFK1HCpHdtV8mmuG942o8QjTsdlXsTDexT
lf26U2FDxpi5fhH4cMy0xRuVFEBJRK919KHlb9kU1QADkWSjD5g72vkAJuGbI3hxKm8ZcDe3GtOO
bi9vhjREBmUrcvbgpPalrwpN8sXIe1QVlsbTzC5vp1TA/IEGJnE7l9trSw7h1bE1l3uj7q7k8zQM
LaNfsMQP8d4XB6UaPSBuejOJeDPRF/8Qefy9f00cyBYaJ0+7YL6BpyTXPH8Vh+au2tP+fXCR21cp
6TANnKban5RK7ehUN7NV/Yt0DR181W65Wvm88qfT+8mdysLutuTxpZSIbFuHXvSuI8XQwc+urkNv
jq22ppR7SxwFLwx8bD4pgrxPf8sbbmDF5FL822ek8woEKfMpuJSkd6ioZwm0M7tdglMF6pmcadq6
LOxfgE9iFNjeyeNnPByDJiPCo4U+tZHe/UFQCsGEe2cvDjFbC2vqK4etpXHOgQYDZSDrFWpsnCUG
Hxh9IxLkBkmpqh2jbwWosfKIuYuxLYJVx7kvs6pb0bA5iU+fUnF0NRFiok59F3H9FcEwhm9xSrBy
zpvgJKRMRe3fbFSVgcO0IrOzJ3jfkkmZE8EtPmAB4lT954fgt2IFr7G/qsvS/ZTk+ZBWodOXlp4v
G6/P97rddTp0wypiJy2R04IagdO3uA2Vp9Ln6LbU+atNaurkHY2xcdZ9HjQO/HJLZmdYvVToarty
1EgbkTkEevhYlc5Azj3bOIRD2v4QrSE2EdTQ8dRK4+z21BF411egjuEI4KZgXrgpuHoDjy8EeZLp
NWMMit2b2OzbHsL3P/ILCfUbOGnUSR0VJasohACtmvbQ4Cim3L5V8kKrQMxHbc1EndUXBUbx/f2m
o9CDgSTbYz4AK/VXoATCH/dwrog5p+Jyjx0kNmQ9viNH8RPnKppePkUmm10p7R7jEG1LFRRz2Amm
9v3NStvsScEFS80TevIcwGLmagPfleLswtS6NzNYiR68RFX6WefeO31mkKxpnc5DtKxWD6FbvkYG
rhgAxiRkbf4tA6YDUtDkChTS/LLh3p/vr2Y4n0vXnanbB1KfoqqpqdLXNF6xBYcKJjhHOiz0GHt1
LtimXTCS4Pdg32Iz8JTT9Kn0jly7rjKjUgxqM8t5ll+n6DvkF8T7QUIPoah+gBKhttDGD4ehHQeD
666lPCbF/UpMBt307Vqjx+jclLxjrcIyIzBUG1rxVJfIVXO94dvr4lkJZZAeoONVIIsz0I2Nti4A
XbzJK/4Yq/PuYLiPCFF4A9lwcNFaXvLkM9SCDlfh2fOqru+JboVGshwpSa+asxfKc+KT20eDSB6R
MucgQUTgISuos2SouzbcV7XxqZemJXPGQPp+rjD8ik/oz+if4Vs0MnB5voVjBJgN5nj3vSvkCuaX
TthGIFm+uSTWmANywiRTs2ZLnTkxr6OXHwmcaqfFavp8YrTbBmcwKqw0s3EOR1XUqvcLSvmIoySY
051hDkvnPRGE9Y/TkBrtGp0lioNbiEHDZRetUC/xSDsQhF41PjNNDFICmDHKUkARyHZqbsfd5RpR
6OxHsrpoHZOsxtoB7Abks1gp2WQ/McPw1ehcxRUW6E6GCgV9xAA7+q7wyouXDAvu9XkFlFr06Boo
fCRz0QcKL4S62uqdsQhV5GkOIBckLt2071zQ4+eZWKPfLrOHInMlsZX/5lmnptbAfGwLDsZ/lpQR
PqPYaQkYLYqxg70v4R67lS3zw+t+mRieWNSaspd38/VRq5u5OCNEMIEN4VtCLiBj+2aoQ3cLPVWI
TKg+3HxidesasFao7reSaoO20qZ0G7FyxAsKa4EAS/nr4smP9iMcXveil4wJpcCmlae2yL9Fnb/L
Irt3j94gT06sKHrI1QXaoZ0IGXjCIOw7JCaZeKedzGvDUgY7TBNn01janY+4xfSto1PgB4/XgqcP
DJ+dDga/6fsttREcTu+BFsChLiDUKna5IltAY42Td2P1l8XUxW1nYaskJpv70vha8+1yoML/Qcmi
OEk+Uh6X/8cqa3oZIjTctyyr2jmHtVGW1VnCzKtYxNGAzc4SFzdRAlpbClbso4kBfhBnT6crzqj+
mK6fh5j7Nit/8OXz3BhPHOFKaZq4ceqrRJIAhVPiC0tOknjKeTPufMpqO3OZ+LmuJKKUKiGpz4iI
/cPgMTf172ieXwR2Ka4lfZnTVjnahdKbrNsRPFi3GMD8wzce8RNp5C+6nj2ux4DE0Rd6gGQsviAe
ltiGj8lgkRkf9/5FHFx2QjaLDCuphH+ec5q6L+VrGfD04WmuuJTjl6h9zXCGhpXFpo4HuDiLWu2J
Z3rAep/FyJstcnWrH3GHjeuljru/da+nvUVIdDV5+BkyECprEYZkGKnZduMB1Jk07LPB3zkagMrW
X+3lvRH6yRwD/4h6rMs9Q3X2RLEUV3li+PYjKTPOzsIyGQ0SJ5dHBZw0G7jDLMcdiSR9syIfbO2t
4Lz6dR37OZfvCrnggshJPdCJj61IK9bS6BrdxyabUUQArvsCoi8Hdz1A6IsaVynGMQRxrEi+Inha
gOD4H8E2Nsao3GFegeY/OyrJiOtMenCqKoL7Pz24fwt9OoBM+V0KiE+3SG75W74lx8AwJd+qhNVA
2Ijc6cu5DTBg3+Tx1wnKSFtdd6lqiVx5njcccFQWrTgFde+/PX/3hqwXmuddcTpLD2ldB5R3xyA9
TmXTTN/XL+hl/TPsDVGq7r+BS8ppUic4IzVlZTz8luH/3XO6+0p+iToWi+O/q0kgfPCGlXpW2keJ
Tnx8VbTUCZTseg6uisCmypipGkqnfQ9y9xs04SqA6XTWc+pNoBqHT+yxtBMKiJxRorLXIgKMiKkH
WRVYrOTGVk1OhBLvo+gl46TSeke+I9igMk9yHi6InyDS4lB+RRw7ewP6avUHIc5GC4iFC3f/0eK3
NAK74fgcWbq9hk3wbtzFa9wtApLDzFYI7Njf+c8hHruamMmfQYhUakaFuA564VU1DywzLo81jHZd
OYpLY7aG0ky7gcG5KTo4U8sE7eb3aFLnwuiK0gsXg+rcHUx+T90cV7wjE2I+dXlZDsu7qLJsd85g
dU0fEm9OORvlrOBHgd91DqG4oR+kA/43LTemoCajUv8aqS+9qz2BSsnFJBzJHxRnZF3qI254HWTB
95ZJ3/Gdh9Qg1dl1IOtzxhwGmDEGi9mxn4buqzfdN0B4FFkgBAPL+TkYD01ZwV3NiRetkizieHrC
g86QjsvFqZwC9aCqkG+8OUdLcWueDnWmKe8LsqtPEwXTRCVHlVoFTkYFvbS8RcLZGyTpWvWqknRa
RXu/JCQhmByddgYXlqtd6OjbLKAQudvHMqlW224Go607dEzMJmMMHlABthJDpFH7iaU62h7RFLQM
YfrLsb0fIthQQy+PGHVOEhhP85yCXNNIUEk5MxArxGTrQoMltbZLH4UzZNggDT0h8C/zcGOTSv4V
es4JapVrCbj2TyAahxXyH+1Qr3OWJoCaU6aakUWmdPU511Rxm7C6kUG+Ef/6qvdepQDvfZOaASud
zaoYGiCOYF0HTPAldlv334I6tucvSWmrRWJqE3SRoKXBMY6EvjjNfEPDc6WrtEOjjb8ZlFmTRNGz
KrOUo/U89ufyvjoV7o1r05MClmtQIK8gBX92/EWUaJTZEtEgn4PISZZhUy+/iZWtEK1gCHW82nXR
fiuW5w2/UznyFmwGzzwnhCczy1U+HuyZVd6vn0Ku/aSXY3gt4HJSc+uOyl1K+oUIdhGmXk+Z1uAJ
kSkiAkm1CVOX/Yb7b7EymP0acGLlSWWTIN2PfP/01zrBe62HVgqjQigI1LtkGKBJV2MxCN/MB0vo
8Q2EDRdQw3eLy+XmkkGF0lZBi/1bzmd5v7+bFDybIxAdjdgFr8pOJOsYB7SQgklLIvRxPGGAa/Nn
HNhhxh9ZQ6PGNOdHhA9Z1nu1WXrtlbltibSQvR7J2aVDsGHZ6f+tTfeszfPjFgIgNaiFhdd3DAo6
+t9Puu1iDPMWG3lZNwIB5f3HL/Ko85CJ/l4fPTc4gTFXuxyj7np55T+PB1prf2z3hw7Kfq6HNkf/
m14O5QMJetsTPPLYrU401d89JwJnW9Bj7rES6ssfkslZDQPG+8VtxAkvWNqFokP0HQYYBXNuBj2w
c9iUAfmW1ObJQnPb2m+E2lH7O7af2U/lts0f0ZT3uiY2ktMVnZRcCeQIqFrosR9HTIWYI1WluBLT
kYbUnh3pKtUVRraVhk65IIb4FHmUFhT9J8C2e+lUE/wBUVUOgNGLyfciMWwCXnXyQJQNmBp/iWDC
bs1Yi6JwFITjUjQT6OIn+AZJrHG9+hly+oSBQMIbIi68nGE6axxUa2T7dd97QYrpSyg/J2ebQThM
N6LX4AmksJHkMjC1hrdirFAQbaGqYVieDW6IUksMG7W2MTMB0ZCX4UEJGu99f+dBgD9REN5MzmUm
Ln8RuyT50Zl9kZOMs7ANWam9LdryYVmTBj42v3FR7yBrEAWbJXgjAnEDOAT0uSNlRFTKebEBPuEY
z1DIjACcI0xDtwESTZ8554X+0w2Wrbx1NU2ldtktdn/7XOxo0QBkhO0Xv8d4ghByHK42WEvPZ60b
HB/R0jhbOx8H2d2bisMmGlPzV3HlUZqjWSCX2ZHMtATmUmwCJNf8PA2gZkgdW3DkaEugApp34fY9
uKAEvyS9B7u2b35lJEXTjUsREG4Y0R2sVNKTLn6KTBEji1ViOY0x9lmoWX3ymD2fOeWpo57mawbd
aiY7Q7ri+wPfXyUsn+P1572V2UG44tJHJ0FedH/uWY3MimNf0ZFpFDE0fetbHMuqz1WWJlD7urxB
51P+6lo3EYLUSDqHSegTTnjPDIGFl32f7WspLXNlDrivwYDlwr91o5U/ueJtdBvsQJTrPl8qR80k
7LQUzWp++p8P4R+XzHbcuXz4BEJ3SIFE8boHB7tB2wsM1pboaEHIQDYOzvrSyUy+Bsf89eOlQhMm
DE/pTd26nRYMfDrcCwmUcgxo8lkxvqfU9Bn6VuY+wrq1D4RWbFyWhPrXgUAIaim/zNKDyUnbrO0L
Dbk6KJWaxFRo13uitbAVvOh1wBWKfEbgq/dGNUkUEnP2E3B111EofN33svHEARvakKstKhDCGwVQ
DKjMHWSqO9+IxIxR+SuWFmXJm7ynLXrnWxlp1trpdJCuBtddrEvV69iZROKF94IvdH4MDiRh9gT9
lJDuwV92HU9tXB1Bszp1osQ0d+e4fQGG7WvsV8aXe8mErPeVsToLLY/B0uYUmVWCdzQ0OtHbAFJi
ytOPG7GMMik6PDuKc4saZgQMjYf+iV6zqIVwwJcPm6txT9LYYju2H9obToXJY61SgDNpLAbW7g60
74oL/tHs8tMLIxNGD0ud0goot9fhMiJEhK1ouCXzxBzkZrCe+WnQTKO3rSG/7lj3wiQQohcvowZd
vNnBYQ1+DNfPDS441tkRrEk4xhftrad1WmxswmPMKV0bWGWjtvNG5Exq3i7SfyC6tNEzpu7pFeJe
zWpDhrH82Ns0sIQZGIAuoDlXm/vR448INaqumPZWQvzwKN1rMsX+s7aOfSjj2kUL1DZXwCAfmG1J
HAfKXa8E8yjLD6I+l0/XISdTy5rw9Vax/5yS9TPA60RB3gkYWyoSCGIOTakIAO8g21jk/9liyU3+
vBvykohLYuI5Wcwt2yuw5gL6290C55T4nvzC1/C/X+VV66myyUShDam863FGoTy2pNIngU6+7CTX
oEoHJXZ2OqGi2t/31Hw8r6HeGn3uExwzJ70zYOCtllZt0QpQ9b7BEUAgWidvb73U958zzlnbyWdS
B1+/HqnKVOXtI3F2/hMiZPjqieKdQqASHTo/eiUa+GsYcJGgMR397aw2haybgp798+uGbKvqElw+
OT1jvEm/vtH74/YdCzqyFSgi9S1AOwi241XLHT+1J1ejahWVeIzaw6hZSjVrmrCXtpIjxzK6OjyU
tbiLmyoD5KB3hKzxlFYZ8LSCg8DcyZK/13/MJBAGyMVv7KbUUeSSz/2QM0ZTHWGKfUs3+SehtkSf
ZxAPwJ4yYvv//Ol+6sTvIb3GtNzNw3ZX2Wi6J/N4zxsuAGarE0CH/S+s2U9ti0nF1t9Qinp4AcHI
/f7xxTg6MxwnB7+KaP97p1hmjaadqfVwcpectKg+vh9Za0fukgBoCrcty56wtuSvorWvd52yHzDl
imHKCGaey4DTLI9JU+yCBP0mzicHYncbxdvPlhIbn30FvtU1wnHosyJu4au3SuPI+x7/aNp5g9sY
NW1C1HXm5Edorv1c/3vhfLMOmqbfmkq71bTUi6OvXNAlokkM6QPGwFAbxFeQysaSiXludqsyIfDA
613vx5i8oqq5pCja2j6C/eiArZ6qjUprQEmWse/ljG9yXKYSdp4nVuR165guOL6eYN4KVChP40Wl
xHuLwEfd88BzUUlbY2EmtYv55qMGrNuCT+LrxOxjyKtCim0bSV6pjYRyDUhErLD89SRb5i6+2AMX
6u5I0GkUZfWPhEZW0tbqAM+3Eg2Y+cOBhnpow3glxqs84f9Gs3qd0OYMfAkYgbjcOHpPv4IPKL5R
w3xL2Kh/iXm+pLz80RKro4lAzJQs01XOqxuVc8aMxv8w3hYCMvnvgtq0cBHG9fvy5sA0AVcrvdeU
vnhNtQlNegDSIscP7jmIJopvW/pa07gCAWAObF6GJ6rHIVtuy3hkgdN1nlzxgbKazgR0WJfFd090
/aCaW8NxtECbgWnkSil4Y52cub43dk0pq9HiDnp3l569jafWjQ6bl+j3Y/K3hXqMDr12I47szZwo
CdcUgpW117gsFz1pfBDDabxao3A5xZJKYXXE9Fok2l2AcRd9cQ4pyH7a2OusOofUHDtgOHTHLZpY
wbgYkRaGgOsd8iURzwoJ/vc2C4+1IxU9o+qpxQbkE5xXiM3fKt/SIIaxR9eYKVea9MbeadqR1zGE
/nTz4dwP9NNyT+KINHDbwKvkqp5jxheAq7w+mXsRaIfcJaqTM+H36q9MRRkNINmc+OHReWFvZDfG
Tf7X4IqoUiyD0e1tEY1IPN5InhdPDvKRZrJb+5ALq87QSBNya3DdPXYEq1ykiU6+GPsiYrT6Bd9I
qKNpK4p6jXTCqqx2XG3dXMxFtPhKlmsolgE2d8H0JZqL49CmpQGLO+cUgKIZTaFpE7cQ2sFOHDby
83Z9JrwE2nuCVaCbebWmNzN7ZE/10n57/Jvnpg0KCpJ2EPI904++vA/INftGBJzadqs7vDVNt34z
6UqnkokotWpkmWfwUi3qPyARrT/goyrpElT5lC3QHAxCGwkM2NbG3C1Fi/wr2bWXAhQardn2Ccno
qyk0GoQFcT5NaO73g0dPXkqO8CKIQmOkHPp9Gr3OC6knRDPd9rBLF+Zo0XU3Us0V2kbaw0wgiwyK
yW7gjXP3ZQZZr1b6J1kKCar5HlBACo7Tr6/rO+DKQYl4Pe9C/eb2fxhDVrrVOmmyN3cja5XdxeSU
wsUiFaqk0pKMYFMGrr3c0TbStZqpyOPlhu1h/JmnlH/VyNooDkKC18MkrXEdGg33VfWcYV0RlvkX
UP4Jr4m4yAeSTxHHueZRZfF2v18aQwMPVO8yTgEWgAkszEnqYF41spIqkP6v8QTD/N1afD3yDzjZ
8UUtzU5QpycgsyH02vwTnVd7EoXBp4HinVFXsXaehyAlIpmtTi1Hu9ip5jpptdmhQR6SMy6XFU2L
eACEBYcA/qE932PCdng01RrDc+4ONlTEaoaV0RatoM/GXt2lwz+4FMpFL6xcgu4b+1bzrr5OcsXJ
M266SuUZ8M9HMM+suFlnpf2Z59zGtED3K0vW3jw9owsiqWNII98Qr511lC8O3zoTeOpx1sOR4jHT
cnqADXhNPAX5Hws2V6AOwAnGYtx6k9blVWVEOGGh26bFBB+BUluM4lNeCXhvtoXbU08OmxIurToO
uqC/USLVJhD+3oTgnIXCCyMc9vOauOmTc5GMLQ7ZAlEhd6A76emd31B4oOsCU67NQ5aCeYphKXpp
iHVoIXYv9GUUf06pP87aFtYhJScwhiE2uErFgKS1aU+DXT9V30dEv5d+sT7JM7Vk5cd7oMhbnMSp
PpvgAaD8nyCWGChJL7wTYOyeXJyvZwWuTkDSt5wq8lTPqIPSjkeKxU8FYtx6miJr5omIVQzLlIKv
jYkLVrCLA64T5Ro0GOhJWBClpWwlnCFH4ekXgmrwiKHLn1pQCMs+kKZUeliQUIPMIf+zF6cruibN
27BHZpLQW7Y9vzt23PLQnfkJgaPIaGJB1vbznYKFPoblB+EU540ZgoYaAbos2LtgohKZdqou9Gkf
RsPdLdkK+GtQi3VugTu08wLHL8OyRbAIba9O/TmOH8HyfRF8qJbHhgrYP7XWcTbERwdsYlQeL6+u
hhV6rpGMK5JFpSWwPDtzr76r4oGCU0jSBSDd3LO4hSQTrFjiMMGilIf/Md8kforUPAidnr1wsj+h
4+AOPuyHsGFa0/9M9XG28ZyTeemB2R0NeCpiAijAjhETycUX6yBa7bLqJ6Tm4zB/zHKCk2bWbASs
WG0G0r7m+NBjKXw5qT0MT+fyu9YjXPYLN8plvTFOnUEFq1du0VChWPYKlMcu8D27XqYhrfW+8ZWk
jLhXR+Y0xWQiYngKcsSiHZOwikmi2iH7maDWK0zQIIcW5fpNeijUdhWi9Bx37g7L6W0NVO+KyYXl
yNIcij42deGbSazdJRaaW15nLDJGyPXU0rmY78tRnhfpdmKZHBqffuoOE4dRe8qMXt7YKfjTM/E+
WpxJ6wWP9ChBJNjslF3yOSxr+ySvMKaoWzPgrG2OckyPmO/rbVFqxjWXukp/s+fE24ErkMSDBOiG
5eptoiQUDk2y5rgIh85pU0Y1i5YaL8xtqZWnAHaQx39igALCABe1VPz+7Rorkf3lUZdOw+nebumo
fXejnQpAJ6S8rrpUKgF13Nxn5FeMV0fIeHpcxSWZwg6ooJM24pgmr2MFoQTfMtxwYzWhQyfcv5nq
2uFy/IGKCz8jnhkqKtIg3DUCLHo16jykgrTcEpO0ztm/Or8GxibzZx7W83INmBufFH80Okhv4qNj
P8RWq8siKBbT6hGFwZFmDQhWOLQE4mxtzhPtCa7nLFKngqo4GvdwvhOr8MWKbz/KfTMjMcYIttSh
i9PEhdiqaqkUiB9P/siirFQGozivyCJ/Ia61hiihV2aJmvB+9xwNUeb69I61mgV4hKS61Fc15p1O
IogJWqAP9YByeuwxn3rsQiGpZFFgQcLg07VBYzSRrRucaacmXzA1/mp7uqXC4BZ8WhLqGrZxyydh
23r1dIFSFXwuy80SZNphczy96hLOYSDtWTrjp7hEo8QRGw76DMNLlSqwBzLMDGr7yn3YexX1SZgR
8NNA2gwgMJ0bnbqhX/OEbouI6ZbByaTqUKj4RoNCZLhkau5cUTbKW9vGO7NLphZcJ8LWHiMTRAnj
c4wXHcFKOLXX8RVvSIgDiiDDpnh7UkmQKdLznIMrYgUum/v3UWIn6jbuOfRATeJKti9RINCtnFZE
ohBCcsPfnaq7y1qljWoXqUYOxoHlqjHPHD++Shy/tFg4yP886uurcJs2wK4WEyOV3PDiizFsufs5
kBnAU5NtKPzug7FSyHsIO0YKLShzTcU7Infffac3fHcqhFN6oObLFuTL5lrzYzoe+Xax2XFqcsGi
Tyh3X+R3ofUesLjxjfb7CAU6SpS8yV+YKcwmoZhh7X9XGFJqZasWkrIQ3tG1GqnOf7izRCYsYBSF
E94Jh/YirVZwInzFrb9FgBtfgpVDNbDyPLJxW28n9xlnio4Adu0KCOhNQpbYT4V48ms+LkB24I1g
UHyqcCOl1T9zDxMH8WcRj7qF3wSUaaHuFg2iU7bH35xXFSiQ9nnMeMUW/qcm0SQqNTqDF5u75YpN
G43I9bekTIiiPsT6cW9lDiDo4E3um+stN95m4VT43cLRPysu9ZG6pHr8bDUOu/q+9ZDxcAxYwyOv
Ukx7znS88ib208mglXuJ7yAOJFLsFJzYXXszea2DWbBke6x5GZZoJ5XFgLmv4Z4xL9hgDkerCPVw
TRaiRKdO+0BvQa0889REQpfCjKEPKWaGXHYH7X9AGttF4xPy/C2QfGVW9Q4ENISURo7i95DemfU3
oyAb4ufDwQcYUQcH2N0bmg5bsGG3IWgLIXYAP1O8Lx0hdOjJj7WY3RDnboI1fcZllJFmXOdUvPWQ
KsNKjIpefbdeKu9aNP2rjlsV9hBQZtLNZo1JYBfJkqVqjA7VL73FdqpYklmifZTKzGC4nOjJQbyb
NN1pSd5Rv0Mb0g8sxUMTIRU4JmW4KR6KXLX8+ZgxT7XmbmECFalerNfsRjliXv3OWci0Dm/Cw2G2
FxWK+npeS5bNSih+KvAu00WjcDXuqFCDF9wGe/u8t94W1L+HkXScfLYei+14YhqlY043F5VMZZO4
4SfqzrGSjzGJquAjZ4b9yv8qz4hHxcYKBBlYXTKK3xFlsYmk6HaoQS98xuFCBAgmTSx8esrHRvD8
+FZYnCSbKKu97rimrUNcTakdB5OeQzmgq3pgR6mTViPxfSKZd8LQnyOdQiSSDJZPPpCTr9hlXyBG
oDF6YWvF8YXXYUNfv1UeI68z5vYiUjoCo5s435lUiHSHNON2oAoqE/YGg+ITCPTiNr/vZ5X7uHH9
rmL9UAw7z+JV+J0gueSWk2j6+gzHOat/fDyNg6x+T9NcQqMF+7x7VbzS9diw9EcUUN3sfwH1Gn3U
xzrzJI4ul4FSk6xyr8FZaMamuUC7EVj4/ZEZaBvOxVju71eTvhdlwZ/Urtm0fCODkJaBqCwsiv3a
rYDbVnDPGB/wyzoCs4KifY65LSeRGfcmvQHzbhrw+xstTHXYeg8PajkEHThk7M9gERYZurHLp0ER
RYZgM7JfWoo6q5koIf9hQ7imVjhelDJVplKn9CVAfeUh+z84KN1FSNNLTk+ic1JrNsFUOrV+M5Ry
Q0cane+u5qZx+x5saapdMutAcqxRTKW+vzplQA997NLX+vmUn/KMZo2Bofz7gHk8r/LZ3xf4xuln
BV3nrYJMuPSMtwytElQSC1czPdxHd0qRLnM92OtGFr7efZJLwQk3He0JMCCq5IsTFXRK+qcGdpeF
mhL+3LOm7KAikCgSZuksJsO8SvsxA57QuS3TAQNjE1WGCDTsjEfe4RdcLg92Rm41sxzXlimuA1Pg
GdyjTdMz0qGkhNvnFxqac4rHgd8L0Wncvpu5/MGX5eVh84/4uhDknvchOEW/BKT0wTZwMRhSZBYs
Y7UE1EE0S9joeEMPtNle5axiq+6t5WGNIQaLRIAw+i53m2XK+9nfLodq4u29s1M8Jt6yEfSBulfr
TipxQjqao/QrPL7t/z305C9CxsdfgCL6RWf2F/YWvNDct6yMtOAOVrDqdhzrsUppjzZWSwXGkUhc
uFb0UAnGsc1btDKoluY7BVOoj62YbtH37cDs8vYk0v54OZ2MaFzoEC8cot5MsOZSKUhyyVHs0632
UtqL3XG2XZMOHm57XkTbU6NhV6B2FJnXdxBl2x3krv5OTRbVQxKnJsVFEi5/6FsBoNXwuimjxZhk
QQCAxVFTgzFDLK9pVsoyBRPY+tJJETvDJVolaYrVbPs7DyWBSi5CuwXwgue+gxi9Y2HPWGCt+04m
jJxzhjyb/hEGFBhHiME2qiTv8m7gF6fD2gxShQIztnxApVFyynJ0Aw5MsTeAdFYoY6NO5F4cPGSR
KCsrCYDOGT37BN4w7PY5Gw5wkhM1lpPq6JnlDGfl0ju2F82k1yP3zx/suRd/7w2MpuIrCjotFyrb
pg32lIECpvV3/Po9sPoeVHPwoV1MdnDnAksup/ngoTzqn5NLXgrqnDz5u0XbgCvTyc9U8qEG9jvL
Z5IA28iWLLBd39EksdnWNqhG3OFUCjQUXARjt1+1y9WkUk5HW4OcThJXP95dLBq/SVPVoLCaJTCU
QREDI27Mihnwee8/vUdnrrGxWZxc2DkvTp7er4pOfy1ACgQ/E8ztnkcz86fIpPsDQVVkMcOQexuu
WQnS7JwgV2wKutukLu/gsILr1bvNEl0HkI3j8k0mLKYsQ2D2z6nRR9IZOODQXrLeueZ2ajxMFLA/
MlsbfEomHM3d+R/oEypdidkr8Y5e69k6UJYTy4SdEbiYxoWxkg/J9ekVNGZrj4q/O7y62GSyuCqQ
ZQJBidas0JW91xaFxYZSrc0w8UdjoCx7/oQDTnHiX4wgw/TpFg0uYlhcFSYb41j3qitdoxjBTFaJ
2KSrA1yswHbd0Jw3K7PuRDCJB2z6FBBe0a93wZ80FT3o06NDH23qbyL0asXii/O9nMSVIAizwNh5
ttlA21gw1kV3y2TzG44Cj7q2D27U5NHiaTMxqnGyqhGj8ReQTV8vo15+CptqjKB1ok7twcusWDRj
esTd7unfS05JHxGGIo9vISGSaBHrrJGXVkpRTwvKlg0i7f2fgAv4G231/6hEWeCjbebWq1N8kQ+w
MdY+5JzEWjWrjT7WNYN06LkqgksqqiHwJwAdd25lA/Er262atWE69I8xbX5vbJou1H4Qsl3JRm3U
Lz1Lgg5V1Qpw8N3/0IqgWqOhMJ1mT/z9QhehD933UrVeSmzRDnqv2Q9bRHZyykOkKlXVLsVgMWZG
VpOKHKJ39e6DuVk4ouhblMFSufTnWJTGAbo0S+LGO4dDDk6uFtA2kipPa02ykDxBGEkXjlNYP5G/
b877gapfvXvVkPVrJ0hN2n5XNs2grXSEYejfdcJub4ZkJpNTfmz/PRtf8bhx0A4Lk9oRd2GTUwq6
Y3VM6hbWbzoVomKwYoxAD1Y4NI1LA+uS9pUXfX4XPuFIf4wgsG1zOfI7D7H4rHy1a9OnvaSJfSA6
UkxkbD26LWfBfU7AkMS7ENZG948QGl5ykEzfL/bSOxEB8d6CGd7SA89Fw6euCcuZK0Hd12zt/JtW
wgKs1RQjpfh4bccfUbuEKLbJLgmSzavDhRwqnKLUml50Z/SNkyhD0TWdmMQcyAcXybx6sbaA9HEE
E80Fl/7P3pR11YuB/a+Ilrr+mszqtEh+2GnuOCZgop4am5NERtgBUNx9S6ouf7rNLKr2nsP7yvHM
3xBJKdYuiR+KqhgCtQ+k5rNrbL1832Faso+4GfAKtHGuuf4iM275wGK7ZCA6N5Bc3huxDWnl59Mb
eFRKPou9lfcGe+cVrN+Zz/7noVX1+758Tzz4/NQRpz3it2p56WpO02oo+zWzKn32YAXJ3r/6SpJu
WHCojXttmmIz5PwPnYJBYyyCRHhI9Ch4VXAxmI9zukFzNF+HfNCpqIEp9kner/+Y0UDjY+BMTgoE
hjfQmgkFP/sdNX4kFX3amGUNth6hVbzRXFx916DS4pagadjYU3cPRcuaCgg0opJNaOmUQSZVBXPN
WLCA4RpFZZXjeBrL8tpJZqDZYTykglYbl1as3d6uJHDS4HTojapj66LvWNQp0VmSHCKA9kEOJDV5
Y7TkLbR57eMWbNvSzCJOb9xR/O2p08vZRdSkG63g6F2tF/EPQn6bHuc7sUwSKG4D7g58VINDRAHV
L23FbSIDQq1tbgzc4OQ79XQv3VadxvddIvMccjnrkNXrc7ougHq3AHbpvq6S2P9t5ZQSzRgtzkMQ
wBPu5B3vl2qkL4rYpdGJO3VpD7jgxghTZ2Hf+m/4za/MTUnBlseUNhj6wEfG4O3zqza56XUXSRZV
BZEqWZbDiKSjoUkM/HwbTMYeY1OH1P+Q53p5Soc4Wt2L+/BagdYCAApjtFdkbh4/eF6OdwpgHP0R
j0oTmMBVAmhPh40btH6b34eGU0FNE/LcCsEFo1jwBHT7ORrBvLhC1jJ3fs62fSh+tXmfinEJ8PTH
B0wqT8FZ0xZqNyWfX2YqU4cx7Rhi4xb/NFXyTNozZWuUsH80+P3jRI7gMRnsMXyvIdnmmMo/UsbW
ep2Z6TK3XRFATMWR1G0WbtW9WPr5qdURkrTGEwo4S9FuHv9ma8XBk2HuRN0+P082RAm4LL2CiMRW
Xqapx3uRTFc1O/9Km9Xn1p5tIg3fGvKZthB3nlvTrEq2wkBNZFis8CvILOWWHV/oQ/WppyLFA1tI
/mGJWOjYwKErUuUIlYDMZYHcHsmsw255YQlt4YLAoDXN5rMdfM5wmwXAmCTm8eygH0haPyY/FaNX
irR1KEdekWd+jkjW0EUe/4PdThtRrVdrQorvVbCi7AxVk1qDbz4goZEzyihAzv1jNEz4Mp3N7Hvs
wlg5VEgLWiZToaJlxqZBzkoLJ4NVqjN4KLIv7+pU4gZUGpHZ6XBNzZP1Ykd77lQ98iiZIlxUMahH
KQTBjosMl3w+4PBt2a74TXGlVsWpi68ZxWsoeyO1rBW32WaLVWT+pyvAwZ8SXv2mIqXn0FjSYGNJ
c8PbLz94mazcmNTuZvqnOVGzL7/lkgH07D/WjrJCHV+uQ7DYE0Qo2l3aNHmFt0YXkUY0PtZX8Q2v
x+rrlDlLAD2jJS5BweNwseOtAxYZpBZ0hHoulDezxjXOXIopvvSkv7Y5uHnJXXGqrB2UL1wJboR+
YUm1dVFwmEefXyNtyyOPPgNDNu18D+H9NVYE9hjt3VfkQAW9jKIE0Jx0i+UpwDD2OfPA3zz0T/oe
5oBU0Keh+GtyelmcA6n3xwfxTURAexI5pO4z3F2tBYHwSMFE3DwuDlIf9TSI/hcMNu9vNEhpRHfe
R6brclWu3G3krARL1vzQDsIr1x4L1dpg4VSa+invwTe+PkUxRakpFuvmOQTeMTiKlfYQWuUbUABg
hqNFlegDTFv3ayqlq3hc4I7JjC7I/MTpz7ueOAWf7x+t/UG/xBTojHzoMr58Ijalwt3CqnIcnG+x
z/OUjH2cF9WUFF5wF8x92o7S+hzlYbstwmpnN6CJjWhTbEM90vmLZltxr38bgP1XwE5vrfqGDMcE
me+4btO35d9M8r/jGT0Cvkkgx+sWltjCoJWIbLjLNzktpjO9g4LalikquSH9dGX9aDYKQtvZo0i7
qx0mplj8jdQREB+uBuCgo+LgtGLYaCLlr8V2t3yBkDHVukBHnnygk+jzlSRa/hNACNpcGAJvbAxR
FlgNmdO9ZYsKLmCiCLK2Y3hjCqOtLmkJkcp0sMzrvsCM2JugrpMo2F8dR1QZVeJEtx2aXIfz0n83
hg2l7dGcLRa1a8SxVlvy10zgDrKCCZ7AGV2sFav5jhLxXYqHmjmWGrbiTEloCKsYArlKU4ZgPKg1
RNuKu7afZRW9Aq9B072uBJZQ1/IUphdF5MQgDopFr6Ma4vPSlKkxTpvbMhyOKpv+5g5t+rpplZoI
eopO0wtC/OiGFC/2br/kwzk8nGuEu86u/6I1CU43DaQwZDazAM7zU/ReTq9UaYMd5IvjhYhlqseh
mu/JOFjwdHX2VChBydxZG2oboKF//k5+Pk10f4R1aP1nd0cJFFNBJ9RmhmYlwHklhcgT1WlgtAEm
sF2PQJycoThA36aUS7KJetHlh6dKgjrJKR26OdwGymRPUpQX+ZmxpqKYKn+4nXgtfG14gGCUhLwn
QNfC+FzgroPkn8LGbbVYQ7JjYrFvYkLUBilomfpe+hEO56Iyz8Rg23SQ8jKovxuUEbV3MHK9XIP1
kE4kkPIKmHnF2D9hKRDfTAt2zyP7YMp9lrTLFtyh1Nnnalre6y8GS5YBC8Lub7llVUR9c2baqP/K
jeCAT3KXROsX2naPb8OO8rQ4oFy+xaCI4ck7cJ6KuMh2iPys+1cecU3dM+fnIMSi+VcBVfpNrN22
9ArDMm3TeLUJxFaEloU8WCylvOS8j/yj7xcCHg3Y3nbJhb+ZRogUUXLfb6Vd5qY7fEQmWUFb0MPV
GWF+OWi9rNDtddEbMZP7UGSWH8XpJNpL+uluL8c7miiC5nku5l1YpiSTnJDtRcSRXteVzkThH/Nv
J1YEkvHIAQ36o/WdBzJNgb/MY8PAwT8m9FYkuBxB4ETJR1fo2US067CHB2h9AgaYaLP7Esz8Bbcg
3wniaf/sjNCrBHfJ78xXj4v7+2RaYGSIKzfdYdvCCei1zm/0/Y8jBA5jhhTxLf5bOXf6VR265cXK
0C7FEaxod8M9tBXJEwnIbfxnFgfvPRV/c5U5vXxqxRoLT3ZQCimXzY70DNYQyZMhF4ylTKOA/F1p
jTEhEbKGG9EuPdBFyVm/0ORiOqsYYC9mOEoXFZeoRE0zlpm5ZEBfjVaJX1ZrjKXrx4os3MYT4TTz
43t/+IplpWJYvpALaMWLzUBxv5xH5JN05dwSPFWh7y0KQnMUxuoGkeySVHUZIwntc/W4CHG5Tzrw
udiDhesXMWJMWYwdgV/U1j0KP5ZrsqQZkYCifpR9rAjN9unDTpzQbn7OHxYGYBnWXBnEanUFCc0h
/WLhNf+Mu7K54dHwUEYOPYN5R3cJRKh6EISTEVIKzvZ8SX2l60MQPm2e3s8U2d93OT0a+VtmgLb6
sZbxpYMoLfdV77T1yaEhZcvHPuImchYMWl2kCVlUMWabsL1ULQr50VbEssR6+QlZPdEfeInpqCfW
YYDEiJt4zZ9/1UH6bREVXb3x6P9tUyhhZIDdIrDuEmgwj5yQ6xxWmHZZOBLqJvsBvLP/6kzngDXb
AtN23ROwqL9Rfc5dBqZmV5CCRwgkNatOMdy8titYDTKj1eVGlvvPw8lvEeNUVmQyOb0pVSFLTX4F
qi0Y+WcbLoiYM23UtgpN0ktPDB/2aIErNjW18ExlY2hx+EFruty7uZzCteJahGUb2w2UFbgv9LkN
7K+AYjQooiliKKTqbN22GtzNpu5vnhx75cZsKB5fKpq/tB1mxgZjjpDiwvxx64ktwj9HQFC4me9U
ImPbi6c6HrgZW0cWHkNzDxY6u2tflYQWxhufe4jtlcIQxIrQMbQdYlv+dXPB8byeOcuvFJ+QiBEz
24eRDYDAL/6xxx4hoeFnJgRZfbQNkwN7Diw8BtGOmiLSZ5DNyvb2bDBdMj+oImewThFg9odjDI9Y
GJ0G2lzuYylZo1hEXVfmYP9U9PAquQoNCSM+h/WuSihUtMcvRNTT4hlUacLar7/Kkkjz2pbwFERE
QAxgVH19Beh7FCffO+OA3zi6j96TAuLdwGgehEGXT6F3i0SYZllOz3JIZob/ZjIOnhL9Th2xen2R
pljwGOS+Xh/SeBMxMnHVuFvMbnNbxrE8N6DvM9sFlaBlKJIzGSQmbbNop8ffHsMrP3NfkYyi4A1L
yyY2AsqG488TmlmZ8sC33uIqZIxLtBrFLUkr4qXyejIRRlGV70ledacloRiFYxtQ/bfFdHL3Ffwk
j6YaBh1tQL3h0JzfV4gh3ILuCaYKm13TxffeZfYENF77BG97V/4f9cnxKIZQuFmV4rXZ+cEwRlKt
L8VdehKqCO171WGucZ3WrBJVxm4gBYTBcIgikg2TSMwEWlS4A2fHIr6XWE0iAJu3Qo4nJi5o2BTv
OkuQs8fMoiaXpLfuTPHl43C7TdMR6b+kMrxTNaqajWQq2xw+oGob9J3LcwU0DgQQ+UU/sfZa4GJ0
ZlWIOVqL60OyHxGabeQg46erwjGQSD9EcAYrkBf3JpDvQSqYSNg4euOikAjaSRzzVL+l/svpkflI
Et2Z69LuyDIE+Lu8pSLMS6NgIffeo0TYQ0uzzca8cKiERGtrd0hIEawwGpfIjlURkTfZP+C+xv9p
K8M1YWh7YXLa5mFMR8NvgUGxb6RZj4T1BQ5EEdTOA5N1J0xsZXmgETBAIebSAal9GteEZWOGqWlo
kkQ69N4bPVlDqpXSFYp2pmv0LZIyeaR50/NrhVcdimfAUbZ1/BT1vfeWozRKFYB7Qx3Nq4K+qCy8
+anXJ/KuVRn0TUbBJB9HOPSrzBrsPGm1grSOrP3kJ4erR2nbplP1OQmyfi4MoJRpAuFEdF67nEGP
SKonSLWr9Q9Yq6GxAQP4JqrPDOZ4bhBDBnQ3P9cEZls9rlD6Uq0S36N34I/Zskcc+A8Un/TFhbhA
B1IqADToioZlN5jnvaD5UtFDEl0An4wzhH5dU+AWpzeIzs+hVYYy0xExiPU/ZHh076AHkNEaE8ZB
mTMlOWwCcp/XkmE64nLEWrYYfLel1L4YNzacdSPKG3p8kNylprNRzloJT0G8Xkuel4FXtyJWsA8g
yOS3VR9FylUbeKL0XeWI/r7Pa8r9Q+da2ryvvmGgZjsm0avTjBvdPOuorhogkO9oSOpOOssRdoRI
wKHUZ6ci3+SuTBRkW5vu5NO5DdszPSQG1qNdpytIwLbIbSyUg44Wtwz1ch0VRIoGPdri7h/oqlu6
fAIyQffJbaQNLaJgySphq4bUGsqUSjBxT/AXRyMBPa0ETTOHFZMkt9dj+EdlNvmz0RjR6Kc/6AoK
tyhFP5hEphhag1T6hu3o2sH/ys0wHDQE3aWLLViGTYNyMCmmlNqdGYFzV7bxEziEGatgTOTEqe9I
MiCifEjCv9NGu0qU059nrUdEKc0v5XtU2p39DT4Tl5650x8Vu3exhzu/pqryVtMcYHcn1LnRDAV7
k4vIVRvX9T90hlZ/zUI0PKFxSfPs71hkx/q5CJ7n15HUmB1G7A+4dnz/DUvGcGfBdcIArcw8yVoa
ye7hM4ASatw498TrygWJY8sTdn7TQqWEpXROxdIX0pXmj8OUv37/Omk0nYUEtNpN5i2TJRMAuGnP
BqvZrJAKE1H0pxv40M2mr+YfXczKqz6SLCXAl02sUYP+MrpetITu+y23yEOWZPJZGmqUBeykBXrb
6I8EfKKEzwuvlXMFOspmqA07/tvoWc4IV4HyPDgc7cMdHD0h14WcM/KJBwyQ9ArfSHVOlILwS8jP
8Hj1flz/vGuilxRiWs+m9q6DD+lrFXYuuXFAjcMdx2L41nelAOGqtJrVQAJ+YKdgR9B2xbtuxGA0
durYgy9bNMhiEmGBD2tadvf+Xowno+Ldi3d/mLzKk8TAuvqARV/o5K439VELMFWLaADFUFl4+5ub
S5FvS7Q01cfBI9uy62gmciWeo4AzXQqh0yYC2Egslh5PY8JvnTweLKPd7qD1gcRyJJj3Voyo174Y
xjKWyFZ/EjRm5cV18EZAMKid/mwq1nPMdVSXd4hfu2aci0DKPlrmNHp5ZN62UzJiWmqoaeusQeI7
8GtVJhuNCuclgoQMPom1+8b727Ak4WPgIsNqtTEah6NgPwpRIEPCTLicvSHqcubwkEhJECIEOswj
tW7QVTvBO8e43M3RIOZmIhLak0eEpoisFeNXWCZbryEJSoqEr9Rr5F8WE2ebfltYwv9F+roG0ipV
2KOI7FXZxzawuC88l6vYO9baHRy3HkO8RC/E08lgEEQlSdSdQxr4sTouxwLatzl8SqRZSeEJDD6G
IoNKb+GFux3W+2RcX+NG+mVfZqbbhNaVGXVXA2h2em7LNAWWsDj3aiT0HyRU5vCIFVqVVzWz4o5c
NegJyeLVKEqGEPYJehigFbTqqPfQfrFKOJNMEtnAptrNKBLbJEd4cIRXbH9DL+ju5jx8KsQV58tv
bXmbS8sMKq2AHBQEBEk1luFUVeSj+PgNcog5o63kSufa+KW3BszfJcbgfhOxvBoekYX86UfflTMm
VSkbLlFUmvebQ1aaxMNLVAXKB3knEAypK229RviKA5pJuDVw8awQhAETYawrNQgdZOmCW/hxOyss
V4f685GUQkiSi8BU7RKCbVIdy8BQ0UYo5YoVS3dpCcvHjHKIg8jFzsTuDG3wWqYi95XkxdwTlxC8
niDX0ZVvgA7TrWUL/E8vD0ie5rqCXWBiKT+kbpSN8jGPve54i80KbewZg6YXkmjAmf4yWmVm0I9N
VuI5fO5SEUx2+6+TDjkJ1RnrCJq68zPgvnoajm7UYRLICMckU0Y8PdqxkEc8E3Zc9DUwsMBhxvwE
lKY9ii+1NpXYlvTwwb7yfh6PeoCwIUBARx6DCpGC4xTFI1HVEJSSMk+f2hSQ2tqRGlfqmai+GkO1
YMskbr6+OrafzfNLDsLoPHg5hjFr6Lu8NPC7WYMMRzY4pJOOBNbV8n6O4SSXL9eubp6J4ik1Pypf
OmfOgPsDSZ+/7M4f4q/evxw9bX7DtMAtXfM+0jboIcWAJJjwAoVrvr9fwF38pVa+4bD4Bk3zQw+R
hyaGra+ZiWUmHkDNE3/Z6OQgD+mTrg2y5R2oAXy2+VX0aKZlX4ejdg3jAvu8GOAWlxe3SZdVDS/u
92g8M0aCR59/kGpyd1SetmVjYM//3hQNVblluA/XfQOfoJdEZf4dLgU4ZIzafiTwk5jqVEJ8kUh2
7jsS2myz1jdEzB2u6tKVK1KgYZWtk6cCE9Eky3FhqAfVN9Mwrf38CVU7MA++dIfBqax3RuzOJiPY
AXrCFaCIeDfycTtZeYyiezKKHtGG7nVWYN6U5w13I0mMP9rZ2wfiUjNc6+RpHZg2P0eeGfxjwdfs
nmNK/Cdr1s0gnlsyGp3abDNS6X3g8dryNjz02HPlRl6sSepHf0WVvrLhaqYZcWVowHTFYIflFHAA
G6NUdu+b2u8NjyYk7Qdtpulrnx0Y903vWd/MdR1FNYOMxtwgj1AnePprYWrVEQCbsGOAbmuKmgeV
lMcRyZbRPvGwGdhMzCdskSN5jCKVswuFPaj5vkgmXPm19YeZvqNwQM9KW/LRk/UpqMWCJs69M7R0
EbxqQlx6bcOxhAHTukX9ufoXuojr0tVeslqe8MF/f9qt2V58Av7gZGCw5jhFdVTuFR5OYtIvXWgb
yvh85fdsDaN4b6XzbPMNbe57A1fsnQ16YqTSj8uutWYoSvO4j9/+fHKS+A/1/oRHx0lA9WK74vxU
gTMySw7YAEP9yfw4VcnPA16BIK26XiWJZVA7VaiSub515YlRfy9YulWFgAgQTmxd8foB3UWDQ99g
wbn+EyeHFmQVKYoqpeaxG5bS5RzLUwZG9G7YzW65p0/dZ4uQ4JnUaQqdBt+RqB9WeyHS4Q0GEtT3
OcFB/jQ01KCslxBv7QnmoTDlpECYBUeQjJ8JFACdDtn8+aFhvX7DHD+iJBUBtFjWDtJNirc/46lm
ad6SrMhkavSO3EdCaH/qDIcI2wjQ4LsM71weFrQMQ4UT5219bCi/gkW/UW1p7XvjVsHlhsWnPBqz
KXxIgdV1ZAAWxi7VlqY2NQjVb5/Hg1L20HdSy/ZOcN2aqEUFwhFGJlpv4WRhdI3zxySCcB7abtMb
eJS5ilm9XZ4mk/Vq3cTNI6GfuteUTnUH3/O2e+oWcsO5PCZw9fHAALlV/kLFEsgsIn9x7Ucysxa5
XC3Go9t88vweP2V5iUlDSsssXUuqQRMHEDw7RxGWlpG+jCZZhBwrzmEfZVeg8Os+CLoaVWEuoeNr
X3XxpJjEkUR+rfN5Dg9LE62bDKbvkI5Ol3RxTPAfWThMnuoYhUxZAsimsCdkEPzDaTgG1ylNSH+p
dyzG/k4m/s01PzhU5zrPYD59TWufd1gYnynnFE2eME5lrNwt7JryvlwuJ+3ZSSOaXU51U2N2ldBu
ZlWP1yVv8B8XIjEDMrFQKfc34ek94grGzgqqvRWFVQIMehJNKp6NKyuOuSo6R5GL6J955vnbh7jl
TbonDLm366RHKvMT46mvZsZazVJdyzBZTespGVLIappIcXe88yyQWpr3ob5EUl2QmIzo1LrYcwqd
GzM6ZY3QCAz+ZVX14lhKPqyJgNtLxO/hNN/xx/Jp1UphlhK7yxI5IzsWhTveih6GfYak8KEDkBwC
AAek0OeQDp5mItMirZ9pte5LUrPjQwSCQmOT4xv738xr9PwAoBG/qYYZqR5UKOIcIuz0SF7vlh/M
TczSu+s9ywFrPZVv4T/UzIM9inDx4y2e5dFPqpSkVGgbhGZSxCjII6M0w+p2zP/R2ljvYqR1cE5t
NxRphVRfIVmGWel9piJ4fRfqDj9kBZ6WUiubiTS2ox4g3lSKh6sq4Rjw4P3kAKatZ3KauDyyhmo1
BErgcjHW5DiPf9qsQUyzd+wLdpbIZeScacGa7jshwwjwTbIwbzMRGWUk7zjxOI/ss9BbyoEdkZ9p
wViC7b534plHyl+bP/ApyfR4PatrQSFJbZ4t2GkEKAR6YRqEzVcx8YMcWoo9sxJBjHfOOzlGljwZ
6dCKd/lXPAc/TdAQLW7DyIiZtqEcaRfzFfmflrV0Kxq7dkbyqm5hY7VrDLnP5KbcVIq+4/Hpf21l
1S3XeqxnqvYCsdqiFo4qQwZBtTAKnjgT+lEb4+PMwHYXHnqEb8Nuw6R8HTJrR485+z7RTEHP+rbe
ia5I1rMNa/7tIbUM2OUwpKMit+ndq3KmL11bA5oFkCKXJe3HheAZEOan371CmyAG+AsbqbY9iAnM
J2r0iWDMnAMUuAXoXODSY9h0kkrrYIMEz+hLsthy4nznR8/Sx/yfjmwfYIqxe7BPDtA3SU/juVW6
ShuskqrgWy43ojZafgMSlk3r0gAWVcWLolfpuqqoYWSC41F2WT1RJ7NWsbr1fK/OMO+yZiC2MBC9
WmfPj9mUt7HH/xqcIH2QOtDpQPOx/LYQ6SHnJkCfgMH1L6z2GkO0BTpy7kl1XB74K2JjWvH8aQrV
oTnmAQy8v+JiEArYfooaIy2ejE5U+XBQI4gsEowkJ6mT18DaVR+YSbqIYmiYfmeSa+qFQA3VMEpO
xlHoGmAYZ+rCI2Sp0n26NLzNBLjCZznJ+ls1jPlw+RDS0gD24+GDHWjemp0WmvWSOXKPgB2Q+5ew
Q/nPit08DNEu4kEQC9ihUlFlU9B97v4sss0ZL4P+/DtUJ92YARevorPrMzf2VfgJ15ft1WgIW2CN
BPiugJsfjtLztC7luB2Yq044B55y8VJPBPD9YpMAY4DcxYKdYOwvC2hmvYFtxDA2DtWGrYBFPQT4
U9RgUU+53HaCtvVAbycdHkE8EbLfEfU62duIOa81360xY+3s9EZQo5Hg+1CdzosoKP1pSPACEaRk
n7tDm7LbCSLE6HpKGEaDhdEpdEw978rAD5LGaoojrTEa2ETew+B3VjGcGHf3jWM9XrFPtuffV3Mb
jBi1eWLtlAMP4nVxG0JFgbZN4AGKtTo49ufw8rfbfFhb2HiVN7fDVBAOLH4VG/ICxIN1lZol4yta
1Td1KpwO1BsQ1qXi4ls7VXnXUb+syeh1Ham1itT3bUjPEKrVTnxReFATPlpdlowe1Eirikp7C0IO
Lb/UUCubi50ilE9WafupkZ8DJ+IY24FcbVAQpJBwXcg1mxSVsV7C1QW3+3I2bUSdgmDEPq5hWA+h
S175XTS6nJQApytK6VGmgqvnVNYpvfm6vE9n7vXE3cGT7PGa4JQusSfaLxx+rJfAC3cDjOiTZpS+
T587pd1vSJOtR5nUDJZZ0dRLcOHdAGg31yH1H6tHcBuKC7nLntQ6dljdbvbmqWX5D2JGGoFK1Cdj
48r2RmSw4bWfQT+53PW7b0TMejFSzWpp4YL32Z1wdTvyuAts9hxUR6qY97Mhj3MwePUDUFE5cX3+
L7C4kFFxykFZfZW5VyKG39v3iXPx5ayj72xUZwwylomwYnq0luvFNeUP4lBFz1G5vtnU+8CSmPFS
ChA1MIEo+LEvQh4YVuEkhdFBIaRFiVaKLr+jVOtrOufJyTnPpXUrhHnRyJ3L53EIKtdK0hPEU3c4
HXBm+LL/198mlAUvhw5SmSppWwinsZ3QCLDzBETSp1JuMBgcK90Gysas25vSYgp7NYI4q94ZoWXM
yYknE7aQztQE3fOB/d2y4vukLsBOcEZw2Y9EJQQhYZ6zIpt11QqDPgm35k2aqtj0xAmBEkfe5C6D
PkLSvHdq957pD3g6//1xRdcQVAlBYcqXHW7AvllJJ3qWdoMcT4CKm3pnfboO4IBzDAiCAhj0hMkr
WD046DcPnzYOFCHXAfe3Fsy0Nywm2S/lUkQXtPDzkQyFHgvwuk6lsomgZPNlOsVgTP0UVTXUgNFL
DoesqgRZdONsqmYOSPmpvPnfGwLF87yv7ibsUoFN261w/uLpjBfPhrZwQSiiDPYRHxMVMcQBDrOD
957/GvcLCI8Ub++rnd2yKkR7jy5wx3kQ786thishty9ZvDEQZTKbUwGHjAcgH+kyEvfn0iPPGEjJ
ynYtYHBXQTuGgcnM/q37XzQ/cmmNNDbWFaN0UYxxka4UGy0+Z3UIK8rScBtc7zOBUyx5fRP3Abbu
rBht+qtv6V/qpooheimwl25sXZpCMGKJ3SPxDL+64vR/gQ3UsDgQF3o2Wdcc3fe7l0LEOuOvcBSZ
G5PPnUMAlTbfukCRWhf2xlzdA+YwoKDi1guJmxAbxV79RxoEwKW/vM5iN/FGSnMih/V6game1tnF
qAHy5RiJ0MbsIQA6d1LeypfTh2Q6mSXYMjRCl6VWfM4n6LZP0hlvU04IE8GdY7WD7q74UWNrTICj
IPEhFoHb++9NlsCxU2Lw6f50oQQnJPz+6KMIBf/bKO0k0IgpQYbnWpQyBWABbCUCPWN238qeYDJv
KV16hq6gAp5AfAQ9ovuuwePYn9wllC1SOlBtESzoBAuHiVYUMJ0Y7Ql0QmObEEgVwqZtA1W0kV6p
i+KO634DtPh3ZxpsbZlH54ax8llurUDxNFSi6r4Hlqk1Ig6WRzLUnoPZPvmbEu5rPNG6/Mo8Jtdm
9nKui1goGDcKAoe/108e8FSQo8KpIdLlfLI0Za3NGMdh5YKtYrqXSs/QdOtT5tmHqsck1tf+t5ba
W4F0czFxxwMfwHcT40T6RdPw5oc1H/fxJz+FXM5LYb/Aja5FhwJbtGHgf5CtORGrFp+VD+pjgoHp
+oc+dpDbBlhBK5g/AN5cjGGvM7/msQi3Xqrc6vMvq+HDithQkh5281Ri/SkJ3SuIGk3PADp/NL/H
5QdFgeRUrMXuDZVLYcdqCKiAwljEPISyd/RldpavN70M3Y1hZJFW43QmXa1tg5d/ZdpGPRMbMDaI
o/ZlUZa3b5Vo5Sgn7aKOctQKUcRk+tZz5Qldq+G8csY8T/TQRgw3DDyndaeIeuevEGC/m5hTb19v
cMsNP+DXSGdpDs8BquGFhhsKSeM+DHvzm+r9Us0Fj786s5I/XQBSxHN6j7SA73OEFlSZVesDHEhb
4zEh8V3Ak63WaOkVrvWmcBCliK0/hiMNIeCd/N8uju6l/uVOYLmG6uO08/+gHnG9fd+NpH268vC3
uk3jz59iHAWCc67n0xOg+xCeM+srEOp3+ZokaxO5uaJqec/X8Oy3O/bEKT4zmyyP0mqgDM/X0HVD
QwLqVn/pehOyeloYCPcS9ovWBNITyHgLo2v8HjTlanDqdfN2XOJYREpo4/uymj9mkU1aTpQZhiak
h9LX00g6iU80kknpgpO8hn6T9kffLVyqFzHwIaJp3pqmnRnsqnvLGzdhmqXwtpaC2JI3lhX+AAj0
UMybs4ci8zioJ28dTwP1239j2gDu7xBB0F5udFQPB5daM36VjylwbkEKxCpfUovG1r9yb6Cqi0iO
4I+SA54ZYiPUHIJmTkNs5sK6SsOj0cd+fBH2r3ZOsYgm5nBFrXFl+qTchYxy7JTMzCag13fYJDBK
sWHzIz649nNJ3D9OklP2cDVPcfKdChyXimrEt1PnqZZkGfPfLB66XUn85a7owI/r5eEZma9Zmyck
vj53YTPeFGqO4m9eeLijYM4SErHmMpspWHOzWbdhxg1659uA4yQMELav3FKVD/Awjft2mgnV1XDV
T+iVZ/TAvoC2odUmD3e6GjvoYnb3AVtlT9//dpESQwtmSrvJjS9V9Tj5Q+NKoCknEfMTwqj1xl8i
05U/oHHrXhqUhQ8dLKoyTqbLo2x8/50FrcAGGYOcVtqWPO7qcnxNnZN3iHl4RjL1ONVsV83DO1hZ
xNuCHwogcb6GEGSLvnnRLupAkkaLo0mrxGP3XexZbrHL0rJedRkbphHINGOX/twD6JwEi9qhGqTS
6npBxltrbjsBn+eDA2KYbAqFfHPqiViVj2P2m+VtzHtxCiIcY7XdWDWyannqqhWIwqjppcabgukV
N5IjwoQtoBgJbjNZ7X2Q7fcOS9omUPwNrWQhYpjzeq4ry3FYGGL3tf2GvVPzcXkuqANna48RH58L
OHgLRkS324YZpxjRXH54hagbOS42tTIvUJiQnQXma+YA31NMfsFzFGVwkhApGzeVvv8d/jRZ2dkN
+kNQ+04TWKhbu5pmaTlcfD26B4iQKP/yQYor3+QkUriNNfymZIFjwVeokQ7Tc/vKhl4YB518eIfx
yGzzNfPRe5S8tqxZJSNIsgCuSDBEDUpRjs8oCOEUDFIbUeM6lAe6aODZY95mfwNIqx3uv9WqBoGr
oVb1Sxzo03qEUuoMkPH5hb+iCczSYaaENOjdVySFQSKGZbocK59PXQK2drm2dPsLavGUOnSRNg0L
lIajA3nAhL2J+Qwb4NKckNnWHkaAUTNil1UVW5hIaNkoJSf7+R0ZV7FpxYKRyi8EL+dcJMfrZ/gb
ZsbAljA5xunYE4utBqN8QS4WbXct5fTc5MVQdPhTI+wQUOWRM49NNIVXmnm8/DY+GSGzlYdbpstS
UhTDfodbSOQBXK0fyQYLoNaHFMz0CrnxkHMoZq1fjVIwZXmrgqZxDqFY5rh9VBtRyas9a87Kl0TT
tCsti6XE5rNRHAYF/g03aZTMHJXW967wmtI2+PPt8iUoGcUQ847nLxWvYCIgaKpSuno5LGabjeIi
ncSow0XezDlOh8tn6RbiTmbwVZMKnceni/s4zQOQWA8YpmRv87pMxL8jL08cWgZG/+jDvgJ4zKe3
CRV1qa8Mgdn4urjE/TtoGZCwmFNP8cR97rwW7Wq98Wqmzxb2T6j8h6rMFqBvNj7rujZftmCaqmaq
36DyETsjBifhEdl5rtGN3y7/EjZ5lvnGATY98Wtepg8MOQBU/xjiInYBJ7ndYBDvj+/rZP3WpgGx
WUi3sWwJsuQ5llOrclkBthi5FCItnvrfRE9exdB15W6wrSUH2G+jQ2iX4vQYVcBGD9IjI/59uSCB
xptExJ/Rl7/sSlaFGBck6VPpneA/M0eEWbWKO0Id8Ysfn10fuUDfw5wDklEFPQaY9HpcQAXycIfs
VvQxyBRzHH7WdNXqE0hIQkm+h5/wOrv5JTEEIZfWyiqkiz9mpBiBGkeGjMNqkz3I/2styBJwQzvt
UQRs+JXczoTZEzppLiD+YbI8v1uraWHG8P/Nr/JuQwtM4THUBDAwz6/RfBpzUSiRgZbwCPQfCiAW
72U1zQN23fOeTcC3YiJzn8ajhIvyf/J1lGEUmIAcHNZ/AaIND+rIyVc1eC/KJnJH+2lLJlXxl4yH
MKh8DEIJCa/KlGN27LYEphk50qMkLOQdnFDIeO1AdtfW0F6gzAWhqIUr9n19pn88MV4InOL3DuzL
i2MyTOOV2MXWqoDvNFl0NGLU1rfjCSu+3gulWdPW7OdMDXutKmEBdIy+R9k/53VUC2gWQl4bByY8
2v87OyEifr0hhpHNtpdp5ZIWxPrql+91zIKHPZoo+ba+xTl9ERkNKKFVdlbTt9ZWRpVmOBmhxVLA
Lsr18UbZ68CzmZfb3ZKZll+xRRe2wiWuIpwykRiiOBFgmOr/5MtgNTXa8FXLYtDssIClijCd6ZDF
kHUYkrxtpK4PbG16hYqGFyenyNvzSbTKtT86Yyhj/GG9Lutfe9wiE9PgkUSisjTfNX6CmX2M9kuC
4cw2PbLP9dnBTTl38BwoDs+6TBv/Et6JZ8VJwIEIUakKrYXu1psxu8xNgEviP1fMXHe8QjLQstpK
HVuTfzFQ+ysLU2vwhONwW+co4HbGx9YI2K+opKdMBQfKEF6DospGvZH+2w8IailPsIl7hlqWqLGx
U/tWnAIbppgiq6hP8dfHngr06FJUEUD8hRsZuMfAugxWir9LJCQLCbIAMdGfN5s6GZBGpZHe/bAT
0XK27p5LReLaFd0Yc+BY+lfHbrAnGD5fRaMs2WSsL6K7XyzWOXXzNIgwoMmVgctd68rWi5mK1tol
7Oh5q5ldnlHQdOguvhnfzqabWZevahexL4Ev4ooMtA777TJ+pEccxnP1cuWe7H7JUhgs9oYywJ5T
pBfjmEpqifHAyrGKlBqEfZvx3nCE5l2EHmvPIdKNPs/TQzSSdnBJZQLvRSfjNpiQh4wlfPAPN25C
AyKmRB8GJ2PpoWS6GRJGm/XNmsICsdnr5RRT2l2DyV0dCW8SbRNGI7fYOeJLH0XVIVbVtBg1EZ8E
ATN2PiGgXCJaNwexd8AvbNCZ3/unD/peTq8zYqs57GIrXzq3eoWREoMjxLp+qOpmT74JEX6ym+mS
r5efvLT3nqWKoaWDUbx+rWafp9jkSlsQbA86UZPPlHMjZE2D7PwLqgU+cqSPu7OPReMD0hEqEdrq
WHJLVI83NZVv8svNXSSoB+Q2bu1BOIRu0OhVn8WAtyR0tWo+LsrTp78OiA9VjkvcvTsHrYIHerQC
55g1lplIqeP6+wdlUMPYo0+W2lWLcTNUjbYm6XB/6iDVvQ9meBU2Bxw8AVZwqQai4HHRmGL8AYEM
KMtKXSOkL2xn42fWcBYEi76j4zN6V2urQq0m7qquIb2Wvqy148bjQ/NgcGaywmb+I+Z5LNrEcYeZ
yOrJAwnUgEEoocvHtauj5KDh29xNagekFgUqFl4aYJh3OFbzlpUzUt+qwhgmFdDJk6HMGfYVt6bY
mR+Kmhbngi/3/+jY9baSI4ak+AoFhub+t1tRI6h1UPqzDayHEYWLKgqXB31ICQBa/XrRmE7exhHc
n3JJhT28iEeFvDUjiK/Y1ou2zADiDIuUCrnFYAI4hR9yKdCBLhh1FaeY7C49iXUJeTkK96gwWLjC
LlSgigfFev1IDyYJshPW9Hrd1ciBQOPw8BmUBwc+zAIQXd7iueYy0kaeLJDf40TzP93OhFqaUZH6
yuk43+Za9NJqEMflLP1tiFW11mPm8Tpla9APFEKNLEbu5LPsLTzs7SzeFUS42lz0aXtmnsGvlcgy
y845XC9O2/6AYeACLYmh6a9c0caXI/UblxvNlUldgDfNn2HwEXafwmYQluKF8ngZicBHM0LJmJWd
tg4tRlHto2PPpVThHm7EoPL4lxJ5y+OngXOO1+XMfpR1eGfYhxKQKwd7SeM4xY6D/D0nB0UW/VLi
/6KSVR9ErIr5pKCEtWzhjREZyMMm/USI9SZl1ERHdJJHF2X8wQndOIvsEgr12+Wj/tp2Z2fbLlcV
hhlqK9LTSQJbo5ZUr6qady6UKvXKIz8JiNymSvwoB8zCfzL7ipKvYqGw8XJPOaysObRVaqf0n8I3
Gpgh74EPorI/BX4rWA5cZzqrPW5tDYF7lqDeAkLiJ2DbELiV5JYIwaKVX7N+I16ppCmzaTdy9blo
8QeyZx4h5Lx/8gUqTXsI2m65CozaPlOIBrVvPA4GK4PPV7JZ5uUYwt004i3ktWo66tg9pNkiM3mr
cM85yYgCWPF5/BjSUy+zcRegu06keSQT/k/ZiA9J9ixV5Pd5dULSvMI+V3JmEw82NB2lJ511TpCS
+RyGMzLBKVOjz8wneU/mJpCAnuHufyd+xibMWTIICtWKokDik/j83aVY0Pvgx++7rKX39OMypWIB
Kiwvd+pTGOVEO0FF8ZWNY1ovfdyuDu+ObaciqKxWcgsOY8SQraosXqYgfBViPHJtrsBmD7fOqGvk
FKqZl8sGMjefWOgZJnQrhNHXiVqWekEGHio2Bjx3aKuH7/nr1o9o/Q97dzudcMyeBjrM/zrEwaUP
W0F0aA9zLxaEaaIsIdYwp3byQAlrQYNJqegOQVbrFkt3U7SkWkR92tIdlxPLW7LxGDMD4h5mkGu3
iljl2mgKRYHzs+ZNA/eW13kil1tFv0sg3y8SxFceFJ+o+0eOoqVlJ4Ii/jKBLh4iYKd97SR7wgZ+
jIdlXvxlAnaGxdatxlkPQrrvjCjI4y92VgiTZwv3TyGdIS9og5ntnHytEqMziVzHVbW6e8tFGPIz
Pd2UnA5RmXK3nJOxkJZzP380e3apL3hmoODUAc3Wig3RG2FAGUG/ezQECqyAu8YitjAbtEwZqwI4
6oQrs7Ofen+in/L+M6MGwm4V6F52vwoG7RoDrU3RXQKl1Nu111hjx1X5n8zBCWtlB1qRNzbogDm1
nm1ObVs/ehawMp7mFXb8DLCC0OEZj0EyjiqMYo883juX0GgiXqDJyEm+tSEsS5LQdLSeq2uFBVnt
RMTde7AJgKgRwAvUmoqTYqog/ybJFrUdFSh+2uN26+NoxU8jqRtGZJDFKcRNmHAfemqofFku+JMV
+MFIgHFcl/YyZFKMDaqwboLyqcMsQBTb9C81ebSeXK7Mmlw7Z9wJjF7t8yQxKIJAbx+5cjWBvaG9
RuwceOQQWdKIy/aqEfPVkaNTDVDvnZh7YqLpEm0lO3aTQZ4IYQIXbNSxguJPya18fxW76aQaFRAA
X9PeSpoGD83yNZZ1td2kr3djavvoLEamrj5ORfh5TcAOIAKYTZk0dXTJa0XqQF+mav5iNw6qNLcd
QPbJkw37eSHkxnpfnxWLQVdQeZ5TyASlB58fvsi7gH49EfG96PcIi0PwLi5VBET/ayAFXVPZDguw
/xpsuxlMa2IVcKd4bjkyG6/yhJ8i7wkr14elCRAx4cbN6tJhAZ4OpMBYkVgO7aVB9wO0o5XYydkT
mZkIh+84Rx7WNJNU7j7EzHArZ0RomEeWJ+7aULus0cnTPRDfo9HnDYsJejsiKYkEgAYVElG3VLt5
AMXOKHufj0ox6QAvKvkedRkC0a6ez3qRbtwZzJDYJUC+10Eqg7ifN4CyUuN+/f00Qfd5x4rRuFNa
aF7HSo5KEqg3SQVOYxS/h6jYTtFPd3c0zIdBpfDEVIpiNGMNJ5IVPh6+X4dWwrxOZLIRC7yQ3AzJ
2RoLZ4pV16UM9emacnF2hpv3uWifrbZX4by6FxVeem+AIq+xa8zC5PrEpJGK+zinRdybxyDopPCM
75io4eSnppcn7THhroAvnazXNpHrmqUm/JVYgFGv3r0K2dE8crApyD/fjNqYVIPMStX6R9bnHJam
Np0CLx/+cOg+o6PNSWjEUFXbRtw0FhVQ9tjQzfwhopL9DmFtR1klBRaqs1S/gbZ9LQUc28s3N42m
TsmKHICWwxx71TiE3WAYM5fBSk9Ze1jkp9pz/e0cVXMDqi6b3VAKb6uCo0eXbCFT7ufYmUVP5BMN
9+EtdcIDv5N9m9tyswJ3igEU6oTJPMU/Y5i/e3ds1vKm39lER7LHYJQO/jLM8vU9loJvR+5XiWaF
eahEBztlzKxTyir7ihZ2pguxnug03md+a+zsA8cInXiQxTZx5V/8IKlK4QdHS91zjysFxHTusRzb
YHvHq7UTWtwozj1qQAVPd72yTSVAbGOSLILrsSRFEq3yen/9zUZa2DIZTBuoWxBdJfG/t5bj7t3n
dQmAwMs6MTWERyOBDaKMz/pNJ3FbGuDz3eeEwl9vjl2UP8VgmESXdnm5Twgb1lWMQlE3tUTZeKbM
iN9Vl6zKVpx6hLydiv3sKIxi+q9SeSTlxKqaavjNiri+5Bij7bicVo+A/UQllPpCsw4vyZgkqHeh
z9XqN0BU3HhxTcvCd5SOkWZGV83jWL128Y3CSr0d43/N4Mjl1oRBsEjNuht4if7H3j8uprFiSC84
3PAZOTAkSizSVTtABF7smzWzH65dvcz339R14aYO/mvrvhevKgX4jwMGm9eQu40TVcaFz3ya1g/s
tqYjwh2gerkPcAmeTQToPO7vofOa3snWyzo7Ot2zwwy6dcMNtMSauUhoUKxrT1bTI8Iw7SAbHwzh
87+q0S7La9j5+WB58gfv+sJol3VUSsrhzk5uVgNPSdR025LnAZoAPkpPBIHjwk8NsvbZAKTl1jgk
mB2g0rP0cBW93yz3Ey0sDvI4crq1MRZhgzcT1rZkBI1Io8Pk0a/0+k+37nXv3IWWZ7QLpCVlrl7d
yXDGvppxpoJfM/0OoeHg5mCiUqpfHUWPkNY3s8S4RUSQoR3VN/nP6/z9BmiK3LPbxdBfCnEcc1R0
HDDUNWwnH0bw3mbd2uBNPI5OqeM4hJOQYMTJ0l0MntOdzqHycMH5HvDJ3KNCcsApr5FJ9wJ5DAXD
5RCa3AgzOcxt7N23fxLT/d6O7XF4TCgueZv3n1EpZ6/VkDBo4isC4QzoI1ssk8ehmpamcH6a1vBM
sietUadNHg0xwa71MwahQNfNOVToMgVIZM45WDk0kIUHdArlPw4qd9pSsR1Ej4A2ZS6rpaPciIP/
AzdHiwi0y0T/+XZBdQmpjvf8u0kf2WdQH1HuWaqa3OZPt86gIue7vPWZeIag8TmmwyD5dPQGBHk1
TrIAD9bgMZNNi8EeSXLEaM3N8VBuvPxlXX8T3je5VN3AbhrOa6E8tY2qxs5nxbmgPBDyxkntpk78
eUn5AzF4XEJHiOKRs1iQ6tqb28yS3Shj56SEhDnOOOMyQ3/aMuEHI6gwruOuDbhb01P/W54CYX2M
bJxeFCPUxwuUIpZGaBOC6oAWWjC/zMU8qonpidrAeWjCaiRlMsY/y/Nh5ANRI4AydIuPMgx9hD/p
G5e0VLRf6XzkkiH7epxHw7wwxxJ59+gjDauCGbyHYiDkIf2BWn0914q42SLR59val5RJL2puv12H
toUv78be+MtAGD36OkhSZLVDdZjQ/SClUew/zFQcYa5wNYyZMFtpTdOlrjsTHdiuK/zqgIg0sIFi
Ial5EsThyuuzMgJNngllefXcU6okT44VJAuGT1Qa2huSKuy9nRNa9Tcu5GwTwI6z2/cQpPdCPQIj
x3MirRdm/u3ZpCVrilgQIALNbT22kC4SYvVvKUJa2DmWAebhytF2OsX2K/4s1HKbMc1MFKnY6WD+
kB0loyXSWuVAN5ee5ifqeU6as3tbt37bwrik0zgRLuFy4qmH3Q9wd7632Qtez1QRrD8xheUsA2H1
Qg+hAXT9+rhdCbC9rXiAkwXjZmVdPYHfzUQVMd6Htd6DJiPdNJNkilCSzL0jUs+27lJR+5LNYpAp
Ze9dwbqjKBaPxzauul7pHz71LXG46rAI1o1ubRyYbg9Q67F5+vUAz/XHAuSyOlgLug/Ded56i93Y
KRvpGBvcySGTy3+/JL1JNT66S8EZrfKHhIG7kPGuYqesdYG61+mYhvOwWyyoCks1UAoRGjzk3fda
hV0RgCEKHmUhQ79g+8++dy1fChEE1Dq06LkOtpAWLQg++/8vRnffwkbl+ErItRoIuI8lUvgno94g
RRVA11b2Ts2k4J4TeJa8fZ90sQrBTyNQ57w3wqG8v1V50/e4i39IA6onV5FH3mVHEpXhp977HEoe
++ZU9/82mvUWwgOgVb3LYXMZnl7Uu/Kyrb4lLqCuG9HpzFX5LJ1aDL37D3PzSda1LMG8GE2CIHNO
F93c0GOXCOOFlBFtF40WlT+SsAB8VlgyWVF6ou0dTyMzg4DY9jF0lZtuICaixTQ5xi0DohmnVVy3
G6rER3lsrL10aPaVjH/jpj45Q82RBn0TOeA848B2Gd2xhyzWabqFx/rosg3hK3i5MiFZ/6u2BU6j
jfXeWtVQ26KAVh9E3vqIySqwTVJx1H1nK2R+ivXK+lQqk+5v5MEn2R6v8UlozRh0C2aKFUUIwEdV
8t0/vBzT878YGaEbvhjNfciL2VxCTOB6Qr1cus+6yummhAMN11d8+C6LMwn8kaDykhdwxydCsVMy
ZLm5G7mq5FfVwDjp6mO9x/olJAur2g5ICD7jGbFtpGPp5zBPAnG9pJgYovRudfLYcIKIHcnzW1Ni
53PwmFH0yv8JL3sPAO9uoVLgvotZ28nx6J0mRb4A4HCBb4ntWjIM1I6FEv5FvJKlZzuCn3QByAtN
U8m3Fhp1/3qYRqD3rYvPD/7Yjh7aDDSXN8cH7i2GsQdXjT4U8I34FUJLWHJGRahuhiidOBeiraGy
oUBXrLO7yLojqUD1iQauP2jJSyhguwPj23Jc0sVNSRBm1OmnvZZiFutrZApqu8jx/W+KhxiHjEsc
afkfDY14Dptx15szlF2pnL924CJ8QvDw7qU2IG6DbhrbY4QN4NvwJGLgaCJwK9ch4W14U68Dv7EQ
syLbSO4Z6buF7P0//FeAIijUqd2trPCEusIHBPUTMzU8IzDLAW32u1kCuBQb7Vvb5EUqzUR2wHKb
1P1Rc4B4/+rqFtbxJYBavnxtGB1TV/I3zkct8gjz2Pe8AaV+VgkredN8LySjUCg910fEO2XjJ11j
wzInTnQzSjW9BWs3GEMwmY08K330TslJZ7G8PYggccS/rzqWu7aX4+bFoQwEstklLRRyR310cllT
rcVDVM3buVMndttXIlJrmXzSmlcm14MZIjdRaucM8lWcaChboZJUtwp6OR5p/EXa3CKk3FtxEeVj
bDysZzFdlnMmIKoJLyucPxvLWDq7oxiSAhevQrsSlktlR/TfuPgLc1cWoa26lF16UR0PyUwKn/JK
7aEsd378uwzrdGLjSWcs53FeiqOA38n70fawHKuAkCE0tl1ZHg5p+78knk4D/+mUjdHYrMzlmOHe
1UrnuMWD03yGJydzRa/aWnS4uGyR+KSe8kv2NCTjBcE1Ty7dIYIQL0U9VLJgR4/2oBj41FI+hDaP
9XkvnZ5pBxMJYIPqXxjzSULycytuoKwIt027iN3ob5H1Kv5HA/PBK46w8iUWXIE0ykYmDVbOTVHu
IFkmsng8VqgBVZeoNPTfw4QTL0jsnd1HagWEyZPZbKp2LIoYywvRB6GXSojBYPfAEoyJDdbTJufZ
Y3V3bm93BjxhL9I6kd1PUCNVYYWiFacnqCimwYDR2JjFABz7hBZN+TishwX5ghHkGzaCAQPSIESi
d+0PIfFP3s2sN0b29ZrksQ1bPcyYOEq5b8qaRKgc/rtsg+9KmzpV7SvbnWnAoXCOzABfivpvu85p
8Srp6K81vkYrijpH8L26SAUKXzW8wB1nP2BqtozMJIt3b1H/Gj/CgJtoOTA2EOWIL1+lHEXwtyNz
ajMLGunl8R7fkNNReST2xQ1KzKu5HuVN7LMldxsyAQJi3R47FPCW9N0Qps/0ZHiNXw15Mh0mPNiI
5WGKHc1vAXvwiS683AKbjmaOPx/jH+1y+yWcF4Ip/uL+HPbSlkdKjl/KiboaN7dboebomRHOgl3p
pT/58MAmcv4hTbaXIYaCvzCmnxqNS2puL5Kozzp02QAv6CvZSxDLdprKMqyP7NZcyhuyYpa0hRYv
9LQofyFs7oYHRqGrXq9Bb8AHCAYO0xViE+qEyiiXvHb6t2GeSIbICIvr2ByOBA3PVpKYfwGCU+Zu
lhkFlwBE/4DcBLye3mGySf7ugouXYFMyY2FfWejCU3PpOFnRCagCralN3ly/vrB1aAwdJagZNUMd
uHDFZnNRsBbEBfpjFJp040D5fNV8bWVm4ncWxTNyRNqex/nTB7b/QQhK/jYDNQE0CVeuPPOiV8N/
hm6onuiA3hcnWdYa3u0lOt9++5YgBWCdZMyPzuCQF1NyJr45l9SDj+JKpnR43NHVy+MVBYV742p2
sECMrZq6XSGip0Olcn2czxdwAOUa5haPht8rGI06TfKx3OQuJoteBQaGwSVQWC1l275aLhRPY0ZR
n8wqm5MTpDnFaQVIqtjgyLX8JuV38A27bOrba+W+/nAr26ieTVZemWKD0RgLE30fghQ1qhdVSU1M
KpV6A6gj9at4hC5IhcEutu4JYxaYUhm3fWYbpgalR8zQmVL6e6NONXP3K2KUcr9op/7JYOfGmvK3
5XiKOAjNsPgAdTFCeX6URzIBYiuFrGFIjdZPLCUPoBystT06aw8sPAmfTVXwoaVXjifFR1W4M0cC
kH1kwORkMcexH4JaqpswBEKW4D0qTxRgZypLwbi0jUukOA8VY5P5f/o8kfH79B40AacIT94M7j2W
apj2KQJpvvq5ZT50/YNdZvGNBC29NY7iRdmyr/PrMYNe/gcRZ/eY3TNuMTzwnCU6j2EQg7EmIGcr
Q7X70i2fT1wfXlrfOaSucH3PutZzaZPds3foVqggDVYCjyvhCXD5qcCkGH+258QDuTBoiBR+/94F
ZFXaFaCQWHUJh+KutPiFhSrPnvoRh6rg97g/zAJuwRE0+TfFdkPPW/lPBmsYAOKKYN4OZ0pY87jP
fyH1IwxRDWdXszOo0u1pGdBk0Md2yMDH3/Bzqv6fF9plfW3/9q4dseDHBlJuJd/3znqWekvquvMS
cZbT/IAZdLwOOoWPp4DRQq4JfAOr8zDTsPuU4Wvnm6pVG5/VBzaNuRNQBpWEHrgJaz/nX+hfV7Vw
RssAORe6p+AnHXAnR4zp+PC0Lqhldt/Rj4aifPi+6jXXn++KXomPYfIXqoXa1Ao2A51Slch1o+xG
X6+UhNjbsU6KjpgJ5kTko6tzy46x8HbFs2c3Yu0HtK16qPhWXitABId//4fYpfd0mwwrK5jy+ZHO
5k5nUdpn03op1KNawpN/KFMzv7LH5/b1gvCPsebZF0Q/SIqvnVZmLMS1QvdS5MBnmtI4lZ96qxRj
ZTcc/p8nWZm1smm3cmCVJJgg8+bLGGETx+ijUQV5fy8U4ncw/N1/UtBcmVzkCT6RbE150a40//Ws
1zKTZUHtnEsaAuM/yZONqACA+rTJV28Il/joE+mKBTVnDi7IgDj2oYUvF9GHjmqP50xz5PlLoePZ
g0+l+t5ZjH7vGhLP0ZbVldV+twjDHXz3xJ9ySYfaOUKKqe6JC+Ji49kLqdhLR7Lz2u1mb29/Bf+O
2owZqVugzhkMSFVajDsHjGnFiIEagynmM08aNEK/0yw71BQbPJqalZ1hjJGqjcxKZ4BqwOMvcBbk
lqc0LUjD3hAiNmNs6mEsihiYnRoIY+8iVf+dpbbvxAS5wxCu4zdkKY51CzT/QC2woIG1fpzJuzXf
jcF9ffcvXYmChnikaraVqoXGylgt6d3LN5y+6zmI43e6fZ4BlpeKhQ7Kh1RRBRQ+Q0b2MmZwp9Fk
ApJO0QAdmPhKb07uYeDZRn+uRmyiRy9TD1yKyXl2Rv0vdaIui/TFBdc+4pwE8HreaBSQJq7nbD5W
9qr/y3zdLw9ZWcV3UebOfmGrmQiWFZPmHJ/o5CX2y1Q52+zuYgf3jI49q4ygXFS9wQGI8p1pJVAU
J6mozSTlbINV/bJlOvYRFzXEC5J21bhhr9asSgDseIq7FEBPnHrjs7eUyf4irLiNY6j4EWRxQr8v
1WCawrnOE20DNxGwItdCxiqYv1oYoVlPuRpDIQvH8ne9eUa3mt4sm2lNkZCgLZM7mvfieUmKjXKe
qLR6VQfLHF6tOIztZkArrQEB3HdBhMWAko3h7Fzz4e/fAGxFjG0wKXmNNcY2klkgJsbuwvY5F0OI
pV8Hhq8Yhm7FeQ0omBAJ5wS/iHbLO9egElWpzWpRtHpH9T7WXHyhof7uSLx5TnMoAwMJDWzu9HOv
3pW5vwj5Cw4ZFVdVkGyw+Ac0NBFXJJ4Q+dZzW6pcBwyPyu187zs60qjwxymTKXjjBOFxGFd0ez9M
H8TqtjwkXFMU+k4qwYUpXFnPaiNAv9gKDDLDm3V87SsMZ0TLO02bA5tSeAa0j9csYsn55lSl7dqV
4If+dK4b9IpURVTgKclmOLnqZZwdiGpYLrwnf8lXQIusY24uXgX7gC7N93YUcV6X8mQkn/K5abPJ
TnkXeGuM8Rozjb9+GRL5DpyreVU6wvGUiaHlr24fPdxJUft17JwY2ldyb4HU2LUQKs67XsGWroTn
cypG9NtFqKFobR5MsCxqJj8UAPYS3JLKqzqDXQ7oTvHqfz/ZKz/i2ZmNa+BQ8bCgNDb/KTb/lhmJ
TIxDLnSczhbPKmi0gqJTQBFbxQurgLlLGtiHdhveuobws8knr+9Kwe7ckQJODo4YlOHYxYQjRRcm
d4W0a0Tjl3MEMcKQgRhnX8m2zLvzmkdDRd+3PYjHtSSNgUxuA7vnpks78JIZhBjx6EPNIIYCjZI3
kjLewshANrYgAyrmr8LkMU3kMQFoArOn4WCp5OTfpk8XMamlnjO4SuvdL08ktjSRwqXb+ruMTD7b
hYLsXGmnQge2y4ghPck9gYBkiJ27xwhaxyUED64Y48xnnZzFnmzCnEhKXuoGcW1CtBHJRkxevVtv
T1mly2itlr89KHODVnWg0qtfXc2iXMkhOpyZnVb7iuSf+MsVjPYUlvkUo71vLtuKFHyHqtuXduMv
ixJYPYcMuwsL9614YSX7k7Cn1evgn0z2tEnb3u+PvwI10YLx1ENrvrLDfZuRllnh7RF9+yoT9lzj
LH2UsudfbqW/Ee7iT9bMRdYyU8bGEDOwD7bP97nv/KFYoNlEk9GwAho0BYBgnEDr4sVFDr8im8h7
boDFDu9JwAnqNJgjJ4ff1oHUpfTQuar0jha2FWtnsAsEC3cYCTQgUQ+HrX6vAGICNKFzCKcGALKF
T7JbdDwGcTDV3pCveVmkBnKOo/On7d/RVcXoDdvja8Ajuc0EN9OkOyPgyqxoLhtunKbCnSh8n8x3
6hRH7BGmEqXe6epBRPg00rHmK41H0f5EkmGZbhcUCJn+OYf0wAT1xqovy/RlB2Z0G2MRtC9Oo7wi
FTF+waXtWOcOW9xfck8AH50cPTQauHyUqCI8sNcER2daiF9DUP5Kw4tEyMBtdfBbSonRr4PM8k8g
EACTTB/1SxVn8M85Cp/fdCnDWNKa63eFYrFxN/9jhNoBdt7JHu3VE73kHz5snmdamrlwF0xvzxLD
8DV/LPPtUsbqON2Vc0/hf3BPVrJQHihrExSEqivTt5qgroqae4BfuVG57G5bon1M4iJLl1amOevY
xr7Qkq4+hhZ/Ras5uSHC+fbeQXEfugNoSSXuOMxCc2HlatiXNlplgKT0HxKw/QGo0S9YywQaEtAJ
CBq+hr67MgdEPxJlEoqr2UgIhriMmeIWWvyoQ0vHZ1VLqCad8AwthBT0T4V7iLSfGTvn/aY3Q1Pu
T16tWYkg+0ougrxsrQHbek5KTg8R7KlV9LR6iXp4cJX3o0Oz/6F+5gym7iBGOEsy0MMasBeBB6vW
M0WXeXd9xmPm2vSKg2/8zfPXupCMVLHYiso8OtZrZJP0x7IK1V9+pw8i84JSSA/7kGT7Ic8poGaw
tVFY4VoAiz6nHURQ53S6tYFXSsmn3HwXcJBkQUz6B7tmwKXLh7oB4Vewye4xfFQoan3WOYSe9BE7
HKdXR/y3gaCDQbo+8Ibt0YF2TUOGBTtarDQQXfb/S2z6zhoefFlbW4bziMsaj+Aoskt25lflxt0b
gO+rxAkvgoZHqaSy8yMBiIUNL4saDB5LvUugS90WlUrzTp2EBOmH1lGtkkRb1e7vCKd8VtjzRECU
Nz6cLvJdoGbS5/idB09CVU1HwFvwvcbna7qaBivrtMB1POcbNhivb3UTgVpiHOX9c5gPPo1+ZI2m
DEef1KRggsBMhBvxBoai77c7rx350ENY+8su3Z0CldXBd9OceLAs/WKRXYVU8g1I78XY6FTg2g7d
ttwOK5HHnCJprM0UZ3TsqL90ugMJ81EIRJEfuMScIyuEnXkFVyHyUeDgISSDSDop0YLCx5HFK40I
eNv+upnUsGsRkON/hS3m9zaEVONu37FvyytmkNNDNWhWe/vEq4sxiY4b3Fqra7DKwDuGnxSgeJ4T
2clC5tVzYdej7bMKg0N+Ch9UMtlzcmntSqpRkVWML8i0dlbjIRcbMYC8VpCAwjAd02IK7dut6YnW
gbZMCcWKjXtFppGyJ7bMWI2QoX/VE0zs1Z0E5mdBlRDHDMMa9Upr9VJIYHeBuP7bnfp3AozUSyO6
TGoy9P+5ad7UO1sU130aiNNcsKPEuc/0l8cjYaLKSyrkhi+D0lOZsVTuHMPe8N7+UsMGet+GZ3i8
ckMVZqQic4pjxglfzQzRrHKoKKZe6oDmh745fwBKz+zmHg6Ldk2TFBSFo79UwAM5WIZdYFNxNkth
17pVxxsz16p8KV2DqTWfGciyHXf3uWwn8X4fiDx/fG6InFKoibJZ78D5zd7k/TPSBaexNCUl7iKx
+KKy84VWwVlYpv656ljl02xGd3F6PcjFV/KchFAE7OsQvJlkNAlg/4BQLxMSx5uTNabw/MfMHm8p
gjCMcHBN5cfkfduAmQXtjPHQm+jWozJPAiryz2KtMy/sNhLJNIb1OP7o4fWf7SY9jttwFk5sQwpn
vITABQbUsxJxGEt6+FSwCykDjWsx1AGFI7ajm2AoDlBbGDWqNZ4mkZ/GwI04Xqh+fPnvRproRNat
aZ2usRBwnBJis03HEDwPUabbdK82urRrhEFm5MjiLSms7paUm1ZDO0snvPdgp4MDoOui7LSGe1j/
mb/7Wl22POIGAsv7iupaOoXQ4LpqXNFBB1CfiRwiZAuxUsmqmXHEecUslUxxY5mr1gJ7kbQsH4Ng
T86GLLPKiJNFS4PV53jSeZ4iE+U9BTqkfr3J9bK5ztekeYM3Fe4hYOqcojRq2CxVGgc80zv9vbsi
4J3E93PooB3Z9T7w/SB1ewO8mmUa3/OtDdY7o11bPairBSFmxOFMIcVsflPKSgk3GVTx8GDiBFKG
C2e7/9BSs+5OeJ2KxiQyAR8AP/0yaGarKjde+/FsCWQXNbYD7BEDdl7vwUgTYZV1AoLmHZcD2UQ4
meIcDwv2/BL6bWQC34pIcTUHjfwsEte8KoPN0fhrjCdzBXorZ3eUL5UUgaowBaMhW1ALeE/6VRnj
aGHpdFZWnd0O72zL+bAUlGOLqkBDHCsG+aP3iEzfZ+fVyWd4KB1ELU6yp9rYSFz8P+4+Hdtt03OK
1DhNoOQsbjyxr3gQtV2YrLBR8YSzQ/TX7qjXIX2XWo9ZY35QdgSAJeYMWv5jeVBt7St/jJqnNdXM
C0mAgMsqWqcMYbaTwKVBZthN93IdlU0lpajHybfEvBgMKqimPzLhzTAVlDbTMhGYEEGDc9SSnIpj
MTbJmeEOuJwelSjb28N/n+iuFgJzbhWOYuMLOmcY8KkdY3oYB1Rdw64APm7SxpwOh45Zb+bdhh6k
6juMtRJ2ZozptATVf0U6WBYiSizUy7YO5cUJFRAPIU8EmpivGsH590Cnvsvg0BLSsywgMdKaggNZ
2QRl5GzSOWa34WXHpjEaKj9JpwKrA0yGVGzCrAcLelphuLvaaHynlENYckNREN/JENF1fZUVWpmQ
h5diECXarLyVBYnUKD5JFdm3DffDApgpz5Xxyzsy6Yf1R1JKqaMq4qrw2YHvN4MOeK+sUw1nHZyS
Dkt3rxVSNjSl9GdUcoY/f5GA+DEfP4D0Y7TxhgT1uBuQE+G7iLSK/rIdUOIC8jhHDyE8mMz0rmn9
XNGJpzmr9M5rEkxjmAgkKZeyOL3xZyCJ8P4vi48xKrYAUNx5Ka9GVtvjFaZ50MyE/gngNaeb9FSl
bYYZA0TYfQajC0Albo87Z0JxDIYoGqjRIe3uQs0kdfbkeOzL/PP2V03NfTL9xpkYCcIsnJCFqtOj
q3OBYb/hwyR1UEBBetIu5f4Y1pWmABkqDLndyCXFPbEdoH2AC9ReXpuj8KYwdxGlz0hvtELwh6EV
CnfP0B9TDDgsltEJX+Ww5GmVo0qIVro1O8dmpTa1eHZrpMUYW2NBTDE2vlpnDlERF2+I73+CQBi8
USox0O9GXxrSfLIQUa0MIqtoRUUPq1E6Fjh0zHCrlYDqVzLIl9555i/cp8TaH/L8rWwRYW7/qxsH
LiNhNRvtunhQic8nQH8lGhebv9rvX4TsqCdHR0EE/pnlvlj3RTv8g0j5S+pNdcmrh8NgwZtMssxU
U/zazqM8F6U2Z5eZlGTNKA8VzDJ3akrc+UPW/4CcMHfyEOvoTNdWmdx38+D0iDTSs+cn8q8ndeBi
r2EVHmh4xKQlPik8eyQ4sdHb9GIlNNBbE1XDroKOyNv8AZ5Tp2n9cmnnFRGfNDbfSI3eDGCg/w1U
vA5XAJo50//hPltphxEg5HBbBW0ea20IMVhf6ghLmIztYG7Z7MVeahsBAlwt0CQJgImQdkq+lqrW
5wK2o9UYSYjzt/jf/9TpY6XEf7qX4w9bGgAYUAthg8RotwKbCj1Nud/fTslK/5co6asXy/CaNLxb
vV/nZVGzArdz/Ka+TBGUlcVraqMA6+ChaVNPXIpb2yEQf0mkrWM4P1hRCyu02XJTpLwlMlDdIt9D
41ci7ts77/diPlnb24DMzFK3qU1pg0bqh0h2Zbdd4ylG/eGo22P3SygfxSbCW19oYroZJZjDipYA
rM4K8y45eF9LF5QwMcV8U25LKCOAtv+xq157kksAo6yRMB5XCnmZUbTEl/3vkfgvJFAjy0QU080k
Mrv0joTv00D+r5JicmAEg2Y1FEIcjloUC0lqeVjutpOL2sfrvle48ZlcFSV3xZKoYliHUKdCmzy/
yQTOclaJlj9edACqSzNnFKPjVk+0EenULiaadYzyf2T3GMURz5MJf0QsU94HTGbbN//S7276tajj
TJP7w16tadgEPylBHq1V7lz1Aqq2K/z7G1VBfaQVR/qrEqMEONUjvv3wjUE0mo2iXEdRPaq9wVGK
x6af+5dvtmB1dnVtwQOXVBQ0aR2E9daByWiTTCgF7uLMdjqAx/Tg5FuSB54zEUEBa6X7X8zcc3xb
XCoiF4KJNZHf+E8uZQlJOFhBP3XQT1wGgsZZCEQXpqyCucxf1wsf6yeNg9SKUWq4KaVqi76Aozn/
7oNoCaDyMLyIotQW3rfJFOmFQVYgySvMw8hUeBzuMk0Fls0kGTN7Z5sIFf+ULqwSfnmtE4M++kD6
6i7zlQbY/S0FGidpO1ibIwekvSPqIi41g9IhBM3MNYbap05XJo8pV7FOAaPSUM9SyelztZ0xd3KD
Rj88kmGDlmvRO8OrYcSRU4W/oBOSXzyw5kLjJ6DeAKt7/YvbW5g7eGCfZpKgfTYAnY8l/6/N5xZd
6THJBon182o+eRAl8Ek3aWyUEYdxxAUp22IlY7aRUf+Ls8UiLa2IKxsHgnyNZK/pD6I0mey+qQcT
D1DbEMidd5k7X7djMH6QrJ83PSoKjVmceZWG+9FaBoqP9DF1oODyde+MB7LFzpJMmqzMumCRLC1B
LUrQgGcZZq1WWe4MO3MD4Vov3cV14mo5tTN6YO08gti5gHpwJ1eGsrI6OmOXtf5k1GMF+ZUx6GSj
SO6aervD4S280jKZcFKqnrW7SLKmniWNxzw1lEr3H2rnUapB0CWTD5ry3fl6ZycCWV6qABO7m6iW
Ify7NTsAI7U24GhsB8bn0cEk1rSTUf4dCyOf3VNRTZHRXmQ4H0a1fzKiB/+xnLbmgRDVug9Bxeu7
Agu2UDqNoz3Xz4tXer0MQp32oz4AxRJgPD9rXFyRP06OSQ+6DJf2eWkJwZLq3COOq2j3mUoFWFGB
txcnXgEvbSDJNs3UB5YODkS0W3d7jMv1L3JCByKsJUCe/0hDzAqtxeoE2c3SHZnV9AirxUAtriDk
dW/Rgn8ND6K9nZL61qyKsfudGStB+59ujdet5iFJmEPCPZxLWyU1UIWh3oUWkDfbGgdQmyb+za3s
wad3WaFK6IaiFaciFACPsK0/ytwQwy+hVG0lR54pfNgCd9C51P6CildNOJl06vHRq9T3Wc2IUFO9
EsZ5swwqXSIbi1SyZsHGtS1UrOA6HSmmyur7/XgmAeETyHaXC4MXP3B9amv+nwawTV0ngjQcmJVG
RXktX9YQzNVA96bhcHx/S9nPjvCwTuWWM1qshaRTI5Yh40DMamMaZ34QLApl4GO6OBRqvyGOyEbs
CKar56qsZ2bhJ8yAi4I0/AoxCRPYZluSJNCWONwXg+mQceaBT4xkdjvPtKr35FmlDk63yqD3rpoL
FcRo+vQkX2s4JjVu3yNQMJjYc5mgJWOOBO0mS4bT5R/h1u1Ntp+y6H6b0JplTUuI2vy6LHJnVtXs
DEWdnZY99EHlGaAnL0Kcej+O4wH0SjElW/vLDEbe618ad/+On1wO2PdQ7iJbUcwqt3LNLpNak47Y
f4/OdhC850VvZG7juSq7PRFL8hZjqnRJ6n47eVQXoma+eUq19JTIOZAXzPcTmVr+yrk6LNC7U0Ta
s3s6Z/jFiCXYsOUOAO1nUDK24mQsKqCXXNtjxPDWUa90ZSXmv4m0Ji41NQ0wb6iel/FHpk2Lz/KF
7bt2aby0DWuCNRD6B+ZxCMGzLTr0SrZEtG8t9Nf0xQJgGl5BXyjL5EiSstjFvMrBPCTCBSuNbp1z
Z1zBzsN8RkPPDMFxQObTDGqLfxVGYsSk0eobZ/KgeIL1IJt5BOtx/H4njjXXx7fLUSgQDZdfL0zE
FJO6ce1uRiDDUbtba+por1qvzGVSE4EHTCpw5/mn/3aJvVlsABz/ODJxKgUB/mQA+AcSvfb6u6jM
n9jBlPMfd0p9+sab4D7w+Ha3cIQUzN6ZhySN1NdbbSgcGiYuGePziZnsxnN4E4L0A9+mTcOndUzx
ItfrCUrCT9++SJbbs4JIKUku8Z0uYtmgN7LvGPacK5xRrPpAsfj9y1jX+okiCsVMp84XEsNRASCk
jq9QT/gGE8MCvvEwx8QsKgG5Re1Y27viY4kv7TIUAH3tCOjaQ423SoPsUMSXnvs+TfUmMwfQJW3K
u5hh+46zJc/lPNTgiZJJKOOrqBP1JZRcvYKNm+mACzSSvruN6SR1ozbn+Ul94B7mGhswev2//tHK
1qfMYTXg+UdchumYuf1Ug9T36XaHDTaWrgbO1Gy3SAM3Vw6PC4iqJ0TbWfllA3KEY9gW7cmYNH9w
8qBfsSJAmuXKZhbvRdB0bve44bq37T2rfYBIkw+m3+ypdcsGXZZpi+bAiszAIrAmUHFMN1yUPT4U
74wsca0tihw8twqk+jRd6z+0kFehhjxaP0eEj15flc0w5TasAWMXPJN+YXBPRjmC+TykRKdje7Ft
LUfk0+ybhulWV8JzngSIXjWzR0DKdQLBmuAZ/+YKng7daHx0Nbl04aiAqT8ZfWuabRSpSNRLEshd
HUzMNLkoOl6z88Dy3XwAyopz6TpdkJoRlNTIS0StJWe6EDv/3WGN8BiJd3tX4gFJuqnAxrvsXXpa
EYHT8Ri/uWKTP91sqgwoDzw7mQUGr8ktxhAMhviQUu//i+Ky00vEVdt0shUxMCgzQs3QPkGUV6gx
8uxDNAHxR1KKljOoTv1fj/+eQgKwdD9+m65/XqpiRmR9KaHGP9KdlZJEDugRNkcrfk/JBFrjl8rb
DwMylEocY2XIS2zw3+MNXF17kzFMLHcpkxVfFAgAp1+QRpvoafM9TCEinag2xwpovJZgh0ijqH2o
paJZNo38CJ3ntVWTvibY7udzt9Lc7gkZTo1LZB2iET+SFlBvAwOcFkAEXfTbv82WWcueQTmihfzS
yno5AovJG1o9SlNriraFYz5rsmLaVi7jqSsLmONBfIZLyCeD9h+KmVHeWl4PBaUxjeuh3yCIqHgH
3Y7KNlslakC05XBxG9htNJ6CLdMjLSrpIEJynsDtrdnKsjuI91nzU0kGrLT7XcSPicsuSAP9L4zY
g7IRh/oCoOEc7bOzwVX1iT9YiRzeRWaqhxqmNEfQsVpAR10nBHLHtQB5NmuWbL5dX1MWTnF5dwD+
O+lf7yyHE+uTRP3fPJi7XnEt0XBF5PxFbvuZEjmEEhWuop9gfp5CLJ3aXXLuB1mjTeAFqNfBdcYG
W33/8wntziIhzXcDJ+om68jV73GTuiM0XavtWuUfJIZJG4SPHDoKE+8SJfRyzm9FmUlSdYSBTqN4
v4EgUDReyOjwRMnccsoo9CJ1IYbIpzgioNc0Gk+j5Ueut1Xus3dhuE/D4/j1xtygdGJjvqBsYkvv
3UZzN4K6+6TJSoukN6f0LhgdMVvYFrwHiu7D29BL2KSyKobsHswJncalAhQDMJYKA+dRUl7FseJZ
RqGSO6l6GdeQsRjsV9zivVeH1EZwgeGGo/JpeajsivGg0DpMbZPaH3DLueCMY7eW9dFZuXv1Yn9z
CUAmnkTihEUBdvqdOLXVOE5UR4SDLoTe1RAZmdR3ecNqaFZLw+5BIeIB5MO4FrFdX3v5o1iqgDWJ
cvXyvJEDOVoMdYman9jLViJBX4p1SWEULWVofrf+zUaSfHWrrNHV7/SCg4LO5fQVh5qws6JH+U7U
cUQhN8dCQkavNrNlL0SHQKcrfVqoVLB0+cvNicF6aRE+Y0XoG+VRLmjcYz59mXTGL6W4qOsUAY5z
8JieVXTJupT55/Ac2sMkMGi0amzKHFP7QDi1Qs8NuSQ+r29a3d5THH1SUdJJn7FRND+Zmie8bQ79
nB71y062+I0OG3gVKwoOT/feqDvlavULy9/ilpZoP2rUZlIDp3o/rH+tKGzoEtFXAFcUlsDra3Q0
M8Qh5Q7BLP+u0D9fBc/1vPXLbMQrqcy11E8rMl7tG4cOdkEpr1r7CLbrTR56fnPUia04VO4WR3wu
+G7q/NTvnFX/XemNF52xgBbmbuJ6Ne+Gl+E8JKRtRGb31uuDHJbGVQWA7BnODcTSONLHBmgL60uU
Tte1KgnmsUsphfxNPUL40RbhywpceZe3sX+OLBIymCROFggIj1Uh7HCIIAm2AR+hbXw+POrgrtmH
6UVL17d1003wk26HuzslGpe8iqC5dVJKMTDOriLH0W8sTqQEqkMNyHIdDeviPOH+b7qhuAegk+uT
AHS4+O+AmDXgmh5xD2lZLyWWiqwGOXy7qozVB2l6cLex4fjDObMWyv2SuRSIsS5Ipvzbld/My5wx
jNSeHVtr+WLxaA6Dl0df3xfUGTecrqfkaEs2nI9xZY2UP8cst1ouGYa5vPwbecKRjweJGS4n2RO4
JiKKP3Q5r532PevJ1X0qoHEoxFJmyIwgPjiB4o09sEgT1TpkkQ4GCDRcYhZhW1oArikurBb7ZKwk
6La5bYYLKP23INrLgmWgFWr4COB+tCy51RF5ytdWQT+zRJg/E/yD0XtH6x+yrR/VTrVl+F/QjctQ
SURC4hpKu03zVPvp0WFPqHLPrIzqFo1J1oPKzJl6TGDUR9CQOa948dDGc/RTHneDjxw22oaCrIIM
dSNXsSnmCENxRFfj5VMKt1NRfFb51+3olZV/tr+cySeXGosoZKZtJtprgWkMNtTuI/31vCGTwfPb
eowSlE1fjWL/uKHALG1adNZg3Ho9yQ82wtk6NMKTCyvbNG7e1qE2MtBTuv+ZKQotn0enVVHppnhq
YxSkShfVUr17F+JBeqb7Lx8v2TZSy/31EIbiZj9jl2NkENVS+IQSVz6hWpS43qQOqbmEm0BIJbUv
f/Ueh1800yHzWGDQ1APQSk0rct3pgoOfaKIyH3wVTXBEkLQgMrN1lgaIQq4vasIC7X2Xbt/WJcH3
K/nt+cfwI8KazV0jg46AJC4uhPtkBsLSj29z23la6uC0XJ0zeQ00vL4Tjt6Bg8TTetA0O/npWZze
O81QSb5l7PA2mTJu/Ui8ezvmEsmhaTgHZHzAVjkMVngkTpMCmy0SN8t9N1WY3IisIooaSZUbQ0hW
VGbvhwI0V/8RIhhGrbuol02EtEfwrFtGNC/n9bdTC6opJyJ2U9PL0/ATmtNhCclxpPp3Q2OJAcWT
zIQtBXUPM6Nb92uC+dy/ZapC3mWfaSCH0801TcXEazsIuA4urXIwKRVuNVkYo4ZAS5scyN9xmMAo
sioOyQmU5Mv0ZwBhuJGq3u+gO5e933R1DTmIBlM5wr9+6SbXfqSB6VQMGrUvbsu3Gp7h3zrPQOQH
4B4OwL09wyJ4m9EaaNCIX665k0A32ytMvubwf1MnOjs4M+6yXvnLccaJGaG8jyHoty58OO0YXNsY
Xb5Hr1W08J9cL3kx6bpZOyBXkMwV13f/7xbtOhqRimZjNLjjay0FC3Pp9FITDjwPlxiSIMFjmCI+
Q0n2qeZqd60SzSSRHQN/ucSE8APY0OVNEng7ZrjeczdsqwZLe+r+P+Bu6rqarp95aVMPHP4Dsx4b
HmWX5ewzASxZdmdERO2Lq+W+50gWmpK2PLSXdi/pDr+dPvcG4L9GCuXJomC9xwWjoa7Uq2OjDbfA
4I3UOIq9w/PiaW2WXIUiDbhoqo2w0eTpF+7ChMIicqi3oD0wBjW/cKXmMwnDdnfRe0XaU1he7rJE
keZfEiSN27EUQvC+JkyFGc5kVkYhj3K8whFgJm1zYZM6tGWR+vlzzEkCh0IbUdP9d8lOUO5piiDT
e4j+37NUXIYfz1F6NdHesMpgPnTDKqoGxmsUFdD1boXBHSbOR+CoVGsn9ViLseOTyh84ql+XLIwO
5ndsrxJOcdP5a8b1bjsfdI8qHbsnBC3JENCC3lcLpTJUlGn3gOj6VmzfL3hTppP1BiTwO1Nc1eu9
DwTK+XCH7W/ShGeBuXUcbSQ0EIwONkAJf7ntW+83qnwsHmNFkUM4ZlxkDatlUvVBzAJkHZ/XDHxK
xNC28yRMpleHZqjc037lLHkDkbXw7xd2iOiJqKWItBTikNAQC6I5tlB1FkH0Y0X2vvRENYibO7rd
HDDO22bNr2+usv3Ut0HTOg7E4Yqtm97ujen5pkfawtL96G0DS3xUCSTlaTzEAvNoXwwD5M4D6aIT
JazAgL6jZxOx8vmlEAOkX8ejejyttxCsVoPPaMGwB9Cw29bTK588qUJvSpEVMfNXMzibNTHKA8Zj
QWPqJKmFmKpiOG2Isb+BZIR5nrgC7NhpZ2uzedb0jF2Nn6J4s1rH5HhqwBgro2ihR2cdWiNiLfAw
kd52Vm3iE4b7keFzIlDC1K+wrdQrS1m+mUEAFfDPGy5QCzsWfYdwJGwDQH+1B4oNO80tOEff8if1
PSPlBdhiXXlq33CzGHUZEWaFl44qKm9g4C9KUuWsxPxlYobBJ1nTJF+fUQczGe1cPyjilR0upX/Y
A9b5i4qx5xRSqhOzF6n+L5xvVUNIMgz4k8uKe8/oIWiBAgh7lRG/hqF0JrjLNzzVMALLVHVAyxVE
V04sVtDUF5grqVrmcxsf7Q0ieVAVTOt812Bu2+gD5lGyxWXlR3dAtrktQvphoPjeqIzjzaV0EAin
SgHEcZgPpr19usvA5rFEIUJS2P2edXYLnfP6tVaqqzh20yO0W7FPZeGv6MeQ3jVov1w7OTPNh1mJ
QxWv/a/D0dtFDPpPawgjVqXXa9yuW8BuWZvnMP7loe7z/YNXCnTWKrPG7lZeW/TQhStey6wCxw/P
A7Sj94ZdxrYdPVJGBpEzugbVv/6WCEY2a1SEO1XpFUIn8Dj6ke0Dnj6qtlBBnKm2QCAoXGvOEURQ
ysWTmEWCQrDOKwHleM83h0OBPaiCgIXpdItzBncznNq8M50sg9OWfGBzRGHPYaExuXrbWIdas/+m
ZmPsTGUyff5bJF0VbF+Wcam4DwyxKUnCsMK6FwFq0kWMm6qeVLWKbPa+729LG9sbMwQ0gRxrJauv
x3sm4rHQWoms/K7b+o0zcn9N9KfpBXAOCrInHtk+w3xQEy4ru9FTh20Opb3F7rI08iTZZx/2zTAJ
tjvLsJS+orq5RaPaEIAyXlkpgjANZOT60NBFM6jmrRs/coxRIF86p0pVR6Vk0I/o6oycxRnYUWF3
iLwD3565Zt/VVKbGklyqpqPrE1oVlDxsu1PuLyvAq32VT3bDARrXceYC8lp3IYeM5IGO5GjoMrj9
C1XAa7o+HR4BaDiCJ5rAAZyByV+hJPECl7+Iqv48f4Cab5SJO8Q3v4Pz+DzPZQ39f0R8Q9cT/eG7
KFRbLFuG8IvcjwRhynq20cE5hywPAMRqD69N+1/S8DMGYEIbCMEHynbQVpba7iZARPUSncUDuOpJ
M6yJ7ZlryMc7Wc4zCXvsCmMTuQfpdPMxwZetLbgKu27pQyidC2BEA7/jK/u7VgPttOyy6UnliC9V
HPGPx86aRfDso0pIC7S2w06LsOQdsU9HgK1uN4lncj/STPK1E9AiyuNo+KYyV7UpGbQ0zWUKI828
E/hYFJyjSyg5LGg1fssbcNnqlyZxLjp49r6gx6AfTIb0HA5bO1kQ89aiCaD1O01VSjdfGfxflHmo
0mnbJm+71FW741Imsha7LO2Cwz+Gq/+B80okJoQie/uPc/QSXyCzi1N7xVwJCTN3uITNawjN07/s
fLMI75zr6KY6HGKXReHS1iNuUs1FvKt0FAu5WdcZIhBFlnuupPZHSsIK4z3Tx/hd6BFIB4lB8Dh1
Vio77I/mtSwDvm0dy5bMKlgUVcbySLQ9q2+tOgWsMZbE8P+AJr+/aMw7anqgiGd3OeBXmGrP+yzv
zZxfd9PxBYhx7VEqdUUd5ALh1FCr5Zi523UIi53tWKgK6R0yWWFJlN4jLFPxDORib9Oz9jGmeEV6
BhMG4yGmU+EZC3z/6q5Xp6UjP07z59GbggEk8p44QuggEgRgoMBvPga0Lw2PL1LwBxePF8ChhBma
2kQQ6tmR5Kvpt4s53owmvsrY9GMHRr844mxF5ybzLMMxvpCyf5gZoiA2MIGLV6LVx6T4hWkI8ad2
zilN+VdqOrMP18PtWB4c12ic5EZHTBiQoQjtiqYQrk6JFaKFbCRpM7F7aLOZT28L0rQFR//HU7wE
lVgO7ijGoQRjUVSlZFlsf3Ef27cvzXGsJV5N9n4k0UUYXk9cffpJwJyy77bDPpR8Dmu1gFG5+g48
1Gp8RvtsVddQmeabV+Wb6fuwQteSWwOrDG7MsBugrsIFMLMJkwntEun99EwgxvgUn/SixYaufKvP
MOcP1OzKLHvkMoT7y8m6v4XgChBePoyMZ1DY0KmWDjmfebeVO8gs2J5OQWOHr0Ts7RqS7xJ/ykzx
GgithE6QbpbNEsa1ctDf77JlJO1V8iaTN+pqoRJ+sjZvgCLyDXdsH51o/LHN8qq/i4y1ULVk39eN
/phY8vY4Z2xQhUskoEdctdDX6wBzByBfIK2tcI9Qxj3HY8TXKqrOmdYLVwj+wErQ6h3eSVt6+sYR
5eMQt8vv6GHQRE7d0TCm4uH55d4K3r4QSFxajs0n8GHj63ohiF2qhCt8568YrD62GNkWDdgXX2hG
6992Y/l+W0/AZEYKjqVsDXwPgfRQK7XENo7RU3fLowSLge1BMPKDYs3Js2xrjykoqrWXWA5jUcbK
vA1YM2Kh6Y5zTJizAgu1sfNIYrUZ0EEA2KHIUKzy+EZQAxwCW6WvP46FfFO9KvrbSVvIw8JHz8ju
8ClC99KsFysc2HqxXe2Zf5y7+ZoKkCHrGmkvrMYmnIjPMrfv6PERQF9PfRhwxbDXoKkS1Fg8rbf8
LF3tzgYOG+Ws82bWVyK0mPByDpbTa3XmTmNE+AvPsjhi9f0pAEkrEGRywHC48FJi8aPax6qa7J0z
uO+s02qKHyZWrV/YrsaFv1SPhuJqtGOSL4OL/Oh7pTUJR6rGzRYem5CRsF2wEmzQG1pEd+VmqLAk
f9H7iaheVBil1hhSDzS/kFN2wEhXq7bQhggxHaEGCn/YeZ85iIAhKkxWkCHNcXva16Omr/TngeF6
+clZilBzJkzUqHNDNu+11s/OBMxRZB8TI9M+ccdZ+IqH5BEReFHUiLQaiZQBxCAwW/jXIMqcsSRW
Nr4gQXbv9Uzgn6jlPLuLRgK5pcnKFLU5WPeUnG7ZaM94sy26FnqRyGtK34nvDAl9LasGbpKIbY9B
bl5QSOeenWNCMxYzq+otIDiXODYX4gSXJGIT4Lpk9IXkUFP73d6SSC2w25fej7gXphPHry8ihXrI
/zgd/l+MijLRagBY3gKJZpqTkVRgWLSZANSRKlPl7sMVO/ZyDZQCyJpmAxSpkv7wptWrV0L2s//k
BBTaR1+lMlotFpCMQNXu2Er0Q5qOgt610cRBq+FLddns/ZIHlHMc3TUN/5a9v52mlUcPXrh6UKha
40JxF3QK43pef/r1Uvy5cxXy2oLJUoCuiOaCVacn1Nl7GDZbE9lAW1j62VbEEk7/x4PpsbiMApGr
UWSaoCOke2DJFMHbDa8QM+8ng9YUiVF0bYw5GozsL862Rpr0sFSdNql88OoQh1HqMOweEYq7X6LO
nQKsShpFID1U8K3n5oMNLndTOPeJ7g/jlMFFmYxb9UswvxVHMo2THYBucCOeWPfbmGQzbvi5QdRC
1KYC6j0CZK6Tjgc/2gkplUA/aggBCtJUnrE5WDiQK4HV9YSoWDTFWlTJRbunVgIjztS8pnWegOFp
Sf9H5lY6Krrlg2yK1h8XpoI2xvf3kk++iF5Ragt/sWUCKAgyHHARa53xaMzAYcl2cOWjLZoI+Ry7
yTnefm1004EzwjgziEDiYoibtysokgSmh+HbngFTrEI9mf3V6J94payg9LOrA5HXwsWWzySgEhpP
sSQ2tORk12i9JNEpkMrZaA234W1ICMJxTAUR3nr+6CDcP+UJtmgW+LAq0HUeUQo0ABjNJigyDBQA
3zb7MLp3eGiaGEQ0gR+Y3FT3f46J5B7PKk5N7gvvM8wGUVT9L1JxYx4ISIIgqh9nEKwQ6cjyEdJ6
ZtoU+M1FOgm2nnhCLuWo86ey8v1/X6Ars9dAx0RxHR9/WAP0Gux6mK50ccAcorfFaic8ktI3rgMS
KusQD4ALvAoHwVXwTLm07MfdBAbGVTnJ+neCwkO5N4f5POzInjpLcOUwHNchtFZtmdJbH5OroiRz
gJ42NzVLRWsVE60pN+Yh0V/kIjkBjQfsKkBdCZLC4GfDstZ7WrACJZaWOeZArLSsKYu3sXm9fmWb
BXrKOhricMsep8X8nCVIAHbIPhHdCv9sbnX3lQuhVSDP1At4WfealdIN+CzhkqKDcDdlI1gm6pNM
tLgpswfLWj25XoA6d4InIW5zTLbOjbvIv8gBZLnlrnHxpiBOH9RH8b1vTOI4jNfNwPWGuhT3fEm3
CFZ3CpY4pNeITVe89zyzw/FZQ0pBOUWPfU0gvQomGPa6IFOXZOGtJJ0KUlESSTrD7l75ObXV5xV9
Kihr8H64DiV8pI07/wDOro3+Mnb1ZEJ3hQHvYcDRGPTxMaZBBs15WuJjDlUv5QtYdMXuBCPIh0RK
RKjPTtMUOo2HWVzjNhvrjidjik9KF0lb1TYBZc0h9s+7vrKnfTJ7BjmJxDj5auWaicJ2f5bj39ti
+wzE7JL+pl78GlE0qSacRgdOJgT/9MFWqdDcPjFge90r8wELyEs9xoDrsg6gShWvQR1UVZKmn78h
H6JCNumF/1SgXEthdcEBGn9DPKDO4qOlKALms4Ja2ooU9TJNUkKELRi7euk/Q2Ggtuv8ZvFxdYeP
u/ncivXhp07iJ14q1q3+N5WPd7JOs1ZqdSEeWxtmA9dOe927jR2bRR5PQd9egoBuT/5dpTSkF5yH
BL1XrCYWesYczf4AHEDwLvaDBVz70zFYfYky2XjYsP2GtuzpXRsuWC7w1Ft5Epw+3RjIKreogNLY
022nf/DhWbjiDqhNlFSMKrb6zlix4QRkvpkUVNlfaA19vUD/G+zMXv+wKkgszF6qlkP8FfEImZgh
dRr/4V9ZJxxqIQyJFGQsySSqkIHUGeMjtXULP7QW5wvvK3jnL6t00E31nSHYgCo4CzOiqF9nX47r
kC++liV/JdOeS0d7ME/rxNDXUH2b3VbMMcOcCvcV8kgY3rlkGbuSNy0GSov6ELl9/DmKtcJbMNW3
KpASTS/vf9oOx6M3Vr3RJuC5uyR6BMKGiabUcK+zSsAOq2r5GpneVkxy05vlgIrLmV+7NZfwRu3g
d0cNdlpH/EUw2Fiq6xMS1N0bLYml7xPgY807MFpfdUH51XmdgPaW7N9kBAJWC9MBUPmweQirZ91h
aj9F2zJjPqjJIKD/ACqRHX0HYGRb3kzAJfU0itjIwTdt1plCywkcNr9jhr6R/nQ5J1RHO8g12YWo
32ApWGj2aJgW4W3e0z6UjU0in+rJj8S6vuM22tsYmytRF/clWS4epbTZxD8ESUfC7V/vMt+dLQH+
eHNHQt9/8Ms6cFplheWg+MqPvwISzyJ8y6K67CW0AfYUermBh4VetIjlU9Y3R4aMtPRagAlnCXpI
dty4Rg2H0E7E65XXmPH3fMHotaQpAUtUj9J27K6s07xjXGk3al0YHSU8LdBAJCW6GUTanKZSj5P/
rF0c23iFzzl6bEPjGGXc0aZUnhnb1ATtqPIuYVMheaaiiTw1NLBansStoqw4ERUaejH9cUVOJ9J5
vmMYgKvKR2+p9qkVJi3h9ewtFoDo5AtFDm16Lv+G47yphLtAfLLksUX//WR5ET8Fnq69pIy7elDm
VsGC6fUQyaa5Kemq0SU13BRfKgeYpkcPDuhkD/kAkQQTjNO0EG4bnRDP+nDks8+qoZ6MvQaGoqxY
cQ83/VLOalCZIihmsvm8KnFKTE+egMDCV302oRj75D/Wf9cVPnIf4vc/zhEINJKFTGvhiMS2fgmY
YjKURpyfhP+x0WL0rwY94x7NrZXRNDgf16LVACO1uLF/TmABNepTr97BzDB1p035/GkadOuZkdvi
4DESYJllBG0KvyZcU/h5SikkLWgLDhSjQxvRWoCzpf+XFX03vMFDTFmPBSkes/Ygp3O9rOK0rnzs
kqakYJVNwOtGstTE6YhEjeBoOZPaVYntJFCrUiRTlz8awtMKU4SQ/hsvFKyzjOzC/edrwfjHwiCx
akmtZ2ORIs0HTkWR8YOd/BG9EhL6ikEFaJwwKV7dYMMuAxCxiNc9h813MZn3D6AmCWmY7iMxnG0q
D8eLguGyI5gXkC2F5DCmgCyn9RlzhN8b+iBMpH8UdepNa4e6wYVxTZ0V8nNSVRcpXGLup+Wyjxyg
In33fzSK4MULqvyMBI1f4p5iq/CJgS/amYuhnKpdakqAeqW0BZAil7un4W/GV0MPU4q99FzjfpUX
hU2zN37VlShZBpx15O/7r56minlOXysn7y8HhCokVodtCxWtITAvzCnbdfYqAfMWglHykGv5uV83
N7fwbh6z2v0yppSW3GTy6w5JkVfttpdQyRavMrdg8OSGUP4vAbVQKCqb88VWIl9GOKPBtUBT2xok
2niFAzQ0hoqZHRpr94lneQyRstiyKvoXC3gVLO90FkzROTpgRM/fWnX4VUomUnmhBKOoIKCKPBbW
5pQH4Ik5c/mCrKFglpaZpWwBFI7zAKWqbrbbxWpzvD3avnmaB8bLJQ9LfKQYhcaaNDd+ejD5Txu+
qADSnoV2TesqzXRYpuqPuFO31xY1ACepK9wETqqLxbYOSHqH80hH+q4tvhVfVTc3lUI2aL7lTR4D
YxJ3vhZqrWgw6x/wKoRNeI0+rQkhT6lR1IdxGinxTLkIDiaDUttoMqwYchRRXk1vdmzV72ozsqbA
oePckDtY+tDD9KoWBE8DiV+k7rs16Hw5//s0J4Sydep7HU/bqFWs/7jmkqBNUgKJ6qsBrqyoRbFu
2twXGRo2ohlMYOaWenq80xygbd94QsOOCjNfxTaXPEICVGWXCoSODtAMlZfPqd+HWifcpJcEGgCv
aqIGhLvkcifgjTA70o1YDXMTUbVwq5ZsE2CKrNAxR7XS3bKuka53v67GhaGVxPwLMFjwQotODaUv
s9NzxMnb/ob2sVyaL/R6sz9EQTqafdQFOoUbUe/uxsTasBAW1lQRkA6PFMpqDU7nx2syTQAjHv7D
ijQktcGlI33WtlVkU5msGPpboz4apJwPEO5TLPo3D/1ru9agBgHCT8YLfY5qt9gbVzGjOi2r0mk/
1TUfgoKyIe2GsFFG5CLqGBFXzya92AUwE+wCQOsoIa0FcZ6Gvizt4jc9YVBhKRq/BEX00O+QJ/CL
qYFENFT3cuI3qotE1RyqfMNqoXNflXGV2E455LwvkOhp5Y4MapDEuxZ4k/0RB6gbr5XXE/odBkhW
dwaSgRwqpdM834/U2jwGvaSrQbdVictL5w+VE9TEFqQ8055OZdCil4xL70hdLiqZVHavnK1Z7qZH
TUwhJtL7ZEX51L33/bf6kEwsbFCuBiMUON+ct3pH1np8AHmmI8IPLGHuu75yYNiJIF3+alZehSJs
LVYaOue4s+kzO4pDlhEFELTj1YZ2HohDnBKAXw/K1dgKyCQkx4ZSN47zALY0eKql7p+Fv7eN9R8d
50QNR6/Ok5nzu0gGF0wSdAkaFsEvzEBeB+vov+HXyrV8k1D57UOiQv3in/Al2dC+mi+AH5Vrll19
QL82ByGbbXG/m5UevsewkaVQyO22cEThf584ciW2NBpiQOdCmayJAHGDvhxrf00vh1w/zTjM3Bhy
oph5CjLYwTZQzXDZ/G8Q3xQMPJHL/dYyuzOyND+69q0tyEOqn8UpKhlHouI5lt64UsnnvEWsOMvQ
rKlvPO51TqK1XZ8Zx16SOKQcLVm9ILO+watxJtHpmkWRNX562BxGhZG+4xDrW4GqDiQtLlDA6wN0
2xG+Tv3uGie0f/uVuIyHwvSZCy+6CHNio45Uq0aUAuNjCTgRN+lNHGu1a8/bD/G42oBWbsVsLG5W
YtCZGkLPQrws78S/udFh9RncUjMZ+jYmtcHuowIA+lnie/sUQXUxMSfLvebU3dZ2CDFEzPw38Zs6
POS0AZf77pidrrxlGt5Xz4+7/mp3f/GI4qTF6imkTNcGvANZgWW82T656iw/tfRCCBkeXxXSGph0
rZvz/8qWCG79VVZjfRcaeo2BVqiafxuhPaUg1raQGtqayu6FSGRsuP+/N7vriWPgjfy3DWpJYC/j
FVaoboq2sZMlGHtTxHE+gi4aoh+4kSFjE0icQEMOOeuQljyJUa+QAZQykpWlKTvCVxPBTl21zuUT
iTdK+bu2rUQteOf1HZN+arN4m4uxqdlcvj0mMGcNL7YibZKs+TFQpy92lLlPjAwpEC+FVHWPTekY
QHRrqF0zRd5XSWY4r0NlcZRfNkBO3EOVteN/HF7+zW8Qj9QBwzdkCCDOCEBmrPTTjhiQZqdmwCO+
ilLrgoHpmA+N5IpYf+F2WPo78VqqFiDzxRxDQNZydV2yRW3EmYMIE+9F1qiwkQs6RsH/A4+EVoFZ
WxJ/rGoL5lo5c6tGGxIygH6jB0NOBjwD0/dRBdziQ16cLn60BcN8SS7VPZqu+C+q8IlPIo8fiIpz
d9XSypDwoFfFKUNFdjvdP3F5H+MQqoJuQ04fHA91WXI7DfI+ES9JWuoRnPcQcbeOi5DlhBfSCBfG
sHh615py4LVJ5a2ZuECUj4UqTAzDA3EnSLC4N9we2uZDXj/RZz/hL6RLyeRd1VSRSW5SI2ajm2H3
LgV40/YESz4o6Argfjwpz2pDijBmZOyKRHUMRUxUyrLumOFDJVsXfkgtUJ61iNxmgCseY9UoPpXL
tzN+paftKCQhZ7WVcR9KmX+BtY4r7wDfOTFQkEehgaEh4qSsBnEzUHNwM9opkxbY5nVWyuIR0Jbh
cRh75z8F53gOt0u2gmw67mrf8tjBd0rF8NDYSJPcMmnTscGQ+FI2SqKHZY0q2H3k5qC1mlLJwxHO
zJI4OJ8KUKKVqw/tN9vaacXCifE3eu4zj6zEBNRD8vZboqni6zYqlrzHNkxeUNyBZ2kkMwJZQHHW
vFcZiTxq4cW5jaFqBzCSVfm//2ArBCOITcuD6AyXfAOXCn/1VbjghZCaxOr2mebyKU/CEPHfwVe1
XNO2SgYh4jzFuUprYCeWtdOJuqGlKOsEfp8dVZ03Me8pZ8Us4lHv6XbOtnUpabg8Yt7uhtGzNeRn
uUEW4M9/VkP7XbFsKD3ZyIAKFWUPTsRvujNk9I4N/1TwJ0+12uRGm1/LxAYq/03PzflqMa7s92kt
Nf20LRWCgGghvN3SvIe9FrfoqKixnVIZEVYp4sZh9BRfLRROCa4W57srCtnB/buLgrKed0CyDTJj
UQx5uzaMwIPKgUgHm6E94NXk9bwmeLW2CWP0Fai76yyLxOGaNFRtjxsGK3Etb6sFvjWHHv2SX7Je
Ik9Kg68+dxxiYL5ktnEvjcztpHT55B3ylvdsy1ubIZnOHGljEUmsSeS2ocIP8t+5wmbD8r/klDl4
G+gIkIgVa69yya9L+dy7R46tzc0eo56ElbhPLBZ99pBEXLouVXTGsk2U64w6MzKFsdmZa6wVI2xQ
oyOpp3LSpXqoo/KrX9MdVd+Q90DeFwH8+mL6GdEnAwVukry8Z3ou0hIIZJi4iyR3J6OHF6dWo4cw
2DNzlAYHYJNDWXnWvba83Sl/Vd7QGmn06zu9pQ1qpJfLj8+JYaQD4k7WJ5UITDHHBNbvbS52va4B
Qnl+XJA4caqy09fgt+RyupWFM9qM9lXZF/uef3rvzuJAzBYm+oPUckKGiy22NaLnVpnJ6+pMY8+d
XkWoB5EQBiiB7Y4VhT2ZPqb6whtCe5IwvJLpZUBBgGKMKwPCy8C0m6TV0yvbdcVu19t9HvWOva6V
+rcLbJLh+dke4lYuJsZ4V95N88iqvvRwlDkZOPRp6y3coy6yeDeauX1KL4GTLLC0tpH8fLYsbhoJ
UECEC09IYoD0UhM1xe4pLK/Yf6ub9297bi0/DgVG5v5gEbe4Xg31tyd5dfsv/LI3jiBjWiJ2kpuf
rrJHGgpklglRcBHOJYwPpWJBGiH38R+YQTZWCK64fSXvlnXB/7Wq7+UbhryBHZELgBNI1FkwoJYg
2OqMoW2RYkLCB9IbVaYsyqYoKowhNjOIoMbXsEE1Oks+N+86z94eM3fPz966GLvi2zMGm6bbVcFq
sxI0lZoZPezMW4jOPKUlB1ay9hHlnEfwAa5BSRt9CJu7HDnpV/sJBHBu21DVmEI2qR6XwcqIEI7O
6Btpr4BdigSq1l5FHdufXz4OEfQf1PNkhIsXkQyRPvm/8+vmBiNK3GaaCmuXH/vMr3lMTDC/cRlK
n9lRmpl7fabcyvNXmAruUKndWL9UM5gwXYDadoB8OyJ0ziHRBhepSVMbMPbePtuzKVJDtDGa+yRy
xZWuxidHyigqnyiPEGNuXu85/xPmra/KrD0gzScXkV3pe8v2IXXjzdYrdl+/g6Pjz4YxpQuwSYjx
XrInzEJFnrcHPd3o7xz7Mw6NlJ////Vy4/y0s1pBmVozQxkDqGsiPDbMuNml+FxUBcHjgBBYisZC
ahxy2VrrtxsgJozLGvnah4q7KHRawNyF9o4EWBAfctekskveKXoH7Uq5FZIqoaC1N+kGVqHZneok
TqwEG9NQwQTwFndEiEdNgX/jvqZ3YtIMQHu4Gon1nyOywZQ+B0tKzaRX06+lvvEua6v6UeMVbVKG
Jmr1XKRPZ+DNZG4v1AgchJug/jzTAzvm9Rc4Q+kZ34JeEgKB9z9RhwfMcZ4W+GcKkvjhTHOAZsh5
xbJPXLiedG+GLcWnMvO4TPcl0swzNn5lef1k4HdlMpPb+VXPOmcOuTEgTgBj8KSjqMzTXq/aQ8Pa
7LQPwnXWmICoBd2x3n8UlSQRgvV9icc+JdeTy0O2u1VTj4OZV6FNWdVFhewAa5XauET6FSzyRxfy
RzQiONTN2F/irIgliQmmmn5RquuEkZf8fW8WMc/VNf/JMDlcfxwkaVS2XpidbmiVDO7r+HCNkeBs
dUSaVvhzplaMdjXpuuAXsvx8EcNi/DXXd7eY2H3iPo5j1Mv7peELx4hBLw6TNLRm2fxHoiXsVOFM
H8iA6JLi193dd0gmHtcqbaBkbG7/FCeuaFpgd9qmz3TUoSpx5FG6To7n3DCcjDr3FIGBrn/xfPWN
BacrH+XUXK7AR2XKACkUyEl3HYjF3XYeht545kykQKv+Xefq++fw5C9Er9mOCnEV0t70PVi9U1Ql
UPxXOJJ5H5k+wi6IhIbeqIrGGifEnP19d2T8P+dc7dYoL4xGjJ0n5C7EVgRM0nT4p/rWWsN9CbOC
r6lhUPy788IXoLsQblHXpTaZ2W2sDvXmbHSZA7MMIz4rc1I0u705Ad4AuQS96tqzfWyhrv8PRqkr
30CQigzcZCe4IC/fVBvG9fjFGYkqQsVIJBJXyP/JFR56J28FudcwX7g6xp9z1orxMACowzbxF6Nb
0krujY6WRe4QfxnGkUS7Ac0zdG1kAAZiZskZNfmPa2Gpz4FfWQS0+nwF5cK+QDcCBPiGJeKmk7/j
fkxxXdARPZmnrMHdSmU5kiPJdWO8CZ7DNkbqGbi0UUULgd8PdhhSwFTHaC61Bx/dW59YwXUmb6QR
FeKpsxkcQVXSEE8rC/pieaedanco580/wQHG82MaZzvgUHU2q74U6G+1D4K5J6VMspq8OXpdCP+o
eToqiRqrhak+Ujfl7C5n61NgoAceYD2sP+KVHGNAIoaKu7G9KWYA1tKDCopSUlhGWyWT9ALlC6x/
uceKKwGiwPAgq/Elarc6kBgcm4dOxyMT5h4NLM6TU/T8d9/1jUwDIG+Pzl5is51fxO5rYBms1iJg
uf8JOH0J+R6idzABTi6JuFADd56EWGsd1abn3lgr0vom3nR3m6yHC+GsQJPb/29QpXLQL4qFifpD
WaMJyDr+en4JRf06gwvJOgATj2Q6kKcmHJLYhJWG6HgK/vHB/lgnx2rxpXjgIVzrgIGzhBEO8uUh
LvsbpZaFW7ze2clLYbZSruEsKSvPVmGqywXG3RbfKUOYl7y4Ce6rvIORcgBCbW9gZ0Fmyeg8dp/1
5q1147kM1im/2eO6nxggzjgsnWfMeK1UyjPam1JKy9dFezJtmUSaNRTC04kJ7HJFi4gZDR+dJIp9
zrQbgm1azyyHzOVV8NWGjAKnjFSk95l6poPc+zW6QWh0cbd6lfY49/I6UNbbHEQXAJfoOfFApzIR
RY4zFtMTiO6/T+BVwYx/RYQm7UB7wrwzcMeGgtTUz3Z3x1hAp8FVKAnhonxVP6Y6CaZT0+2ePTcg
J9B5YgrHo+kNr6V3fV+NJ9kjO2cgDUe/2973vKOLDEHY1/bTqL5thTpk+4xXpSkgYy18rZcXQMAg
0IyZ7li3ieBMJxsVSEC4Yp8lP0+rooG6R0oiTesxjTn44vvxaroyUbUTn9Nz1K2zHzsYwNcq6ugO
hwovnhYDZ+xO2VmsHB+oPDX1P8n29NQFfbTLGI2DYr4EtqQFnRF5vSq5g3KNeMziJhJf6mSWWPVD
IX1eIcGn3wq6sFANjDN3jGhTdgXT9pCNr2NqSOfdlL+OgToCdE6lVN4+o2jPA2b+QBf9VxHpG1iU
NlPXZ5M1MDJw5iCpvX/+6RRmkOxNnYQWWuEortpZqM7mUl5G92SyzIU2gWK/FDzu/PAStImxZVyg
+wmWxlQy30D+gP/aPFmts3KUqyhiZv1CY+1uhrVJ1voRchtnguF+cRb2PxMRrXLVbnstgJVhw6Jf
f2Cz9oz7M63BdUGc1F63gMlg+tff2nDvecurhLEJnFPxC0GYp5fuKqqes0R0/6f3dN3kKUufYcdm
Cm0Nov4dPXs6MiTUNhieWlG9lSl4LQftqPdb4Ne5b+VYNiD/YmCPtLmSr/8MmwIBoGV1J27SbwGw
uwbNBJwIBjk9GoVvAXsanr6qpGobgPAbeUvhFtR0z9rbRc21O1C/c/3H5k4KcCEFCZcOuqUf4TcL
XeUfg5G3yDFAx42ZaEbOEvbHPGua9gNob0kmZcuUuipOedid0JdMxe3aAn395D+kNBSGWn+ylW61
7+nxMAU2w4TCnkDHMZobuWFgOu3lXSZUPp22Wuryfnf0nrJm07C6SCtmfP2vdPl5kHDIhLY4d+fy
R+TfVuh/NnVLjXbLhHIqoOuq2BbLx3X4o4JnlYdd0oCXK0mfkScSH6S63iOn8YrQimMXu6gXHb59
2xVG5CVRm5AyOEXk//+Nzs4jrUSuqXxDtDys7WrVdShxZsBhuorcIOkTB8g8vjXAPp87AXnF2UTp
Gw4ihmzhYf9ktfo75lIIzcCYVi6iLaQLFO1Jez3qdK5vgiKo2/PAA8feyLijXBRiHP7QK1QSjO1k
kH6le4iySfqAK7ChSwjiHJ4R5is+bgFDceYcwfNsA9BFOoCBTaFSJpKYiLvUSw7pvvqytb3p1tZ/
h4teHjL2dVA+Y46QZtrAVN5WVH0m30dpucfqYeQzIX0YWBR8gN72Cbtl+gPqmg973op1BXACglQA
0yPBMl705Rd5ZG3vuZG659kDnXp8hk0aioIIjZ0fQSWRBN5p8R3Hin07hnlluxNYNRXidCnjp2eB
xbwoioK2zx3P2EEqzyAn2YNbMUgiZztMkr/6gkCc8pixSPIvrJWU6PIqHUQkabo+p4hWCl9j69AH
jJfDVgCDqbA+eGQfS3+WgjKHrJMR//BMkgkOfqLkgI2NcPW2Mkvx+jtS/YRzZVcz5cTLtEl3i2UB
of2SchUiN7Yym6V0ioUVNeMy12nR7qj0/rql2wySXmqbhP7tV7xJiCym0mDh7eh2VrxVLoSAozcE
Ix7AmfvMcB6zSjQEknW/6NpMrKlfGfwOF0kdbH1SlqXb0PjnfxdxFzRki2fEncq8+f5LQOy8Q/H6
rXfRVXbDjTzYwSnLvPvngIslENcLf9rtms0K5Yov5sR51RffgTeG05yjKLX1S/juzKYk8k6t4WW4
mx3FIgEyVQwz7vvNidq1kFKg7UM/VD9VKvvZcqmfs6KYidmVIE//lBgfJ3zcfVf8AQADfC2jMD/E
PvpDAWWWurFHXdN1TDIVFSIIjcv4bcysHWUb0qOxOvI9kUVY/KYWkNGtSHHqwUQau6urDp+bfksh
4sYvNEDrY8SLvHfikYgR08pVUs+O0AjLPPfy/kBvO0026ebReYXOEZ+QB9aArs0AeCuRl/IXUVdo
4DM6OzQSYsONNqizxr+jvMDNRlka2V+NlwtDeJ6WTzSAPaR+0n4vjLQrQwMACWFI53+kPOmSZjSe
kxRA48x2hsyciDWkvjtWSo+uLN7Vkkpxr5IYdsK9fra3PaENqeT3+APXPuq0m7hoIADIUzuyeyho
lOzbNfsHeSkQc8nMaGyZNWZ949b0aWS+y5PclsnktlZwlkbbbKJFb9mrNUnP4uz1dBpLOSxH9aHk
aE4gSQzYm5xQy/X3ARlzAGm4z/GXQBBG60+Pt/Sf1IDw5yzSe6eLT6uY+8r+sbtDTOf7Xf+8faRA
HRYb5RirXUsFKv+CY6pseNPcNpYS7HMaai2xcRdc+toBUWqowgdwoH6UY6Ko+z2kNGQAr9VsfuFy
Qj3+KQNPU2oaYv8gAfn8XXSlWhqWkRo1kuMWgFlxmjQcJmgKw6SG3b+kb0fmVWTDllRyjzVkMGGI
5l0skSbPEMiW2W9EtWaRa6KIu2r27oLeelWlrRb0uLzenRzGZe57Od1Pj07GvlMNrRf13wBJSSPj
G6R2havQwjzWt5Lpo1C+6oEoZ0jtBurmFR8hON3r0r3f6qZE2vlK9bbpEVTZe4tsweEv1VFid8cl
Vx5eFLVKQis6bsZ0yqo03wKaCUy2sOVvBpazRmaKp9NFFxlbDz+kd4vdaX1Kaf3A/7pASlukGWLN
FSh6l8+fDokIJXuIiLWqy/QYoUUvul7ERhzj4fWRET6/N74558eFefil695eoSHEqUkf7yOHKDvY
F84E3LDiZ9Z2t/3RS7rD2+lPL+7UuGZJZzQGUYcC7EF5KtmEaothj7vrIy8Kj3uZhCQaWEZBMkv2
yeB8a8M1gha24Gc4Uy5KkyDLMkeDeh0t+sI+xYIxdugPFyRo2dVKA/pk3gbIknnAhkHEA5fC2I82
FJG9UClextD3RkZn/NYMFhiG8bIqcDji9vLQNQV6yr+U9l8/WlPTT1M5sMoAYrI/MkKAM4XulIhm
7es48CulcHDUVBSDjgJsH05hdssNOxh04vfkbZd/MbkTZJ1OWZHAqHdQxfMwX87qK6EUuCF+cEB5
AkstgrNCrBeCDoPKtwlgIMleim5+nlIVHdprPmsNKNVOMYUNRXNYLFGoxfDJShiwmZip7MNiz/dQ
HcaO+cLVe7FSGgXaGmAIPzNccBeL9qUA+Psh2eUBfXWUEKl4CYdPMpFOk0zzzTIa33UEYr+PIo3t
g8R/Xl97Hnj8d+1lKs9A63LNZtsMnlzmLZFGyJUtCEUPbDYXbWUVrqDcy7wcUib3677X/2JmrIJb
gPNDmuTyRO2tqMbg1t1b9kxEKkbD0DJrgXd8A9FzckBJBNjtyxZpewRszJO+bevAJC8v58sjkBpA
tXzPkwU/m+iDYQCA3ZK5iggvw04XmiaCNg3OaiEju49aZQEXcEdfLyx7p030E9izoW2EOJK9zmRD
UFpR7Is/nVJkN1/CFV7xDc4X6ZF0xvFQJu9Np1biGu13pVQtIH5SSZRzNQbPgynOSo91uQMLQ4wM
S7BKtvVY/f4Wuxg9nZdZmekcERcJrYrtYJvaXXqX95vgdw+afNBvJiP+1vaXcssEmJ5IbDXcnSbH
E2cz9VOMEersknOLRaYIF0owqCp+7/PEGvB6nL1JzPzHW25uMPgCTKbLm5c77/I3qfiJ12mwoiru
4hRgDi36tlspo2OIYORLKk2OgOn6VKNE3NBQ8aaiOkfCW2OlZqQ6IhP59xthVCFdOuqeCDRP5FFQ
Gu9G4jns0wMPCNSGLSEcdb7bemC9eh9pTvslUi8G0AZO+WV/bnYv3qYwEviadFA9yzmKMtYJhRX7
x1aejPjc56ir27YJOzXnQ9YyzZ6Txdcxfh4+dfhfC7i6QiiTltUKlrJxnyH9mmUlL4I4bTRkTXsy
sSUiV0NNBsTxLo16oLekMRGW0eC9cEL/gz9IIzBnm6oIzmjqSzggD0SKyoT+Y2pQUQiaoHihotjH
6dgHQQmopxQ1tvFuZzF3Mb6bKHeLEn1FHthLPV8CmFk0AT0BfoAHwTbAoQk9uBJ+LVeK2iecNnX9
ZJCwvtY/+lqwiCJWPqU8WA+H/LYo5KjHVpQKF0pTfuADMydbPgKwl2mlBugcLwSyuxl0GtY6IR3C
3Nmf9wSvTHiT5P0F3Bpl5mza5jngnKwD9XRkIQLI4AQI9UGhpn46QTqFl6pQfIBgsCWpXuAc3R/z
zlsF9folhamrXh4ggbbce7MAioAI44e8VuBS0RlHueu7ZsV77QxVWuGLP0FWWS+gXOXjn97S+AXs
vHvIByn6sjsuEfi45V6nEUN31FbCcalBKm3WAA+TMARHV06QhWpTuIlJzMs4/21NucI4P75pNctF
7d5MgtMpZ/9ih4PK/7kEaU9yUZkMoPI6Dltj+ZukSHuZ2Ia52QmZn62qEiet2SdnAd3KIhKGyKdE
x7/DPYyoJU3u0tuFBU6pj42/0UH2/ysoxUrMQkw2kSUjsqRGNH2whEna2bCqlv3JwZ9wWffvH5kT
s2ByTFQuDKK+gCKq1gkdzedzWItMIsJ29geVbO6X2gi2rajp+0zOq2SyFRXLg/dnHjqFDIvGOhxw
lnrPmvSNU7zHgQUnodiT0JXSYTcLLrutEQv9mk69F0c5cnEhWkkAiykvN5OjqR0YIzt3BVYVt4eN
F+syF6+RKaQji/bcdkirwsVFJsBpqnper8YBFCg7GqfcG6n5AY2h7Ur5d1mV+yBdxGjK+KflG/73
FcAcQYLq1rvBPIEzWtcROMm6QhowQAtbccGYlpuwzXa9FR9aAY101nfNI7bF2VXMJihH951WPh+Q
Z2I4nr4fy4wL7ji8lDOJ04R8xkVQW2rsd4J8syM7ftKEA1C6w69pm4e8bDys6aaRpdaZYzfOxCaI
IIcrq8KGydOYm0i/h64FmK0CURuDrKoE8M3auDsn9le4eJO1jEEOvaL04Sq1xAXmfcbEp8gcr3s4
o6Cg8G1AAQ2kDNf6UoLou8pCJFih4dH0OenEWGyzFqcGJPso3qmFA/1u6rStFPuv/qnvuFUsB6dN
VLiz6UeF4H2upPVaIC7WM0jTbGTwCk8hHXnlYgaIXKusOj48MpWB3ickcofXSl4qVkdM1zsabW8z
IoNsKKalYJkb58QA/ixiduqM46vWZGii09FIyqJ1opNKVZCakHrNOx8jL78p/WD6mlPeZ+ODKEja
d/qQN/EjW5aLDyptLRGc3IdoJO/7zs0cEwOzI1vYhwCAfvxaUQj6KkMn+retG8SsLSSqFAYmiQN3
73ZkcFwQ1KDSQrJdvIvjXnibCOg0a0zQ7utp03JxQdj+ebdiqDJA5T52/QIWxr93cWZd9GHbk+dX
6jjIf6lYNmn3zppx0/SnF2E7dApYXYaKyUpP1YC4SZvDEA2RcTDvdd049PmpEegyDcajt7NKAYkl
YMfyqvFOT5W7+QfrYps3148G0wyiQ9NeWOVivFg+UoInW6J/rdIlhOPtwJW0qd1o/wUFHLm1wXB8
OXmmxCU+D2r5rqabFGtryGtHdPqiSivgNW9E/Uh3umKK9HoWYvNCRTj+31D+OHXBCRtsOrSzd415
I8K+SudqkhkcHKXjposeLlRcGigDUe7LYzYB11cYIpFkEBvAI2gHNsJRHvujnoWEYDN+btVt1+hH
luTr+4a3SgrQSSTjwgAS+e4L5j+57CF0w6uJy4EwFJ5OIw81T7uhwZ5xeeku6OTnHTAyUONpsV9k
rqEBoXfuvhY7NZRBsZL9MVGlBTMVs22jrWtJAoTx6LMbV1ffVUvyM+r60wFoxqKys9Y9+2l8Nkk1
TA3CRevkjsLoKY+QLGMXnUJ5U6qkySrkXopZLy3m4FWHutcfnqNo8e3RThd8n0PNz/L8WjifHZob
Dwl/bEgKaCE8k5Wawzelx47F7jpcjBB57ECPAJ6cA+u2Ybj9YUmyb4x0aPwM0Dz4wfQVV/ciebVV
XLoYuwv4+Mpi5cbkqvdXtXm095w6ZUYeCQ/rErjaMbxMzOqWCqdZwMqJ75naHS8eSLDvd6OWhAxv
vim2wlz8MLSRYLfpY+7kuVufXgdLsmKvNtpOswCqXN6tdtVYhhPNJbD7gB5MP5Ffd//cVsATwMSa
bX9HXNNuvhVWl1Thdx2l6aUDLMwhBVypaaZy/BTzYbcF/di1EK3OglP7vLiYE5ewsI/8kiYUHTPm
rzxDQINp012JmiUfhleBuJdo3vIKAyqz4Y3CY+IRNgAC1b7wlPmrL1TJam4/lTIDrXFKOuQtCLHz
4d8gNsCmSLSDt2XUgIm7m2DP5BjoX0uaAREYva6syzFPeaPvx+0PPnuHn5KlwCRL9PNGOC59NHVw
WKv0goUQyW+vCr3TfW/jcBBdaCaSLW9me2txDDtwiDQgSH01IzSxYplox1uULhOQhpmrRiPGK/VD
nVOAIpCe7CPcqdb626QSaRNJEW97fup28teslSOPo06EeRTQB+pU6lQS/pYixJjTpdAuyXPPV6Md
W4BJ1aEx+bz494kqy5/T12Lxv0M1
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
