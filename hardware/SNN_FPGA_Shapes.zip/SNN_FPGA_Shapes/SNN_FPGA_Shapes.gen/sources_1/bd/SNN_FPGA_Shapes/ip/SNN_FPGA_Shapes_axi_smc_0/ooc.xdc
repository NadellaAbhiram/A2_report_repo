# aclk {FREQ_HZ 83333336 CLK_DOMAIN SNN_FPGA_Shapes_processing_system7_0_0_FCLK_CLK0 PHASE 0.0}
# Clock Domain: SNN_FPGA_Shapes_processing_system7_0_0_FCLK_CLK0
create_clock -name aclk -period 12.000 [get_ports aclk]
# Generated clocks
