// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Thu Nov 19 23:34:32 2026
// Host        : Nadella running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0_sim_netlist.v
// Design      : SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "SNN_FPGA_Shapes_axi_bram_ctrl_0_bram_0,blk_mem_gen_v8_4_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_13,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    rsta,
    ena,
    wea,
    addra,
    dina,
    douta,
    rsta_busy);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE BRAM_CTRL, READ_WRITE_MODE READ_WRITE, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA RST" *) input rsta;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [3:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [31:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [31:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;
  output rsta_busy;

  wire [31:0]addra;
  wire clka;
  wire [31:0]dina;
  wire [31:0]douta;
  wire ena;
  wire rsta;
  wire rsta_busy;
  wire [3:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [31:0]NLW_U0_doutb_UNCONNECTED;
  wire [31:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "32" *) 
  (* C_ADDRB_WIDTH = "32" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "8" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "0" *) 
  (* C_COUNT_36K_BRAM = "2" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "1" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "1" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     5.3746 mW" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "1" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "NONE" *) 
  (* C_INIT_FILE_NAME = "no_coe_file_loaded" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "0" *) 
  (* C_MEMORY_OPTIMIZATION = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "2048" *) 
  (* C_READ_DEPTH_B = "2048" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "32" *) 
  (* C_READ_WIDTH_B = "32" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "1" *) 
  (* C_USE_BYTE_WEA = "1" *) 
  (* C_USE_BYTE_WEB = "1" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "4" *) 
  (* C_WEB_WIDTH = "4" *) 
  (* C_WRITE_DEPTH_A = "2048" *) 
  (* C_WRITE_DEPTH_B = "2048" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "32" *) 
  (* C_WRITE_WIDTH_B = "32" *) 
  (* C_XDEVICEFAMILY = "zynq" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_13 U0
       (.addra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addra[12:2],1'b0,1'b0}),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[31:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[31:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(rsta),
        .rsta_busy(rsta_busy),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[31:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[31:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web({1'b0,1'b0,1'b0,1'b0}));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2026.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
kZgFhM2d/jlaPzxpf6XHBAvY3udA2n90sVrL5ios3dCU6DHMG01BptGv7AEkMGv1nBWc9wOv8Ao5
MO+RYUWfJloAgvE9oz3EJHrmhQHk1oDdQ/EpnejIRbEZCjmfHUEI21gyKS6oLdkyx2gHs3HX+wks
75MnE8jDP5XEe0wRk70=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CotVlRfEkpF8whBUKgocdcjhKyrcMEGPZvHkGVHISj+GCXwa3Gdeme07eFJpz/ZotBRm0H+nvk9U
c+cu76zAYcGZA4BB8k5S5CN9te+cdcMud4cLzxM3NWHdGuMLRnzIf+YH7ADhhyN/3GRT3GlBC9un
8gg46/rnawNHyJnmhY8sUwhYJFSC6Zp+YpCreJEMMsSSR0D4CM0VZx3eT8IWhFsOz6ekLOhifcRk
JdWdOdywGnTqpOq97/LmRPbfEGBiYB5YDEex+rP8S+WkdfZSRXRcMfIMDifCL2F9vyvALaXXU/HK
kczWE+R+OoMRMGX7ipHLpx7Q08Lk2uu9pJiE9Q==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
tZnJNN2Qmv8npxJcsUh1oNo5AcwWv4Go3b6+WqtB8cYERd3tAiuYpzM9E8x0/NSOgU2lO+XGGWqL
PXOFRGE6+vT9Uw+MMZ7IhiFhNUxakIUv/kmA/Kpo9+5Y8aWN581krtWN9KT8/ccdMg7//qZ5aT8D
c323EB+407vCn2c62Ug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
KKZGVVr56cxydgpa10+BIppw9vsPylE78OMiTW7WTk1ML6QnGGk6Ufm83Q5BYCGjf79wKt+EDVr2
Faz5O4p7NqDjYc+6UH+r3tYhzg8ax3QQ/lL0h4ROXjjznYZN4GT3jpmEVd5M9uz0VZRUklNggvzs
aHgFve9gt7F5cG1cwxr+CFWUfKcsH6XCTrNM3UP1/Ye33LxT6qzhZVuCb4w1zybXO9K1HZRARNeE
XmaMeB1MHLiswqCVSWCi3ahqMoTIL8Nkwb7LISvYxN88qxMca/sR/Y59W48DrGDRBBzZ48hIpVXK
9wpPb6wF5zA03FsVqRSc5JxQzfKhTSxAnXSVMA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ywVnQUL8hRlFZUGP9Kpsx7UfX2m6K2oMp1dIrzsl1e7ahG0jDMr0uZjciYiQvVpl++f7jBR3qTGo
/E63+MEs3aH3oSmrd0H/Etz+j2FU3ASZNwvS98uACXUBPzAeEwFUuJ9/8jqLJsiNybXigf8spDDy
xB/JnUfJl4/mmyClxySXyscK3aOnErzAZ9B9i8PeHPttmRn6onzR+wukt29Z0ETtVcyKKb9JQeO5
4ipDn79/o1IPYLzFyyiP5/oKUP/4zmX/6pbiO6bdzi2kdrhBtRE6ztlUGTI0WBHPOO+nZcIlF5S4
jckQo17l4fcqBJC8p6S7fb4eyfp+IU8PFj6wDQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GUQu/hEzrCx6whrKX9cnRKGYwu/EkGwKC+5ZIAahvY/upngQfvNVWyz4hLS5Q+jQdoupTTPWruY8
5QnccTfRLO/UNkPmbg8atB4asCjrKgLIhzPG1pqhoH9BtKKby74jLu4vyRH0Hk9XOXkAXLos7eBX
Nudw/vzxy74RzWXjstE5NRhMqfXi+jrP7VLV+NT9AN7PZQ8SsVifNwD2P2HwGzqQT/beYW8LvNbr
bRbtDAwcCcJomfkUvNb4pYE7MuJK22aox2ar8nUAviLnxnmy/ASVSGou0mCxgkZKW88UP70HDIhl
aueFj0IyK2H6IPJM9GCgGAwEeA0w0rzI7faPlg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YHSFaIRKyhIVU+ZO/EyZESP/nTM928AcWJGbKx6Nxkm8PEl7yBr3z8S8G0MbToKUpAO14Ei843y2
QSES26grec+g5bQHTjG1w5mR0gi3IRbGAT8ctIbI6qe8HxLmMViuDiYNb2JRHPBhpGjx1o9s0K53
1FVtSLcIMPdvZ6vGzYYlswxXiOA7D0qdnIFeJXb/6BzeYM/ZSO3kXFNYZVuhaNU0AcFxQzxAe/sK
lx5QdNGpyfexd+UnTCdHIul+eFr91+gTUaOVHDR7qvAiX+c3k+nbn4d1gBOExbPG5xXxO9QzpWZH
pkGcv5/2mmPVGGa6bx1rd+/wxxqJYs2r4GBQhQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
SuOFRD2tIt83R5vOz6fwY9Uj1WJom9jlw00FrgpAa9zzHh8NDaN1pvHliEpw0RI/EXGai+RqFTtv
ODI2Qchq2R+Ohalo8v9B//WzHrQEoZOqY8ExEpKNbhp2IJiwsZKz4enjUze+QgFiZFFBQSuEtvRx
6PvI0tTjXp4d4nJZP6HbKHFzj2SEggoTEvkYm2QqrEIRu3HQ9cXOaM9B77eWbQvHHj8yGYRw4A5u
Grwq5j0VzH8/eaysSLlB32jy65hpz1XiigFMnu01jNTA/Fh2qkMYpJeiiityiftiHDGBeEi78AUU
DCNlSbHo0NgXbyxwgV82OqxM0bTJUXK6Gh6/8xgla6TEAub1vTzQH5Uche+S6QnV24o6ll5HwYyV
RoBr27Aj0mceN3MNqSTnsoEMthFh1MLmp0imxgG/6NjNFKABJTDuaGPLE9XjU59knvKP1VKk9Fp5
rI7Y3IvGFhu0bHKEhV60LLTosXWr9gzS3uKCMCb0T38cAx5GX6FcChb0

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
WC3gV9hDsJlJGDWXD9/OXXBzEn6vsr7+oOdKz7gm4Rk/FFR50y93jhYmcWd1K2InGg42AOhIHo2Z
TvhSjky9Smc6kaftDv0qbAD/y3awUgVWMhvanfJnlEuAZfoFEJGwGr9jYg55AvfvuX1rQTtKoUFi
ACZ7pJVaLnkCKFVPNuhRAQxCs7KLW7cG1ALcdtOdnRrcG3bh4dHzct2JzL2/VK03C8gPKr3uM6DE
9O0lltoTf/AzP3jfV2LZekZChJx+UY4WWMhnVCiQKoa9voReSAKbrxHl/hqJvWQiYa6CFpABdUpX
fjEHVkVIdpnVpslTz0sOxXMvpxX7F8T6O5KvOA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Iqc6J3NDm5J0Ukvjev1H/S4Q4RmJahnBq0A8nClyXeu33t4xanh+aGq3+WcR0KQRtSZvQDrbXWvy
VpRaHzQu/lgwraB5780gv5qhqt1D3uYyerl5fx6fl2ozWlr8yZKs/qaDlktEWGF0MPUsJuYE6ZcM
72yOpO5/ynMUgwJs9FVcK5pRasgkXgOUeN1tA6mmLAiYCor4CtxoB2CGVa0z1Xsrai6cNrXCDd8I
D1f10kYi4ICIsU7uhC3hLMQ66OSpgzGDdHUq52hVB7ESc7B/fk4nrcm0mSK0cPc0un7O8vvvykdb
kA7qDovHJqWd0VWle0m3J0DvA2pKJUU4AmG51A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Y+N5GKAwdOuN9nS/lU52Y4ZNhFpP5Eg6jiLvP1rQk7jt7v332HLd3dDgIcKOvTZ+cT2qc/fEH3km
qRW6R6MDwiTEv5NDgR96180FbWhHKmyQ/AZmvgAhcSnKARj27eDEkTFcUfN+RgRNycooCPjQ2LvE
RAHSYS+ob7G8GxymUfgoG2pJ1BZF8n98Yv+Aj+fx3pPWyFx63XYQu0VIla5KV1WkhDxakW9v4pJh
kWzHMGwdhrs9q2KAQjFgZaDXVv5oFd/wcJWXkvkbsRdm3Ok9s3OwuaW9LsKnBGReVg6ii5BR+7Za
9w0kFZHcWjmf5ns8L/rFEzHcIGqE15ZlLKYekg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 52848)
`pragma protect data_block
FUUTXTHlvh0XKxFXYOIUYz3urex9U5tmYnIxGxOgi999Jlnf/VX9rL9EIlqeyMbGBWDJaIMscbcA
uD1ysrFCiY9pmwO03O/2tvihofXYKHiuk2+OJkbMFohu5AA5Tpbo6fz1h+hfh4kqrzMEMp1VZgNJ
AM/2RyIgmffAa49jd0KbVkVeaqJ8LQPXItvrGjsB+gQwXDlZexN/Qape2Fq1Na9FY5US3v/DsKfo
tag7WDHM89IWLzMeX1AW0qAC3YyzSOyce3qHtaMuZht/d01pyqPRcHeYpN/O4YXNKiQJ/V4aW7uE
pQuWJyBEZvaOTZe1CE0zcH6lg8QhQfU8Ggh/kQ/jkLQMaavr9YAUT3Mp2iX6JfD1iT6zHz+9v5f3
/MPoM3urOQmCE3EFbeNpQmC25MmYNuupNGyg4LyfNyMJgVTPziPJuJ/sgnGlSDvVpE9vF9f8LTSM
SNqiqb3pvraQpqdRyt+z6xRqNO+LmbDzLWz2n7amjnS7Bx55bpEO2O6HH6Hj4pV/Hfta3j59B6Jv
WEDY7agNrE1s9uxEV06DlrCitFFjavdUOzAlyjdSCHJ7JqBqTwfXfWK6SmGstgGZOZ10rS5hqugw
xxtc+FQPNX0kp/1zNsLu4KBB4YZW/7L2pZvjVNX3gLc1rkKHlHhXj8SuBQ0DsJdQpWihAoFeO5T2
cko/mDYSSK12iSRbY1QEBED7DpcF5Tz6/I8DEPIMAqUumYgdwo8F2+9G8UVa6khST2llxC108lx9
LVG8Gn8jtyeUd3TM5GHoF+w0CTJN9eAi8X9qDJuTPX+62PLBy8B6V9N8qXbEXVubiTrj16Jlqf+k
TdARO0GsF8KW/8b26eEEyb+0LJKD38T2cxJVPt1sjj9mXiWeHgnjsxlKK1m3FwJwGUz8mMIO60qC
nK65tjhlumz92lsHGAbkaR1lYDUtD3PKMZViOLqvG/+6h82lS/2Dyd4Ukk5E4OMPdsg0Vru1pld7
O4P2eo2rbwCLuC6vKEPrgSoFQadpLnqTomjgRYrJmkfqF4unLNDVU31TMJSEVpXYkVDAgQ7x1FPU
YbPmrQXwa7+iU02QyYEM6UkZN3JYwjuMoVA0DtDsJ5q/3OPFqJyPH0t/OJZX6keLLOU/tjxZiuqc
y4oS/85lqdVkf/ddW+kOwIwnbmMTfhWgthfJ8Op991GkdYdmwBKq5IK06y3ekLhHaWW71ZlAKiSG
MX+WhfdsSnr5O6PmPAUj9hABPRcuEhtc7VS3LN23NscVNEFKH886BPkhSjsvUyHzEVQ8OsFWIyRZ
/SnTzQWoVV+kkCvNxz+U6aG2EpfuLVIObkDMqhm8MxRFM1+xTkoP7WLrF4Ctbj2w/pNgJiscfBec
wDAA6r4jjMMADAPIQJu3f4lpWRjIfURipTqbYXrIBQNGrksPpW2XaBXq4PIoH3eMB0wmgG4lHIUA
NCeGmAJiyelv5GAKPTNt++GaH6gU31p+EBMzgLEMdJVmJY7YS2PtLJUSQWNdTfPQXaEjiYjKFGEK
OTgSvZLaRI0y6icEoOxg93kj2blpUa2mmMnL3ytkB/sL79wgfnYVoABn4ZTA7pnptkOoTFF0SyzY
6gRFKIu9Xa0XZHpzSKlAjh33QelJrta5iuHkVp3ehf7yKKrTU5Nc0UeSs8hAOfMtybVLB3NXq2J9
/a5gm8pkjmdorprHhE/TR6fbAIofppSvuhoOFuSi+bbF5lbtzlH21mSCuu18cONK/0fQDQuhOfTC
m1XBeLjaGT1G5TdlPl2eS5iwqbFsXdRsyZ0Zt7essM/YHyn9XLOacnUpKENNBhUz/VHsKV9wCB0S
t0DgHReG8E/LgrHZ25f9JObJd8Yn7VudYEXFqBhvXkdK1FYpj3hekl2vycTFbz/JrXq1cwhzK/X2
37eLWymHJCPOnuRUJ7vRcVXYzyvgRj/beO/IL+mnRKBOm7tNlBbj3UDWg7QCCOtEBLCxWqVNmK2s
EpubLSl9ISzlLS5xO0HmL06RxAWKQYqPdGQqBFatm1ZPXO12vVDPt76/S5SOMFpWduuf0ZJZniHg
HsS00KaV0f1+flgT8fuLEqA9bG1RHU0DHQ1f6bl2kD5gbe84n20G/6pPZO2SaJDZHWvgmjKFQazO
WlDMazm7LHxcS2/5uokuK7F6XrCDP1Gp2t+xP0fLBl/nyLlDwImGHeMpLNEqd7r5GOj1kM3g8EhK
sPQLVyHS5LzdKqhcBXaIMrCpFiwbx8g2Y9q+uaS8wX0g1N1w2AECXm0r1NyYfK/PQhBzso+ALrAb
ABeve6Lij4aNpTGqfAR5R0u0G37h9gYg3ZuoVt6AoBH4rEWWdZGNfS9QXd0U7EWy/+aN+oT/u64G
uBubfZo6qRpgKKbY/ISRkUV5/QCOzf9/HDyg5Wt6ggJsMZ5NKbirhnMtP7C+K7lH0hd+P6C7uPfN
MjaXTW7G9DuydXv96aRjOUDx4Aj3fqwwjdMsw63Wu5eBYER3Lk8OxMkBDbi+iPUm7sIU7QxzKB4Y
UEyf7v3kGVdmN0+U861kmQTSNLp1Y0mrXLQYojUsXZApno5dBoUQAc6J0jTNEBIExU0Af1PCKN7O
S5rEmBCS2C2qcdF32mP1EhQ+zaOZp9tEMioq6+McAq4NXMRWiixSPEV24dCP8bsSeMTJ1CIvSEt3
UVR0drGYqLvqGaY1Ofmz4KfT8eSjtzxS9w+MRPSdW6V3p/j2D6xOR6flLYX+AFPYN3DZpZlg+WDS
Wazcmr+iQHipywfZTP8pJE3TvrqMdfC3Ds9YstyXwYmUmeZrei0yuDNYODJQNu593PPpWvyq3Xqp
RC5RE74pyKMDcfjE9p8F8OaImZG1yaUlRSZgWEQPvXrdxOW1e+E4RC4NmkedN/+Ft/KUzt4ocfKM
n5Id4bLpPaP7w2zU/AAgvbdd7exj/T8dTdrE30/2M7nm2CuijA6zhWHU/s2vlTl3bjUlorN8Is05
s9nmAJq+P8qrFvrqXBaYSmR3g8WNOkNPvqUvY+6otP1IlF7JLbr+6Z+ne948KOc3fOppjrMwCcX0
/SuybNYJhdAazFLwzvBohWyW3Q16Ugqortb/FoCqmO0q8lHcHwAxT1vkkTI1ROSvK5qsVXq0Qhqs
I/h5W/bEFg/THW1iRS7lEzcBEA4v2I1aglr3Ms/hrrj/fUe2sL88g7A9KuLweKvSxhxkaivcuatD
7EevR71m35YBCA1kbbI28WZj/rojxuSOjRZFoz5jNz5bpPQxsNxPh+TYHLYE3tCL5+N0495jWjre
ZlPKbrjLXkjPDyWOFHmDDbigzGCcTK4/ggITm4Urt8ndhCha4+99bDj6uUV7GwfwsHVt2GKCMWSQ
JShNWJS7XqKvfdtzP7PLOUTqpSa01mZ1O9ZfVmC0wGHS54Q+Hpbh0y5wBJVSttdIq1trjGGBUsIC
LASAndMBt+mhvAINxICLtcy9FDPawJAyH0XWzFanuMchNBE4Rb6CONUu/5jwXM7kz0F0bQx+LlhG
rXICiVp7nS0ORqi2fUTH4oEnbaOAEFWZIriXSuaLCo25vGpnGixDJta4YThVbQW2e5Pmzz2lrG+X
nBpsKjkXqpEj0v9HflaUrRdU1fk9G0gJBZMV+Nysq1R6DtherPT3C6CsfjMrg7QyKuA9GY0uz8h4
WROA+MMDP4y/rFCCucekK4cEafPW10Vii9JWsE+NpvDyQnDgFD8h4QWb5QuAdUFdkpc/jYdP4cUr
yb8+0IsVo3nnxQY/wq3VxfKBKFD0CqvHZgaBwc9oQrgip+QblvOa633xP/46o0scgxw7UGQ38rt5
Aa8hFy2UPRe7IQjWWvskuZeSgjO7qH5mwTn8syd47E20MieRegZSewqpuEIaWaSrzhu/dwbO0L4s
LUfvUWPhZycR4U1K5FLWdAe2XEDo+Qq4FktyVqDdxacQUYbubzpA+Nw4gdT3Aw1BxCUqCJ6T1uIF
AV5fRzDxUx39xQsynI+0fEs6j7g30cpovmOqpL6tScdbQ2wVB3qum8uPKkuuW4HkW9ZhLq9z2Bl5
uWz/vIXluqe8jvoHmPAesTjoYTTHP1Te6dssIXM9sFr4jw3Hro6n2UTkAF9CaDeBGGVPpFhCKLsB
N9tGd1yom3CA61+q71HbSmWLtuk/osLC7AkpAW7IDJDKfHSXuOCHViCbZXD2qlBDCJ4j7rs7lC9O
pCpzVI0UxiRCOyEdkEbXqiw9r4bWjSc6yOZkUYnRV979ExnhfbocztlOMsbxwyfi3JnjZVm9w3vx
GTLBW4AZNGlJgzD7gQdX1JXEG4p87bJqlI+/j1Cd+A2X8d+n/BZJ64hANYbQNsGaVI4RfT5Tgz60
JPTokv8LXVkbdzgFg88YcRm2Z0X0374FM3GeXOzoH5ZWHUcvd+B9Ujj6MOSF+gz4vEqyUDQYFb2V
428tpe+3uda9DUccTunmvPfegEpeSaqEV2vdW2krFr8mYnELQ7ap4S/e7x/YqOr7TIp/kmCSi/pf
ejkoeoIrxkbqIvOOpQGugmNivo/L0O8yD9yxXxAI/skF2TE87T0/UN8CMEMz4Vjf3u9kJ65sUFG3
spz6z8ZNFFGUBMnTsh5d4UkBienSuFaWkAJGHF/eOwPSjOWLEygFmT8KxfI/xW7Tso3+c18HxbeE
FXdCHkc9NtVA0yYTcTPeC5jnxACZPdRthtmQcMMTanS5jyOWGysLE9qC82ZJNDctTBhVeEHq5ho1
FY20xavz/veRpH4UKocNAe7M2LkIwac5FlMVQc8i3if552Sr/fgccD06rJuYn20B0av0R8nIXk8B
lVl/XITm/LXFT11GrrLlI09kEtEKeL3GrGrPqZjjE5CjcyRfuZjDrAsIYfVrlxRQU8IfCinHNvnS
OCM84RCRTKFoxNTMDgxG3dGkd8WlY1755bPtl9NGvmaNScqjKqQhS3AqALUBQGKWfDImULrCpxWY
V1/dx3RCG8LYtM5PFFcDQXVE4DSjwZoVb4xo3KpaaiOzv1RQxxv1cmhkyeUc/ZQoZSyv94ddExie
Uws7t1u8BKxb2Zj+OpkQcjHwSTTkUuT82yAzhkdOT+hx9oxLGYva+i7SDuQIUfocc2H1pLpwRBVG
841MoDeXaNzFDDokpStbcsfM5W72i0ro7LWhVNx2UWHeJnuzYNmfs978ybuDcslifR87if2HbYja
NshfniOHMZAWWuMls30v3b8/zQGZUMcZPH+6GczExCi7wGBIkObRRPXJHq6eYUy2qVHOoh48cdRR
I6OvDdKt5ygfKojumQ9iiHSXrisV9pueFdFncXc/dLLFlNqHXA6qDsBUNQXSit+psI2FD5V9UZB3
U1M/5bVjxHgXHEltl0l0akQ7T+Dctg8wPAsZWq6AUuDFe1eLWuYJSRthSG5aZYAGjMIVlTmCnKK8
oKfSpxiULMSkhn/ovBSAYHfE4FNRMIcH9llQ8hohtlzDVUjh0ECBjg+ZkE+Yyt+8FMV//zwW2/qf
+lSlNO/CmgVYzTegzk3aYnVBGDJCte2MTzi9JP4mjexooXqOeHYTuqQI41mLKt28Wnqus3lwSi9z
c/uWM+YdnxBFX30AxN6KZ4icACyAMeBwF8dU8I5McpwxbpMAcMKf9SRPz7nxrB9NkOMrz1459gIN
byzLxUU+e+e0DrpTG8eeOGcLiYulrcy5dh/n2T7V7BUjNIEarNA0POIcmYiGkwOZdfDT1LMnkUL9
GMa2JFuNTvNrb3cZ63Cju8qfQvvD37HJgl+gOcffdDKrdFyYJENbYIxYK9GuMXMWrX3Y8yNwo2O1
MkIwQq4rWHz8Gz+D62YYVYhuTM95Sfnc+wgZuNBghU+8n6nVLYXgNzPqBI3oAEIVDRH6Hq6+cmFb
BRBqOiJ6MQ9ZsNxoltUxQwfAzzE8Ny0uAskfySrMc88rvv3A6mlrRXsdTgkUThUAsSQ77GkYfvht
Pn5VdyZlkE/RreEZa6geM+SNQA3EWBXAH1+Oh1sJNARQuJRCXP8XIpniLd5LGyww1sKBoRawYBJq
Bed+GTEyR/4A0PiXJ3phB2CXWEu3wRSsnf/JOUxvBLO64GHCLcqXKfYCAY2ARTxLBHU64nzhbcGf
Hzbtik/tCl3UQCGRVTFLJ63q2EzaDrIJ0Odc+Ys0jxI2jKKhuYpTOPcxjQoDkmTkHV0cbcAMyFlq
bnRx4mLpb9DqUbHRyZkR1rrk2dPec/ooiMP8ba3/viPfCP21np/BvKX5/3d029OamKQaRqaERqip
Wb/PhmMp+YPR36UT9SbCZuKukh2pkrvzETxcdW7c+j/5xH3CUxhWeuHyaiyRKXELDtQfWpobqQMA
eLT6IrZE7JZG981SIscdj/z5V6ZpCcuvidNWlBtomp3MMfD5WqMe3BtvjfQQ9ixEMzvOmWS7O3/F
8Oqmqh3zeeiP4t7Sq+r8i3/vh/O/MRu8DdD/x7htcEj/8V43l497mcLW3bjXrWiaDFqmMlRVrTgm
F1Bj2kduP7zalSAxtsYIt/bspT62ZItvLaOUFA4RCvdlMVLG9p5SzYEP0EOETgSnMcwGK1u/2m+K
dyDt2A/7b/7iawCpsemiw1083fAti/2QANlJZF0Bv0bilAQ4ySxb7ICHwkqIw9AE6jU1A0/9XrtR
nOkwVunbhOPalGOxLdV0mzbee4jFccRD2/Pd4jy30kqlaRGeeMF/JbeaZINlTeOH3IauBTxg9b4B
Egr69SoG3I1LBGFvJVyvBdflTq9LgaSxn+LBUVRnBGs1n6DMYKplaSLEGbwgUXeIe7GONkLJ9EPf
/CY7Mh/+NDYLLFmDPyuSu0TWuTbSXpBg5SeRVAVg0hi1spVgoF0tswGjorVUxykWaae7Ria7GPiu
biZY+qpXVAolk2He2tLdmRLHlJbAYYTP/RvejeINulgev0Z6zBFhPebtzGgWrFs3dHtD1KZUjNur
rA5F5tgafSn0ugOXMPejYSZRXZM0w9numS/slWEobqj6nTFfceligiytLTQYYEX9qa9NBDs80CV7
wZEmfRiftebgqGeSeH1DWZl3YZ14c5UrpenBhTkssucnadiIavn/CyZ9xmVNIjv99ZjJKWaZib40
z2Pf4aKkEC1OBUAPFh8ork+eaMkLC+7jILcLTKDcSsFijQJjHu+yM12y0jnYrqyJSlMYTXPlQ5lK
4Ka38sTJsARkS4II2hzKovRYC+xBhsyLIf6xeS5DZzgPMowl3d4lLFfDmYXqeD0brAGPGw6Wc2Ml
UZPFOmyEGOaYXQhxSJAWxW6lyw30ET1E/NUbAfGvbhpaB9IYuXa9FxRwMPweZHDrbUq/aQABcWy/
8kSXNLdNbKC/lYnPHNGFmCDGOREUsCWIUnzc/1qtXZ4yzkeFC7hfndJfDoS7KP6E1/DHQdAG7WtG
NfYUbqVPToJRPT/ESylQZekXfyfPhRlLuISUPqoUb7ZDPQpQw/ejQZJeNt0IEuZ/stBSaAoH7CtD
6CHBX5FOfthezoIqqjrpSOlN8rp+1khFi4QOV7+2d3c4HsFqWOUH4DYZKparQdVP9qErr8Rh6kSe
LfpAcFR0SMkNvkxGBL95mTh5YVJhMlh2hmbG6Q85YcIcZhwozBdXAOCCDWIfT1U1KWVTtC7OxsAA
UmT9lKaZm1Q7eDcbcWVgALIyIa7z+qLd07rGH7DPkN9EFfM0DNVSUcwFY0O8SECHPAU/9dny5T8c
O8w+1eZJQVTXA9RjgWeUd1cDnWlQcQs3mBoVYsG6WFhsyMkrfTUIGeuRNmI6YJYtmH8agK8v82Ut
XH8WVMXfMegnqtcN98nGbj9GT8TeoN7qjl6K2qVEvsenLkjJqA71AITcW9+k7DfU8I2HqkR+cUn9
GYstHazCOu16wt+vcUN5Y8JU7FavqLwcVIP2lrfAc3vMmvxBktmbgjIC9tuon0c8lSUYTMUvEntE
ixnZlBnRcQTVNP+PegXhD5ouFpTGIldiAJwf7yPBwpnJjq21Chs+PYdWWr2Ji+7KxqxTQd+JhFMI
kzOE/VHNx/k4oufPX2tyHwxT3ZFRJk2psmuvfABnPw+zU4aJvEie2no1Wjq4GH9sYOasQ34yj5rg
t3VsKwsBoZWaDMdhiPLlFvkX1pa7519PF01lbrYkeXKTVt2GbUl46A236xDFmRcEl++u3VB9x7Wj
bjKBQGvYYETwCpX2qW7Mhbrg6AAIX2UeSmEHq5CkNknm/85JXL0ZGXQrdmUv+wCQmlE9qBNEzAlb
tsW8t7Z2zjMFN6larEwsm24lY7yEdUug+hOp1OeZhArkPvd/vGCJgC7n/mG0N8gBWvgQvG02YD29
PHBOyqhp0aiuxLTxBkCkKhxYZ3ePfholV/epARWEtOMPrpYxvbwLE388amEvOETUONDjo4Fmq3Im
p3U/adJ9Jkpce7sVnDsngMXA10vURDbj46UFi1ZkzRRmYJPEqomGWDWr20ugoS42xviWWv0wh6SV
cKLAf8UxklFy29RP8Oj6gBwpYDCRYIidRaZryDgKoZ06EvIMPXY7n+HH18qSNVPocZNh2cWB4tMp
PL84O2pcRyeOLm2p3fXt/ETa8Ir/CuXzXDjLAVOmPqX5LjlaK4AW/x9es5j4Pj/5HuRkEjcEcVrz
yXaBhkhrxn3tiuNuZibaJHSJ2HJE0ki9hyUOsG+5iOhA95RM6jZoOmHTsmIUV5xRPScT5+YcWA5s
pmH1kIbDtTIC8wi0dlRT6e1qTjdOyexXP4sh+6O8CpEzp/DbGxYSPn93CBHXHTMb0Afm+DXXw902
hntqTOihZf6l/03AEJJyAPEh+3kYNQiIi+XzQI36oV19Hr/36iClx26TchL8PQtxZxPEV9NBau/x
FvpGBKt06sfgE5I/krkyc5fQxLNNCqHRRfhAnO9YLHLAgyyjHjO5dwt9ITK0RLvXQSp1UkKhTcaU
fLib5e0xJhkcH7l0Ks9PDh6iBjTWBYMK8z4nsjajgoE/c76A08gNUtarFZE8NXw6I+TT3fyKhIXs
4bqqtZKwDcMjHPO/s1NAZ/4MeQPo1FDAGBjnBNNCsP/dgOu55cSi5xUUkeqY/khfkfFzF4Av0uHv
onl5sRyaZC/HCMCXKcyRU4Q4mPzBjCKpnzfxbpNf3udVWWKpTM/HjaKARI0zDjMpFt5tHSIq8cEc
AOwx9mNTPv14Erko0pm0mN+nk1yjMQNS+Sld4jBhhlUmucRdTgv5tG/YzjpzwV4ASC0MFDYxskns
PkjLX7vU+/iqdCtS29WsUqCz3+uIS/TsYtNptU+rafCDN84QbY3y4FhJwE/sSgOmh2x08uNaLJti
pwy5oyUl/BJlO7o8yzq+KtDAO6fg+KsTxkSYzlih/CsYzU9lzrRDKrNHgh8tcsV04gpyAkEx2jJa
8N701YF+Zbh3GI1P7EQTb8r9U0LWv3TJE39faUgLFO+YWGTJyxqy3Z5Pnnqbvti3q0v3kXgwCvLL
hdvj7/i3bOAigafPv+GNqikeNX8QoTT8ZszS5wOw5Jcpsk/tK+D5eUD5nnmoO+CCqszD4z7wazAI
UJDrug9SA2qv6nfyFQ7Qg0Y/eh/xmTwWSf4SlwovtGMcC4K3uStOUcF52pcKR8NqB/hAGhsR0sZG
//Ae0GMxY0wjGlNzdUbZfSvGKnAL+jH1C29mIr3pAAwvsabpW3AEu0OPrGqNVWLftHqLmuwjXaQk
4np57uCvF2/J2D19msxhWN9Mzh/i0fGzjYk4mC7S6CWkACZIcrW8YzdEmXy/BkcC9ns+cYooZBIz
m66MLRNt9zo1iz8NmWJxHMh+IrDSb5MamRPDVZfloEodkqN0B7sJl2X1V9mHS3KhCZM/7/Tozyov
zUuuF6EUxtReZG8L8AyUB7DVGSDZy0+gOWylPh9YBswcVLSTa+8S/JR88Tc9yEFbGrtYighH4rIr
JBcIYLrrOf6HdDNn8LBtBdNNJXexO3BPYZcaW+0RJpHVTfv90A93Yb2uuTFn63J8s41++CA0/2Uw
PHnsTV//7btio63E29SSGpa4gWf3VktC5K6CGJfqgf82fhc5+8Rq38rWb9rOARajsqkqkhRj4/8W
3Ec12cGxTPbKERui0DjiYDXv37+BLjiSnkeOLCMFqaBApWm08RBq4sep8vfyRPtbAO77WKj0+vwI
hfgQ76/AfdOcV7gCiL+PPqhz4jpHRbjxer1G7TEuqErCWwP0KVd8h9zPkzIE26vws/7WjmTBSuz2
zPSvNntWgRBjzUj+H/DcWE3K463dWQ5jX4A1zwhd6A3WVTFIRMK3uMRTsLcTRi4FzISUNT6NpX9u
bNBTvbloZNM9/TeU0T7q9QW2cUIumeJJmDGvPWCk7NZ3en3RI215XAK5vj/BGwJNigXCUfpttJpO
YSQgoKXBXZxfL0wlo8+KV4eUTyBzWy1JU1IlGakc/8AzCqYoxshrI40GQsSpUBquFlYeBCN00TSW
r3cGtAuW9iKwPtpnELkyFXmihNoxn/RUAJ2vaw0F/INnwFBDg4oMbZrJXnz/ABBaJpZvLr3DcbvW
n3swBah8wWK73E9A4uoHC+qjv6nAXBePI7uObnHWoARLLis28TfO2ZiGGb2qFf5GtKRFmHZAI5PU
SQJoGUpqzhz3NaSSZ2wZ9VyIge0pz67P+Rl4pi8vjp3bYEF94B0Q/m4XmTVMr6Vj+SsJoau3z7y7
hG40IRd8AA4mJwB0pbWqivOtyWoB6Axv3ZvqkgqPAkSPk/TYLNmYWVr63cM++bBS1AzgDgVLruTe
XdgtEIwL5C3S5DEooG/g+je2y68DorCX+tt9pz1Bha9SXW94o8GApI+sO03t6xdHuPZ9EatkiAZy
mbgTAnJ4U1VYRWH31Tx4tYrX8cwoR5UrHWSrl9xw5fpKa5WZSWmyF/n9xNPeKVlBoz/pQ5E92KUb
iwV1a68ey3Ym3u1coTJ7tMSS21aLxkC5YPcxssI2kxGTNcQ8gHy+mYCAbEuu+O1r2sTWywqZQD8P
j14M7i5fuZJRnFllG2BeZmZLirZEsKfx47aqqbIqGj+52ial2LgVev6S3pFxJ79/Ra7PgOB5rq3J
eHY5EHZlfA1E/s+EvMVpOsnFfKkTW3iKauKScz+78G0rgDey7g0uEnZDckv3WZKRU+lF0LYfpLoP
0pBnUusxv8yFnBgO+lie9WI/Llz2Hd6PEic2bCYut5JZ73IMMgeaLl8XirkKbTJfcrqWja7K6n/H
66SEf/v8iBe1k0KYDsoERew8ZmE9b2f587R5pJaiaqJ/vSy1dN2yvxEdywXIk3LbYY2OYSPjxHMk
nBFFfW6htaDUhO60T+Z+P5TCxVrU+v7/BTJ+ryAOQS/LcEr/7T65rcWMjVi+WMvlDzhz8lg98wO+
gZN5Vp3PcagppmirTucTHA7jLnKNoe+F7WVM0IgtkFtiwTngXg0LwiMQCT7LCyUbsE4lsRxGQDHV
3N13b69+TT3wKXF7uPE+y8Rf58wtOi/B79HZoKwLf/LHmn7msS1jOK1eEfI8eVXNCXvecfF77UqM
mgxIlNBNIPB5iCvakN7zKEFJ5giDutezxyIIg6XLAWp8JAQpF293m33rx/+Cm3ci8Sp3FpHgiRK4
ckO2qJBXnXHN3UpwYG740gXEo1xP7UVyVFhPD+/btfswZsb6CjtNxVUpc7G4tDSnL80CtK2rorfx
bZfaPxs8ERjxwlfD8YoBjjOpdPyQjRllhMwkNoWfHJ6nzXr9mnPkMiZpTu6i8bclOXu9YC9XS81D
aKSKlx/yBDLbU4S1uQ8NKewZ30KGNDRbJFKkWBNQRdnP4nXvtK1mscpMoAJJJlcASHbKw3KFhTRn
WgADzFbQQQ6NjCyc7Hg6q9zOsJp7VQ6L9En8GsqmltHHqAm9Hz+ugpaRG13PRAyW6h5YrzOQd3/C
kUGXFChAlfRKUhUnBFTMQq8uka7I0C6IjebakPFKxLFGRh6Qmzqohzq9JK6RygxUoyYk6WvGBdJY
zPb8ViWhBWc4UmgTXgySd0pZiaXGl03u+s9CxypWng0bjYwJMyEHYszgnY+MZhLR/k7szgyMpN4m
LRjRLLBMSo1U03yuuNQYD1x6kiG2u58DRgqsBqYMKuaFt1CSMtwcvHY94cXjDAkPS4CineqRJ/AD
Fk0Ha81ExhRM7IJT4yByH0BYY4w7dnTlZBieKQGX/UH0+wIf4/bw1EbdIE1AAE4jSdxcplXVV4eJ
YA/slujbXl+6jBBnVgdEy8xKv0bYEYbOUAdY7Oke973svMrjqexGZ2xN/luVTCWcQ4OdnwH/mz/i
wWvRsIXV9PCQ+MV69aaotIEZv8XWQFqJ/HAzISm5a0kx46t7UXf0IknfoVr079LZhCcIciDGveoJ
mdP2oZCj8GLaffK8cbz6S/H0VxFFl2C9no2ivaYUkC7pWp4L5ety+7a+CSd9VcUhbHM88AhqFAu7
+6tlH+NdZle5TSdLfZPujprZmysoffEzgvxWDKYFY5bAyAyrmmx59a0Hs34CgNnPkARxGCGZZOmV
vuf3a238Nojq8dAGsdGxYpH8hBxLbKEmbsEDPyUclFYxH9346whA+LyPxgecz4N8Pw4kuCBy9xfq
Foe3XKC/KIYFxYkoVWB5ilrW+zZqat4NTeCUUCAOT0P9cPXkkF4axjHdEHjf9CcZXaX6Hv2Y/TWU
8eex7Cp1JZXHA0yEa1g2hlbyjL2u8QMjJlUdbKohjWTxouzmGhtvSfFEq2CqaeuVMI8sa1KBXJEj
qRvNbbgW/n5DJHYCWGswXndK7e4urclNatmYSI01P7jx2ydWmWh0+2j0Fi2LjHHGTClS6twrtziY
2a5ZmQH5x0hTbV2kPi1HbUMRdYY94pTqBC5Wy1YnhxzlKZS6VJvs3pU7vIqwL6Yzz0Iv/rxMeSwa
4fdpsVu6V8GFkme+lauD1i8Igaj3/cgKGEfBEm7ecECHtEiQQsCqbrS/Ls2W7c3/2fhhavBb0ZsD
LCAqz/fO6pc3XVd4xpcbqBXuQvAAQBBR9s6wXmTucXYkuAt8E++hTpUqAGnghpa9G/fK0C4GQ15j
Ms5bQ47E2CwdE0plbOkr3xiTbMKr2SzmBCTldWu0d8wZ/yO/GfhRwIFDTeRAhWh84c7pF3DmAjE4
O3Eunu4HgjoWOeJdvLhN8Fe7IIto92LwPgHEJVCEPyrEltRWQHak60iU4ruzkwKKkzke4Q+a2S+0
Z84mMGql5e6L7/zTKYbXHKuuJKaHwCkwxJecE5M5zsKkAW1Rdh7QqPwe5Gy1AFfjTFgTAsCL9tTy
dKBA7azSEGPe7CjMdhN9zFXtXXXf4RZCGK26hf7vOKI6MhBLD4/ct2NQhdObeY4i9lna4Et/k6kv
qG2IRtP59h46JsXoORTRSITy133Ah6OKKe3MuOPPfN+zqoU4xa6mBVyh+NQvZB/oiGL8cMqk3xdg
wpFz7hlkXpmNL//OnQEaFVejrdbbJUwlIDltVnQ6Tlf3blSb4r8bslyqQ1TQkx6DYy3qhYKexP1T
zuov/VZq0Spq2L8rS3Kfv4O+gJ2s4GlzQ7/L+ky+lhN2B1TAHqJD1fpK5pd9SVqzR6FJa+GAn0c6
mJuv7X0PshuVwhL3u6vwA/3/ii8axZ+mkWYXT8BO+mVQD99Zj0NjqPN6wjOJ2PFvc0DbvBroJoJh
OeljPov3yW8x4mHLBkRVKdDutaEil6Bh7fXbTMn2+OJ6x6mF0lKaC01EN24ZqfQDuC1UVOaJ0uYc
en83SSpRsWiktrAgpKpjPzlYj3DqwGQWV+dKCdCZBCx+0uCaAONpOHm7Iev+GsK8Q4n0ig4HvsPv
zsYwK7bQ1S8SwJoOMG9Ok3aVaQyWhgpXEdblixe2v8J29Wn+0ebo+IySQHlQiyiRp/xaM6MWOju0
N7gAnevH0ENeBPl/d1XDoNr5hjP4w5zuBJ4vVHn70J3QPcLE2RDYiKm8Lk8MdP3YOkGaw7WE/xDY
fP7FXu5TVRStrWoPA4LjDsaZ4PYiGKAoGyWPAEsHakrMMW47bAk+IH1uebE3fTe4BrV1eeuyGu3/
O7f3ml7X4VS/4XVjk+8fS5voB4UX7rK/RXjJ7P79BNTaFl+O1J2dwwUBFOR8QTEWtcw13g0oNDya
/w50RTI8tpBb+BKkbeHD4EnCmuRRaAS3ZpkLATGVn53ayh4qhpTCIOr2rHh4ogeTiOQtDc4a5ogZ
hp3hKDm2CSMmG4LG7Sy2Prt4eCgYIAmADmdtQ4NcVcAMxap4YvRKDsOZXUCOm0TMiR800OAndAVK
AbouywhII4uM9gBI3dhC+S7cE9kbfOXJrmmZxfRF/AWYOJO/YgoHoUQFTtrUwUL6/yWq+9kACB2y
OE4YRzrtIF+DDdP+d7aRjr1ifckl6nkccqItMy6nmSf3StKNyCwRuwDLtvjMQvI7SKWJjjK9D4fd
ACwxc25JMqIy2Rld3FIi4N+Q3idsRFN6pcfQWhSbydqxtUhOojYpNAdt8MEgb5MPBIJxDzEkojBO
YILE2Z0dxf6qPkOQKOPq486gWUhA4Aeh0Q1gX8EcTQQDVDzrpwAE9RlCgG/oqVf0NNgJpsviFo9D
MZ2Fh//x+mgffcygwF2TIPelVIAB3Ptl+NcgmF7Q6pDkI0n7keLynPU/lc9HORZQi92q56+25SZA
1BrcL42++t6PNnh+Ui8EFwmoxGDK4jVSnymdEBPQBqh3ydFBDeG8Dmd/i62JRWU5cyaUilGUBVQ5
vV1IIuViTd+l57U88+XnxB/mzOgAXjZIR17Gzkl18LF0GBSE7G1OTfbbwAhy73u3eF46kgy2steL
ppCTWWPJ4bjSFyvvBS/nk6TZzMvTndcivNG18Gx/nNVYdUctEw0z1CZMMeyQkjx/Sdw58o4RqGxg
Ml3jy1Ui/4Noc8hQfQT9jn7O+8bY9x5tbAeFlW0/yrSxLGB5OklrOVooBjE4OXR15KEZK6EoAVbt
1ZgxJ9SE4GS6epvdGyWcyOvmZPALTE2m/m3spJZTTGymEe8Qf7Jj7c2SPYctBCjLwzswQkCrR/MJ
x3orJF2RyAI2gCXVpYdP46Ay6eEaiPIH+U/NGACVKFgchhxnoVNmgi0ISeuuaUmtPEKSwKCFa60l
K8QFFB1l56eo4EE46DNH+rSmqPw2duJrzyI0YAEQNoUa3n9Nqm+Zu6vreBrWsmcrUkTKw3TqhALV
feuVtyW+Zgo6UgWCSoUcvbH81i0Ni18LzGsRnS2odULmlA/O29r+hNEtHfOTtsOi4HMCfLBN7y+k
w05JfX/JzM+YoD33IRWjiuIzzvxGv2FB98n3ZGNmi2iGTkYf3eoDmD3ypvnNU8ExgFVKeQ3avrRo
P/VwQuNyFZ5Y+vsYDZG9SEthKNfX6GTEni/HuGVsAKbo0HsEhCRd01MhNRhpzbmF0Hdr0vSdZKwd
WVkFQvsuPMTviM30uOfoOa9GedovbZ1SLlBZlhlwL5R95p70a91s2FTPOux7VUJiBnRVmS9guiMS
Z9941AhEngNroUUNrbuQJhZNHKRXe0W/3Rm0jj/mbAk4qwIjnIX8N15Q2gNWSJDkOhzVweE3DpkW
N6abBoRM5uo14tuB6+/gx6Kr3NaJPeAoHp1kohSrFk6belAdXUx+e0P/xiiA0z2bYwuxPWx0UpMO
Tj+IiLo6QMOxkdtTsVdG2h44oS9It7l0tjx/zmyo70xJQzGYD9dNS6REqjGZ6U8YJ2fqKsrLNj60
8ycL9dEDlFuc53+Oz9zrBpuYvirDJXOfW+IlE19da71bL7TQHfMo+A0PsuPwu3Adrx/Fs96DtSHc
oATVCSGFMp5zgAIfXy81DHbTzJuS+yu2teftYSZ8gyNUrdYdrqVPd1aFGcF/UP9ZX61m6HOBbWry
Qf+ZP8ifc3c0UCPCx4ocBpBZbS0/BKaPNyxfiAVuuqu6IOAz95txUCrV0SfrhhatbyQJ1B29Luh/
AKcoJbtzDfNYSXGxNgOKUrUlU18ka864bibc2gkkZBJ8jc6f+InYN+xuQX9ZaIkBWzebj3pRd6bq
Chv6p9SO75Rdk5aCX3w/xKDNTodDQU/pY20vzJaSCaCngoPZg4f1k7a/o/cq127Q6jjtSGU6fgyQ
H9MeI/MJN/O3J11xpTYMyorJHTjZInH9pk2GavCeUBvxSAQIY0Sh5um0lPWamvfaKCoXqsnlyELe
iM9ux7tCjm44Ou36IT8StaZWlEZOZC/GbeC2/FRePBSk9WcZwFQeOjAQUMPTZFGEy15Kq8D8RpTS
O0LzytrZYiYbHBA/OC8suB72W9v1NF1El6hSkHdf+5g5FuSJ27t32qc7+Oui5+dHvfo//YFK2bqg
EZmvCOifK29MoIzhX9HzEWzMYcdh6cD+Dj/xThqEsosHxvVhIMGD9c7WYjHL6SdhjLRXduncLKG5
oeG2hR9wP768oRESk0KqSPH0XEsSdlV9/DPMnh8MeQTPeWkhaOsQ50fHLJWSkCgU0FHDMuwz+UaX
DdNKi/WJBxnwCi/Ziagn56JcElILLIXH7MuBtLn0Vacs4t7Hl40VHZaWT+KmaB6qIY87Ixwmd9Jf
pe5AdmnSeQMzmnWYJm6RZ1sgZk6HmdkFtXp/6BYZon2hd4cBfNLE70HkbWPVmibDvQUzdVhCVJR8
+LDixBb9eosv6vSOsBoyORefBAxHNpSYGlNxEp/CLsJ4iQlIc/YXrdA448BrsvGFSLZyyGqBzx9q
7YH3bADRjxMljzHTATy690Z2P+dQ3HxgW/5OaJ9og/71BqLSwOzEKePt2k/Mo0zUnybyKxlJUPol
/VL6WirqgpCT5yI5955F5DvajQ4sGnMZ2cmUIyqYx6cQyAmCDv+I3PoB/gwwbLB9KIlzAhegxQrB
e4VsqtgWvpQbLw78zy367SNeiBOmRkMrTitghYe0yqwXcbyLcIH73qx1W7LnF+k61eUi+1sqR9QL
uhrW5rpk8ODCw1Kn4XmewFn4lkdgLodFRfCOVMo3EWsU3mbAjnXpdlxPPSH1cC8UZ3DpxvrSYJ5u
d2DsExxC2yaJ/bPew0LigGpgtPCPakTNivdorIQl0+TdsHhP7hf2kg8gSkhVdoiavyRa+J5lvTws
UWH7TAukyDKZKIQpupTI1aJXhC+ho7uK6okjlbr21X9NOFgvMqJ7FmWUvjZ9gPwfDCsQ8SJXTd9t
ZWxDVyHWue2QxLt+iDFj/jAzLweInVR6iesH6u4plSEXSP0eag/Ml6GNAK+kbPUaq25cjVlEfrQe
LEzxEbllFvDVutCk79US7+iwQqOah3SxNvsHRQ5HGGy5TcDkRcOgSNUOVF7XfboEOWogZC5IpzeT
kkBVlBhJfhuDJSTVb1+m+jY9Ovw0fnvYeZrQSUXxjziD35XaiYrVW9P3PBrQVyiuuFnRyv3eWycd
GQL0AknAZxTa8jM+9OoI3G+aqO5eT0Ua8uMnnaMpX0HpREqyir8vy97AoYGlrfDAYzCKVBJjoNlg
2GVBmJYb30phcUeIAmJHEMuhiaRIvHLDoMGzTY6E2GEPn+iS5Fnt31HNx8xRELq054qZ23sX1D3C
IyDMpMKObSrqK4epIT+0fFvaSNOVSUPRobLLVETZOZ96OuLIwiiN75GMs13h3ImRC6axGzyZ5Ul2
NvKBnhBR2DX72Onz7eX5aQ/J+KyizJ6L4v4UfW558sFgf9+ME3DyV9j+01V/5zyqFydTpDdSAsuU
gbRQIdLDE9UV4OGkmObBXzZAcKQ/XuvAS61sGzdg+d9Dy6zokrpVINmzdWgPE3KHzq1KCbAJ19ox
uqMYOgcMBYC+zIHy6Jz60ldRWtgwNAf7vbGjQ5S3Gwc19lPGUM0w/4aD+QTV0UoZwWaLt9E0fZd8
JjGzFqDtHpVyZO94E5GeQYEGn46vvJHNHl2FGw7uG8H3FKEpOnY8h10AdV/ATL3uaIzPIBiiFRtA
ujxhYsq4LFxCcbnEyMIBXGAhLCEiQunk3uCyDMlUjZ5w5mke7dE4d5JxmXyh7Buzws8rV6Q99/Wp
TIUrGrPD3ScsvfAbphnQaD/jA6OnyHzleOFLo31+v+PxQj4OEez8EzlOwzTLGfKlT/wtX9TS29qL
rcGlMZ1CXg82fXYCesOcUBnWEtQIr+imz8WwMy0bCjBdO3F+pJbPXWC0jyHSnb6qYPe9kGP4bUGR
LFTcMCTI/auyF2V78F8XKLvVRIop83d+cuvh8pK2cvYyXzGEvx90E09hdfHFKiu8F1Jl9uVtEZnZ
WxvHeCyWX7R86EvjzbxZbUJCKPSjM9exHE7nI3fTSnn5gAgk8XE1C8lGHtC7ymzcdYfG8eMAsYLN
oZ6BvWJgpVO4Tq7+8sXQAEqV4PiJlBijACBKKHMHyqTYtfLPbKd1/NA5cFaoDvjx+qejM92H+MKC
P1FNsLnSQMYwnM2vGFhxOwckNuUGPX1l5D6WXJstcDdeSs/Gf0i84EQSLiuQhz0GSkflpEY7Oi1c
nSHvGopS/kSS8EDfcnbNPCtRo9TQ6tH79gELzGvaxcwSYWO3tIvtJON5ZpE19H58EBB8xIy7imw6
3c5H7tMP81sInsWi7f37oBnqQi6GMqNbet0E+f5FKVbQ/SEzkd5kbWAibbI8gBzFtzmkAchx7bSM
fXv1iMdXoGVBukfHz8dt7NPyhEGfL1pJVkEac3JicPgig/Fy3elqs0F0sh2RfZzMUIWHLfSOQLpW
JQfSQ/ASZx8NqsQ2ENgNKZsFKDzb0ihDMR0DTCMLqG9rV8eRCSXJeAkfR5Bz3lT/44pTugFfX8ha
792kHdOVxTIdHUL7L6ZUtjFES6jCIemaqFeGO8c/+kTQwEWyLx1r5doGT3slQgH8MZ8tDuAect6w
1XqpTt5vKIHy/G2lHjLaAbzr5oLpEHNf66eNXlKH1fUanYQLruPDqhENyTL1dbBIbDsHBz1WQZkr
HO0t1RTHWEtEmP/njZfwhKTqS3vlmLF4aWb/21dU7aTGMtWsgZ2mD56D+ZSH/xXqF5yXej5ZE8az
qs2Ah83QJhS4um7kZS7uzDmu5jvWspF4lx8KvWsqvVc1DggHnZZXUORzaI8THi7ZAwqG5LZgiY4Q
iQv1QkB1empe572KS+NUhLhyd9HZl0eH+EIwwo6Qq4nBIG2dAn7KRsyxLelXUJ7Rf/gItlFXKFfT
IhcCSphNVV59+HHCzit9MNMqAldc9a08vIyH5afbAx1fU8PHqxdoIn/toNLL3P5vIC3yVmXBTOET
9kbj8zLxVC2b6AKlkrhUE7H+Ws0GZV+Iu50odPOXbAngegn3eWHGDZYrPILMvzrmZxJ/DaUZSA2p
LhGLgQHmn4AOFfMylbnWUioxfrAlFWU7V9PolQ1TKgjsosqybJguPn763g+Ph9Ab4H32gYHLjCnL
75MNtD+Mr4PYxVXtucjEGQ9oRapnY8vHo4ulpVgLqDtj8PV3/xihDXllXKZlPAPpDwIz8TwyHyOd
isxgyOUSLQp2rwpVHl9M6ei2Nc3x33SXQAOzWl/cL+VX+Sd4qdtDTwsB3SwLtfTwyZclCCwYU/my
Ile3RuBjUgbOI8m+RlJSuTYTDDa2GKbkWrxoOGIfWru9VVUHAYTYCLvOVnGULzFX1lWVC3VU1eCf
aqwK4+nB7ZbPf8Yj35Yby826YWh6+KIsma403F7wTsN0Ght9zM5C51cvpqXyTXDlCCF8P6LNdLvz
WC2fjmrsBjeD9AzbxJ33YEOVR6SGeb6qNcEYlAYIibssWs178GVw/dYXNt9J1mu47o+WUEXaq09T
0jpPM3ieU15CiS2dNeA74usGg7rx8e+IBi1HZdm3XRkjRuf3YKg3QEZwcLZmvDh9Bi1ytUezKkGp
la2IDqtjSpbiTxcOzP2Jd1f+xtEpc/JABXd/u3aucESh3XIq/9HK7ZHsdr/9zJSpNIvcl18qLyte
1iAzmeKxTRt9MQ7gQk2k32JrR8kcI6CFKyG59RCIPB2vomgrf9MwjZh/UqQ1vwMvuMD+jC4dwKZ7
xi936zCHWI1f+RsSA1Dcl/RF2qhbdkMbUrn6XtPl9yH5hLQYiQT/2crAB9EEeeIcUxk4avV78u8A
UUlSQctk/Aes/LqwbODvQ5aw+1DCPbz6OCn2JRqFnJDOkiU+daAhQyAeRP32veknKqQ2p0OpnKmI
d+s4lCZihSJWXP5bFmKvKZxpwX9wz4x5c2E6i3OiJfCzyoYBNgXZWxDlEeZSfTOybBatT+U0ocYz
u3sWPUiWBxw8pp6ohf1wHxjsYH5GPdeosAUOXXe+Q7ivwi4GurSw1TNqz6z1Ida+Dn+xipYCyuzs
juDEQ/yKKesFhIJqPSOWdXiOEv04zUsDjdG5auq2N2w0eQyRWQVWFYEsPj0xB/8aW2lm4Ltm4wgF
3tGkGcSx7fxRwefN6i5D8v/y8gBEIwhMPc47PYwyhibmXRbTSDxq9K9P3GZQ4rMVx2YSYfNo0Qbo
PexUBQxJvn8dVZCw34d1M/rrMbQSFiaQCF1lLkqsJ3bJnvaZPIcYQ46KwcDMNexUVld1KMBfi+ky
lBmR/Zi9g98qmCYQCxLpBk1zAPkwuk56NHp/RJV+0ZmVaVthOYvV1uAovg0tLviKvo9MQy8vbZJZ
Tfa4Jlhzkh7iKgpxjdJ5dH9Q01QfZOFDuGxuDVY0RD4OCec/xeINfz8tbKr06hiAK5g0vM9YGVUR
E5GtrGR4LbUSI98bH8c26iI0JKZ2KPB4a7LoY05B4Sv54Y/bfWB/MC1l/nYrTPSEXEB2Ly8ZJIA9
eeJt8q9gRJm9qeyX1I1KbV44kRv8O5y+SNN3V/PeSt/wJsUf16K3lOjRk7for0DK1XopdiicFRu0
seWY1VjVcGY/6536p2GGrr6s3++Ny1Ky2ZjZuDFODTjfjAlOfyIFH0nwXngAULnJGE1kDX0BXGf+
iYqZ1M0GlrVS/xndGwPRKRr8FXNWa2gJ0TyvMp5gippDURVWt0gh/rKSQ9igPDFvHghnrsylVyPN
N2y1jrKDUDygHA1rjRA6nLrtvYRnt3p0qIp+lOLIDhJM+jprr93bJWsF3Ye5HLmrDmzW1WYLmIin
yY2j/JRbXFZOQYNXaTrxF5M+FYn0JMlr6KNQsfzJGEJ9oqzOGcZfJywJGTn1D7SN1tkACkMvPz5v
wWyrqgnLJ/0CMaspm6bXOCTAFwS/cjxzceTifPsVG6rmL2xQfr7+H01hQPX7Os+SvMn23BZ22PWc
qPtGl5b8eLG9O9U/8xO64xqRglo5xXFtQ7TDpv9rwvwlCv8YDhN6Tqsf6sOxTCAJU3j6aQE4Fnbp
zRB1JWhcVsJpvC6gtGgiQKcLO1Ue3ObVang9dvkT4m8VRlGb5FTqIkmeMY+Sa62mh7XhnzwtZxtO
NF3vDOLdYlCTvEoNPr8VGLe1ADbBRbF93+lI9vDXEYZH6dnLqI0bfI9GSaF0DZ81D4Pphvj0zv3P
5ZSA4lz6y7Cpl4ykrvdFvP5WWo9exFBACeQfbNvR+Eq62Z/t1OGe4ZkTV+VswW6fQ3aHML2o7hQ/
krjeNKRZ+e9heBeX13+0gZPhalpGvx3Oxcru7B2vVqs1/YTO/F3sK5EEnkiip5PNgwMcl0qLsY4o
+IL4EN2iqn22OTk3+y685KfF1inkAQTCRPTvW86uD3V9zxsnJCvaTn567+YcQ3FxysSFBKC0SLHS
OkpkwkLwOb4F5g9Fd5f/nczOZKBpNicRUdBlDXP5NOQUBgbqAYGFtR+XHn6NQxrZTGplQ+PIuvYS
tCXkr8pjM4AUqE6pEAcBkKZmfFSl+5HD7sub437l9HhZRWBew+FjU6AAXgBOmOjMm2dSoBVjq17y
dBWPkcgix9m79Lxr77kSJn7BKVxi/ZeqrHoK0y/n3eUKiSej68cs0r9p2rdLPB98AESkN+9gsHjp
GZ9VjEipIlEjo0UlPz8fmKUEAacjX31a/4BNK6ccg1Dm+ctk+8qsaCl8BE5M+uqviWX/estImJ9S
gJjcF2+dX8BZYWJjTTFGQfjeWWCZ8pwJUE24ZCEHAcCYes2Kvbh+qLSxmkwPc0sV9SZl1phHZQHE
1SoRoY9TYtCaT85x/VtEWfadDOVuxLo0md1Z7kDIfN7P0AUioT/TH2dTmFAxwCll+2dKJQtwCwws
XJ1gQhBvNUAUrukwYnOV6nJdGqXt0TO7e4Fg7NszB7KTxqeb4fi51e6Aw9fJ5f/NVEcqLHIgrVcb
ikJeuob0Zea8izK8D8Bxa+BX7HDEnrHrfiYosFAnKaEnQ2aH+yoebzpmGLWULJISkodO1EG5o4e8
udfbnPr3QDAPAFJWlbDeeQLNK1uZCncdJwGBzCgEr1YvkF+dMHIQhZjWcIrivjLx3ypstu9Z4zQN
j35Mk5xB28feNThOZhC9LSMowTjAHntGGc6+ewkkSiVZg921N70upyn0haoNbEyGNkXn8zWKA9Tk
vrCvDFStNYB8JeRFNuaouHob8G8FeIhpi2v9Uhs5DO2GJL5w6scKq45jfYnX3JVLAOL+j1H4/tvb
lOWJYEPt0tWu1QDK1Qd8p+HockS21LxXHMRhHjNQuMcL+cyVFimXNvCSXHDfBrCTaYGiBj8zqzXF
FkJDzOUerrgTJURTyUvNLPqFWdY58PN8rLKcyX4AgxoqsAcITnSrBvDxa1zOPsnDGV3WYL3HTMtp
aC+6kenhkpz9abnn/1kaZvpiphiGr7mXcoxooOxq6MiHMAA07/KrmDVMVG2PQ5dZkvNG+ESLZbqC
WC9miThC9lgaZ68TC97xwsWz1boJlFniC8L+67AvMOYVs2A6MUFMa9MtOr6aZbSbOCr+EcAQJgAe
CtHHHD5Tg51WkL/TK3S7Zvd0gW6es3Psinm1HMLMupqZ/LrHvlkigHKs3CErj/4uMn6DOpMjKl2J
ZUM+0VzewkWeaiKuDBrM9olu041KSjlco54qNYS0R+8l1dBg1uPty54n+VHOVw6nbti5LBWu/QIl
mSldc9lgtcTfd5Sig+ccCNeqav5EmuP5bTuN6u7vjNIBs1fiDNP02e5UwQpy0aPrvMKTA6iV7U6D
Xoz728+FBbjMohvAbzBmcwJ5CzINHrg0Wu83EAEKUWu44pAybKNzTbqIUkd8eazHTmuNQcPslFnD
2iDRcTJo4WjxoCCqCAqvhc+y9O0Earfzhpss+iOIjzxCpoT2uFGAqvxLSv8uPxExeBOBiZkFJw8r
BGW0faBHLG09+m6c74oVTByCErM8cwb1OYnmtngYG7Cw0EeNQhON/rpQCIafvhZDydCcwZRi1b0o
PuIQX4ylYWznj1tSofq1ew6qP+50CoFWkXMv//iQQmfD5pKU2tsMW9vG5tjhDGzGut9Pssygkwf5
NV9p4X/q/fUMo4DF1OyUCsLxh2bCZVwO0VYL1V7G2aOfBoHk23QJC/lEoRDBVpuZs4HkgOih3Qph
H/TqcGk/6ENV9tjXHP3rTywHg7K/TTB1sThhWpYlqGjj6OvOesvHrilDK2FjSbE08XhZlFCzrNGH
8up/ltCZUB86088hBPVvO1Tk8YQZ0JqXrkhsRlyKOMMICh8hiZ+uanPS8t3Mx//aM+lGOjACJm8q
Z3QdJ7jXerF07vfUndIuM/ed/MXY3b8XGtbIifWE6fIisjJPJ3sq3sFyrTZfcj+E3WTdZZ/m0dL5
VHmx5w6o7F1Dkg+Nvb8OWfX5koEKKhypKWljX/XNFwDBtt+m3XUYWL3E5mhs5XoEfuX+mCTQbiGA
lxvPf5ldOHzwWAp4IA1uV0VPRMuLarJklIay3dMrx8IFn4qocarYhvj+kyrP0GVVkPyKFfe9sQ2V
els5/Gw0g6LvqoeTY/ulNrtxo3oxXyUwXtXxPp7qrIjE807f0ItYd1b2xzTM6RpbpsqIdeslW/q4
7PZmM+M5dKib9jfvPSy9gsBN7NvuEmasbluOVachPDdq0TYv+TEFzemGf86+BAtqSvRDjIxGx57F
x5yB50HMKL1qJhQ3vFwN2CxD1Dpq6eVl39vRZBv/G0VrXMQwuV5wAp2dGPlkyIEYljBixvK5+fD6
+XaxAK0IKxzhHejo8VkbGcnN3hrI9L50TObFu0yCVo5mAEg2fBvhXgs3ud0dHyl58Dwxk/u3njZl
p18ihD8S7AxYKO1k0WYAuP9jNmb/SQH5PFQkpnqiqqQODi+KM0jTZ3YNZJ3r6+Izp3JYrA7XjPrn
QXyrAaSLx1APJqJhQRb43rD2Sygm1QTdVJyhQkJOIGZWnh+hbBvpnUNUijNuJbttRBIXcQ9+dv0M
U6DCEoW+1OYH+GZxKbv6Toxj5UHp/i2utJxUiV5il9Da0TSlpM3qbWULURo7Brvzj0vyOLB//VPo
tb5L3BRLRELQAXTNpYfgUgea7fT3J/mQChRnD5rRtzKoS9gcmdGS8uJO9/oKyhqy3CNputKZs8fz
LS6mpoBToxMzNihb5jb+QcTZT5Rth/PV4Dj2b8VaFCAJ4nsbm6zGBWjFRcNZ7WDZ83yOK9aaG2kd
p9ejM9wG3O/6VnCERtrgotEBOZ8tTjcctNPIjkMLwX2dNrfdhuKrYCvzGf4++K7auBdiC2zwoLBm
l0Gc/3cvCBozlEjRMIRYvgCmxg82T3dv9orrC45rojIpW1AAIr89F801hbiRV8sBV8rIdWHcBu1Q
VGCW9jycxHsfSx+Lx23nGFRTBNb9kukysTVxeX0dT7p2VYdKf5u6MCMi8Jrgz2dT68qj+2auUyf9
PCUFsl/u6u9or7rdqlX6jF/RQ0OElMuE8kkuF6mXlEKgGA6GykhGo5zcvgfGd7ptOsAF7KQHoSmM
rIQ7BDQX9tuwU4HJikr8jNktt7u6cDiB8mwwM7af9ENrIa8phG/gSzdAodzPl330cS+ka9WnTC2u
lbn9/VkDwqfT2Bz6N94cAyt6GVcUFiy1/kqtr8+L7YJjO924EoRucHh0Fz+o9wK2FxLJlMODvwFe
su2z185TM/+4R+bGKs1V+nSx9IEnR6R7rup+cZkivfMrGNRhaIM6pRSSPCDbAOU4aIFiYzKE/agt
pjUIWu4pB8Dmes5W8/sH2nrN3ThS0Z8ZJlwmtlVUvPBMgXXNENHHN4Ffa6N8FdADIlBC/0lLXpCc
FXn1UlTbB0l6v9Yx1A9zWsN/HzkaCPBYNpBWx7vu3Y4pJxjT/x4qScdBrhwtcFXl5o2l5mAEVjkU
OR0vahciPSpUQbuDuMDKPcbqa6Anmuikuq0XryJbbpegwNfPE2SFUc3qgNoWqCEaVu4XETCtJaw9
3CsSrtLZZjjulmyj/HexDimSMNY2dgBL5h04RR5kMDDV5DdiQyPj/PU9RH82OjkNYa6lTSIOwWhM
achGfiycus6yuCmuklMr5MtFhgMQyuDQ9+4/6e05+w7Ua501Wunn+E86P9zrGjaYlB64L6P2kLjA
uj8BFOLWZJW1NPWpS7AwkJh8DJir6ZIvh8QHvmDNp6z0bFIfK7wpGX7CIrcnn8mXrn1TpQoBSFjF
vOOAGjVlb77KiOPGWnRPhNwDjKqk1l6dRJkp+hvo4W4Xthv5cfDsfpQVIQLTOIK8bAzPe1ZhiYh6
h9W3J7L+9T1WUGItVUWGTuzuBCXIUsApekksJWuaLNu1wSHEj1Ac6x+VYaGM6ZNi4h2ZXWlZjjoU
4zi3DA+hMDWAlZU/5OHLT3ChKjcpfHmFeiqc1/1Z52B0S1dH5pUyfDjDOfBf7JldpdmggCCGbWOt
AiyNes3oQ1cxj8HfqJKA5GiIA948mLG6E8AoNyGij1cWx/XTFOeOE0hgGKqV2i6rSWfs3XYpD4HK
g7U7NmZIMUgxPVABudlkybAdG9sOTafOVhlUP8PxMLlTQe/YVWyOKp3XiPcFC4Axs3yXEoqo/JV1
RhpMs8NESqSjDzIBf7jDDt8ZURJ7kuSZFxLwnSrQ++5KLmfIO3s1i2Q//D6DPvLlTwi76GDh3vSM
09LxcXHzpm8LciSEHz1QCuDhhtWojbOwsV/tCrFXsFWQuD7w89e4aI7YA9ozN2W+OsSHdTG6xeCj
LtbkRRp0UMKGubiKroxdgHzEFWJqQYrxbuwe/kRYxtCJE8B4udP12FTxuFsqxBTJjvMiUDTu5XQ4
V19eLp8EEgdZFiWHZCIxvbyQTKxnad5meGLXB5KKMmVsLhadSHTb2l/sfaJ+Zl3+9oG61hcgHn00
h76AL9jBJwFdYyuRorv03Sn6STiRXcV604ue/JRq4T1/2yXVuOsrxFggHwx7F5BgtvsLDLv9k1r2
HPbN7im7CCM6Fi5YBNbzqOZixgZa7l9Ynr5uDJzN+AVNzLNYL2aPYTwjJMvFJ1RhBkCqmAFdX1hZ
lL9DUgt0HGAcddh1r9RJEKU1nqDUwvLmxPTlkWQ+AWNd9VusBMRva3280l/G1b8V9xbrZvLHy7pb
8IfLnBCW4BE1j3lmHWFODXFxq42Eckb0YcD0M/0uJy6OVf/G64P6IsnQ15yn3ukNeMXI0ZESuJNJ
YS/d4WrJXhDssjUrzLo4l+qTIbap03oZ3acUIN3lGyOlOZam8QANoAnqMg5twvr8kNCi1c3SHDpK
W3rSO0vimHyD9+jTgnXLaeJAHTB9PPNFaVBjMib36XOLxkK4v7XgQ1VTcw7rGZbCfkC4r+1nNlUT
7WqZTmZOhuV8Z0tCQT+jRk4Rsgh16vrHL/6vHaoK2A62kYSFrgk+UKfO9EgZIG66PIxm6p3KQ58z
7Vl42kJX+9EJE5OobhsM8ZPepQeiVpP+2NnijyqQ9jzS/oBOKPtBRiAY7h0S+B4/ihzfVuJAWN/j
kZ1llsKNU2fEJHORyL8zviBgzCl5J/Vk7r1kso2ScORXAmb0AxFb6Slqybsm7yqTjlr/8Upi4CH3
/+M5aU91tgJ8YSmaoRogHxp+JNMXIOhmQ8L5bV6bC5JsavjRwDNLQ6mhdlKqJLdi/Vu8LO8Vw1m+
7cDyC8m5DmeivO3ufg5CsI8lNZEuN6bBKfXvL73fLX4Wdb9ruSYlXye5Uq25jwfuV0Slldu9CLNU
h5ok1PD8vt7YJ3WBq3GlHytYwxmI8v6H97HAjqrAHVZJSGNkPgXuPqbiW5yAPZbAKkLc22IriY+8
9Xw7sKaghn65KnEmVpv+haMfyhPmTwvPRXcdxW9huxbqEgojpuCth9CGqkzv/aKYk9q0mMC1LBSs
UGh02fvPpZvU3B8TcvsCQOl//CcokrAdnipntRxa2F9sOPvC2x0y5lmr2dJ3Z7KuuD2sCN9X1Mzu
Qe2jRtHCNkwhBJF2Uym+vIWO+CLXWKJ9FTVondOjoNvylQxF1jRfJV0ooo9O87U0Z/u0Zgq5fdFv
Q3AUEdHvJs7TFcQAhJdnKm2oy9XVmjukvAyUGlfZ8wFjMecVbF4+pMyM8atiJWF3Hx/RAlPEkSjD
IML9lxPdGEdmR/bDJHvyCzjVVCrM/qwRvI3a0g0n8gKiR6jaI4+gReo1005rrdHMKycFEOkKh7oR
ILBDssNMzFIPDUJ0inIJLVekswcBqlPMowBreGZ55o07tH5r48VVt43RMoh/gCWhFd+Y4izeV97l
mRl2PkOrx1TmrFX+AObxqPXX59iK/ZmD7uep3Yz1yjdR6wHtMsrDvEAN9A1+IkSldxkCJjCX9azC
YnYc9rzq5zW5w2fcJnk7EqhvltdDtuqdOIoreTd7h85s+5HyHP+HHJJ4O2Z9KAC353EK+sXUEuKQ
AN9vugNJvkdZRpoFt1Xt+8QO9L86LxkzxcQ0L+lL2V4DZR5bAgm4DxLsuEszE7EPLS0tNlVaXnH9
TGU4/prJIGkqc6Pb0eepFIlpTnpgz6vY/N8dIhOGpMdCsy91XgeHWMl7m23dS2V33tNEUCWOkE84
oZ8vfzM8ye4RIwHtMMmszGs5ddIY9ItWn0wxkGHCIT7f9iR9v02HgETyyPpJoT7svZQACAgE7XIn
HHxuvbSVQyL1HJq96XZ4zadv0UKQD7D4N6chRo7dpAoIpbztYhQqOaA2aE30aXN6RZfA6aX5CNCa
2BPr3/8xIW+y6a+BpzSmEV0OAaNMF4mRSaxbANaSeH3N28gamcJw4cEt0A4/lytc9Un7yQT/h8uM
lXb4xD/+k8hb+UVaIZdxcPhwqzQVdawbPaiHwG/UjzwS8nfSuvQ8Lo2LWI7UDQ5D18luwUqdJCKs
ub3ShJuFfmgIDg/JxAe8TI0wJxQgotWFY2FemuE9Iliqob3VV7NYsykw5YlQvEkHFNNNCVVVvgSe
4nCZ/UVQqJRyC3zgpAMaKNunOPOlkA2nKL4hnyA5T9Yg+M367909+uQXU75ZgdZ7cav2wvkK+wA3
Ha19vKh2vpRmkGnB9BQ45Gue6Wu/uF/bXw3vuAXSYT56gylP0ihze/ScfNInray2dzJsvSogSq46
x32fTterv2/CTfMZMmhfli+T8smBaTY76xANTVjKqnk9Hs1liXjkqhEpdI7Ngycm4HUQX9GbIHcl
MaMsEq4e8Ja+7Hr2vcQFe/s2aUzChvqt/9a6oBE1eAc62PBFnv95ifhjHzNruCPthDYnXkJLYk1M
Z0uUH2nW7UHyRdkNVNJnir9RDozY1PgNdcrlsmy1UFQwxf5O5YopetDcbArRSyDCIVbsJ+uibTbC
EiuFV4tvLKPin6Q0jRYYqrz6xPpOlsXBD81nQpSPAMBh7VaIZKPizzDvxAXPUNZAD53bA+gNSQg3
pCV+3YIhFJaToYzuLf3s8wB+PieioEc8oAH3UqMAfU+5EHmriXhWaa99RWTMotTsLgVYjrGhzc4j
fYaV1x6YZVGGlQJ4vqatvYJ5oNXPHgyk6BDDd8KpHoT6xjoHoWDk24dTMfeGTRoamuGU+ycQAfpW
qOw0G0DotQ7SQxc7e1OFYYeKXCENgqvHMvbAZh2/u+J9F2/Hwfs53QtYKKP6SxhlOi2kAVcZa/91
4MymYw18YvQfQgHbRMTufoVH4jLJH1Tg5Btd+wLA3KhswFnKMBTRCIlpKGISzVDsYHp2Nztra/aB
5OOodh2ZN0UmkpBVZbZVcDm5RcPZL9fmNwjtLRDftCAiu+Qovykxu853EiM6JU869fC9nYA44h7F
NDZdL4z/H6SsHp9Bq6MisSqNOBrwAMjVQhUzT4HX2lPdE1TDsP966JWqH22mG+cdpZP3pPxy0cSQ
h+N+8tGbcDrY2llf81eo8qOjjGclHe59SyvNFJtlAaAkgXlHydCc3Wn0kyLN5tAfYrdg55WDWIP8
272kQitLEztF6kAx1ZH5YhuoqfhZSjiOwrtkitUgd65iC4k1xdsyqELjK0OY7qCQ6T9byhXUnDZ4
9IQpyhbJm43ydDHqyUZ/MNjVjue/jzPF6UcMk3n8fkoY2ka4ulFRuJAvGMEfrEGRM0K52tBtl9er
pQ3vE/iH+U79xqCzOKIXjUKwMgnJZnRqI2OCnhyYsKj0wmcCVhbtGA6/qyBfhJc1YxKzv7pDZXF1
zYCXjLVvuog9GPnhf1faY/ZGG8d+hqWAgtt5t1HwyhBvYufXk0xvjbr1TJlfyfL/soPxC/KtkGd6
0BvriouJV1eGgSNCA+9lIy/uY7bQCL0JfRizf1S/TPQ2WL3vIK6eODE3NdnNp5sFDIt9AZ7Mp5BP
szPpRDnVoWIQEuIw3twEIKQ75+LIa4zRxrpUL+Quh9v3Wy11MyPuIXD9icB1zu/exHJagN22WQ6U
03SrkSyUZ0o/7tY6KjzoiPArtAx/3zqcLf63StAjSWYOnh8WeOA54u8TALXiFojRi5shkfWMWS0j
tEJXfVUa1fP/vzYle37E1P0Pp+CbvV3uHsD7YnagXhxDKo5EaSWQU4R8RdSx92mwKwaaNB3RupCN
S+mzrweexIa7CkUa5dux4z6K4Jd4No41aH2j5sNEXo9cG7CiCYGYsn3X487IKR5R1zAT/40G3Law
xUL4I9W44SQ2IvZgk693TAhHHhQO64kjoujaG4Y9HzUEXfV3Q5WTvkUNY0AvktDOYCrojRFFy8W5
OLti2ZmJ5zLdKtZN8HPJDrvKeBX33VirIbWaOxwA+TvlLBDfC4tU0bb0JJR8s8xf4uUl90TcfgLG
4nqa3P7pTFzSxaeoC+7TImLr4eYP1mIN8rIBftCt4d4JmOHUGt3OFKNmmCRPUn4rBw2YFBvnUj9+
hVXKEXovZOmyJpW8oA85Oq1QirH4NFryTm/wqztmcWagnqk+7inlgJBhw1aMLm53rr7ir/Z4pQ+/
KqwqDMwZbP+gUIDoIUNxRKNhay6beMgkOjy92QeqU9Wx2iNHb2zmKAf56SrFKgOn7/l8nDBqs+TU
la5WAa0uTtdeRP6c3CYbTBvTsO/5U0d+bLjIAjEU16ZH5bO0QL26KvaFb4FLRYuuTW27njiRcli5
EFcCXPR1clgKLFwOAt9VjL1eP22MUu2sZ5tS1QIezauBcgOcsmr0lC1QWi61FBnVFEcUXFBVUulq
nTlTqz9Jxc46rkYwwdR8rKlFhUqSleO5Es45WkV6nnMY+R+0VJ6Rf0byh+iZPlHpolbMAewrCo81
g1XrsQ0qlOfER52B/n6Df5LA5nZ5oyIVC9FpzengGZ1bQ4y72XozuMd2Arv9bhmj8A0JjEa2zzJf
c9jKyE7+0eUZsnjJWUarPhd1P9qKhw/0w4JRzCx4P4QYoIDSQtbh1Qgl6daMd+cFTgI/KJkx8g4c
THKkCUhDqp8LDr3mxx4wcvqOrQ/KnDcAwte5keB0ejA/7ehDCthpyWVYq7WZvg+HmwG4kHjUzHfw
3lv4ST6qwUAVmD8Tqqt4OicaJflgif2m5MbSX3r7XfiRpqHSC2nmikI2rkrGOmz+nsyDSDyOC84B
4BV68W3R0zP/1rEp4IJxqvN10Vbt6vc52XX7HhFuZ/ea7auUBeZ+3t81mRqlT8k5TyLK24VXQbnd
Goo1/KjO14Sewv3oTlVLvxpRtRQ2iGOGTSDjhhqVdTg3ucw93/kSha+SFHqT8rpJmxVfUILCo508
EA4y85Cv7mfxv8vmvAdGtLsCAeVj/ebspOQJ9PMyNY5CCK4K/94cRhWwetQClHDzz9ZzcyFylFaq
avYpBDNm12bdJim7OCiDL5HfSbjdta8sFL/dV1951WP4S9d13NpD7i0ZgADOafjNPzx2RmOajo+I
qiIuIVODHb2DjSNdqhRl80Hd5lvsHxa4UGyRGZiRzw6dMX+BYn0/Or40OD1v+RrzoQcBKKiRVYEh
4IBanMyjBlY8FvDyK7BbPVSgyPJi/9U8mmCe0/rW2z/m0cnagSmZcZdPhOYC7CD0aHSKBQr6NDgN
zPiAhtfRiF0qI4tZD/54/FBVMO+R/kpAVoLuJQPxRSJHvxvHYTRlwfeDDoWH6BU5N//6RmG05ERD
w2qYIwH/qTn3hFCgjvoK+eGXpOXzB46jjwrZH6H42OmYOdbyRE/Gm6jeiRILVWglNtISl5kEmO3Q
pPHFB9mqsGBuimOcfXDhiCZRLeU6pC3oRASv14dqsnPVFaPOC6wVZS46JRWj/9qB+nihebaAXCQA
IatDWCCO9vXojfy7AO9NbcEmImjHsudjrYkwjFfujawKdIV6taJeDAe8cShGg80/4YKOLhUSWAiN
k/lSyP8LSxaXPIdK3CnpQZ6hJvL/SDKIo9EhKYXQS1ffSc0i4+YV3bhnmV/MfTuy+5hNKYkutxMV
jXMiQz9Jf0Rix+FKtRWnCkPku4ORNZvgThVCRIOZKIHziVQWTG9fjon6Pc/5P4Ad2PNIVS18vTQW
WgMk/2gPSfrheHJkqo1cN8snyh4wOCy+D9NBH95mICIVxYYCpYxrIpympnxHrz3uj3Rj+/RFnoxm
eYR5/As2lzG+24lLjjE55W5Rozvhwasi39LZMx3VbU12VCNG/dL7sHVPRDHcCzqOOE8MWG++xsOf
xDCJVKavy/2KPBNCXfCfffVMCuQgTgGoAphWLIf3SHzj1GsnLRYK7XNrmMZaRsflmlp6fIPwkxir
f0owBEcPQ9efqfe3PryT0fLqvxlUHVyYBfYOvEoxRcTgPMWVUyjvcEx3OvLh0F5YgRVQaxAaMJWX
uKihTV4AyR87U1R9sIwUalhWtcErSygZrqU8YPowdB6kH8vPq9yggkyDLrQ1kbXT+wH4t0DRcEgw
3vySnZY14hvMpNhWh7yfoSaDosV/o/yiD5UFfjhBmhXSVTRk9toNeGEbSnlwRJ+gQyVdE3AA01/o
j9nuOr5J1OE7hfyKILaEj0is07QINxlXOkcnPOwuiADRf/JDSXoJI1BHGNrT9F6iyycMuh7goXMt
+C/mi0oxj2gXo+bfRad9cFazUHtQyJnzKCn/LHVjAMDrA8HFHMhri5+pwY2Sv0JLC+NJYivxWOgA
wi4skZ+F6+82TWA9vTRUyZQNu6P6E7osxzhlm7a8CUsvKuIr83SD7A4Vy3oQ6aRAkYpYqQAWev/R
mGQOumWyek8U7JV5LIdW5eC4RVaqjKmwtGGv9ME67CuiuXve7TtHxZGzq7xz0yA1ur2Nl+i/ZEJV
9X+bCxgQ7dnlNBzMfZwiJBGygopL3i7DfHDUxQXYeBJlsXBi8NGYDy4GzfuXhDYQZZiMdvdZUwf/
tN6MwZpIYLFLfIVAaJk32hUBzKFFtAw7BFjJLl04xG1qlZbAz0A2Ytyss+zYVPpvfUM+qoT7LZD4
Q0Pit6eWYBW07Wf8NWQgSWFJ7/pRQpra9XxZRk+AN40MYMuORVjk6oNJKdPOm2DPzWbgxREtjZYO
v78HttTaBd3YxOGUaoSb2+E389YLrwAAeKI0D3Kl+bpf06vVKHmwfX36iNUzEyvRf2tbW7vWaQCm
eEgXBbgi/h7vydro698NChCn+KLpawHwYlo53Ad8OO4tdgXbrygHrGQiwDh2QT523AQh7kZ0dJI0
DS3VR4P2tv6QNDUui4Ti6NxbQu/QRuNq+lPg9+dWDSI5cUT1AOb9jlpvmUgCWYjiVx0ivFOs1Eby
752H2jeIuupHujChcnAOdqB2MC3IbNVFOxYY2lySNmj8EvmC0aC0inBPOOUmbxMvXlypunRSVT9Z
bFQjOINo8TQ1Sn6tmPqBeVeodbwFGg2UGOLvyXXOBxd7q7I5Hc94l+MCAn8Y8mvVH+NKKOU65So+
1ydmrBykK1wqrTbq6thLpkffelYwvukJlADbjHdB/yWLmF7cpmLGhuZkuIfjZujxASHU1zXfRx4B
KZHvhkpK/PMT7Ly3LGLVtrSZ66D26aw/nd1MDlnsdXzhg5Pd4B9Ixl2b7h3nKLNKiP7tdk38b2wh
/eh0IFMFKayaYjJx0PJ3lKpyII4yJsno4+/fHKEXMaEPqUQc3kXVByhSDiH84SCZHAqR/RnXQxBl
vELl3Zu12kjs1VqIUcvv0QMOMDrUvAhWJhjyQA2uw7QlXdiXyTvplNQP0AP7//8I/3xqi98NNBOb
O6qKaF3BN4HO0dkIXlTIXJv0K8BJGSiBNqxuGQhXOzIZTX9gc0NrOWKd3e2WjaM1MDYQQoKNIwGJ
XXTur6Rrd8ca8TdzzcZogWbJ3zZwxAskXBI3D5rWXuB31JK9tvIvpwpNbLKtkLJ079WbMAfdDhWW
BBS8v0tXEN6GMeSEbrVZPQo+811192LxfhxlQ961oO3w1JKjloAbpEJZr25qPe+6J55tqwxgdquQ
K3DJaDJoSIYmSEsDeV+U5cqRwh1Pryx9bVO1USI1bW1f97lMXmDYpUWEr1VgbgsxFqkyLEYrFSjL
6liOkqWQMFyDvfq0D6xUCzYVWHMKKB6HAcxMqxgo0VvwNrj0NKZTE96FMpph2+A+7YPtRGNdzerH
m+SId4XfgFJxUsmvcvrqBXdonMYUEry2zWFt3xsPBmZ/v7PnXMLAHOVz86NbtlcJmkB2uaEN/lri
TME25vqmB3WwLx4EqqOm++SUlBeNzNZ/WJK7rvhnBKgc/LgNKfyMKToTzmkkoyQ/CIwLPB2b43Uc
BQBo4zysCf1lyHnLsMIu9CZxGaUm/RPAgc/9cUWCUHKnRrYTbC7bSEHMlKDmIuqWDfu4cT751kEx
6+i9toaYsNFOeOIYornCsWyw8VjdZETv8bnzCD/L0Q/UOKScqK7a/12F2rfVWJj0qTYRUPqE5jj5
2fSwnpKYs4hSQWUmb7829t/szeoanlQXtq9g/wk+ROYuGo1xZiv4Cj4Awy97JbsYhwBbfJVi935H
0HbsheN3WgajKHuAexfCqApznTAeINyo31F9ge5rP/XfoU7s4wuy9eA9f7rB9P5awfbwQcpu9Niz
JL+HCLx09mu19o9FLGYwBGkcnZADYmDOyK4JwQWq4czqVfLd1wfonfLlD9lUedwQkoIdIUs9sYMD
8qZjJQCiHXNy7nS4gNREZJ7fEKfEf2b0YTYkCszMdBZdcZYETx472uoHM/trxFTtJx6IUnrx9NjG
pPubNIv4TSGZK6JL5UN7WezVCO5qp/d80IbX+jvHl44tojwI+S4MelkOpe2JnFDPEnQxiqngvkHF
9vJGtL3p/a3+byXSpXqawBXcdFB2aItFN2LX8iqOcRqKXvDwXd0xeKTQrBd4ojXI/9zE5iQ7hRCA
geXQPVKJVwOAWfVjj68fz2+OEnqchS22vsUCY6792jxMIJaM/57klwLvFQlvVtxR/3MJ56HVgYWh
XmKjq3c++oky92HFZQjmihSSDbMeaxV8XPeSaBIIc4rKb8rKki5ge3T1gatYn3omx/Aqdy4STZ/g
Hg8qfq3TpK+kwygSRdssmfl+EEeo6V3HEgXkQtqIFbeRZnIO8HmeKfno+6PPZXj3U5kKzxNU3Lnr
5HkFkWYG04/b+TTnfu1cx/CdYVozNqs2AYiyL2Jrf4wmH+RMkw1bqk1cxA5WgtM0XyTywpW50Dvc
wMMuwv9u+ws0+LTUciHw9V1SVkPWitK3k2PHiz7+ZhHiNV2XNtE6ofM+v6lKnNtouxUVgawAqKJJ
AHEGACHjzZWDe8nx+6vL8VbrIC63D8mxeOvrprMss6aaWxNtrYoBftzHNNIBjmyhsQVMR6BXVm93
K3oK3cQ4kGjys6fI+oGWOJmz35VBE6FYtvDHHk3rnA6ZIw3Vh9e0bfXJznQd+Gz4hR4axmcuYpgl
b9SK23ixqu1dsXDDfXEvdODPdKrezjAk/2uEl4S9TVarfO9UfuJwtmlbD4vdRe+8JJvNnTwwYKIH
ErZFW7r1wPnGa+oKuvK3LFZ8mm0Oa9eb9aBVtiCmyXjYd30AThjb9Cz35ZMn2lpLlMOCQWQ5A2Jm
eXNkyOIRvwja/MGGg+malog4NCSxfEvVOewPW9Fys1QlvOJm+0WTMMKnxqfC7EDFlT52jZUj15O7
ZdwQOxiUM5swtl3QF3tpRlyP4VA6PnZ6+NaRend3NPLX4zexE5Th4NV7j9fDiYol8PTzRpTUOohw
+TlIc76xltEi+LcTCZ9QRAkJZUk11yc8C+gzAlJIN7Iz7MZ4+XIT8wmjuTMQab4acUAeLBnpsRQ3
WkwpBFgW3L7XFXBHvRIgHEEausixZzPwS5tnieVAoYUkQ/qKvyYYRUX964KW+rM/r1w/NSOCQFhG
4huFlQivt6JxD19iKmSoNkyvyvl6Qm/xHqxq9DmjyJOB+Lv2c9zWC2SqiLcrvqKDLQ+VrgtbHVXO
bjWJdianWWrByLoFE+4IarW3bZqpr3fB/CM6y9jov+dUq65PTRihzMyeUnkS5mQT0FrDhTCG+IYf
nk98P3Y9fJWW90MBZaUn8qyocXVbHU3vy2YlaUNTLuVTWigfn34bZnBbfgmQeXER3qsM9dBIW14f
nKb6l85sc73xTt1CmkqeOirZhPZV56vyEkQoA+f19AQ5SvYBtMWmmzs9rS+5IF4eiiU86BIJ+2FP
uq222igQeD04uKTJhsOu+FPJG+APEPE/DivAaivjaQqn7NgayBdz+8nYDGlMtADjI02OXOX09CI7
osLKcSEwuT4bcyLjhb8mtYMXekJ0PwnIgZrnc0A2b54WlfZ4UcwGynKR4ZOjUGPDszN8cAbfkzjT
EdkPerY4Oz497OyoJwp8ca1Iw/4+myp8dFTs8AqtyeWO/1YjORiOOMYXqjxXSFdfry4ChsCaR9/w
7h6hSojeYuhQWuEeuYyBmVQhWMp58vV5a7slqa2Yo2yoyL50gSJkQbfDDNtDdphjZCSRhRHfIOaa
Q10JjiBin6wr5aCFEuUZ0Ne0BbL99pFqdI6YbSLmD+e22Vim5b6K7mlbXpMI3DHl2QkJP6+VY+MV
0Hy2/B8jScrgHPrhDEA4gVEQD35p29c3cZ5gMMvgsZTn5vZk9KF5ZrnUasoMV+C4MRbh+3YeQ4PS
IKg80IG5a0RURqNT7VblT42cWziQcdW0OjRQyx9qq6onk6229ik26+owb5cozQogn+GvOUFWIauQ
MMsuutdQkx/zp7IK0IeUhjU3iR70KJDBEZajgLNmgS0eJKRr1Im9lj2D0uZBR+xlBCoOf8yzndlC
4mZuQ445nYHscy2pyU2MVcH42hp7AFcR4kGUjOMKLMnfX0oxK06rKPv9Vb75vqA6m15Jkri/tplv
7WxVz0Oxu5QxMdGtErvC1Lwszss688LODcYonmehCJgjz8UMQmJ9gMyBmu3YJPjyNBx7F4J7+2Xg
ilZuMtmUKp+JNDhnwAxBLoAQ2VPEhmfdZuonVd1gFXM3LeQN54PKzCOQiOhahe5SYWQucu+iJETE
nyDXcJOVv0lYE6/Gm8wkLRUcTcbol48PokRO48dxtDIe+hGapsB1pDGV93g44TPtFhA8r2KtTdEl
3YSlo1ePYqJFz2QKaVPEHJsyc0+p8qZnc3KKe1frMzwKvvjuADkikKNpHgbzuHpj4rsoOhhIr67E
rjPWTB7LUsL2swjc2UD2tgDdIbyt44xutBt1xZBBKFyWP8icA2myf/4nFMgcbQ069aDqWLjP8ZFj
8VI7gv+J8SmG03kFs/4dg3ST5aIzKmpRI9B9v1X1ygM8kyIVxQcZR+p/tTlsLaIlkdGyuvmJICFC
BwT29xEWE6VuJzakNyazGy+LetAPXjUjhcFfLI/oUAugnMqFbrLkvudU4+wMyCGih4bu/um4qI9S
g9O7F89fR5j/4h2VsHaYCPVSCn99gJZXk6FD4Vu1yDFfL42GtibNwWY3p0YMfkZCLjhBvtYflgh6
mlUwalMvSO8gFbsXBn/8qeX4muFXyM3ZDqR+0ThbZcyMZTf6aYnWOnsoMCQfmgNr6Wv7VC0dDDYR
oT4lenAndI3ru0I68QP0hmVp734aE6zuI82SNoK0MdnWBA0g5ePlqiNPq1qA1+F3ruepIH1q6G+N
4U5X3RqnfzrUVprXNeNzWAdHvx/c2cNb+WQUQSw3wEuLpeyH6C4aXI4WqHbiwD78NHNYtsq7HOwe
dytG2bmLZgX+bEl1tjDm6c2uV7XQHEvuIFqLX0GiH7lun+coXaYYaUgn1TlHJjjfHsA7wvybANL2
AGZjOSKTS/YciMMPWPrZsHC6d2s3K2OoGv8SzY9jy/S1GGL5KOwU8URRDYs18iYHsD+JKUPdfO5I
ViIgFQJARMaHmzoXAXNJmBYiq4Qmp270vbTnadPq0+jCiAhxhn4T0KcYT/HE1oL8/g7zeQQn3sIH
8F5o3UnT4SDuY9KKKyTjUTFv/YOCL68XiTnYhCHRkSIQJ2Hnkl+Qw+BGYLozisRxwteiCS3HfDDE
jFVEJcyiE44m6HrcuFLibjsjNKjfbhjiU9uy7byQeqaWTGoOOkxYrKgTr5VPkTsgvmsyF7ilOe5q
7VUjEWDJVBs3ViyD/4Eg2Z/Vfm/Doh9FxOvROHJRvdHlOrCfcU1zw4oMRxrEhzAudlhpa4kLiMUA
S2dtRo304/pFpbm+v7TVrFkUbwnRzBqEKLAyuxa4wM9TnZ6Ax+BoJBqRQCxKaHER058vq5x/YEPV
aKdcwDsSRfFVaIhTXpjCBaa5Tc7WaLVnyYidX5BSQDF/q1w5MI0Ch0ZN2J744To4pSU1giURjCCJ
PNC/Fpr/xVRaeVyzZtYAc1y+l/9Vk0OJCCGtazpXq4bgpcwFnDUns8+Bdz2yZkelVWsMpiDicEsi
8ww9cgpjy8esnE8MYVg/6f4nfn0A9QLcX46qB6AFKZdp1x39ymXCuDwP1r0f38XgXVwDsnq4ZPkQ
j44wLzPSkWwU0qRONqegfEpah1Su/y65Gp4XDA17EqezsayIVOXou0ncXdtezyhJZVDHce6zTcx/
T8ad2E3mUXfSOKeghSXG4Dg7FxOrNVCbVCSl3fM8j2SemFivFAeJDjV9HBdv+we190EIL1SFq0SK
HiLJdrwzKpeHzG20vjaBK4pgDHOtqcRgni6lhaxwOMgP/pZ2l7h04w4fuyIEQcztJg4LMcyme/qV
D8bjeVLC1wSUMzllpvYEJ8X1agsF8Xwu5A+Nt2suX/5X7WIVElIpazhtGqWT9N3HwoSX6Dv4X8KE
G/BhlZstEk+FvDAOn1WajoV0WMJ9Dt1OuIBZpTtIcocxba1LTw+1JT/MoLhO4kxeGEvPB1u4XCS/
kyeuOSe9pqwN5AYPrsL61RR5gw/9pDt8y95NXSPzN+Kzp3MOawErlOtaQcrTQ57APUJkWz7BJpRC
pyn+m0oDz3W3kTVkWmuEYLpcPt3dg+elMIqqq1FvlRYFrf/5JXpVmSMrdDj2VCIA0pGUQ5YQdtlf
Zza7WEJT7CMecWj5aiC9/qWJYKoqOaK6twpQI9VaYAJrJYgmoAmYFSv1zQHIyWuI4+1vWW193laa
YIbwkM0gqgc0ptB5zoQARruzRix6+N7t+jkY0musty9RD8sWMV7r8kB7Yikgmb4nnJL6qafTICf7
q0PA///ja57Mx3z2veyuIdnEjeeesq57/bHXpRR9cSNCzMWbUMiBjdGsHWywact0rHNe3P8vuTNg
WD330eusVTxyxrh6znH5aRYKqgpfVbPAFmPhNI2FYwtZk2sv1wKCKLD1HDS5o4eKrOORB/jGXKwI
2kKnVThSlYKptwYE5H76CXWMeJCWEF6eeAUMYpH43N8iqC6qSd6MWFfsggg7vqg9b2C+DM0HwJNG
Ir6DqItUdZ+WQISCOtspzWrtJPBPRyNip7b2/7EwqQ9QEs7OfefG5kSSXOo8fsKYp1aeY90PVG3n
OG51r8QB8kc+EMqqqeKV5oqlnsnWulvC0TxsQujswKPcPBRBQzSsrdhsJyWgHfEI3XNfKfUsj7ea
R2Wl6CxbOA+RWzVht98RJOHNn47O59YOv9MarxlaYM2OKuYfrWOkmzreglpQOwpppR9qjrZR0vdX
6lGJCetr77VpuGFPnt3QYk0eT/VSLjfHDc/a1na7MdtSRGGDsyYHDtr+cE5tJn9/8cHVi1QV4EXc
gG/Aic5/uoB1bwnwGOkkxuzLoagjLBc+Vn7Li+eGXtI6bTZnoO62UpgOxPs6aQeKcnMCW+QPqzWG
UC8R3PQn+zM8ueuRvKxv4rZ4n7sXpJnAkRk1DtkX4k6SlQpo1nVQHVPCt2MEfCmSzvwNu85dwvPf
DZ3AcOcRobVVaVvx4cA9Z/31+Ze/4jAldpyRoUG3e5GpsxA09PP5xmnmDPhxlsAoj4nzaHzoLcx8
YM4J/H94/XrJQSz/meBgBO45Ijeo1MvYBkvH7yK5qcVQGrZkr7bspYxGLCmTY3N3pBVRSFynHcXp
lKE/qV/Yz/W3fx1gm71GEwwuxqfQy6egj7Ak1MdyHBT8ex9vNRZZCH7EPOCpd2/NLoyTa1BESyRY
uNmFVuBAmoLhnX7y3Fx3mtLsyJksbdy3nWUwAVlCFy3+HWwTK1Cueg0lBpR/ZBmbbTy4SoNePLOe
q0RQjjnQpMT+PmAiFjupx7YIrQ7jgpobMETEnQv2EXoc4uQT4/ER4OapVWVrNAAp3MsVXSktVHU3
r0kwAg+/KqhJ1YgTXQMuxQJvgo5bYYwcFkPpJj2Nnf61Ma24w+KDZtA5MvsB6zBoc2VKYODohyjg
/fPq5kZp51kx0kBCDUgl+c4+R+mCjFknYYgSDCu/VXz2GtjoAubGeRhaRocAydVGY1KUMGq53+ut
cRO/6wfXwvL96Wv+OToSQf/VoHUd/Kob/IP5k2NPhVkP3cSkdql7HU3/2cFAfDcKXGxA4gQUPkp/
pRkm0ioJiBCN8ouf3LCLzEM+tINjSYlJs+lCovZ1l70fk9l6sKYHMWwsCluhlawraQwr4tqGLg8C
HkuJtuARsOvNttwXMuK6EvXkCPsqIXoRzosdt2Yz1fQWc2pOpZZ2VIRz4ZAZsHfaD2RyBTW6NlXE
CVkvOnYmy0hTNSUkxkZ5KiWjQYuhGRsB/N5ywTbMxUdqbt13Ck532bbjTEud/XjCRd7CX9nwpXpE
2HBTUxstMCsnS1w70nzicroiRngSrufNt1rwmJxRXI/b1LCvx+5V3oemTOStPw29wejQF/ptnBAz
cPBzOJy+dayqLS7QDMoHbqnb67n1js/c0zgUWi+zV0WfiSGx0sIZnFALf+9Z5jQeivrFTQ+G4P72
z/p82fCsfDcEmtfimBG4HawWwY8X/DfOCeA5k7RyFGcGYxgPi/gontW4UPYKpDMWUP98OmrBgsRP
3qnfEsCZtQcGt608jNAN2w+IyDBgIVL8bYEUOeMglpZrK8onZ/NKXdBP9bZDSfU8Rpyeg/nUZoOY
74zI41ny0FmA8NxNQpQ8jlCvjEKaTl2TmZbwbENbYak2hPUljQ9jM+SkTuceWEggIGDWzigaL23j
5uleujyy8TEYQhnQW232vKb9M2zFJ03bCeY/vE6nWjA6bo/IH3NT/bROIKNyydI6djr4UsXr9kMV
eBOKD4uJl+KBGg+MJvVaS6O9wicTuNTtgPLmfupCok2WzsVobsr2XcjYRKOmhlZy9YFFw+M/DYk6
W0vAtfsuMMJaaKP0BrNaXjX3m/LG7dX3O+JvxVNwzQ39tSwQiXL6z1Z+I7ZPAolJ3Cd4eHmB7Nd/
FA3ojlNTJD2eatBl6FA83bEPdA2ifODUWkAO3SYNv/mEaEB4F1uNy78Cl1OnLtuL7KSIcGzu/eHa
45czUsyZv7eTwbSNZshIHb1+DfW0KKCKbZwkdvro7wmVDjaC7cuoxMh+/aUKSTYZWebD6MoBfDVZ
a9gAGpaOyd2gNomDZ+IDwzLtDEaJ7UqvywmJGf2ZrR2C5ZOPJXBrI5zY2vXDxRBhbEk/Szq9RCZ5
b4U+LUB9Pt+/G+m/fFEQXd9ypOT8ok0gSrhhiAFcII5M50iTmPG5rkCF5FJkR61339+1hDZitI1t
jU4oYzNNSgdIfPO5wWWFiY+rwZ8rouii8KYgGuKsDTYc7XC96UjiGj7Oz12fyPi7V3e0UoNIpyhp
ZqYiefR1O+0fP2pLv63wg2EEY9YdPQnx5+phrkaAoIeMhIaG4Zz8AxLuzSx7qXAE8EZ0Fo7ioUS7
nEGB2JbDoMwm7yB67xBBqc/mC3y+Iq8l+3CTf/FoAcxpUcXY61A8OysBHLq0TwY38Mf3aTbKXeFP
ViGlDvvDhWeWgSh0pdvtmK8oGrE5/auBFUTy00GqQhQ8guY/lewQVmYmen0UFER4jG/SaRJO5pJr
D3yKVzs4EsGRpn2ZlI8Pgq5bbx9zSbKFO7DOEihkYpvifMHL3RacS6DRk1VgqGt6ZKbQqLnN1kKZ
p7a0W3VXeU8SfAIO7tyNh1wBWSlaCl1IK5eUIveElDM53xWtmF9OWa0EgriRIoUuswYJsb2UbAAH
FSKvcrhsbNpDLIR31ilwY8hayM9zXTue4Jsu7QZADcIlgRFzDphbnCpvs+mlk/g6kwExX32RXKnx
EI19LBrnJIXtS6Wb1075vqIUWsYqVhh0cGHF+mcve9sCUl9aCHxFRBlG1gy7x2Jr4XPlhDvmVSfP
lTTDgWjZJjrRHFQr4kzepKvpqgpOFgILQGLEw7u+bunLxI4pEGaHwy8WBlXc4/F4PonpaM12ef7l
a4xLllbMQedXuSmq5qqLnbiBUbbS5HnQgSGck89slmUuySgwAAYddOquRftw3DF1cFWCwNhb8lyw
KyMSnEC+AzyvNE0lo85+ErABOY6B1zH5Tcc+jFJJ56KfWraR0TzL52yQdQzHPB1456dIm/uMVUI1
GCw4nmbIeKec3E/Xx+4p1pWbkPxm1gfICq9VLgRQeFscS41tfWoeBRblSNHGRWkOv4X5vmz0mD9L
cs4Ar7yhvSMAdb7S/t0kbK1BPjqGTpSFdrioCTXkQjPKDbM7P4+zWaSUAIQ4iudR9XmrP1gut95f
fWffY+Tcx+r+D9sZr6MgDV6DvGx/lasFfQkx9ww+hdEnMTqtQopNw9WG6qjdrwRFk9kPeXm3OKYK
ZqraWvlmZvhUz14b1XXe6O8yO/lbb6AraI9BfrM0ssIvWVhxzvt9P+InO0tsu1QQZE3dM49rCF//
rgJ9Ofa77GInXSbyz2hIAE3/23lez91/+HUlE9Xr9hH/f5hA4OeF9vEv7onLyK1AsTtTzHtBM6ex
XP9FL/5JUS1182BXRnid0jBqv6JdUpxch9kyS7uc2DBR8eNDd6ugCljCH5JnYOyD0o3w4gAgpL6I
9+obB/Oz+wP9qkbECHzyikmi3iKuuKlaySOpEmmEx9YFn5wKPVJ+5dyOmiLvVtejcs57BXx/Vgd4
2NWDnqd+NjJ2b2faDAMP+KK7i6mSKsfjzsHEOIOeagwRienLm40+DsH76YJn2selyJvHZXh5ZMXT
JcmDMIsCymzlOmVMkizf5C+QXYJaGWkCPZsHLZZcXYqAoPKm0IVdxr/Mo91+xwefrVriYrSjX6Fm
Q8WUqKSAjdUA6NMPxNiyudMeO9hM6rZuFBu4F3oaxf7fwpgTMmgnoY7E59cPE9ADlG2xr0vttba3
mxNTnIIUA0AT0bkuyYBRDQwlSv2cbBk2obIDfEiNpj8vw1vsoerNOg0OsUm9WwSzJj2+vciK8kh7
k0MLu6MVCA5VS1e0ais+HHwdf9o3CCzvF8XnB5jtgiMPF3CVaA1qbxCPM4VzI8pMHY2m7bf0553S
ZLutqOD5+i5d93iO3xfv17/gSp5DIPLgq7CuZq7GS8SlWRk7iuPox/f3B8ifl31LqV4/AwZpgXcn
BJxySIgf3fI++bxUOmRwmU8YJIdAui8Awoi++DMSh3dK1H7u6w47rY4viwhsvxmRWfiqzlS3k2R+
oDTlV3qxs4dsBODlIMOx1Citypp92h6VjklMSH19SRcjztygHuMq8ZcCIOuWEeuHPpSHst44TJ0S
cho9LCnmE+cI8LQoH7EseI9ndjnDEtlQQgxuR0loCa3W9yXF/yhFqu5m0CgWjGnYPKrq7rJ5+CkO
c3SFkiseKiP2qopC7TVbrY/WRemwqo2NlTIaV1P9udcr3PgYB/62Zc0dZEIfmwywj0nLsSdeiq00
mnsrM5BEgrqwzkqLpjbeByjALQZjxTZPW5inxKRgaRFpxjtuYXz33EbBfArSrRLlweGHN+Zv0/52
/lzIalhNBZawjO6U5cNEAhaD2TKLGe4+wcEYwtAkLtF79xV508gPhpN1YkRiT7X0SmWtljJUQf6e
t0RlFHkZdupNfKlL5/PbhRIBa6A2fhkRnSnaxRzDJNCfCXEv0I7RJb7d6GkNNkw0Ne1DfZ7L3RS1
IxfrjV60V6l08PTXS6vP/xYE10+mV3cR9R05JT9C44u4yWE+01BaVbE6MTfvknqcJk4n5UHARXuB
L9oSdzHQg2kHNU2hbYEID4blpNepAvvqXLoxUALjyv0iJBs0Z5p2fe4Qcd0X9OvHPpVNoORVuHps
Qx76qq2YB8wxxhXNlTASgb/s9P+SfFTGoJS6+4w0VwhZJ17rfwPZDs84XYzCZphKiFkriFqFquwV
ybQkvAQIrBf/wiVSknVO4kchY+zmmhI+2vQjSGOojmGatdA7ER+7WSn8Mrq3etEE4xlIFzJNiSfl
wQafjHHn9daSgppGrOMzJRjBSXhDkSFsHimG+IMlM3zSqxl4kR/yAXEpbjMWX1MBlwA66oP+Vp1z
x3+0P4ahvu9zI4GRTt1aSKFUfTdTZl1uJQ8ycMVM8cdPyhE8g4M55lpbIx8/M9IEyMBCQiuESTwo
uVRv27+jP549EvkR0uf6j8G81l/H4oii+CU6i3fJ2BLICm6MxqRZ1Hyj2v6g8qyeHM6gdYPHI7N5
R81DbcdnAzIhOqN+qd6dQq4lPwZCTV95R4+E58yVlLirTEyce6zHGyJH77i7Vlyppbh9f2SQG6W3
TZGwGUekL6FMkoRlxqC2Q8HZthM3ZykpnkGFEtEWAEj808K9DE8093eIap7Hq8xBVBcyfS4bXODd
8kQ3FBiHcAPnjyqFPaSoAOM12sZ+Apm9ZFQ9hv9vlO9fuU9hi+pZbYMe0WRc+U5AcEPJpu44saXB
5dzmd0I041+uT0WXoAhem6KmOEJF6CRa5dn/Bg/OFQdS9HQ5m5xezzGQQQPPVoDI/APKn0HrWGI5
GZ7xuoeXLUraF3qdJZKQbWUuz5upP2a8FeMQaq39dV3nYZ0GMhyv5hEG1ujmvrTv7ww41hNuSnNG
2Xr3eT3WZDEf5qxMYctA/oqY+86yxnaUx7pvdaafv0mxl05aJN2XlbKxuZdc5MOfQ72IlsqVgbqN
Cx3n0O9he7rsK96jgYvCu7bgwA2Ea28Cc+ue913KmAGtjLj/JuaWm0DiASqJAUvmdEcCzMuXV85c
OuEbKq5EA2hjH9V8TTT7P0jZzXwA5EImj0xXuZ5HmVDFCkZej3OH0++GBS6kdN2EJ+fwIWJEekgU
jmjRG1z/wV1J5jWi2oZdxu/FIv/zMZNVxnn4tEQz1hHT0GJ5QS/d2IrAvZyS4Km7LUasJaDf8nlb
3Nf1NQi7IenBzxcoPdSXv4m43oL62Prsi1eLdBTsOnjbyf6KlhgbwkUF/QaqUOKCZCvF1oDfD/oC
RsoE1iboqhvGu49x0q4riQDWjM/mVJwUstJqTzu279DG4/gSDxtNgIjoeoc5javgCkS5kV0uFZwx
C4ZRptcExzAuCIP0DUXwpw+ddF4AFDxPbK83xid85hC6V7GMAzPj6J7bqVz0SYxpD2EaYF7wRa81
M8/qCv0daR6RoMRAKspaowdQPWksTd90S4QH/NsJJY/SM62wyuT2KSj1pXjmT5Qsmw216A1/ivMR
MuO+Eox8uxR0IqT3rdQ72I8191onId8ou3ZEKwoBDJlG2Q4wYjbUzaJyacW3T50cOc9Sg5Sd+WtC
rWjrOWgG85H+G+NqUc2p5H8vlFebA9oSbcJ4z4aJRJxjzUS9ktMiUJlDfymlw8dwHf7Z3dOc2xfy
xqDBEUPyTDgwFT2aOm5cHB9fP2a9WtypC9o2r7qi/EtowqDOU75mjHNVIOnow2cXncSdweJX4WKR
iSWOhmp6GLzKZv7vxl5YLS1SXdG9XWBK2o4Mwgj0INzAuHkAO+JFXn6eHHs3JlICFaSnB4su1Asf
zipPRazU1hQsbO4LQDSL6DVnMgU0QvCjyyM1SUUsZ8vrtSxDCE96rlS0j7poSfgXY18I0CiGBW9r
gRTQXMhvyxq3qirKNNkioAu4rzpEnI4mPby++nHmkOwC5QzespX4/dau1Eabs1SfYg/dJWqsvYd0
SgenIboNJUWWzn/RbzDw2Hwc+MWHFYC/j7JgyfYyCWOS3KB20g0/o7bQD+jYtrrdcUl0MF1Pl+78
3a45wCKCMLdhTieHxOClZHV9p6rFejch2PLgg/po+zcLGlcfPBQ6r+30rikqSewYFf94cU+GQhUq
htSHxzeiJbpYVMQ/rRBFEbA6snJIJ+F2rSvJLueWJwZIuGrU+2+k1zeif5Ng8B5ZA42MuveCVrOT
6qyyn+cl2B0ysF9CnkiKfUJFJxCeI1KqJB4c15OkoVKZU+yqYJCcTBM0z4EvGGxEKgKwPO9a1Qbd
s6H0hHSHjvNYCKXmo3RpyyXAxFyKOnRzYEFoFuu6gmHgJ6H9b+4vzVNYiIFBRwregGUbsqt8+YkL
FZWBIMbNEfWmjIvnsCE2MNpmfydAx5XNnLUBWZf7OsyFw/kgpt6XPr8ZCOLAIP2hOe+PU5owKTEx
hH1dPZCfzmbPHjfjGYv+vVWDV/e2ToEoRuL3W3z3xpn8FFUk7H3tLNkUpKzSBL2yrC8PXuErsBaz
yeltT1hVsNR5pZ+bU0jdFam76KizyIOxkhHhrNlBneac59GwQ5ae7aqAbY90BDU1Qo1DSajSouQy
Lq4rsiCY1oiq5E06neqFX1Lj6mL0p0XiqLdAC+Qrzwrga2c5DJPmIp8/AapKC4Kd/5uhfvWBLBIH
w4M++YRB3BNstuhyY8uzN/1dfvC1N7+My5QOZwEPO4t3a6bOhMgORQzoqOHO9U11mtfOmAWIeziT
1yklJYEyMG7lejV1oApthMZDs/KdHAX9V8SgB85zeOcwgtcXRCgnrkcTcUZjAUFDbBMwuy+oNcxR
X0tbpsortaXI2YVYfeqoPvbOgkjBhcJywkoLrsnlwPAQSDM5NZ/zghqyiHzKM5WeDD6LQJOYuSEy
c5w2I8Nn1LVLf84r4WCM2Pjr+/0KW5byThc8bnLrtYwLg5d9Qjvc4KFn4WoJqIeI0gkiXpWO0zsS
HummJxm2T1aTdFBSZo++r8jkYt5wZYHemVxKIrD0IZ+c0DdKFiY4oqyaSUkv03gihL/7aSIlY+v8
z/jQOfHIGMdkINrWtSzqZMFytqf+FAqXzWv2vLQBOo42a0WhZ5UsDEOzaP3dYvWcUWYjmaJmFQZu
eDA6JPnJfcV4yi4LkpG1eI5ZO7nOn4UfE387Upx5avXuGrNZZm9fXrlUVqtb8w8++MQEnWiH/HpO
JcBAvtHi6rYXSTqRm1tCXRCTry6d8KmjNkv7lczF5ohN+urgHXiljr0a06lmEGxJnooQQjRVLYbW
COO82b/srCGhF8DSwFPyB4FpFuPhP5wrPi5kI2E9OYsiFdxZvOesxD3tCdtwtz7CDSSscrxgH7fS
9exN0jWOOeoxk1hCiqbiCNZVaMIpqVHrqLq+gXk8FXlw9SIsmllN1MYMfR8MlpgzlHAqVHuCcdLw
OIlxrQwaF036rFWgjZbH9zEDJYiSg6tOQccw+njf573dAeFvAf/qmknGeZCbEqDt4MdPgf///viB
umdwqzU67wIjWTW+FoH6tIFk8UxkiIJm8fv8LsPkkNAk5MyF9NLqdVT2ZZvrp1H9BtiwdDgtYyZI
cwRH6+U5m++0EIIS6EJVnYRD800cAq8Hcc1giumJgHF+HBNE2SDcBNVYDNUXtbUaZli7Z9j8s5UR
jdrNMDUhN48alW9mmQjuinY2cvGrLQrm6NUchSphGBqr5IfpzSuRY6B7LjUR1daqTPrF3jwmTJko
tYwIapAMm0LTSVk0fMrIt8NZmaZvhjCjIeQ77OT2o+cyvFulE0vQaji4ZkuAh9DO5TZa3D6tuLYV
IGMfGEFGwtkFgu5fmzvTt+dPR+Hb7gF9R89jAhcunSl+kroQzIjxxnL9kKUMvqbH1/4f6P3ZX5fC
hWD74mWgXH/EClY2wnL0HB7zJFKdJkJyk19KwazwdCK7vhlxc0k+m1mWU+7czfd4oiCTMbXRhqBx
I95ChVX3AZkoywJ9UvZ5VqJUdYgdEGevYwNVE0xxgHip2JFBgKUylB2DogE5eApQmNIIuwurkImS
adyI7gVqOA8gaYUzhXlDD8Mk22uUbZ+uFX9+3r36ODXPkT9wMRT6NHfRAtjo9EdeHiVMsPnV1+v0
XYvzSjZoWiUHRfDF5WWUjZNx89+UNJ0h9sf90QaFRgJUA2ESCbmLl+mRK/hKiwiL/D7WmpOchF+l
d4rjQsgGU/a9asqvdM5y14LtM0ppXEF1qn2oXuptqGI6cdQdEcJUWK/iVRlDhd791ZIrmJ7oQ2Jc
wV5nOzt7whMLN1YcXK49DBUrYx+dFv1+MtxTvOQi9Ar/37qONww8dl+2jK1K5a8aPtj8TpSekV8I
XrljbKxCpJ+C2WCUD4e1EnorZZcAMU+VbSvrzBO0FGWroLqOODIzTTNtskZjWMGH6eaCsh0pMJIq
RxR48K9NZztvmGKuFYCM/SQle+1U/X53mphSVH6l4ncY3qzvw2xZwi33iU3FFhF844oW/1TJlCUo
GeiZ9hChGmhVANwe57C/Bo3VI6pmHC3nxRMgOrnFuK2mApNRdsC/R+N8GIH0OK+F/GUxS3llOWbo
ffGD8eKxBYjAW1nZKmTIx3B2gUqaiLdDP/RQST3HLxLxOmlsC9hmnhr43Dt6wHRTVimHYhi2uv6P
wgYJch6a+boKMpH0QPHfFjouVRRDnjHss9YXcy1k3BvNT6fPXvNWEoiI3oibtBvAvADH/Dvxw6g1
0tuCavxOeF8wt1Jh3eRKbW+Rp3ThKixZbUk2TEGJE07KN+O2fjEk5tzIXMERzxbSXrckzkN1+vNZ
XI6Bb3/euqCblAF2X8rkxp7PQkAfEPq8FjEV/X2pbniXKxegrpRljBXKZDUhNilAVNVq58guVYs8
0XFDQx791v05DqvtAO4dCXuT4KKSBvimvaG1MpBI/ZbABPLe7XNL+UY6VgiwgckpgE+9N05o+Mir
6rFLeYTgkjjyUt57g0bB2bZUIGNUiuRWIYdzcW2VNm7Y8K6KtgejkPqVhw4xzj1oGZ6R4a93H5lB
OiqOAEmv6U5tYav1VO0PLqmKhaE2qHQjqJ7fpsk0AghR/QkXB4Im5H0HZQX4J1maiTs1jdzL33F8
GytKwBf3jPrWRifDggP2CMAIkuu/Ul3Unqtr8fwFyuQrxytAfhwUW7z42DzYIIYEePQFqneCWEzb
/oi+3UUx2nD3Wcz6SBsRAiEF1gIJabrTtYiQoY00CqiuuJcs40hiCqCD+R90P7BfZPT3CGbv3uoE
8h4f8F3bbAuT5ZamjeSr9I7bwbpZWlbyTV5RLYw7TsSRkQpyUOlavQTvK3GOIUBwH8aGLc13+AD+
1OAZROtEfVmsocG7qJpsVdcbmO9sysboyx6vBh4hTBM8dAvrBj8sDJhc8eCNj4PaU+bP1yAqNHCB
cT7KQe+TvvCLQJVB00xBjDmNTBMqA7T/Po/BKvcYIXASk/lk9tSqXk1gir806y6dW3MwMstzLbLA
4dYMtIoO7BUV6Gu4oAsMmi3kVBT/ZbwAJERKb5bN6QwgJ9yZLLepDXaihp2pYtuKdxZ2bY2YVLnC
jQQsHkMtzB990UohoTlBiR/W1sK9n6nhJ4PPDlkQepNoJ66oGAR8GfjIMBHTNEU4k+Nc+j80l3TO
6N8WznnXu2so9i6s9nBAnyVqcFH5jEzq1yXPla+haKe+A6zxumu5d5SDsSGYXpiikZeRwKfqFUj3
Ooh8vTfhlExamhEshhdUe0gVp95BsaYdm14v1ynhUb8IdxsF6AIpXqUVnz1AasLq1KUgRhKTGQ0k
5sgd1fM4sCAuHoTNxQLT+JeMi5iOh74n/NUIRSr3ltHTsy0VgZ8dj9TrW7373j1rz7XdcOeFSEiA
VxMmjs7fxcvlndDYaHdx1SFQee2bKotVqkNSOoMwO/VgO7LlDrQptcF/sJu0Hy6Q6P/h7EE5E9GR
tlDxRzkXhn+C5TsgU3z9XrTXaqn4OcXv1xLs1vyajKRM9nkhaKh5p2t6TwzZdRZmFNiVmhHtmhIS
VVfm1nTCqY0HJPI0NFydLBAZ3HVYhrimFG7uLyM9bLXBXFSsaCiPheOLizUkz+nhtRq1Y/BAc7IA
tNCaACvIQ76nCtMApBT2ciN5UeOsy5wbmAxPwMaENTem7We2KNOiu54kCEIX/eTcOUyyymUi58Tv
hDGDBax1cAFKEAvke5D1BokO6GVAiUU0u/74/DM10sBTwjT/i2gRaGSpFaLa0J6oXUbdDJyonX3f
ncw6dYV5gzMxpkYAVkey3wIM3yyaAiI5K1X2QSbX7Upzss9Wype2x5K9vgpFWtIwW0+j1zKjRafu
6aHhKdRuUVifk7sKta8K7EQf0OZ2ZDFarEGGu+XuqwJeMY3eyYdsi6aQl4E2/lNjrCTvAxtFDdIT
A9mwASZn27UOREdRkIY1gV019mivogxNYimC3/O3loK7s/gMXfbgLYKIFptq5QaiJhlpYQF9XeJE
kPaFAZtqudpy8l7RdZItwMhzocEAeubu80mgtiKTPKQCwweTCIAmwB/NznloI+SBMv5Svl7fbEFi
owBA0V8sx9Xc0xa2DYuj7uGCtpEPbrKC+IfcVAwTZx1Gxhk0qHaq69ljutElqIv42eLGJ6QnRo4Z
wpNLBa/ORYcS2oBTE8Ohho4qXAHAKAHg3quoGOVk5MfKhKbXgDSIjlXN4gBrzWkJOpKuJoqum3pw
RywXGJEM+tWLu8VsSdZeSkO5GR1yZck0euaht7mCSQ1mSmulhdYXoKpdW+RNwtnN+WJJ/8Z5g4Y7
8MzhmBR8lEUW5/KuMG8ZH89ciW6EoNYTTJEH2Y5KHGyPFE3oaTHV6eTmWsbB62f390vrng47nVkN
AsqAzmd3tT5rGYIGCmAyZaIMb7n4cT4Uat8VMGmg92V/rxPSvmPqyW0dpVlMZbBga5LDxRcTae4B
HCkCZ6mnuUWxScIysFCnwBK6+JTUzxklQr/9t8iUftQTUiIVGDMrRNFioBHR81dvQuyI9U6hBsew
msT0n1DnxJq1GJyyoxdYxjeXKZ+rb5A5MknyvP/Oj1tzl+v9DbzIfRZuzIKlwdzoq6+iwhBgCMaa
DHJs4YC8zj85B5uukMbANoIzi1Q7Gu57CBN1xIjln271Nz40WIRTTntXdbVE8z3NqYvkYDP5V6QY
KtpLg06Fv4KBIILjtz8gx4vJMF6Wfaks3tpozqbnEj21lYHRFvbLeCEapvzKq85I3ajqCtIh/5T5
Dn1zjrm5FQFsL2BiiNoKqzcOESkry7TZSzPQLXow4qEQF0fuyUrybGxSeNqWa8racNsjhv/bNx+C
t6t4oO8xpV3D77y7rZigRE4MSlldippRFBRlhowQeAGux2Ri47WC2O5+dO6qG9BPXeKAkSaV1RZw
aC90YNplvMTq30lAsrCh7jWKg2KdvmQG/61vObuqibB7EIlfvy7i6bOyxGDUp9mt3mo5sdqCLwjO
X6QxJdHQUJPoRe8Yx8a9EizYgEypgHzcSxpuLGd6X1YGWAjq+co9QvoIBk+SscJnx6f/k3pbBZGL
utnkNHJlIiRpsY4G+LT8N6wRaHiUDpaP91EFfNUz6fqAYw4wdq5w9N9iGihUYHbi389uhe3yRCeE
+50cWrmv2CDZdHLOTGPJjvuvLLOLQVlf6Apf/YF7ppKPTQ5r5PrMCcJXOb3gCfXUbL7VzMMT9+gv
vbYGZjDWDrDrrCT6YaFP4Bk4Pr/Qt5/G9ZmEnJB+nC+ZsXBkPWHOKI70oprz/wOLeDzrpcC3VluC
qcI32bn76gGhZcXY88qAG2ny6V3uFKtiFNmM0C8yBBx31JLh3C2DZCxEEzmA8ZruxKmcBcUW/CUp
GuQDk0tAf16pqBs8OfgjL/7RiByu9r4dSbPREJQJvyVxDk8g6XtkE9JNmZ6Ok6ciEZNdAx2OfXfw
8LaVmH0/tOJujIB+DfRFF6ZtqrMDh0rs3DPJ7jBh/PHlFMd/zis1Pg5m0wsodAo3j010N/Xo29ol
onUAK8MthJs3+q1WtVoYs/crHhGNrxZq66NjxcOhTo3BUEQgfjg8lRjFaM98SA56bxJ4aj2AlyKY
KAH22TmzpVoQXbfGUe7Ts8TNkTNijijC/v+or21YYFpOQ3I968Vwv3eDOv02HIEtc0ERzJYH9v+c
i+zXOmxBHka0vzMJwLfjIzi3fbRbHDvDm1GodQecie8lS90lCUiFCyEdbinI+UAtMUL8J+sDqlcs
umgRbwah0mXkOjcEZlkLODejkfJmcVsXRcXGXjHbimEaW+wqrjWvBm+vace0sWhmO13gSgVovvc6
t1GTLr42wuhvg19MK1ehFTt/dUEPUBFylAHF1prKuTukeiu8NHeYt/OUswvcO2h4ur4K1WIywPxl
rCwP/4oI12kD2F6Zt8ge+y6V1AP6AGGRkCXpkRlnnIvV8WHZHQUNIhx36ldMnMR+FlK7FZtHe3LG
Ojb+1TeSmRLVPV3YyKwzGRB0WNZqfyrWB0VP7xcVIzAmVcOKjTM9GLEk6/JTBC78BTZ6pSAvEhmS
C5pSQT+3VVkV24mQC57KBchz/B//Yw/1RACoIWdLGYtUK353FCXlccXtGTU8mk2UErSr2sZesZua
RMyjfb6814Qjwp8ubCXRpx9QXVhYmaNJWfeo49nbH4A6dSf4arjhp3Llf6yoIx9e9p0tOEnVZZFK
fE8sFfHbVLlBpdp6Nd3TbxIqQ6TZIVhrBC0QMV1w6TqV9mR8Cg8jQnKW0b5cZKV1oOJ08pni11Ka
0ax+jVk+piUBf9xDFKliNRxD3R3Nt/G1Fy9qohcm2eI3hRyG3qrIphrgQmu+DE3wnCyWiDNCbfeg
CRIvWC/E3NgoBpFepqi9xiAGL/2xxw0fV+7rjh27HDkjbscS+kZvhodtuWmtvn83Is+Gjn5vd0Yp
+L4TRazFNWlfckuPn49mY8fiWXM1cHBxq1ai0R0QZkQ+KIIjprE01kmVOV3y9e6M8SAQXXfp47Ms
Qcw17nM5QAf92EALM2TTffdiHl4EEBftqRdOsegb+A/iFY1MU4pAeiBfraRfnzgk0KaC78JQoJD3
FkgJfU6t6tFiKeaMXody7JT/stGmcWzUOlGKBdwiJeDj0XiALhywrq86oLx10qHKgNTQ4dP2C0ij
i89OMGyJn6hLepx4ZRYMEiOCOOhqbpIhCUAoHUiv/80uc9Zmv5W6ojzym0fg9CE1slMxKU2SmUbW
ercBLWwi1YrKa0XH2rwWONlWzSCx+Vt8jRTS4QCr5R1b2htryJ7kuOruO+liYxqnBJcBIzaJ6ibx
pImZNk5P8HgX+e1Vim+bPzennpdz5zsZr7BANScblrmRwC8cJHXH4tAjykUHWh4mQVmqiuSUhbrp
OIVep3Ep9TShNUNG9M/0DlM8OMaFgpNfuRzcL8I8YpT8eMJeLJdsDi4dPR6MWXF+V4/szhMzdAkk
osDqYOmzEd9w8ViJidtCTGvpFazCCqED3+3FylFBevRYlV45nbQeh/ex0J/Ntvuy3g2Ej2w3yDkj
v140QzlpYnLwakXvivbQHGAqUJXqx7cq5jNPLuDSTl0dQVlD9LuwjVG1M+AKAviTvSiLJbVEC5Pb
KVrbf+gUHbVpkjd6TlEkeVxBqiVpA1ReYovcQ3wuG82fQjNdIBKipJif4TjN0ZN/VfB/ByuVCzuN
KCLyyridk6ptO/eruPKtkyMT9l3LDH5/hWxsy1QOsCVnCD7ACjbR5Qm9TL2SSGRs1DHxKmi7t43/
/C7Vy45TEXBRwY6N2GQa+IuDGdl3KKbZ4dAzBz3y21RSO4WaywbM/nCsxf5bGWcH7kEvFIJRw/wd
DtH7aTxVLcEuvhTjTGI2S1EVmdyjE6sImyA4ALUDLHsNguKgZxCZklRdER+cb42mapAetPP50+xi
h8h03Ah5djtVswauuHadB41Obu7NHvwN+pm1sA31WitbC1eWE1pi899d6rRPku7WJ1Xc+1Un1u28
DjnieN80KCDixRZTSeWnzgvGdVEHXNwCVk17lCIcFZWcTqK9D2RBYthO6OnN3woTgCmysMHxjYm2
unermG/5llSPBe4Wl4dfV7+6QrOgEVKBDjAop3C9AM5v7+9KvhRcRuSRSdhcNiB2OL5eJF4DKpx1
sruCRf2PqprOCBqvNplaohsEkItXOy1HYEjSODaM/kVYzF0zy/5tRvQXuq6sAG0r5KFJw8HY7lLM
7WPxyM0FgFJ/nYCc0GWDLDpzyHP3cjKrATsvEguguLNTtYW0v+Rlrw6PsBwaTv+JEaISNlLZz7VD
tKjKUFzZbWFVZ57wGc2kSRpAX40WY/TBMLrWG1jbfEb9d8nLq8kVjjh5dzHeWneqyeqhCWLA6kmT
mBEQiOZPDEN3LwLYo7L5HAy1RoT5qARc4fdsaLfHfgHQ77Mh6zwG7JufigvAJbvaJ7uNc9yZDeXf
EaEmD9Q71k1IqGMrD/rT/OHfB/wz365S3H0lfAT+5ePvT6bbgLbQ858mQ7N13HZwucz1tdNnsXky
MuX+cBODfYdA+pMk2LhaL8YLpcBIY7oql9zWJD2Lx7/Sr2u/NO9tau9Qi4YShVmj0dJjUg+PUk2x
tO104iICXmldjEuACu1SW2fskDephpySarFVdr99XW10rk/nn4RHA820n9Ko9Mg90WCmT+pcrWXI
8rp4vMp+4bTka6YjLnJLRF2R5QNiYw3+8ijBCMVlTepJ83ci4GBxN7BUPD+ebdj1qUZSxif0CLTS
IBCO/iBBnT8yqvXKJfqcIQoAinwScZJgFXSATiSLXS1iYTSm1Dr39iCCx9xI5nJ1OS021j+PVyBh
0p/WkSzdh+mhzMvBE2g4aJBJFVVePiZaFC6AOo+OWrzZ1YWxF1PYhBKnkOmwDLDTrEAlKvNK3v6W
xlbuxqHxkwQtQzhBK4WoDLTEbGHt9tbpntbkS43m2YoLqepOpeLjgJqFxOtTqv3OP3WpPSn+HOhU
CQoLFHepbV+lMDSWvVNviYDC6WiDU0EVCdUouvt4+usjbylGhzkJUX+vHbqBkrS0oe3BRA724yCa
/Ezsglgv0oM6Ashs3bch65RFehJyKJpd8RPt9dMFvQNLGS/+jGKGb/53UC9FhS/j4k+sBHIDYOOX
bPlVn4aUgN5P0Xzwu7ForoiwjIWYllyh/tnQH/9MwZ4COz6LMtVu2m0h2WxwApBboUqr4ZpHw7l/
vzxBu4rqRY/UbUrQcDaqHKJfAuumXRtKcsfxoQp+3Sx8fcRvSjybdcW8hRS7K7CmkBxiX55F+lHr
y3znSAJrsNC1Hcx6pnUhntdnbW/G2sqxqpqrue60qeji79ypqJ+W/tZHFQXAWgG/kQjArsrVv1qz
Kg7B1fZ/gkB8Iw6IaT/Ao4kZQV1rzcVsJK0hTOsQSCJEpZizTZcbz7RFIW3gr5PzTcVFXMmvN6i+
2zWFsZ0/NUXZhBucszVFOmaiJ2jg5S1BhB+dgJ/0sEgz3EeV9Ddu5yNczFlrVlbHSg/wj1Lv2kNX
jO6qMwsfFRs5KredsSvvlmrx8VUAfSQNU0qWqkjlu/dbMuIl0yX9mkkZq0AE4qy9JT5M/LEFNF5p
XWSAqYLqBopOjicAvz+TUTv2Nawb8SLb9WobUx7/o13DnBvFIzVHmInqvcrXLX/eqHdbxqsI0n9p
wSYR61p9ImPwLYCdJFwrwQhp1e0PkRabCs7R5T1Xig/pfMPiNjtrHEzBIiJygQToMXZIbxbkpyV+
vKsWxb6EfncVaebxEvQnQ7r664VOdpLuScP1hYBLpCVnuh3yeVgHnRTdyGRujK1o41wxT/bIpbi5
Dj9btUatjnqv/5djY3BfRcLXzzdZVn7FPOQ0HNgXwTjjv9HOklNIgIxidv3rLxgqSfu8Irf0AKbJ
SLfh0ghTrZwinX6JzoAsf6syo+SKtFbx45l+kJpZGhSi1pBI4JuSWpoyEebclTVtiaieYvTS4uPx
P7gPtRRNYNaiUKv1irz910VDncjlMJstm48hJQ+OghG9UGVCifAdSBetRR/40VmGUFPhi8l/3fRc
YiwkwsEidPBGHK4xuAZqTT1vGpqLaxX43gEvZMdfDSdG4lnjSpAwn6auNT80g9TRujU4ZzHCEowC
ywe7nXgnpqAheZSSHcLm5voeC4qYDojw6Gwm5XplXiJmOd0mQJpxI5/4begYCzxojBjziI7fELPk
cgo7htXc5hBwrtb8+FwzNjthkXyZyQqrboQOTHOUQGCIwp3j9zQhi7OXprfaX/w9KF1s54vQVMVl
jE9eVUlAW2XIdfv0JJGDhqhtcbXF1eBLIqyluWqfYj9XDVzC/Dz56rVduoeB3sQYp+/0InNu0hOc
Nolzf2HSnBbIhRde3TpE6TswsrM1Z18Fb0695sCIeBG5C8N6+RTjXfLREcjZC6+IfwqZ+wGlBjjB
Zbt0NpIvuml2w4W2ZxAtka0oMwm71U2Dkzc3dgsc/aau2u9ZJiS2GScJHmvWEA2a2lt9fVL4sFvW
1qB3E/2VTDcD/eHMw4x3nT3gkGeO6T15RaYh5IqQu9H2/lnh+ygvTxSWJUccQwjX3LIe6/1spTh8
vpUUJr/2jDxY8h4IO8ARIrz4CPhsCkXvUQB+n6cC1WDyzoGz96cmJn8fh63lvpLMUdrM4eKYIGV5
9wByLnHt3wtGSTX3ecAqguI54tP+zUrAKepCcByA0rhJBiO+KsMVTJQL+z/vK/2INqMlbpnLTJt+
ohtwsnPgpuzbgsNzP+vzAyMxwaZsXXqn1MUSe8X881g4efd7t05O+X3LwwiSvW36F+gitBaS+fpc
L1QzkWwV7kD6ac3nU0KaAqSem9DIbQu31HeWpOuCwkoQhEcnauX/PwPB3G/wciJ/cc6PGs/hRuXw
1UOaBVHBzTo5OiHBh6ZNrIsoADBsd3xJrBF98i4VukNJiIHEQjSecCxHKPI6vgGgYh4j6pOJUUNT
JOqQuhVEfqohWCvg8arSu5i54SjanBfEjs0dsmQRqCMnY+tApw0htcShkwyz0A2B0uuuLTXsuDm3
/07/YQdTjI00w4hZu4gyYShFz8k7imVfADMnsVTbThPMXfOi5/pVp95KLHPLAjLqKaMFtH49SC5m
7xBBjQ8ETg+9FuH0hZbRsNuK5WsbOc3i0VwaqI2RKpd1w+giL4wZOuMBL+ZoDONvDEP9nkVz35po
aTIexvQ+wM2Mii7vGLUE1idpNkmmaUqdgZijwoYhqUKPS1TF4HNIN8DiDcMMCETWarLscPBJT+an
2pm6n48dMiBxSOtHlI3+Q8RAtZxGqrM/kQqD7HwiL0M2aKykJgUMG+Az8Zr/NfrIcdxl/slxCYZU
2auF4DHws4h/UsB5eL11dXVnQTlmOUpk5VfDkpj+ei4Wd3giwywdVdzc3axAga/IJYCMTsBD+hEE
gQzcn9bMtvWwNEHOUcW/6oGXe3rAoIrKcd1K/m1b+vYWBcztUDzObbPMpiz2p7pO+kDUdJd1gEQ6
QlxOLvypfu5redM83P1d0f8aqAq9e4aXyHIbbkD5h1za212jqFb4xGkhSCQYraAP/WJXDPTP0u2g
u7Y+7r+UgH5AcxYPYSJpFRgUVXVd2FVTCsDG671fNdqnJ7k4koUYdiow1aMLUk86Qea1w48Fiw7N
t/aoHDygZFtxmAdQR3OaqyxtES+JZJETYkWneQEaXY3zoYSh/flc4NilZiP+4eOFGl86kNw0VMwQ
KJUiJajZPPgCL4Nlc32adCzHJBWTMgqSvequHoZqFc6wXKSt683MQbAyucvQDgHxWel1OfzkaSq3
WEexg8f2iarUSaQQmwww9KgSfK8CglHqUk/mk5nEPQzlupv9I2D5nvNIVIP8VRlVemE6HmcHSBxU
R/o24s9HPVceiavROCgAYuFwXXwV4PeSlQXWobooNKcnmMm53+tGOEmhOE52ELJsiTb146arORcb
ov7QB/vvnPqwBtVu/1xoH90wcK2/w81KCIOpfkl0pp2fLLr7UUfyXvIBgRm4deGK7k/3zRVzc7iO
sSo5RPzla3cYScRyBSUUrbmdZjmcMTofHfhsHAFdmIeGxgCD9Ivc2Hc7Yzy36nRbB6WE0+awlXva
6ybYnhqhOU+nCeLeJJjncBWOaK+OPV/TkbqbIdVlpFdKyp2+hO7fr2Qt9rYUy+oLUWrubyIVfNWe
nvL2B0x4ywD3KfPI1y3JJzWiQ8bGa9NOEjmJQigHdacdbeo9gnExtks3wi1YNxTtU9WTpNGf1GDU
den0XsDPvBhg9DyONox3fjUukdu5iEnxkzp+uq4POiWGwu0jlrSKTuaXzzdx1bTL3+Sn6CQEyGJy
/g9goye0Nv/G+3xFu38/wWmFeQYoy8PNGNuT/1GYG2pnxI2KrdL5izeonz74GWuFhDynCN2wHiGn
wa5r8W6kcnMmD481+UjbQUpgQgnqOsRxpcF85rf76TZlIwwf/o/gec+He/QLyazL1kiA9F/2jsDf
uFhd41kmwZ3wLsncO9NGv/tP20eAejJCyiI8AnImtChZj+0T8+Bo47lR1Q7xIgPrsvBfCL3AbJ0U
AOJ5yr2FlQKHa5b/Bi1RcKzF70q0ZDfiPHX5k8BgGzGVxB7qLcsZgOMx9indEf/qDocOtQ2o7mwB
ebqqQmr1AisrL9TmOEu74/oJhe73NPlZPJB9PkDb4YXkYPdJhl6PRubiktm2TqzZjn3fs/gV/VTa
N6fh0TTI0rhsB/GweW+0Pq25EFVF9zvrEwhGDFbgJ99M7OTw3ThpsF5L2mBoHFQG5P0/ATKLcyez
+x92lHJaTKi+QYzE9vC3DGYxeXAt4D+HzcZRW/SouLHD3ksQUT9SGrjBhWiHskGkA6KuwE0GVcLv
quiR2BBwnxBjKmJan5Qn7B0xtKMON+q5awN/A48AM76wU1NpSS8GH770JLo/pNyAdTZvpjA4wpC6
HJvMriw7HjTAx6cm9gaDF6wGe97q6pMiJQ97Q6w7QQLYnZUDhROLSAqLo7vafWHaS1DQ8TyuSHgL
0+hleREX2lDiezvL43+/WKvSCfnZ4wbul9SEF6Mow3M/GnUIPZ72xKBOid5G819Pm6hvU02yapeV
F5V9c39alObvPuRzEMQBGrnEAclC7/pwv0X0qNuovpPFXJiFdkJDMPLHK9hAa7xbxHZ/0zojnCwd
f/RXsy7Up0c8nZ/j4yloZLs5R4qmf/aYagqWtwvuANbDhEQy4ZgTAKWlqlxDn6pg39w0rrTQqT02
o3N9QJvbUxTquP4ugcjpEIxOQgOje/MQiZvMyt1F3ThqH+O/0NkAvdUHs379Ej1ePsnKRkjOBLC5
xQw93f9WlDFeeoQ8ODyFfcW9DGzzJucy+7d3RVnZ/7Y0TIlGflEUTIe12IU7k9NmcsEW7A0v3xST
OAGJ1vQbFK3S9h22OqJ8gq3Ycu7gVgqdzDgu4Co0rkjyTGpqO5nmUgcQ0DzXRghPMZ6B34CGt9og
gv40dutZNTmMwcqEb5T5kWlcSH/9k8en8Gl9IRnJK6UKXOzgw5GRx+IQIYtypLuC82nuV1Yr5kc9
vFATwr/Vupqs0RkrVSZ6+0aA6+dOy+wUbwtpsub9AnZLqwIFa5jgY3EMR0tDI2/tERYq514FJOqU
wgsK7GXJgl1HomJS1b/vZQLgV6kQ5/Oyj8BAhH+PtMkwvTyv/XWJ4UOy0HqkUV3nwGierCepQi6K
XcDU8RQMg4treZL5zjb5mmEPgHCyqhZc0qkh2/66FIK/JvKTZ+jz914KWqhIq+j2/POqgFX4dpTx
L8qYCW4HEcEzbaajPmBFiCYN6bhIf21rqIczP8qSq8F8WkKda6OICTOGo7IAJ9ejZGWmzqxK3QXP
NiICeax8XfQG47/Z3JG3n39t7wEDea96FXZFfIvlp/USPHuiAGtsEMttJpG1ZzuJAf1bhQyfVElX
KBr07k2t9PXqZyacbq8RzO6qZWVlqgpptHOjFBPAKNdohTwEmPxjxfLOn+QL8DmNZl2MXv2Cxsb9
BFZJmQfc1MubiW4WrX0Ml2Xay8IFoloci7VYyKHH9aMZk3iKfbWvGvTliPTNPk9IUZ9798ikyRCo
5dH7x8FMYHTq+JB5YHpUjQmvID03qDeAjUU7+3LR+O2ePMWB+KWTGsCexewtUBW/KxORyJaZkEaR
2ZzGvxH5JLp2rTQY7duqiqCzy7VQw5wUDOaC+jBK/1S5kMwQAt6pNGn/tBXE7NaEKkHQyEeLMc1e
EcL2nuFOQt9+kKbAS30t0LvVQ/tf+5wX5X7GgUioka75Vx70DZrI7oN74XQ6KpmG/H/HLqokSUrs
8sQOPSoEMUG28f16sxfQguoXpkrMLbW50MbmX+N+5ndKU2i7YEn1W7wG7+8dRK6Okq/ATwVcnJXT
GG3ArOdhr3vo1b8biXCu5YHLEtCcbdkN+h5PWgyKSdIlEkxG9msUeH8GJj5oxiib7AQ/cJ6/slbk
/Aa72L76aWSBXQHzDW0noG4unLY1PWxNrg2T0WhtgtKLoYvv9AFkUiUCwSJfe/fm10oDjzHtYstS
sg24jAfy7H5u0tdmOBEcI+GaFUifytbhVGZHQgMrcAbWJk9RFvr7fNXo9o3KpC4+9hTc5l+o4VBS
r6iKH72EjImPAouRVHBcF3SX3OxH4T8mfDmcJdSx2B1q0xg2Z55x7RQu7Nyt8127Xjfse26bR/u4
MWsp6uDoPtuQ0fE4MA3TgXJkBEr+UJOziLozD2dGmoS+/a4sCdlrK044or0uHobkpDmfk3YPVLp2
6JayijlzOtgyoZGECOnzFon0iNE69vTiejr10ublfCxDnsu93OJ934IvQo4gqZv2YbgDWIOj2bh/
6+kMW0+KwHqSJU4uQtbupGjWTvt9NteFZ3xfzRy4AIRiJJ+H4XRO/63qeenbUB26WUV1jzIi9Eic
k3YCMIgeCwc0j29TNKNQjToQ3hCwJgVmzJv79Dn6rEVse7YCz8AB420lAyzfycpM02kOySlA5apq
IcfALLNVqdRiKMjXgS4ujZTQp3vIOygEhv8iMfMBV2k1PsYH9Z2o7azpaqDkSpTe+gWmclT9/00K
e2NoZgc5y1JhUvsDfEET/N6URGO9+qMmB2F1qSrgNxPY4WwOQXEJn9+S24OKAxRQrho204anVAgc
M689T+Xpr1oHODxr/1YTszTYW0TqRGex89QFhBDdb/zYLemUMPMiV/OV5KkUS+/+RNmuAS1WOiWt
gHcaq1YeH1pa3AKNM6T6JAZtlaWJDQOGr1Sf4Ix73YlTQxvW3Nk1N91g9xSk52eKFQlxJWAs/npq
94A0xk+qEPACAQeIoZzt55m0irNSgA1CMNSdrcUYTfxmDKD7UVwIRhsXfeRQRTrVUHTY/sWd807H
sm32nZX/gII1tY5C8akC3iH/mFqAh3ssYWpBX79+6s58MRxNLFOu11E4yqKJYTyBbt/nySx23jvo
lUa3jUmerH9sSSqY7RVLRRJxzpxdpmiA28qhguHCJC7TUfhRnNIjjGrCXab4xB6dUTi2kVb/jKsO
0WAIKwHeixXSMfvwSMFR3/6/Ej3UlVSBJvaROt5snRsvSwdFnAdbPeVhfxifXPIR6p7gLV9vIpI/
0PzYiQcV1XqZKAJz88+iVdHIspnovoKxsfqTpASaqxV46sdCYbY46DIAkdkbc+8HuEA4WYt17eYG
5RpBAi89Ztt5XRJDaw/3DJYO9kFCQCY7I3Bc5zL6LxUWzu1oqUjk6AWos9ifU8UKGSPquqR17OJu
n+hVxYGTkMKu3yrRtJS+eil0fGM3NTFQuzBx18foxyKP+Ky8o0DwX6QKy7z0dNKDRS3bGPBix4Xo
wxueaZpCMa2GaEorKi8ijUIOtbfcucII91ddy1aTIvl2oXfMhBxTycGRZzG1XBykg7dBTZojYjxK
4SnI+kjAU/rUabAlztthRSoMU+I1pCRibI71BlqucFDvtAa7i3rHemUIncmNytcrCOk/dviRXIGd
sC3dz3FYS6H21GJm+mzUkOXSDFBDV5FR3bT+IQwNmfpm52OYUmOpaGYntGoCEt+GphkBiFPJWOiA
+YkvBITewaFc3u9Vm3maQOzqrDac7+I27zFP9krVWajrEOxSmL0YsE2R7b5j+0orOzAI7dK3IL16
GWNZEdmPObRZQJZ3ynlonQKpS5n+J6lNu7foLe3C1Y++VfnTyDwWATY6aBvWokp7xvMJfCuopttR
arBbDtw0z1TPfSiBodl35diJug/8X+npPJ4D9x4mAsenLfE8KGVLBLd4OxsqZWNPia05TA5xnKLU
rbV+3VZ4M51YeQrFaR/3X6mPLMnr4mHy8a1fM1T6Yyfmn8JOuUSyuDXvNS4rD/bH70epRltwsOFr
DLWuYMi8vh/2qXfFlUBaYuAdy7cz3bCqpHZ4Ohxsl370F+SQtERuv4TKuEnSKEmBdWb/qOwnisHV
7sVg42K+SbbVLNbilkXLYVpu4Rozuxb7C7LZkbvvcQNMV2ACLhMzodYSUOhqU++jw2rrnzvRWgM8
6RMsXiP5H/tG33anOSKD43mOqBLqC5MYjkk15ypfuGVWCpy3j+nnp0kJkHdcqLgcykOMRWoEz3ef
+PxaT9/Ea/QhGjR5Rc/M2WezcOue1xVSKYTRcuQsxtvSnEo76kXLBwTRyWWJsovPCC8MOHSviq1Z
1ukjtQtFm/hxH5+/Zn4CL5L15GreanJ+vxZi75e48xwGyfRk96INxU1zSn3yO0MFCZnvRA8e8Juh
6eY8TBsmPihE2hOJlIb6HImrJLGY8y1BljrSvQEKecqrIPlBJQ7EWmNkLARqGquJlOxf2yM4CIBW
2Gyh/SB63SepuwxaVQqL3BV/zNiE2pLqBZu4q1yhsaLpF0VpbfyFYutlp+/46eGJWj10lLzQh3iK
FO01Aw2GX7vaKF/93+834VwjO0bCBDUD7zpkXfsJqvIkkE3JCKl6AGHN9qKnsbKQvSgKNo2RvAOL
MVC1yyIGZiTdVz9QLygmRdng0zDmNXwzx2isCYBL3T3BEDTJcqs2qMWojYI0ik38GFDPl3F9gE/E
B2MDGBeB6tI/r+sZMERf5Kgy+60JdnicHJShtTo4jWJi58JhJJRlZxc0q+d0QDxz/29MVNsK6v7q
9m9UaqIserPhZieRGNPEq0eGAFJ8tSJr2E62RrXr9k5bIucguA9GD+ItSa/AK+3qAzmt6564ZNEc
cg46Te3UfqBF0VG1Gbb8FSxGLjt5ykB4Sn1j4F8bCAd+7iH0zqvYKdjZ1GhvZkh+el5zPEiCRU+y
WulklIGpzezRtYjJUycw3L1hIisSJJ+iTaE67KxP57eid1PNvhmDHRAvKNxLSE15xE/z5EluR2al
RAy/oDgScELqYvEUcZmYGIYAulic+AJ8VIqcAzZGEO17Th9D7kMOMbE1K3WtlJzDFAdVWOzt4027
UaCUX7i+8l4LvMZOVgAI1kz7lpCyDxGPbyc2C5IQPA473Sj4tIjo8B6j9hXTame5HXHdiF+A1qu/
OwqFz6MF5S2DtQgW04aBM1HWw+9PvZL46QnHyWHcL+I6rlKCB/sxj7TpGF7um51j6zlqyaloIaaZ
zqOh8BzFIjYJ7ZOHSIj2fY2YsGS0vHqGWzn33/YTrR7gV3KvTcj2GZfy+3AWcTzvhBa7pwM52YII
7TjH/8R2r1T83qBtXGqqNsqDoFw7TjR5JdwFXVYZQg6sFKRmIMl0tJH+plEk23W7xJ6xIOah6M8K
XznoJD+C3vPOdjCH7+6sapb5WFipl4uXtQlKLUVco+w00lidAS/58GPc8T5QVwit9y1SYzvx79ym
CklvbP90MFfpb76+vtYLBve3UPUaesDD5TRPViQf0kDkajMbBuYlC6WCZPOY30FAyDL85/kINVvC
vLwS2+JNfCganfoQiICkTxaGQ70OpN7kqHTRfJFGXu6wcVmLrGgTXUN2wymfRBlmzF4KmPR+m/c3
mvqkn7CL7NZfVz2Ol+w4pFRx9MAuReYolu6lbuUWyTly2uOgDhPTFg2JthUlFqQ1BGEnq+oLxpuS
eQRSSS8Hd3em52KhCeAMrfYEL9lhYsLtp1jBhM4Tn8Vlv8bBh+0IPqKBAL1WdehnRMME0QhbKzTX
szt91BIqzMwm9glPQZukZqPM9PNM7K2QsVHM4d9t31G/qxXLGvN8fyCDWaXes3KzmAYrha5OiEK9
hLcgRQfRYW3jC0oI/fbg/9kU+9fKYq+3rA7AL8PO/xVfnou8M4oG2cu1BD7pWK+BD5Kp5C0bqkas
I0diGxgyaYsI6GoTeILkHZCEEFJl/EXd1oo1XD2SGeC4AQTHZ9CTrC/f5rqK3tNBLN+xwimHF/vm
b9aIsoC0XnXEi5DCBr4UtfDq1+GQ6+ouOZjqONeQga6o6+AK9aMAwpY7vYiaKboitHao2GJZU+PL
5xFcIQ5Tj4b7uFahPFABtZNsXe0iZdDQ7ot272FoNPaW/00ZDkDI6NxN5AaZuMEXhQ16tIUJaLfO
fZLKHQAW2kjPRQMOE7CtyZ0ycW80IS670eiHvzzYfhL97dOLMVLdHSuRUCY/wWQU0DVv32Up0jMD
AmCfrq4Ty1HipDbI/CGULtC51+7nQJe9wmZa6kuqTel+sdU08vSjAgM10peoqWg4WOB6kZcSqlvl
hAXDKcQ9HpghDe8GmiUIX10wx15oa9KoyOpj7R2pAo+2q73DqX7/W1k9OyPDGlfvewsxKcwdpVWI
oo4QXGmfuk+2TIe3Ww7eWgrfyfOUCsn0thpNu4QW4wP0uE9wW74enb7scUI63LDxI8B6TMgrU6ot
sDr9eBFcCk3P4GDEpRF6ozjR+bdxHTdmx79CZ4HjfhaVoVMRY2ZR7o8UxetAFtHT1klZx2CbwISa
gxDzOARgKyVlh5aljrrvkwfkc7JxVSCw7EOvk1slHT0wWjjFabm2PBPxCC0l/k+7f4atQwTGgR81
7pjNpFjihNLDTUrL8GAjzvOGk15HojJ5QjZWHkloeMD9HBzTPaOTIR/FcFUyS/68trntSEfkWQkT
CmuaLusx5s38yJjnqus/TlKILmOG55ZyiikHAah5Qp/va4t52fXvtlvLFw9Hx8MVbIyy72lr3Kh9
E6hieVqVTL6hco2/EDnYK4oCuI2w5/agRHOxSYHrroB+wyEhy0aRlUUzTDHxZdDF9Pg1EFdOiGps
NtbzTHxIuYLcqtnFMHdRSlcbuKgfStMBCPocdsM+USoO0VOxzmvLmAm2EZIdTCMfD3zt3fus4eBg
UW6Af3PQ1n63meoEO+EBWo8/MVdYPJQ4vbOQzxkHRhcT9OB2zoqZYOSw/3mtY9OOgznMLh1Obxqh
AB5DWnpRY6EKSvhN3GAzy+5uqe6gBaHjczjOiQ2xRlq1AQaugPwYpGL3BDEIdHzWhNKdxr2L6FZo
umgynH1FDH0e4IeaDLdwKjsMiM61b/PBFQ8trGMWnPJiys6zxImj1g3HIw1CoU7z9eyZNEztm4ud
+gtBfzuaXyU/9jlCFlIWfc7cSeGmJtj5JPwxlphuAqO6pkPpnWhLXqlR1QR2qBFL/fGEBabN7vmW
mEhKTtf4stVyEJBVXa1otKVYuSXZm6Om7+KpFHWIFOyTeIeZmUEPSQpBYX4bW9L/YttxyQKm6mhv
Pygu1xIgnvSIauMWAUyId0lI8aa/4EqGBl1K59QY6t7i/GwJYSQxxXA2ONlz3dMm3IyRzAac69UF
q3+1bd9+T1toWr6y5FEhqISHqmixIArQNgXBrUO5ATV7DGl4+/hpp0AzpYKW4zsSOhu18ctiCVUa
1kbnZEr5rO8qUoMkOlqZXHLcoijk3c2vqqQ3G9XR+jMXH4z6nlWbqJlVcrv57YvubMkwUdDKxDPr
P3ytMzr04QCF+OS0028jGs8DY6knmxhfwjLyqCrq/D7HV0Kpq9O/UiWjfg69RsMf7+7QukaCFrC0
1LdvV7J+3Upz0lkDzT/jvZ5F6rQX6k4bxJ0nYguCWGmsrnHnXarJPsBVRLzpAMCN9oH3S7Cs4qOL
t6f5jV0wWfqkRx4ifmwADci05O5XC+QwC4pRk/K1wcyJCSHnJU8xra9cXX2YkZyc3rOB2kvlAm5V
0IBohE2dXkhhboZHKZvI8OfYRP8YT/cja/+LB8VRtP0EjeaGCf2lWYED0FxLV5f5rKUEx5Qlm8gK
k/eRqwueVOyAtXwFp+csxu/8PWXDB97Pjx/dJ8UpRZWGi/iE988pkNJvMpgna1JSdbGF/7cvQ1ZA
Enkr6nyJJQvvIoXjFR0dvJktIpWQQucAhzPue70Uck8kC4jPuWQvQOZIL/e6vsiexnCWlNAG/1k3
4sCXxh1Iy64tePQ2OpoXCRAcIMbnhBYLulSRx4MNXbev1Obaqp9bYvLdgoBbvtR6wILImVjBPeSv
7BMV7FDAdvyDuAiUNIU7AtDbD8dHbzKgPbIFH9V46kViuVmUoTS6JYDltwOrhAq0LS9lXIRbYDT4
KnnQiYrjSi0ANC8/hXvDQoY8bAmUn2O3lslYz+zfFHPrFqBWWV/FO36yLxnYNc8z74xBFn64R5mo
wkW03ThXTy/zGCP2vM2ubN5vJKeLuAfXO7XkGc4Z+B+XJtZ6J1Cvkj4raOdpY+tiJR75N0nuaymA
tKK566t8Kkac5HYE2aUPZflC2GgLBvI9bWLC2AN77bOsdzt9n8oQumrLWL7F7xlLBrS2ON4aEBq6
WwCR9pp9YSEHMiixtIRGE9SXNnTmCs/o76reCtAHLsICpbROY12+kr22lggDNztKH7YL6IXcUBaJ
9SlbL824BXpA49PsNB5PsAooNtbeg95YtR9q2DAEDk9SCZcv35Tl1LY8XOgTUhw8ZvzU6DM19/6G
DGTuCfpAUvxnXtrdUzlztI8aVKsT7myNyl9W7pgQcZSrzUCP+0zDnj27y6QyJOjMJTzonN0oKF3c
t3a4UuAUtSE21l/h2iaE13hosqfdSHbi8LaZs6iUtGBxnlhPAombqUztC5JDtqbXXGC4piApYbt6
p/u7QphjIPNAJc2eDnVP6OKuDhuvpMcqdyqmyg0MB2+2r1pLRn3F2WTtqoeJUbJ/KeFi9lEhrS51
KUYwyTwvpLPYCj0RRGTJJ8IqnAnYi0CiDTayxlp0NzeXxbNfLCHAtu3syF0lGeBjvKelbqfnldbk
wOImMVQJ4/i/2Xn4P3+GSZGuBV57P//DUhKfA4A3gW2j3TwTF2ScKHwtoH9fu+pYitFLXB6XNEwd
MIkLouKekKwXks23B9NqWatczua0IlqW0Ceo8v0m3vYWdGU0UgM2OHYAnM9VxgmnbKVNUGPlptYY
FUrrSWJu430mi3Q7aN8ltD531fm7TOlv7zJQxJ+trbp3oSNEiY+RInCzdlMFR/ghG2Kezng4z8ZZ
8z+SHSRtyMklxTl6oHI8SLO4SXV0g63XHxh6cjD0UqE/9nH9X+AtDH/zGb9LOR13kI0HcR6yejui
2nYzkd2YZe15iJzt7vdLYKAlAbGQsum37D1SuE+J3bF0gvoxcqx3H1rTYO14tJeoBFRGv/2d7Pb7
e7ZEmt/mxFP8Tou8NDoR5xucq1dGtMC9pFc3djwwMzPJ8Ju75cU4UdawQubJOOfhHZBrbrEw+70P
wb6Jo2hvWfESbad+PJ06rGjp+OxRNqvWStjiO0/omZ3p7G0qWwjeMKW9aQlgSu58mmNHj+GD2N7s
M5MJMxAPNJOBihA8+E08daMUVvRvr9JWLUTPPn+415TqtqDSZ5AK4c8N2izkByKtpO7yTJns4G1L
ZhH4Ku4DMz2Gju/g1bhhJdAz10duNpQSj/Bj0AaC2nMEFUkWisKIhRMOuyn1YHB56SJBiMmzESIu
bMnrFsrOXo+WWgftpInASianEBdVyh/OfzUK6TKbmDbfKCUrYfPcbCn9LRQdQWRf3+cL2VSqvrqf
kwz02PEr6itGfWRJGpI64NnNKHoOCFxgXcvLO1xZOK32rJ7TjUqs5rxes5fZgdnW0UpP4lfUTdy3
TH9723dq+6XX3+XKCCBELDYlg5Exkg90omMP9M5wccZ1bsAuGwagZ1kcE65lG8mUB4qrJ5pW8mSd
3kMzT6i2umEqLl3LTA8EOY+cvABTQ8EdTCgSziLmqbwaPl9Zs+Zkd8zfmJZBVzH+tOUJvaQx9fXI
3zMjWgwVns5PQgo3xSxXVgbuxhfsLvS97LJiPNqnltRecv5IB5ediqKhOzZRnTZDG3pZiLBOWODz
TS24S2q+PVS3Foppou0vKIH6Vi+P42qO+wnJmoO6ETnu32jM9D3TB+/+e2Y9BRj7O8k2CQofb2th
fEJ79Ccc4W7AhKKOnjcSgdgrwcQr+muHxfS23DcTcG00I8ZpSfG+1smcGZs7rqu+faQkMtSdv4CD
Qjf3AjU+Yn7iIWuAIiefLKE1GFDOEdIJiqumYoKjSXjwvOkVmAXudHBNh4H52DKtcRb+vJq8ecuD
WNOpPTuJ9b9WmkVT2J0Um35mlsq3e3DyJFjngejFxgRmHu9lLALspfKobxB2Ao6yaxPxVFqyQm/L
AEo7/0q6vYkq/qwKVttGWQutURh5HmGAjIzADsjaUSUvpe5CBI5x6AMSnHmTjZGl54UW7pCpLGZ1
7uP0bJJzzbqNu+g2BURdRcYpIhuYz9IxTr/K7+gEmfDpH3N9g3kfeWY27DGHbpLW9lrtdbsKbvR7
3AaQ3T7TTQShHMVjiFQrsnkxIqo0v0jDJMi1dxjn+hNzmGigCESVr8SfMUIqLV/Ntt5ytT2yK8EE
n/YQ2AC2Gc22JMXzLwGHhkiJ6YnLuut9oytPVHrpp9fR94B6V4T5yPGpGOFGiHiOrbnTMtpp4k8I
J3Zb/MzRGWKwOwOAKNIUfTg4X0moG9MLVBfMkVBmwMuDXuwc7E+0bfdXZiX7mDxo6SaDj7/Tpsde
bNnBDdHfCO7LifhHs9DmG/wTuQa6UbUomAeBOvO3Id28IGvL5Iv84urfC0P5Dky83uwSHvRiiTwE
SNM1eow448d/qNFvvWIeX5xo8J9rkrr/+bRyXNJ+IZH0R3n+EYk56pCI+YRqjs7r6qKWRvvzxFby
2PKr3tgXl/d32qSoRaPISgowi6eKgIlavggx2Johs/UkEShapwyxvXzknI8N2omwdG+NySCaViei
7A7ahhdQEEij5bfjZbRKV/bLVjbxwZ+nfA2Cv9KMwKt/5ikh5HxJC/6fSziuYoOgZyW32eF/wHOR
x0ocZOUgG1RQzacPu7P37O6+3mHbuBIRJZcTP43Mt8ASfgpSPNEoBa9uKfljnX0ktZD16jsMvqaH
swiEIDfdTESFn8liHMfLjuoaWmNJotmrX+psqhIZzxJScjahTtF+f1U7xuzDcRXXabBu9Er8vg8S
ATN0TXA8UDyLAwBrbYCbb05qPVgWj8jXLlkuuSrykqreSSqVN+nFViFik7anWdHSwCL6s9PGiIWn
HgEDFWoDTYMC5Ma35BKpH4z9+PEDfCdHHPUMEkcXO58HN3GWYXvG5uVRQGDhehOAz1wbYYuZmU6J
fUWsTUfX5uJ6xTFuWVO4v8rxixJQEMlV7/kOHC7wo8vjoiKLL4MyQDcsjV0NVFqc0+NHh4iFWd2k
qaOBXBDiiszgOyO2gyzhpMoT83Df/WWYZu9CVUDatZcx959QyONhaEngJeacltGlxgYmbwjeM0Ib
6c5h3SepPzhn09zg5Ar7C8Swqhdt6i3TQ9PRPF3zqzzrbmpzgeGao3yXCFRqvLc7f+siIz2zkaTk
7+4VwsblBvtSFqbNnZeBgF8atjiP2nHoyaEGkqMNPoVukJsQep28IhyZbP4lZne0WYb2LXkCZ00T
IpzE8WKFkOC02z4URBXt0q/P/oBZCBFki2w+qf/nFVZttV3/HGVDzT1NVy1OfJfiCcwsGV9HD3Mk
rHDLobfeL6E/Bbo2jAe6WHotFNK23JlkfwkVHp1GY44Cx+rKIg/rucpWhdtpbhiG2CPXgiAfD0GO
Cmieps32Fp1kSZtUBFhEiYVssjHXQfMmFaY57MYRLClhxSHi3dkm65+C58moZZyta31u3qdC56rc
5t0fHvb9FaJSNGGpdVeve1jbNP00qLI4bem8OkrSneQB4q/0gWb1X9+/2ILGa0IPuYXOyeQvhzxk
SEQdY3t29PXhivjlymQOXdCyVFh2SaU06evMrw1vRhgxymyt59rrOXGU4inzkgJ3K07T+kquJi6I
1cP/9PpdUw38xAloPXUDIxXnMReZO6i0oKCixzUhDJYeA26YPlk38ot76vZw0zDXUuNmTb9denIO
G/tKn8aH9DEsGm/8YneCR4kP+6W8S1orHMjAm8NS5DafR8TE20hUbIl384ShUoSQlw/5kQlXwrBM
aBhGq1+lgdSJ9UAGhmZKk2Tnl4zmCFoqDmMb+y97dTaAJcLBQ+8RkAHqdT4Qs734KM1IX1Z3jT9R
2bEfH6dMygQrh/dA5wmwFo3Whzbob2EoNHUClrEFHjICWzsCzV2J+uXkJtu3DdAgJM1eG/4R84J3
aFEl6JUtlgrRq9koe2GkvFalcil9CeNwY6DLnSoy95GggaM+//x9P+B1CvBCAfueRTKmXb2iUSHH
XGaaIZu3ROVMDldGzhu1GUdtqjPPCYFnb696KFd82dejQjEQXweZVySiI5HqQX30FEJ35K1DllsI
1CXH4soYazVhOGVZYWT4aBOOqTx7Dgb2MKX8GrXG90e8Mf6fKtxUK06il4qHTiIWAgzdZNioO2lD
+TE65oJ21h/P3aemL7EnSdepEG2PKvxig+ss4Sqqm1KXeQ9UfZRhxaqAJfdnlOpokijxmUHugKPm
auQsbMn6wMQYfd6JsPkDD5pSxBSLb/3ykap2x75oyALGKpe/AzL6irHJmLsVRWaIqMLxQtxX1DHw
5AjoVRKdixDA0p1nGFMD/8rgQm98XcjCcVQpQIIc2esSOuOerDdIxK4VatfSPuaIfzCuwsTnTpTu
S17eBJzpx2pyja9Jig3p09db2bTr6kWPsoQZv15TC/I9KoWN/rCLHkHswpqI0uKwXaIzB3y1cVXL
RhiKshD/JfWD
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
